// Zancut's own brain: a small model trained FROM SCRATCH on our own labelled sentences (no pretrained model, no outside AI).
// It reads a Bangla/English sentence and predicts what to draw: the place, the action, the face, who is in it.
// Features: words, word pairs, and character 3–5-grams (so Bangla/English word endings generalise) hashed into 2^14 buckets.
// Heads: softmax regression (place, action, face) and sigmoid regression per role. Trained by SGD in pure JS, in well under a second.
// It learns from the seed data (brain/seed.jsonl) and from the owner's approved corrections (data/brain/feedback.jsonl).
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { DATA_DIR } from './config.mjs';

const ROOT = path.join(path.dirname(fileURLToPath(import.meta.url)), '..');
export const NB = 1 << 14;
export const ROLE_IDS = ['boy', 'girl', 'father', 'mother', 'baba', 'teacher'];
export const HEADS = { place: ['none', 'bedroom', 'village_home', 'village_road', 'school_yard', 'classroom', 'city_street', 'park', 'living_room', 'kitchen'], action: ['idle', 'walk', 'run', 'wave', 'cheer', 'clap', 'point', 'sit'], face: ['neutral', 'happy', 'worried', 'sad', 'surprised'] };
export const paths = { seed: path.join(ROOT, 'brain', 'seed.jsonl'), real: path.join(ROOT, 'brain', 'real-test.jsonl'), model: path.join(DATA_DIR, 'brain', 'model.json'), feedback: path.join(DATA_DIR, 'brain', 'feedback.jsonl') };

const fnv = (s) => { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return (h >>> 0) % NB; };
export function feats(text) {
  const words = String(text).normalize('NFC').toLowerCase().match(/[\p{L}\p{M}\p{N}]+/gu) || [], m = new Map(), add = (k, v) => { const i = fnv(k); m.set(i, (m.get(i) || 0) + v); };
  words.forEach((w, i) => { add('w:' + w, 1); if (i) add(`b:${words[i - 1]}_${w}`, 0.7); const p = `^${w}$`; for (let n = 3; n <= 5; n++) for (let j = 0; j + n <= p.length; j++) add('c:' + p.slice(j, j + n), 0.45); });
  add('bias', 1); let z = 0; for (const v of m.values()) z += v * v; z = Math.sqrt(z) || 1; for (const [k, v] of m) m.set(k, v / z); return m;
}
const rng = (seed) => () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 2 ** 32);
const dot = (W, o, f) => { let s = 0; for (const [i, v] of f) s += W[o + i] * v; return s; };
function trainHead(rows, C, { epochs = 30, lr = 0.8, l2 = 1e-5, sigmoid = false, seed = 1 } = {}) { // rows: [{f, y}] y = class index (softmax) or 0/1 (sigmoid, C = 1)
  const W = new Float32Array(C * NB), r = rng(seed), idx = rows.map((_, i) => i);
  for (let e = 0; e < epochs; e++) {
    for (let i = idx.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [idx[i], idx[j]] = [idx[j], idx[i]]; }
    const step = lr / (1 + 0.15 * e);
    for (const k of idx) { const { f, y } = rows[k];
      if (sigmoid) { const p = 1 / (1 + Math.exp(-dot(W, 0, f))), g = p - y; for (const [i, v] of f) W[i] -= step * (g * v + l2 * W[i]); }
      else { const s = Array.from({ length: C }, (_, c) => dot(W, c * NB, f)), mx = Math.max(...s), ex = s.map((x) => Math.exp(x - mx)), z = ex.reduce((a, b) => a + b, 0);
        for (let c = 0; c < C; c++) { const g = ex[c] / z - (c === y ? 1 : 0); for (const [i, v] of f) W[c * NB + i] -= step * (g * v + l2 * W[c * NB + i]); } } }
  }
  return W;
}
const b64 = (a) => Buffer.from(a.buffer, a.byteOffset, a.byteLength).toString('base64'), unb64 = (s) => { const b = Buffer.from(s, 'base64'); return new Float32Array(b.buffer, b.byteOffset, b.byteLength / 4).slice(); };

// examples: [{ text, place?, action?, face?, roles?: [...] }]; a missing label is skipped by that head
export function train(examples, opt = {}) {
  const rows = examples.map((e) => ({ e, f: feats(e.text) })), model = { version: 1, trainedAt: new Date().toISOString(), examples: examples.length, heads: {}, roles: {} };
  for (const [h, classes] of Object.entries(HEADS)) {
    const R = rows.filter(({ e }) => classes.includes(e[h])).map(({ e, f }) => ({ f, y: classes.indexOf(e[h]) }));
    model.heads[h] = { classes, n: R.length, W: b64(R.length ? trainHead(R, classes.length, opt) : new Float32Array(classes.length * NB)) };
  }
  for (const role of ROLE_IDS) { const R = rows.filter(({ e }) => Array.isArray(e.roles)).map(({ e, f }) => ({ f, y: e.roles.includes(role) ? 1 : 0 })); model.roles[role] = { n: R.length, W: b64(R.length ? trainHead(R, 1, { ...opt, sigmoid: true }) : new Float32Array(NB)) }; }
  return model;
}
export const load = (file = paths.model) => { try { const m = JSON.parse(fs.readFileSync(file, 'utf8')); for (const h of Object.values(m.heads)) h.w = unb64(h.W); for (const r of Object.values(m.roles)) r.w = unb64(r.W); return m; } catch { return null; } };
export function save(model, file = paths.model) { fs.mkdirSync(path.dirname(file), { recursive: true }); const { heads, roles, ...rest } = model; fs.writeFileSync(file, JSON.stringify({ ...rest, heads: Object.fromEntries(Object.entries(heads).map(([k, h]) => [k, { classes: h.classes, n: h.n, W: h.W }])), roles: Object.fromEntries(Object.entries(roles).map(([k, r]) => [k, { n: r.n, W: r.W }])) })); }
export function predict(model, text) {
  const f = feats(text), out = { roles: [] };
  for (const [h, hd] of Object.entries(model.heads)) { const C = hd.classes.length, w = hd.w || (hd.w = unb64(hd.W)), s = Array.from({ length: C }, (_, c) => dot(w, c * NB, f)), mx = Math.max(...s), ex = s.map((x) => Math.exp(x - mx)), z = ex.reduce((a, b) => a + b, 0), k = ex.indexOf(Math.max(...ex)); out[h] = { label: hd.classes[k], conf: ex[k] / z }; }
  for (const [role, r] of Object.entries(model.roles)) { const w = r.w || (r.w = unb64(r.W)); out.roles.push({ id: role, p: 1 / (1 + Math.exp(-dot(w, 0, f))) }); }
  return out;
}
export const readJsonl = (file) => { try { return fs.readFileSync(file, 'utf8').split('\n').filter(Boolean).map((l) => JSON.parse(l)); } catch { return []; } };
export const allExamples = () => [...readJsonl(paths.seed), ...readJsonl(paths.feedback)];
export function evaluate(model, tests) {
  const acc = {}, roles = { tp: 0, fp: 0, fn: 0 };
  for (const h of Object.keys(HEADS)) { const T = tests.filter((e) => HEADS[h].includes(e[h])); acc[h] = { n: T.length, acc: T.length ? T.filter((e) => predict(model, e.text)[h].label === e[h]).length / T.length : null }; }
  for (const e of tests.filter((x) => Array.isArray(x.roles))) { const got = new Set(predict(model, e.text).roles.filter((r) => r.p > 0.5).map((r) => r.id)), want = new Set(e.roles); for (const r of ROLE_IDS) { if (got.has(r) && want.has(r)) roles.tp++; else if (got.has(r)) roles.fp++; else if (want.has(r)) roles.fn++; } }
  acc.roles = { f1: roles.tp ? (2 * roles.tp) / (2 * roles.tp + roles.fp + roles.fn) : 0, ...roles };
  return acc;
}
// the owner's approved shot → one more training example (what this sentence turned into)
export function learn(example) { fs.mkdirSync(path.dirname(paths.feedback), { recursive: true }); fs.appendFileSync(paths.feedback, JSON.stringify({ ...example, source: 'feedback', at: Date.now() }) + '\n'); }
