// Quality loop, no model: deterministic checks on a scene file, each issue with evidence and a bounded repair.
// Repairs only touch allowlisted fields (people x / to, shot at) and are re-checked; a repair that does not clear its issue is rolled back.
import { validate } from './codefilm.mjs';

export const LIMITS = { halfWidth: 2.8, minShot: 0.8, minGap: 0.7 }; // metres visible either side of the middle at the floor line; seconds; metres between two people
const clone = (x) => JSON.parse(JSON.stringify(x));

export function check(film, { duration = 0 } = {}) {
  const issues = [], shots = [...film.shots].map((s, i) => ({ s, i })).sort((a, b) => a.s.at - b.s.at);
  for (const e of validate(film)) issues.push({ category: 'missing-asset', severity: 'error', shot: null, evidence: e, repair: null });
  shots.forEach(({ s, i }, k) => {
    const end = k + 1 < shots.length ? shots[k + 1].s.at : duration || s.at + 3, len = end - s.at;
    if (len < LIMITS.minShot) issues.push({ category: 'timing', severity: 'warn', shot: i, t: s.at, evidence: `shot ${i + 1} lasts ${len.toFixed(2)} s (minimum ${LIMITS.minShot} s)`, repair: { kind: 'shot-at', shot: i, value: Math.round((end - LIMITS.minShot) * 100) / 100 } });
    (s.people || []).forEach((p, j) => {
      const xs = ['walk', 'run'].includes(p.do) ? [p.x, p.to ?? p.x] : [p.x];
      xs.forEach((x, w) => { if (Math.abs(x) > LIMITS.halfWidth) issues.push({ category: 'out-of-frame', severity: 'error', shot: i, t: s.at, evidence: `${p.who} stands at x=${x} m in shot ${i + 1}; the frame shows only ±${LIMITS.halfWidth} m`, repair: { kind: w === 0 ? 'person-x' : 'person-to', shot: i, person: j, value: Math.sign(x) * LIMITS.halfWidth * 0.85 } }); });
      if (p.dz != null && (p.dz < 0 || p.dz > 8)) issues.push({ category: 'grounding', severity: 'error', shot: i, t: s.at, evidence: `${p.who} has depth dz=${p.dz} (the floor runs 0–8 m): not on the ground`, repair: { kind: 'person-dz', shot: i, person: j, value: Math.min(8, Math.max(0, p.dz)) } });
    });
    const ps = s.people || [];
    for (let a = 0; a < ps.length; a++) for (let b = a + 1; b < ps.length; b++) if (Math.abs((ps[a].x ?? 0) - (ps[b].x ?? 0)) < LIMITS.minGap && Math.abs((ps[a].dz ?? 1) - (ps[b].dz ?? 1)) < 0.4)
      issues.push({ category: 'overlap', severity: 'warn', shot: i, t: s.at, evidence: `${ps[a].who} and ${ps[b].who} stand ${Math.abs(ps[a].x - ps[b].x).toFixed(2)} m apart in shot ${i + 1}`, repair: { kind: 'person-x', shot: i, person: b, value: (ps[a].x ?? 0) + (ps[b].x >= ps[a].x ? 1 : -1) * 1.2 } });
  });
  if (duration && shots.length && shots[0].s.at > 0.05) issues.push({ category: 'timing', severity: 'warn', shot: shots[0].i, t: 0, evidence: `nothing is shown from 0 s to ${shots[0].s.at} s`, repair: { kind: 'shot-at', shot: shots[0].i, value: 0 } });
  return issues;
}
export function applyRepair(film, r) {
  const f = clone(film), s = f.shots[r.shot]; if (!s) return f;
  if (r.kind === 'shot-at') s.at = r.value;
  else { const p = s.people?.[r.person]; if (!p) return f; if (r.kind === 'person-x') p.x = r.value; if (r.kind === 'person-to') p.to = r.value; if (r.kind === 'person-dz') p.dz = r.value; }
  return f;
}
// repair each repairable issue; keep a repair only if its own issue is gone and no new error appeared
export function repair(film, opts = {}) {
  let cur = film, before = check(cur, opts); const log = [];
  for (const iss of before.filter((i) => i.repair)) {
    const next = applyRepair(cur, iss.repair), after = check(next, opts), sig = (i) => `${i.category}|${i.shot}|${i.evidence.slice(0, 24)}`;
    const cleared = !after.some((a) => a.category === iss.category && a.shot === iss.shot && a.evidence.split(' ')[0] === iss.evidence.split(' ')[0]);
    const worse = after.filter((a) => a.severity === 'error').length > check(cur, opts).filter((a) => a.severity === 'error').length;
    if (cleared && !worse) { log.push({ issue: iss.evidence, repair: iss.repair, result: 'applied' }); cur = next; } else log.push({ issue: iss.evidence, repair: iss.repair, result: 'rolled back' });
  }
  return { film: cur, log, remaining: check(cur, opts) };
}
