// The planner built on Zancut's own brain (server/brain.mjs): script → scene file. No outside AI.
// The brain chooses meaning per sentence (place, action, face, who); code does geometry and timing; qa.mjs checks the result.
import { load, save, train, predict, allExamples, learn, ROLE_IDS, HEADS } from './brain.mjs';
import { sentences, filmFromPlan, planFromScript } from './scriptplan.mjs';
import { check } from './qa.mjs';

let MODEL = null;
export function brain() { MODEL ||= load(); if (!MODEL) { MODEL = train(allExamples()); save(MODEL); } return MODEL; }
export function retrain() { MODEL = train(allExamples()); save(MODEL); return { examples: MODEL.examples, trainedAt: MODEL.trainedAt }; }
export const brainInfo = () => { const m = brain(); return { examples: m.examples, trainedAt: m.trainedAt, heads: Object.fromEntries(Object.entries(m.heads).map(([k, h]) => [k, h.n])) }; };
const COMMON = new Set('stage level model language large small like you will what this that there here then when where who why how first second third last next some many much more most very just also only even still again ever never always now today tomorrow yesterday morning evening night day week year time people person thing things world life school road home house city village water food money work game story chapter part'.split(' '));
const STOP = new Set('The A An On In At He She They It His Her Their Then When After Before Suddenly One Every This That There But And So As If We I You Today Once Later Soon Finally Morning'.split(' '));

export function planFromBrain(text, { duration = 0, title = '', timed = null } = {}) {
  const sents = timed ? timed.map((x) => x.text) : sentences(text); if (!sents.length) throw Object.assign(new Error('Paste the story script first.'), { customer: true });
  const m = brain(), chars = [], seen = new Set(), notes = [], shots = [], original = [];
  // a capitalised word is a NAME only if it comes back (2+ sentences) and is not a common word; at most 4 names, the most frequent
  const cnt = new Map(); sents.forEach((s) => { for (const n of new Set([...s.matchAll(/\b([A-Z][a-z]{2,})\b/g)].map((x) => x[1]))) if (!STOP.has(n) && !COMMON.has(n.toLowerCase())) cnt.set(n, (cnt.get(n) || 0) + 1); });
  const NAMES = new Set([...cnt].filter(([, c]) => c >= 2).sort((a, b) => b[1] - a[1]).slice(0, 4).map(([n]) => n));
  const addChar = (id, role) => { if (!seen.has(id)) { seen.add(id); chars.push({ id, role }); } };
  let place = 'village_home', last = [], hero = null;
  sents.forEach((s, i) => {
    const pr = predict(m, s), here = [];
    // names written with a capital (Latin script); roles from the brain
    for (const x of s.matchAll(/\b([A-Z][a-z]{2,})\b/g)) { const n = x[1]; if (!NAMES.has(n)) continue; const id = n.toLowerCase(); addChar(id, 'boy'); if (!here.includes(id)) here.push(id); hero ||= id; }
    for (const r of pr.roles.filter((r) => r.p > 0.5).sort((a, b) => b.p - a.p)) { const id = ROLE_IDS.includes(r.id) ? r.id : 'boy'; if (id === 'boy' && here.length && /[A-Z][a-z]{2,}/.test(s)) continue; addChar(id, id); if (!here.includes(id)) here.push(id); hero ||= id; }
    if (!here.length && /\b(he|she|his|her|him)\b|সে|তার|তাকে/i.test(s) && last.length) here.push(...last);
    if (!here.length && hero) here.push(hero);
    if (!here.length) { addChar('hero', 'boy'); hero = 'hero'; here.push('hero'); notes.push(`Sentence ${i + 1}: nobody named; used a boy called "hero". Rename the cast in the storyboard.`); }
    last = here;
    const pl = pr.place.label !== 'none' && pr.place.conf >= 0.45 ? pr.place.label : null; if (pl) place = pl; else if (i === 0) notes.push('Sentence 1 names no place: started at the village home.');
    const act = pr.action.conf >= 0.4 ? pr.action.label : 'idle', face = pr.face.conf >= 0.4 ? pr.face.label : 'neutral';
    shots.push({ sentence: i + 1, place, people: here.slice(0, 3).map((who, k) => ({ who, do: k === 0 ? act : 'idle', face })) });
    original.push({ place, action: act, face, conf: { place: +pr.place.conf.toFixed(2), action: +pr.action.conf.toFixed(2), face: +pr.face.conf.toFixed(2) } });
  });
  const film = filmFromPlan(sents, { characters: chars, shots }, { duration, title, starts: timed ? timed.map((x) => x.at) : null });
  film.plan.mode = `Zancut brain (own model, ${m.examples} examples)`; film.plan.original = original; film.plan.notes = [...notes, ...check(film, { duration }).filter((i) => i.severity === 'error').map((i) => i.evidence)];
  film.plan.roles = Object.fromEntries(chars.map((c) => [c.id.replace(/[^a-z0-9_]/g, ''), c.role]));
  if (!film.shots.length) return planFromScript(text, { duration, title });
  return film;
}

// What the owner corrected or approved becomes training data. changedOnly: only shots that differ from what the brain proposed.
export function teachFromFilm(film, { changedOnly = true } = {}) {
  const S = film.plan?.sentences || [], O = film.plan?.original || []; let n = 0;
  const done = new Set();
  for (const shot of film.shots || []) {
    if (!(shot.people || []).length) continue; // a place shot says nothing about who does what
    const i = shot.sentence ? shot.sentence - 1 : S.findIndex((x) => Math.abs(x.at - shot.at) < 0.011); if (i < 0 || !S[i] || done.has(i)) continue; done.add(i);
    const ppl = shot.people || [], actor = ppl.find((p) => p.do && p.do !== 'idle') || ppl[0] || {}, faced = ppl.find((p) => p.face && p.face !== 'neutral') || {};
    const ex = { text: S[i].text, place: shot.place, action: HEADS.action.includes(actor.do) ? actor.do : null, face: faced.face || 'neutral' };
    const was = O[i]; if (changedOnly && was && was.place === ex.place && was.action === (ex.action || 'idle') && was.face === ex.face) continue;
    // roles are NOT learned from a storyboard (the hero stays in every shot, so who is in a shot says little about the sentence)
    if (!HEADS.place.includes(ex.place)) continue; if (!ex.action) delete ex.action; learn(ex); n++;
  }
  return n;
}

// the voice's words (from the transcript) → sentences with their start second (a full stop / । / ? / ! or a pause over 0.7 s ends one)
export function sentencesFromWords(words) {
  const out = []; let cur = null;
  words.forEach((w, i) => { const t = String(w.text ?? w.word ?? '').trim(); if (!t) return; if (!cur) cur = { text: '', at: Math.max(0, (w.start ?? 0) - 0.1) }; cur.text = `${cur.text} ${t}`.trim();
    const nx = words[i + 1]; if (/[.!?।]$/.test(t) || !nx || (nx.start ?? 0) - (w.end ?? 0) > 0.7) { out.push(cur); cur = null; } });
  if (out[0]) out[0].at = 0; return out;
}
