// Zancut 2D, no AI: the scene file (film.json) + the voice's words → the storyboard, the shots and the plan, all by code.
// The engine (engine/cartoon) and the library draw; this file only turns the scene file into scene scripts.
//
// film.json:
// { "title": "…",
//   "cast":  { "rafi": { "gender": "male", "age": "child", "skin": 3, "hair": {"style":"crop","color":"black"}, "outfit": {"type":"tshirt","color":"#e0862b"} } },
//   "shots": [ { "at": 0,                     // second the shot starts (the voice is the clock); the next shot's "at" ends it
//                "place": "village_road", "view": "wide",
//                "people": [ { "who": "rafi", "x": -2, "dz": 1, "do": "walk", "to": 2, "face": "happy", "facing": 1, "speaks": false } ],
//                "camera": { "on": "rafi", "frame": "medium" }   // optional; default = the whole place
//            } ] }
// "do": idle · walk · run · wave · cheer · clap · point · sit · or any id from engine/cartoon/library/actions (looped or stretched).
import fs from 'node:fs';
import path from 'node:path';
import { ENGINE_DIR } from './config.mjs';
import { firstCutWords, jobDir, tidyStoryboard, buildPlan, placeGraphic, writeGraphic } from './director.mjs';

const J = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const lib = (kind, id) => J(path.join(ENGINE_DIR, 'cartoon', 'library', kind, `${id}.json`));
const BASIC = { idle: (t) => `ZC.idle(${t})`, stand: () => 'ZC.stand()', walk: (t) => `ZC.walk(${t} / 1.1)`, run: (t) => `ZC.run(${t} / 0.55)`, wave: (t) => `ZC.wave(${t})`, cheer: (t) => `ZC.cheer(${t})`, clap: (t) => `ZC.clap(${t})`, point: () => 'ZC.point()', sit: () => 'ZC.sit()' };
const MOVING = new Set(['walk', 'run']);
export const BASIC_ACTIONS = Object.keys(BASIC);
const q = (x) => JSON.stringify(x);
const num = (x, d = 0) => (Number.isFinite(+x) ? +x : d);

export function validate(film) {
  const errs = [];
  if (!film || typeof film !== 'object') return ['The scene file must be a JSON object.'];
  if (!film.cast || !Object.keys(film.cast).length) errs.push('"cast" needs at least one person.');
  if (!Array.isArray(film.shots) || !film.shots.length) errs.push('"shots" needs at least one shot.');
  const places = [...fs.readFileSync(path.join(ENGINE_DIR, 'cartoon', 'places-kit.js'), 'utf8').matchAll(/ZF\.place\("(\w+)"/g)].map((m) => m[1]);
  (film.shots || []).forEach((s, i) => {
    if (!places.includes(s.place)) errs.push(`Shot ${i + 1}: place "${s.place}" is not ready. Ready places: ${places.join(', ')}.`);
    for (const p of s.people || []) {
      if (!film.cast?.[p.who]) errs.push(`Shot ${i + 1}: "${p.who}" is not in the cast.`);
      if (p.do && !BASIC[p.do] && !lib('actions', p.do)) errs.push(`Shot ${i + 1}: action "${p.do}" is not in the library.`);
    }
  });
  return errs;
}
export const placeIds = () => [...fs.readFileSync(path.join(ENGINE_DIR, 'cartoon', 'places-kit.js'), 'utf8').matchAll(/ZF\.place\("(\w+)"/g)].map((m) => m[1]);

// one shot → the scene script (runs after ZK.unit(root); tl, root, s, d, words are given).
// camera.kind (learned from the reference films: mostly medium and close shots, a place shot at a scene change, two-shots for pairs):
//   establish = the place alone, slow pan · wide = the whole place · two = the first two people framed together · single = one person, knees up
//   close = one person waist-up (the waist-up rig, never a zoomed full body) · default: wide
const NIGHT = `\nZC.el("rect", { x: -W.w, y: -W.h, width: W.w * 3, height: W.h * 3, fill: "#0d1a3d", opacity: 0.42 }, W.layer("front")); ZS.moon(W.layer("sky"), { x: W.w * 0.8, y: W.h * 0.14, r: 46 });`;
const HANDS = { wave: 'wave', cheer: 'cheer', clap: 'clap', point: 'point' };
// the reference films are almost never still (2–8 % of the time): someone standing "idle" acts a small library gesture once in
// the shot, chosen by their face, instead of only breathing
const SAFE = (() => { try { return JSON.parse(fs.readFileSync(path.join(ENGINE_DIR, '..', 'brain', 'gestures-gate.json'), 'utf8')).ok; } catch { return null; } })(); // gestures the body gate passed on a standing person (scripts/gesture-sweep.mjs)
const IDLE_GESTURES = { neutral: ['check_watch', 'ask_what_why', 'hand_on_chest', 'look_at_phone'], happy: ['thumbs_up', 'hug_open_arms', 'hand_on_chest'], worried: ['check_watch', 'ask_what_why', 'hand_on_chest'], sad: ['hand_on_chest', 'munajat'], surprised: ['ask_what_why', 'hug_open_arms'] };
const gestureFor = (p, seed) => { const list = (IDLE_GESTURES[p.face] || IDLE_GESTURES.neutral).filter((g) => lib('gestures', g) && (SAFE ? SAFE.includes(g) : ['check_watch', 'thumbs_up', 'hand_on_chest'].includes(g))); return list.length ? list[seed % list.length] : null; };
export function shotScript(shot, film) {
  const kind = shot.camera?.kind || (shot.camera?.on ? 'single' : 'wide'), people = kind === 'establish' ? [] : shot.people || [];
  const focusIdx = Math.max(0, people.findIndex((p) => p.who === shot.camera?.on));
  if (kind === 'close' && people.length) {
    const p = people[focusIdx], facing = num(p.facing, 1) < 0 ? -1 : 1, act = HANDS[p.do] || 'rest';
    return `const W = ZC.world(root), P = ZC.place(${q(shot.place)}, W, { view: ${q(shot.view || 'wide')}, blur: 5 });${shot.night ? NIGHT : ''}
const S = W.h / 1080, r = ZC.person(W.layer("front"), { spec: ZF.cast[${q(p.who)}], x: W.w * ${(0.5 - 0.16 * facing).toFixed(2)}, y: W.h * 0.46, scale: 1.45 * S });
ZC.clock(tl, s, d, (t) => {
    P.tick(t); W.cam(W.w / 2, W.h / 2, W.w * 0.82 - t * 6);
    r.draw({ face: ${q(p.face || 'neutral')}, hands: ${q(act)}, turn: ${(0.35 * facing).toFixed(2)}, look: ${(0.3 * facing).toFixed(2)}${p.speaks ? ', mouth: ZC.mouth(t + s, words)' : ''} }, t);
});`;
  }
  const ids = people.map((_, i) => `a${i}`);
  const setup = people.map((p, i) => `{ const at = P.Z.person(ZF.cast[${q(p.who)}], { x: ${num(p.x)} * K, dz: ${num(p.dz, 1)}, layer: P.layer }); ${ids[i]} = ZC.actor(at.slot, { spec: ZF.cast[${q(p.who)}], ...at, view: ${q(p.view || 'side')}, facing: ${num(p.facing, 1) < 0 ? -1 : 1} }); }`).join('\n');
  const draw = people.map((p, i) => {
    const act = p.do || 'idle', moving = MOVING.has(act), to = p.to != null ? num(p.to) : num(p.x);
    const posOf = `P.Z.at((${moving ? `${num(p.x)} + (${to} - ${num(p.x)}) * Math.min(1, t / Math.max(0.5, d - 0.2))` : num(p.x)}) * K, ${num(p.dz, 1)})`;
    let pose; const gest = act === 'idle' && p.gesture !== false ? (typeof p.gesture === 'string' ? p.gesture : gestureFor(p, i + Math.round(num(shot.at) * 10))) : null;
    if (gest) { // blended in and out over 0.3 s (the body gate refuses a pose that jumps between frames)
      const g = lib('gestures', gest), secs = +(num(g?.seconds, 1.6) * 1.35).toFixed(2), X = ids[i], br = `((t / 3.6) % 1) * 360`;
      pose = `(d < ${secs} + 0.9) ? ZC.idle(t) : (() => { const t0 = Math.min(d * 0.25, Math.max(0.5, d - ${secs} - 0.4)), I = ${X}.pose("stand", ${br}), G = ${X}.pose("stand", ${br}, { gesture: { id: ${q(gest)}, phase: (() => { const per = ${secs} + 2.2, e = Math.max(0, t - t0), k = Math.floor(e / per), u = Math.max(0, Math.min(1, (e % per) / ${secs})); return (k % 2 ? 1 - u : u) * 360; })() } }); /* forward, hold, backward: never a jump */ return ${X}.blend(I, G, ZC.keys(t, [[t0 - 0.5, 0], [t0, 1]])); })()`; } // the gesture ends where it began: held, not blended out
    else if (BASIC[act]) pose = BASIC[act]('t');
    else { const a = lib('actions', act) || {}, secs = num(a.seconds, 2); pose = `${ids[i]}.pose(${q(act)}, ${a.loop ? `((t / ${secs}) % 1) * 360` : `Math.min(1, t / Math.max(0.3, Math.min(d, ${secs}))) * 360`})`; }
    const facing = num(p.facing, moving && to < num(p.x) ? -1 : 1) < 0 ? -1 : 1;
    const face = p.face ? `, face: ${q(p.face)}` : '', mouth = p.speaks ? ', mouth: ZC.mouth(t + s, words)' : '';
    return `{ const at = ${posOf}; ${ids[i]}.draw(${pose}, { x: at.x, floor: at.y, facing: ${facing}${face}${mouth} }); }`;
  }).join('\n    ');
  let cam = 'W.cam(W.w / 2, W.h / 2, W.w);';
  if (kind === 'establish') cam = 'W.cam(W.w / 2 - W.w * 0.06 + t * W.w * 0.03, W.h / 2, W.w * 0.92);';
  else if (kind === 'two' && ids.length >= 2) cam = `ZC.twoShot(W, a0, a1, "full");`;
  else if (kind === 'single' && ids.length) { const f = num(people[focusIdx]?.facing, 1) < 0 ? -1 : 1; cam = `ZC.frame(W, ${ids[focusIdx]}, ${q(shot.camera?.frame || 'mediumWide')}, { x: ${f > 0 ? 0.42 : 0.58} });`; } // the face a little off centre, room in front of it (not pushed to the frame edge)
  return `const W = ZC.world(root), P = ZC.place(${q(shot.place)}, W, { view: ${q(shot.view || 'wide')} });${shot.night ? NIGHT : ''}
const K = Math.min(1, (W.w / W.h) / 0.6 / 2.8); // positions are written for 16:9 (±2.8 m); a narrower frame squeezes them in
let ${ids.join(', ') || '_n'};
${setup}
ZC.clock(tl, s, d, (t) => {
    P.tick(t);
    ${draw}
    ${cam}
});`;
}

// the film's kit: its cast + the ready places
export function kitFor(film) {
  return `ZF.cast = ${JSON.stringify(film.cast)};\n${fs.readFileSync(path.join(ENGINE_DIR, 'cartoon', 'places-kit.js'), 'utf8')}`;
}

export async function build(d, p, film, { step = () => {} } = {}) {
  const errs = validate(film); if (errs.length) throw Object.assign(new Error(errs.join(' ')), { customer: true });
  const J0 = jobDir(d.ws), words = firstCutWords(J0);
  if (!words.length) throw Object.assign(new Error('The voice has no words yet.'), { customer: true });
  step('Turning the scene file into shots (no AI)');
  const shots = [...film.shots].sort((a, b) => num(a.at) - num(b.at));
  const first = shots.map((s) => { const k = words.findIndex((w) => (w.start ?? w.t ?? 0) >= num(s.at) - 0.05); return k < 0 ? words.length - 1 : k; });
  const rows = shots.map((s, i) => ({ from: i === 0 ? 0 : first[i], to: i + 1 < shots.length ? Math.max(first[i], first[i + 1] - 1) : words.length - 1, piece: 'custom', say: words.slice(first[i], (first[i + 1] ?? words.length)).map((w) => w.text).join(' '), idea: s.place, transition: 'cut', archetype: 1, bgStage: 'none' }));
  const sb = tidyStoryboard(p, { video: { mood: 'calm' }, rows, film: { cast: Object.entries(film.cast).map(([id, spec]) => ({ id, spec })) } }, words.length);
  if (!sb) throw new Error('No shots could be placed on the voice.');
  fs.mkdirSync(path.join(J0, 'edit'), { recursive: true }); fs.mkdirSync(path.join(J0, 'work'), { recursive: true });
  fs.writeFileSync(path.join(J0, 'edit', 'film-kit.js'), kitFor(film));
  fs.writeFileSync(path.join(J0, 'work', 'storyboard.json'), JSON.stringify(sb, null, 1));
  step('Cutting the voice and planning the timeline');
  await buildPlan(d, p, sb, { step, ask: async () => null, runQuery: null });
  setMusic(J0, film);
  sb.rows.forEach((r, i) => {
    const shot = shots[i] || shots.at(-1), secs = Math.max(0.5, (words[r.to]?.end ?? 0) - (words[r.from]?.start ?? 0));
    const html = `<script>\nZK.unit(root);\n${shotScript(shot, film)}\n</script>\n<!--cues []-->`;
    const w = writeGraphic(J0, `s${i + 1}`, html); if (w.error) throw new Error(`Shot ${i + 1}: ${w.error}`);
    placeGraphic(d, p, sb, i, w.rel, secs);
  });
  step(`Drew ${sb.rows.length} shot${sb.rows.length > 1 ? 's' : ''} from the library`);
  return sb;
}

// a music bed under the whole film (the reference cartoons are never silent): the mood from the film's faces and actions, one track
// chosen by the title so a film keeps its track; ducked under the voice by finalize.mjs. CC BY tracks carry their credit line.
export function setMusic(J0, film) {
  const cat = J(path.join(ENGINE_DIR, '..', 'assets', 'music', 'catalog.json'), null); if (!cat || film.music === false) return null;
  const all = (film.shots || []).flatMap((s) => s.people || []), n = (f) => all.filter(f).length;
  const sad = n((p) => ['sad', 'worried'].includes(p.face)), joy = n((p) => p.face === 'happy' || ['cheer', 'clap', 'wave', 'run'].includes(p.do));
  const mood = film.mood || (sad > joy ? 'emotional' : joy >= 3 ? 'funny' : 'acoustic');
  const have = cat.items.filter((x) => x.mood === mood && fs.existsSync(path.join(ENGINE_DIR, '..', 'assets', x.file)));
  const list = have.length ? have : cat.items.filter((x) => fs.existsSync(path.join(ENGINE_DIR, '..', 'assets', x.file))); if (!list.length) return null;
  let h = 0; for (const c of String(film.title || 'film')) h = (h * 31 + c.charCodeAt(0)) >>> 0;
  const t = list[h % list.length], pf = path.join(J0, 'edit', 'plan.json'), plan = J(pf, {});
  plan.music = { src: path.join(ENGINE_DIR, '..', 'assets', t.file), volume: 0.14, mood, title: t.title, credit: t.credit || '', license: t.license };
  fs.writeFileSync(pf, JSON.stringify(plan, null, 1)); return plan.music;
}
