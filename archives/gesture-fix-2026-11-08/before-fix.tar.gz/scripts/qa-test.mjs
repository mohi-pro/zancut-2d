// Seeded defects: a person outside the frame, two people on one spot, a shot that is too short. Finds them, repairs them, proves the result.
// Usage: node scripts/qa-test.mjs   (writes docs/evidence/qa/{before,after}.film.json + report.json; render the two with codefilm-test.mjs)
import fs from "node:fs";
import path from "node:path";
import assert from "node:assert/strict";
import { check, repair } from "../server/qa.mjs";
const root = path.resolve(path.dirname(new URL(import.meta.url).pathname), "..");
const film = JSON.parse(fs.readFileSync(path.join(root, "examples/rafi.film.json"), "utf8"));
assert.equal(check(film, { duration: 10 }).filter((i) => i.severity === "error").length, 0, "the clean example has no errors");
const bad = JSON.parse(JSON.stringify(film));
bad.shots[1].people[0].x = -6.5;            // seeded 1: outside the frame
bad.shots[2].people[1].x = -1.0;            // seeded 2: on top of Rafi (x -1.2)
bad.shots[3].at = 9.8;                      // seeded 3: a 0.2 s shot
const issues = check(bad, { duration: 10 });
const cats = new Set(issues.map((i) => i.category)); for (const c of ["out-of-frame", "overlap", "timing"]) assert.ok(cats.has(c), `finds ${c}`);
const r = repair(bad, { duration: 10 });
assert.equal(r.remaining.length, 0, "after repair nothing remains: " + JSON.stringify(r.remaining));
// a repair that cannot clear its issue is rolled back (unknown place has no repair)
const worse = JSON.parse(JSON.stringify(bad)); worse.shots[0].place = "moon"; const w = repair(worse, { duration: 10 });
assert.ok(w.remaining.some((i) => i.category === "missing-asset"), "a missing place is reported, never invented");
const out = path.join(root, "docs/evidence/qa"); fs.mkdirSync(out, { recursive: true });
fs.writeFileSync(path.join(out, "before.film.json"), JSON.stringify(bad, null, 1)); fs.writeFileSync(path.join(out, "after.film.json"), JSON.stringify(r.film, null, 1));
fs.writeFileSync(path.join(out, "report.json"), JSON.stringify({ found: issues.map(({ repair, ...i }) => i), repairs: r.log, remaining: r.remaining }, null, 1));
console.log(`qa test passed: ${issues.length} issues found, ${r.log.filter((x) => x.result === "applied").length} repaired, 0 remaining`);
issues.forEach((i) => console.log(` - [${i.category}] frame time ${i.t}s: ${i.evidence}`));
