// Every library gesture on a standing child and an adult, through the body gate → brain/gestures-gate.json { ok: [...], jumps: {...} }.
// Only gestures in "ok" are used automatically by codefilm.mjs. Usage: node scripts/gesture-sweep.mjs   (~20 s per gesture)
import fs from "node:fs";
import { execFileSync } from "node:child_process";
const ids = fs.readdirSync(new URL("../engine/cartoon/library/gestures/", import.meta.url)).filter((f) => f.endsWith(".json")).map((f) => f.slice(0, -5));
const cast = { a: { gender: "male", age: "child", skin: 3, hair: { style: "crop", color: "black" }, outfit: { type: "tshirt", color: "#e0862b" } }, b: { gender: "female", age: "adult", skin: 3, hair: { style: "hijab", color: "#6d4aa8" }, outfit: { type: "abaya", color: "#3a3556" } } };
const res = { at: new Date().toISOString(), ok: [], jumps: {} }, tmp = "/tmp/z2d-gesture.film.json";
for (const g of ids) {
  fs.writeFileSync(tmp, JSON.stringify({ cast, shots: [{ at: 0, place: "village_home", camera: { kind: "two" }, people: [{ who: "a", x: -0.9, dz: 1, do: "idle", gesture: g }, { who: "b", x: 0.9, dz: 1, do: "idle", facing: -1, gesture: g }] }] }));
  let out = ""; try { out = execFileSync(process.execPath, ["scripts/codefilm-test.mjs", tmp, "/tmp/z2d-gesture"], { env: { ...process.env, SHOT_SECS: "4" }, encoding: "utf8" }); } catch (e) { out = String(e.stdout || "") + String(e.stderr || ""); }
  const n = (out.match(/H13/g) || []).length; if (n === 0 && /body gate: ok/.test(out)) res.ok.push(g); else res.jumps[g] = n || "error";
  console.log(g, n === 0 ? "ok" : `jumps ${n}`);
  fs.writeFileSync(new URL("../brain/gestures-gate.json", import.meta.url), JSON.stringify(res, null, 1));
}
