// Train Zancut's own brain from scratch and measure it honestly.
//   1. held-out phrases: trained without phrase variant 4, tested on sentences that use it (never seen words/endings)
//   2. real sentences (brain/real-test.jsonl, hand-labelled, never trained on)
//   3. the old rules planner on the same real sentences, for comparison
//   4. final model = seed + the owner's approved feedback → data/brain/model.json
// Usage: node scripts/brain-train.mjs
import fs from "node:fs";
import { train, evaluate, readJsonl, save, paths, predict, allExamples, HEADS } from "../server/brain.mjs";
import { planFromScript } from "../server/scriptplan.mjs";
const seed = readJsonl(paths.seed), real = readJsonl(paths.real), fb = readJsonl(paths.feedback);
const has4 = (e) => (e.v || []).includes(4), trainSet = seed.filter((e) => !has4(e)), testSet = seed.filter(has4);
let t = Date.now(); const m1 = train(trainSet), ms = Date.now() - t;
const held = evaluate(m1, testSet), onReal = evaluate(m1, real);
// the rules planner, sentence by sentence
const ROLEMAP = { boy: "boy", girl: "girl", father: "father", mother: "mother", baba: "baba", teacher: "teacher" };
const rules = { place: [0, 0], action: [0, 0], face: [0, 0], roles: { tp: 0, fp: 0, fn: 0 } };
for (const e of real) { let f; try { f = planFromScript(e.text, { duration: 3 }); } catch { continue; } const s = f.shots[0], p = s.people[0] || {};
  if (e.place !== "none") { rules.place[1]++; if (s.place === e.place) rules.place[0]++; }
  rules.action[1]++; if ((p.do || "idle") === e.action) rules.action[0]++; rules.face[1]++; if ((p.face || "neutral") === e.face) rules.face[0]++;
  const got = new Set(Object.keys(f.cast).filter((k) => ROLEMAP[k])), want = new Set(e.roles); for (const r of Object.keys(ROLEMAP)) { if (got.has(r) && want.has(r)) rules.roles.tp++; else if (got.has(r)) rules.roles.fp++; else if (want.has(r)) rules.roles.fn++; } }
const f1 = (x) => (x.tp ? (2 * x.tp) / (2 * x.tp + x.fp + x.fn) : 0), pc = (a) => `${(100 * a).toFixed(0)}%`;
const brainPlaceReal = (() => { const T = real.filter((e) => e.place !== "none"); return T.filter((e) => predict(m1, e.text).place.label === e.place).length / T.length; })();
const rows = [["place", held.place.acc, onReal.place.acc, brainPlaceReal, rules.place[0] / rules.place[1]], ["action", held.action.acc, onReal.action.acc, onReal.action.acc, rules.action[0] / rules.action[1]], ["face", held.face.acc, onReal.face.acc, onReal.face.acc, rules.face[0] / rules.face[1]]];
console.log("head     held-out phrases | real sentences | rules baseline (real)");
for (const [h, a, b, , c] of rows) console.log(`${h.padEnd(8)} ${pc(a).padStart(8)}         ${pc(b).padStart(8)}        ${pc(c).padStart(8)}`);
console.log(`roles F1 ${pc(held.roles.f1).padStart(8)}         ${pc(onReal.roles.f1).padStart(8)}        ${pc(f1(rules.roles)).padStart(8)}`);
t = Date.now(); const final = train(allExamples()); const ms2 = Date.now() - t; save(final);
console.log(`final model: ${final.examples} examples (${fb.length} from your approved corrections) trained in ${ms2} ms → ${paths.model}`);
const md = `# MODEL EVAL — Zancut's own brain (trained from scratch, no pretrained model)
Run \`node scripts/brain-train.mjs\`. Last run: ${new Date().toISOString()}.
**What it is:** hashed word + character n-gram features → softmax/sigmoid regression, pure JS, trained on our own labelled sentences (brain/seed.jsonl, ${seed.length} generated rows, Bangla + English) plus the owner's approved corrections (${fb.length} so far). Training time ${ms} ms. It predicts, per sentence: place, action, face, who is in it.
| head | held-out phrases (n=${testSet.length}) | real sentences (n=${real.length}) | old rules planner (real) |
|---|---|---|---|
${rows.map(([h, a, b, , c]) => `| ${h} | ${pc(a)} | ${pc(b)} | ${pc(c)} |`).join("\n")}
| roles (F1) | ${pc(held.roles.f1)} | ${pc(onReal.roles.f1)} | ${pc(f1(rules.roles))} |
Notes: "held-out phrases" tests wording the model never saw in training (phrase variant 4), but it is still generated language, so it is optimistic. The **real sentences** column (hand-written, hand-labelled, never trained on) is the honest number; it is small (${real.length}). Place accuracy on real sentences that name a place: brain ${pc(brainPlaceReal)} vs rules ${pc(rules.place[0] / rules.place[1])}. Names (e.g. Bangla names) are not read by this model yet. It improves as approved corrections are added: more data, retrain, re-measure.
`;
fs.writeFileSync(new URL("../docs/MODEL_EVAL.md", import.meta.url), md);
