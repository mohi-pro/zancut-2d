// Writes brain/seed.jsonl: labelled Bangla + English sentences built from phrase banks (labels are true by construction).
// Each row records which phrase variant it used (v = [place, action, face]); the evaluation holds variant 4 out, so the test uses phrases the model never saw.
import fs from "node:fs";
const B = {
 place: { bedroom: [["wakes up in bed","gets out of bed","sleeps in the bedroom","lies on the bed in his room","wakes up early in the morning"],["বিছানা থেকে উঠে","ঘুম থেকে জেগে","শোবার ঘরে ঘুমিয়ে","ঘরের বিছানায় শুয়ে","ভোরে ঘুম ভাঙতেই"]],
  village_home: [["in the village yard","at home","in front of the house","in the courtyard of the village house","near the mud house"],["বাড়ির উঠানে","গ্রামের বাড়িতে","ঘরের সামনে","নিজের বাড়ির আঙিনায়","গ্রামের ঘরের পাশে"]],
  village_road: [["on the village road","along the muddy path","on the road to the market","down the lane","on the way"],["গ্রামের রাস্তা ধরে","মেঠো পথ দিয়ে","রাস্তার ধারে","পথের মাঝে","গলি দিয়ে"]],
  school_yard: [["at the school gate","in the school yard","outside the school","in the school playground","at school"],["স্কুলের মাঠে","স্কুলের গেটে","বিদ্যালয়ের উঠানে","স্কুলের সামনে","স্কুলে"]],
  classroom: [["in the classroom","at his desk in class","in front of the blackboard","during the lesson","inside the class"],["ক্লাসঘরে","শ্রেণিকক্ষে","বোর্ডের সামনে","ক্লাসের ভেতরে","পড়ার সময় ক্লাসে"]],
  city_street: [["on the busy city street","near the bus stop","beside the traffic light","in the city","on the crowded street"],["শহরের রাস্তায়","বাস স্টপের কাছে","ট্রাফিক সিগনালের পাশে","ব্যস্ত শহরে","জনবহুল রাস্তায়"]],
  living_room: [["in the living room","on the sofa","in the drawing room","in front of the TV","in the sitting room"],["বসার ঘরে","সোফায়","ড্রয়িং রুমে","টিভির সামনে","বৈঠকখানায়"]],
  kitchen: [["in the kitchen","by the stove","cooking in the kitchen","near the fridge","at the kitchen shelf"],["রান্নাঘরে","চুলার পাশে","রান্না করতে করতে","ফ্রিজের কাছে","হেঁশেলে"]],
  park: [["in the park","on the park bench","in the garden","under the big tree in the park","near the flower bed"],["পার্কে","পার্কের বেঞ্চে","বাগানে","পার্কের বড় গাছের নিচে","ফুলের বাগানের পাশে"]] },
 action: { idle: [["stands there","waits","looks around","thinks","stays"],["দাঁড়িয়ে থাকে","অপেক্ষা করে","চারদিকে তাকায়","ভাবে","থেকে যায়"]],
  walk: [["walks slowly","walks along","goes ahead","strolls","walks"],["হেঁটে যায়","ধীরে হাঁটে","এগিয়ে চলে","হেঁটে চলে","হাঁটতে থাকে"]],
  run: [["runs fast","dashes","rushes","runs","sprints"],["দৌড়ে যায়","ছুটে চলে","দ্রুত দৌড়ায়","দৌড়াতে থাকে","ছুটে আসে"]],
  wave: [["waves goodbye","waves his hand","says hello and waves","waves","waves at everyone"],["হাত নাড়ে","বিদায় জানিয়ে হাত নাড়ে","হাত নেড়ে ডাকে","হাত নাড়িয়ে হাসে","সবাইকে হাত নাড়ে"]],
  cheer: [["cheers loudly","jumps with joy","celebrates","cheers","shouts with delight"],["আনন্দে চিৎকার করে","উল্লাস করে","আনন্দে লাফায়","খুশিতে নেচে ওঠে","জয়ধ্বনি করে"]],
  clap: [["claps","claps happily","gives applause","claps his hands","applauds"],["হাততালি দেয়","খুশিতে হাততালি দেয়","করতালি দেয়","হাত চাপড়ায়","তালি বাজায়"]],
  point: [["points at the board","points ahead","shows the way","points to the sky","points"],["আঙুল তুলে দেখায়","বোর্ডের দিকে দেখায়","সামনে ইশারা করে","পথ দেখিয়ে দেয়","আকাশের দিকে দেখায়"]],
  sit: [["sits down","sits quietly","takes a seat","sits and rests","sits"],["বসে পড়ে","চুপচাপ বসে থাকে","আসনে বসে","বসে বিশ্রাম নেয়","বসে"]] },
 face: { happy: [["with a big smile","happily","feeling glad","and laughs","with joy","and smiles","looking delighted","grinning","feeling proud","is very happy"],["হাসিমুখে","খুশি মনে","আনন্দিত হয়ে","হাসতে হাসতে","উৎফুল্ল হয়ে","হেসে ফেলে","গর্বিত হয়ে","আনন্দে","মুখে হাসি নিয়ে"]],
  worried: [["feeling worried","with fear","anxiously","afraid of being late","with a troubled face","and is nervous","looking scared","is afraid","is anxious"],["চিন্তিত মুখে","ভয়ে ভয়ে","দুশ্চিন্তায়","দেরি হবে ভেবে ভয় পেয়ে","উদ্বিগ্ন হয়ে","ভয় পেয়ে","নার্ভাস হয়ে"]],
  sad: [["feeling sad","in tears","with a heavy heart","and cries","sadly","is unhappy","and weeps","feeling lonely","is heartbroken"],["মন খারাপ করে","চোখে জল নিয়ে","দুঃখিত হয়ে","কাঁদতে কাঁদতে","বিষণ্ণ মনে","হারিয়ে ফেলে দুঃখে","কেঁদে ফেলে","একা একা মন খারাপ করে","কষ্ট পেয়ে","মুখ গোমড়া করে"]],
  surprised: [["in surprise","suddenly shocked","and is amazed","with wide eyes","surprised","and gasps","looks astonished","is stunned","cannot believe it","looks surprised"],["অবাক হয়ে","হঠাৎ চমকে","বিস্ময়ে","চোখ বড় করে","অবাক চোখে","হতবাক হয়ে","চমকে উঠে","বিশ্বাস করতে পারে না","হঠাৎ অবাক হয়","স্তম্ভিত হয়ে"]] },
 roles: { boy: [["the boy","a little boy","the child","a kid"],["ছেলেটি","একটি ছোট ছেলে","শিশুটি","ছোট্ট ছেলেটা"]], girl: [["the girl","a little girl","the young girl"],["মেয়েটি","ছোট্ট মেয়ে","মেয়েটা"]], father: [["a man","the man","the father","dad"],["লোকটি","বাবা","একজন পুরুষ","ভদ্রলোক"]],
  mother: [["the woman","mother","the lady","mom"],["মা","মহিলা","নারী","আম্মু"]], baba: [["an old man","the old man","grandfather","the elderly man"],["এক বৃদ্ধ","বুড়ো লোক","দাদু","বয়স্ক মানুষ"]], teacher: [["the teacher","our teacher","the headmaster"],["শিক্ষক","স্যার","প্রধান শিক্ষক"]] },
 names: [["Rafi","Mina","Tuhin","Sara","Karim","Anika"],["রাফি","মিনা","তুহিন","সারা","করিম","অনিকা"]],
};
let seed = 7; const r = () => ((seed = (Math.imul(seed, 1664525) + 1013904223) >>> 0) / 2 ** 32), pick = (a) => a[Math.floor(r() * a.length)];
const rows = [];
for (let n = 0; n < 2400; n++) {
  const L = n % 2, bn = L === 1, ph = (k, bank) => { const keys = Object.keys(bank), id = pick(keys), list = bank[id][L], v = Math.floor(r() * list.length); return { id, text: list[v], v }; };
  const usePlace = r() < 0.65, useAct = r() < 0.8, useFace = r() < 0.55, nSubj = r() < 0.2 ? 2 : 1;
  const P = usePlace ? ph("place", B.place) : null, A = useAct ? ph("action", B.action) : null, F = useFace ? ph("face", B.face) : null;
  const roles = [], subj = [];
  for (let k = 0; k < nSubj; k++) { if (r() < 0.45) { const R = ph("roles", B.roles); if (!roles.includes(R.id)) { roles.push(R.id); subj.push(R.text); } } else subj.push(pick(B.names[L])); }
  const S = subj.join(bn ? " আর " : " and "), parts = bn ? [P?.text, S, F?.text, A?.text || (r() < 0.5 ? "আছে" : "")] : [S, A?.text || (r() < 0.5 ? "is there" : ""), P?.text, F?.text];
  if (!bn && F && r() < 0.3) { parts.splice(parts.indexOf(F.text), 1); parts.splice(1, 0, F.text); }
  const text = parts.filter(Boolean).join(" ").replace(/\s+/g, " ").trim() + (bn ? "।" : ".");
  rows.push({ text: bn ? text : text[0].toUpperCase() + text.slice(1), place: P ? P.id : "none", action: A ? A.id : "idle", face: F ? F.id : "neutral", roles, lang: bn ? "bn" : "en", v: [P ? P.v : -1, A ? A.v : -1, F ? F.v : -1], source: "seed" });
}
fs.mkdirSync(new URL("../brain/", import.meta.url), { recursive: true });
fs.writeFileSync(new URL("../brain/seed.jsonl", import.meta.url), rows.map((x) => JSON.stringify(x)).join("\n") + "\n");
console.log(`wrote ${rows.length} seed sentences (${rows.filter((x) => x.lang === "bn").length} Bangla)`);
