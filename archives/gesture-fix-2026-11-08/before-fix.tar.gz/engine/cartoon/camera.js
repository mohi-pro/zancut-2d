// The camera rule book (engine/cartoon/library/camera.json, Brief 9) for the designers: frame a person by shot size, two people
// together, and name a shot's size. Framing follows the book: the frame's top and bottom land on body landmarks (read from the person's
// own skeleton, in head units), headroom as a share of the frame, looking room on the side the person faces. Call after drawing.
//   ZC.frame(W, b, "closeUp")            closeUp · mediumClose · medium · mediumWide · full · wide · extremeWide (or an alias: "CU", "MS", "ক্লোজ আপ")
//   ZC.frame(W, b, "medium", { x: 0.45 }) the face's place across the frame (default: centre, or looking room when side on)
//   ZC.twoShot(W, a, b, "full")          both people in one frame at that size (9:16: stage them in depth, not side by side)
//   ZC.shotSize(W, b) → "medium"         the size this frame shows of b (the book's head-fraction ladder)
//   ZC.shots(W, t, [{ at: 0, frame: [b, "wide"] }, { at: 1.2, frame: [b, "closeUp"], to: [b, "mediumClose"] }])   a cut list that follows people
(function (root) {
  const D = () => root.ZCAMERA_DATA || {};
  const mid = (v, d = 0) => (Array.isArray(v) ? (v[0] + v[v.length - 1]) / 2 : v ?? d);
  const ALIAS = () => { const m = {}; for (const [k, v] of Object.entries(D().sizes || {})) { m[k.toLowerCase()] = k; for (const a of v.aliases || []) m[String(a).toLowerCase()] = k; } return m; };
  const sizeId = (s) => { const k = ALIAS()[String(s).toLowerCase()]; if (!k) throw new Error(`ZC.frame: no shot size "${s}" (closeUp, mediumClose, medium, mediumWide, full, wide, extremeWide)`); return k; };
  // "chin+0.7head" → that landmark + 0.7 head heights, in head units down from the skull top
  const at = (expr, lm) => { const m = String(expr).match(/^([a-zA-Z]+)\s*([+-]\s*[\d.]+)?\s*(?:head)?$/); if (!m) return null; const base = lm[m[1]] ?? D().landmarks?.adult?.[m[1]]; return base == null ? null : base + (m[2] ? Number(m[2].replace(/\s/g, "")) : 0); };

  // the camera [x, y, width] that frames this person at that size
  function frameOf(W, b, size, o = {}) {
    const id = sizeId(size), S = D().sizes[id], B = b.box(), aspect = W.w / W.h, lm = B.lm;
    let H, top;
    if (id === "wide" || id === "extremeWide") { // the person takes a share of the frame's height, the floor low in the frame
      const share = mid(S.personHeightOfFrame, id === "wide" ? 0.4 : 0.1), body = (lm.feet - lm.headTop) * B.headPx;
      H = body / share; top = B.floor - H * 0.82;
    } else {
      const t0 = S.frameTop?.landmark === "headTop" ? 0 : at(S.frameTop?.landmark, lm) ?? 0;
      const bottom = S.frameBottom === "belowFeet" ? lm.feet : at(S.frameBottom, lm);
      if (bottom == null) throw new Error(`ZC.frame: "${id}" has no body frame (use ZC.twoShot or a camera you author)`);
      const headroom = Math.max(0, mid(S.frameTop?.headroom, 0)), footroom = S.frameBottom === "belowFeet" ? mid(S.footroom, 0.05) : 0;
      H = ((bottom - t0) * B.headPx) / (1 - headroom - footroom);
      top = B.headTop + t0 * B.headPx - headroom * H;
    }
    // a tall frame (9:16) is narrow: a close size still shows the head with air and the top of the shoulders, so it is never
    // narrower than this many head heights; the wider frame keeps the eyes on the book's line
    const MINW = { closeUp: 2.7, mediumClose: 3.3, medium: 4.1 }[id];
    if (MINW && H * aspect < MINW * B.headPx) { const H2 = (MINW * B.headPx) / aspect, eyes = B.headTop + (lm.eyes ?? 0.5) * B.headPx; top = eyes - mid(S.eyeLine, 0.34) * H2; H = H2; } // the eyes stay on the book's line
    // bowed, seated, kneeling or lying: the frame keeps the size it has for this person standing (the camera does not zoom in because
    // someone bows); full and wider keep the floor at the bottom, closer sizes centre on the head
    if (!B.upright) {
      const sb = D().landmarks?.adult || {}, k = B.standHeads / ((sb.feet ?? 7.5) || 7.5), stand = Object.fromEntries(Object.entries(sb).map(([n, v]) => [n, v * k]));
      const T = frameOf(W, { box: () => ({ ...B, lm: { ...stand, feet: B.standHeads }, upright: true, headTop: B.floor - B.standHeads * B.headPx }) }, id, { ...o, x: 0.5 });
      H = T[2] / aspect;
      top = ["full", "mediumWide", "wide", "extremeWide"].includes(id) ? B.floor + H * (S.frameBottom === "belowFeet" ? mid(S.footroom, 0.05) : 0.12) - H : B.headY - H * 0.4;
      top = Math.min(top, B.headTop - H * 0.05); // a seated person's head is never cut by the frame
    }
    const w = H * aspect, fx = o.x ?? (B.facing > 0 ? 0.45 : B.facing < 0 ? 0.55 : 0.5); // looking room on the side the person faces
    return [B.x - (fx - 0.5) * w, top + H / 2, w];
  }
  function frame(W, b, size, o = {}) { const c = frameOf(W, b, size, o); W.cam(c[0], c[1], c[2], o.tilt || 0); return c; }
  function twoShotOf(W, a, b, size = "full", o = {}) {
    const A = frameOf(W, a, size, o), B = frameOf(W, b, size, o), aspect = W.w / W.h;
    const hA = A[2] / aspect, hB = B[2] / aspect, top = Math.min(A[1] - hA / 2, B[1] - hB / 2), bottom = Math.max(A[1] + hA / 2, B[1] + hB / 2);
    const left = Math.min(a.box().x, b.box().x), right = Math.max(a.box().x, b.box().x), pad = Math.max(a.box().headPx, b.box().headPx) * 1.6;
    const w = Math.max((bottom - top) * aspect, right - left + 2 * pad), h = w / aspect;
    return [(left + right) / 2, Math.max(top + h / 2, (top + bottom) / 2), w];
  }
  function twoShot(W, a, b, size = "full", o = {}) { const c = twoShotOf(W, a, b, size, o); W.cam(c[0], c[1], c[2], o.tilt || 0); return c; }
  // the size whose frame for THIS person is closest to the camera's frame (a child is fewer heads tall than the book's head-fraction
  // ladder assumes, so the size is measured on the person's own body); the ladder is the fallback
  function shotSize(W, b) {
    const c = W.svg.__cam || { ch: W.h, cw: W.w };
    let best = null, err = Infinity;
    for (const k of ["closeUp", "mediumClose", "medium", "mediumWide", "full", "wide", "extremeWide"]) {
      try { const e = Math.abs(Math.log(frameOf(W, b, k)[2] / c.cw)); if (e < err) { err = e; best = k; } } catch { /* a size without a body frame */ }
    }
    if (best && b.box().headPx / c.ch > 0.7) return "extremeClose";
    if (best) return best;
    const f = b.box().headPx / c.ch, min = D().sizeClassify?.headFractionMin || {};
    return (D().sizeClassify?.ladder || []).slice().reverse().find((k) => f >= (min[k] ?? 0)) || "extremeWide";
  }
  root.ZCAMERA = { frameOf, frame, twoShotOf, twoShot, shotSize, sizeId };
  if (root.ZC) Object.assign(root.ZC, { frame, twoShot, shotSize, frameOf });
})(typeof window !== "undefined" ? window : globalThis);
