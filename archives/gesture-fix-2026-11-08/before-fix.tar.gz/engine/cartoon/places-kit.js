// Ready places for Zancut 2D: composed by code from the library's set pieces, no AI. Each place is ZF.place(id, meta, fn)
// (see zc.js). A film's edit/film-kit.js = its cast + this file. Metres: x right of the middle, dz behind the floor line.
// Add a place = add one ZF.place block here; the scene file then says "place": "<id>".
ZF.place("village_road", { views: ["wide", "reverse"], world: { wide: { horizon: 0.42, floor: 0.8, ppm: 0.3 }, reverse: { horizon: 0.44, floor: 0.8, ppm: 0.3 } }, spots: { left: { x: -2.2, dz: 1 }, right: { x: 2.2, dz: 1 }, mid: { x: 0, dz: 1 } } }, (W, o) => {
  const Z = o.Z, far = W.layer("far"), L = o.layer, f = o.view === "reverse" ? -1 : 1;
  ZS.sky(W.layer("sky"), { w: W.w * 3, h: Z.horizon + 80, top: "#79bfe6", bottom: "#fde7bf" });
  ZS.sun(W.layer("sky"), { x: W.w * 0.78, y: Z.horizon * 0.45, r: 64 });
  ZS.cloud(W.layer("sky"), { x: W.w * 0.2, y: Z.horizon * 0.35, h: 70, seed: 2 }); ZS.cloud(W.layer("sky"), { x: W.w * 0.6, y: Z.horizon * 0.2, h: 55, seed: 5 });
  ZS.hill(far, { x: W.w * 0.2, y: Z.horizon + 6, w: W.w * 0.9, h: 170, seed: 1, color: "#8bb98a" }); ZS.hill(far, { x: W.w * 0.85, y: Z.horizon + 6, w: W.w * 0.8, h: 130, seed: 4, color: "#7fae83" });
  ZS.floor(L, { w: W.w * 3, y: Z.horizon, h: W.h, color: "#8fbf62", seed: 3, marks: 0.2 });
  Z.put("mudPath", L, { x: 0, dz: 0, seed: 1 });
  Z.put("mangoTree", L, { x: -4.5 * f, dz: 5, seed: 2 }); Z.put("tinHouse", L, { x: 5.5 * f, dz: 6, seed: 1 }); Z.put("coconutPalm", L, { x: -7 * f, dz: 9, seed: 3 }); Z.put("bushRow", L, { x: 3 * f, dz: 3.5, seed: 2 });
  Z.put("grassTuft", W.layer("front"), { x: -2 * f, dz: -1.2, seed: 4 });
  return {};
});
ZF.place("village_home", { views: ["wide", "close"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 }, close: { horizon: 0.4, floor: 0.82, ppm: 0.3 } }, spots: { door: { x: 1.8, dz: 1.5 }, yard: { x: -1, dz: 1 } } }, (W, o) => {
  const Z = o.Z, far = W.layer("far"), L = o.layer;
  ZS.sky(W.layer("sky"), { w: W.w * 3, h: Z.horizon + 80, top: "#86c6ea", bottom: "#fde9c4" });
  ZS.cloud(W.layer("sky"), { x: W.w * 0.35, y: Z.horizon * 0.4, h: 60, seed: 3 });
  ZS.hill(far, { x: W.w * 0.5, y: Z.horizon + 6, w: W.w * 1.1, h: 140, seed: 2, color: "#86b684" });
  ZS.floor(L, { w: W.w * 3, y: Z.horizon, h: W.h, color: "#b99a73", seed: 2, marks: 0.3 });
  Z.put("mudHouse", L, { x: 1.5, dz: 3, seed: 1 }); Z.put("mangoTree", L, { x: -4, dz: 5, seed: 4 }); Z.put("bananaPlant", L, { x: 5, dz: 4, seed: 2 }); Z.put("tubewell", L, { x: -2.2, dz: 2.2 });
  return {};
});
ZF.place("school_yard", { views: ["wide", "reverse"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 } }, spots: { gate: { x: 0, dz: 2.5 }, yard: { x: -1.5, dz: 1 } } }, (W, o) => {
  const Z = o.Z, far = W.layer("far"), L = o.layer;
  ZS.sky(W.layer("sky"), { w: W.w * 3, h: Z.horizon + 80, top: "#7dc2e8", bottom: "#fdebc8" });
  ZS.cloud(W.layer("sky"), { x: W.w * 0.25, y: Z.horizon * 0.35, h: 60, seed: 6 });
  ZS.floor(L, { w: W.w * 3, y: Z.horizon, h: W.h, color: "#c9ad86", seed: 5, marks: 0.2 });
  Z.put("schoolFront", L, { x: 0, dz: 8, seed: 1 }); Z.put("boundaryWall", L, { x: -3, dz: 5, seed: 1 }); Z.put("gate", L, { x: 3.5, dz: 4.5, seed: 1 }); Z.put("swingSet", L, { x: -5, dz: 3, seed: 1 });
  return {};
});
ZF.place("classroom", { views: ["wide", "close"], world: { wide: { horizon: 0.4, floor: 0.78, ppm: 0.3 }, close: { horizon: 0.4, floor: 0.8, ppm: 0.3 } }, spots: { desk: { x: -1.2, dz: 1.2 }, front: { x: 1.8, dz: 1 } } }, (W, o) => {
  const Z = o.Z, L = o.layer;
  ZS.wall(W.layer("far"), { w: W.w * 3, y: 0, h: Z.floor, color: "#f0e2c8", seed: 2 }); ZS.floor(L, { w: W.w * 3, y: Z.floor - 20, h: W.h, color: "#b58a62", seed: 3, marks: 0.4 });
  Z.put("blackboard", W.layer("far"), { x: 1.5, dz: 6 }); Z.put("window", W.layer("far"), { x: -3.5, dz: 6 }); Z.put("wallClock", W.layer("far"), { x: 0, dz: 6 }); Z.put("schoolDesk", L, { x: -1.5, dz: 2.2 }); Z.put("schoolDesk", L, { x: 0.6, dz: 2.2 }); Z.put("teacherTable", L, { x: 2.8, dz: 4 });
  return {};
});
ZF.place("bedroom", { views: ["wide", "close"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 }, close: { horizon: 0.4, floor: 0.82, ppm: 0.3 } }, spots: { bed: { x: -1.5, dz: 2 }, door: { x: 3, dz: 1.5 } } }, (W, o) => {
  const Z = o.Z, L = o.layer;
  ZS.wall(W.layer("far"), { w: W.w * 3, y: 0, h: Z.floor, color: "#ead9bf", seed: 4 }); ZS.floor(L, { w: W.w * 3, y: Z.floor - 20, h: W.h, color: "#a97b57", seed: 6, marks: 0.4 });
  Z.put("window", W.layer("far"), { x: 1.6, dz: 5 }); Z.put("curtains", W.layer("far"), { x: 1.6, dz: 5 }); Z.put("bookshelf", L, { x: 3.4, dz: 4 }); Z.put("bedsideTable", L, { x: -0.2, dz: 3 }); Z.put("wallClock", W.layer("far"), { x: -2, dz: 5 });
  return {};
});
ZF.place("city_street", { views: ["wide", "reverse"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 } }, spots: { walk: { x: 0, dz: 1 }, stop: { x: -2, dz: 2.5 } } }, (W, o) => {
  const Z = o.Z, far = W.layer("far"), L = o.layer;
  ZS.sky(W.layer("sky"), { w: W.w * 3, h: Z.horizon + 80, top: "#8ec9ea", bottom: "#fdebd0" });
  Z.put("skyscraper", far, { x: -4, dz: 24, seed: 1 }); Z.put("officeTower", far, { x: 6, dz: 20, seed: 2 });
  ZS.floor(L, { w: W.w * 3, y: Z.horizon, h: W.h, color: "#7f8187", seed: 7, marks: 0.1 });
  Z.put("footpath", L, { x: 0, dz: 5 }); Z.put("marketStreet", L, { x: 0, dz: 8 }); Z.put("streetLamp", L, { x: -3, dz: 3 }); Z.put("busStop", L, { x: 3.4, dz: 3 }); Z.put("trafficLight", L, { x: 5, dz: 2 });
  return {};
});
ZF.place("park", { views: ["wide", "reverse"], world: { wide: { horizon: 0.42, floor: 0.8, ppm: 0.3 } }, spots: { bench: { x: -1.5, dz: 1.5 }, path: { x: 1.5, dz: 1 } } }, (W, o) => {
  const Z = o.Z, far = W.layer("far"), L = o.layer;
  ZS.sky(W.layer("sky"), { w: W.w * 3, h: Z.horizon + 80, top: "#80c5ea", bottom: "#fcebc9" });
  ZS.cloud(W.layer("sky"), { x: W.w * 0.7, y: Z.horizon * 0.3, h: 65, seed: 8 });
  ZS.hill(far, { x: W.w * 0.4, y: Z.horizon + 6, w: W.w, h: 120, seed: 3, color: "#7fb07f" });
  ZS.floor(L, { w: W.w * 3, y: Z.horizon, h: W.h, color: "#88bb5e", seed: 9, marks: 0.2 });
  Z.put("footpath", L, { x: 1.5, dz: 3 }); Z.put("banyanTree", L, { x: -5, dz: 7, seed: 1 }); Z.put("flowerBed", L, { x: 4, dz: 4, seed: 2 }); Z.put("streetLamp", L, { x: 3, dz: 6 });
  ZS.bench(L, { x: Z.at(-3.5, 2).x, y: Z.at(-3.5, 2).y, w: 3.2 * Z.at(-3.5, 2).s, seat: 0.45 * Z.at(-3.5, 2).s, seed: 1 });
  return {};
});
// interiors in the saturated wall colours of the reference cartoons (pink, green), built from the library's furniture
ZF.place("living_room", { views: ["wide", "close"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 }, close: { horizon: 0.4, floor: 0.82, ppm: 0.3 } }, spots: { sofa: { x: -1.5, dz: 2 }, door: { x: 2.5, dz: 1.5 } } }, (W, o) => {
  const Z = o.Z, L = o.layer;
  ZS.wall(W.layer("far"), { w: W.w * 3, y: 0, h: Z.floor, color: "#c95a7c", seed: 3 }); ZS.floor(L, { w: W.w * 3, y: Z.floor - 20, h: W.h, color: "#b0805a", seed: 4, marks: 0.3 });
  Z.put("door", W.layer("far"), { x: 3.2, dz: 6 }); Z.put("window", W.layer("far"), { x: -2.6, dz: 6 }); Z.put("photoFrame", W.layer("far"), { x: 0.4, dz: 6 }); Z.put("wallClock", W.layer("far"), { x: -0.8, dz: 6 });
  Z.put("sofaSet", L, { x: -1.6, dz: 3.2 }); Z.put("tvStand", L, { x: 1.8, dz: 4.2 });
  return {};
});
ZF.place("kitchen", { views: ["wide", "close"], world: { wide: { horizon: 0.4, floor: 0.8, ppm: 0.3 }, close: { horizon: 0.4, floor: 0.82, ppm: 0.3 } }, spots: { stove: { x: 1.2, dz: 1.5 } } }, (W, o) => {
  const Z = o.Z, L = o.layer;
  ZS.wall(W.layer("far"), { w: W.w * 3, y: 0, h: Z.floor, color: "#7fae6a", seed: 5 }); ZS.floor(L, { w: W.w * 3, y: Z.floor - 20, h: W.h, color: "#a57a55", seed: 2, marks: 0.3 });
  Z.put("window", W.layer("far"), { x: -1.8, dz: 6 }); Z.put("kitchenShelf", W.layer("far"), { x: 1.6, dz: 6 });
  Z.put("gasStove", L, { x: 1.4, dz: 3.4 }); Z.put("fridge", L, { x: -3.2, dz: 4 }); Z.put("kitchenSink", L, { x: -0.6, dz: 4.2 });
  return {};
});
