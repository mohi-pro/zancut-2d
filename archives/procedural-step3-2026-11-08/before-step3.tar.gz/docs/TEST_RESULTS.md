# Step 2 verification (2026-11-08)

- `npm run test:all`: all **nine** active test scripts passed, including all requested cartoon/parts/film-kit/QA/codefilm checks.
- Gesture sweep: **65/65** pass at 30 fps in both full-body and waist-up rigs, four profiles, **23,400 frames / 93,600 character frames**.
- Numeric gesture/micro-motion regression: **124,800 frames**, normal and half-second durations, both mirror states; root/feet/ROM/entry/exit checks pass. Maximum displacement **36.50 U/frame**, below the unchanged production 40 U limit.
- Browser regression: pelvis/heels/toes stay fixed on screen; reverse seeks reproduce identical frame geometry. Intentionally broken bodies still fail.
- Parts: **60/60** first answers and **110/110** top-three matches. Syntax: **300** scripts compile. QA: three defects found and repaired, zero remaining.
- Owner's **94.60 s** benchmark rerender: **45.24% → 5.29%** nearly static with the same reference-study settings; video QA passes at 1920×1080/30 fps with audio.
- Brain/planner/guard integrity and isolated local render/API checks pass. Details and evidence: [GESTURE_MOTION_AUDIT.md](GESTURE_MOTION_AUDIT.md).

## Previous Step 1 cleanup verification (2026-11-08)

- `npm test`: passed before and after cleanup. Includes cartoon (150 real frames), film-kit, parts (60/60 first answers; 110/110 top-three matches), QA (3 found/3 repaired/0 remaining) and 300 generated-script syntax cases.
- `node scripts/codefilm-test.mjs`: body gate passed; stills produced in the OS temp directory. Gate failures now fail the process.
- `node scripts/world-test.mjs`: all ten scale/contact/depth checks passed.
- `node scripts/cleanup-test.mjs`: 24 server modules import, no-AI guard blocks queries, 961 protected hashes unchanged, stable local owner, sound analysis, real prepare/storyboard/render queue → 6.00 s MP4, video QA passed, model cost $0; isolated app/library/project API smoke check passed. Uses temporary data, cached transcript words and npm offline mode.
- All eight active test scripts: `npm run test:all`. The four archived Studio-only tests are historical, not active successes.
- Source inventory, archive and limits: [CODEBASE_AUDIT.md](CODEBASE_AUDIT.md).

## Previous measured results

# TEST RESULTS (2026-11-06) — all run on this Mac
- `node scripts/cartoon-test.mjs` → "cartoon test passed" (engine, 150 real frames through the body gate).
- `node scripts/film-kit-test.mjs`, `node scripts/parts-test.mjs` → ok.
- `node scripts/codefilm-test.mjs` → body gate ok; stills in examples/out/shot*.jpg.
- Render: `examples/out/rafi-no-ai.mp4` (voice + scene file, 1920×1080, 30 fps, 9.3 s). Contact strip: examples/out/render-strip.jpg.
- Render: `examples/out/bangla-plan-test.mp4` — Bangla script → rules planner → render. Known weakness: Bangla names are not recognised, hero became a generic boy.
- `node scripts/qa-test.mjs` → 3 seeded defects found (out-of-frame x=-6.5 at 2.5 s, overlap 0.2 m at 5.5 s, 0.2 s shot at 9.8 s), 3 repaired, 0 remaining; before/after pictures docs/evidence/qa/before-after.jpg.
- NOT measured yet: render time per 10 s, peak memory, 720p timing, LLM benchmark (no LLM installed).
