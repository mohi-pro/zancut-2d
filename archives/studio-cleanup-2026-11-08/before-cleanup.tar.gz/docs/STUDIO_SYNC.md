# Studio → 2D sync — 8 November 2026

Merged the shared 2D updates from the local `/Users/ahnafmohi/Zancut-Studio` working tree, including its existing uncommitted engine and editor fixes. Source HEAD: `583eb54f6f4fbb461cfceea8f043608493d10172`. This was a file merge: Zancut 2D has no Git repository.

## Included

- 35 new library items: 11 actions, 2 gestures, 2 hand shapes, 17 set pieces and 3 props. Library rebuilt from its source folders: **275 actions, 65 gestures, 30 hands, 245 set pieces, 85 props**.
- Updated sizes, drawn measurements, search words and matching rules, including seated actions and room-specific furniture.
- `ZC.shot` (shots by name), `ZT` (stage/camera projection), `ZD` (screens/graphic parts), and their compositor loading.
- Over-the-shoulder helper and O1 size check; M2 requires a visible speaker to lip-sync. Back views and explicitly quiet figures are exempt from M2.
- Character/rig updates: crown and royal outfit, long hair, trousers under short tops, head turns and solid hand-pose transitions; film-local parts can be placed in metres.
- Shared director/editor/film-kit and animation-preparation updates, anatomy/design guidance and regression checks. These modules retain their no-AI imports in 2D.

The new one-hand `cup`/`sip` poses have a null elbow target for the resting arm. Their blend originally dereferenced that null target. Fixed only in 2D; covered by the direction test and a real Chrome draw in the film-kit test.

## 2D behavior retained

The local app/UI, own brain/training data, scene-file compiler, inbox/outbox Autopilot, blocked AI query and continuous 2D music bed remain in place. The agent still builds storyboards through `codefilm.build`; Studio's AI storyboard route is not enabled. Studio-specific desktop, accounts, website and chat features were not imported. No credentials or customer projects were copied.

`continuity-test.mjs` uses an in-process, test-only tool registry to exercise editor handlers without the Claude SDK. Production `no-ai.mjs` is unchanged. Voice networking tests mock `fetch`; no AI or external voice service was called.

## Validation

- `npm test`: passed, including 300 generated scripts, QA repair, film-kit, library search (**60/60 first answers; 110/110 in top 3**) and cartoon/body tests (**150 real frames**).
- `node scripts/world-test.mjs`: passed all 10 scale/contact/depth checks.
- `node scripts/animation-direction-test.mjs`: passed, including one-hand pose blending.
- `node scripts/check-prompts.mjs`: **427,297 checks over 3,072 setup combinations** passed.
- `node scripts/continuity-test.mjs`: **108 checks**, no AI, passed.
- `node scripts/voice-take-test.mjs`: passed word-boundary cutting, retry, timeout and cancellation with mocked requests.
- `node scripts/codefilm-test.mjs`: existing no-AI scene file composed; body gate passed; inspected a generated still.
- Isolated server smoke check: app startup, updated library API counts/search, saving a scene with a new action, blocked AI query and disabled test Autopilot all passed. Used temporary project data and stopped the test server.

Run the reusable regression suite with `npm run test:studio-sync`.

## Source integrity and backup

Studio source hashes and Git status were compared against the pre-merge snapshot: unchanged. Its pre-existing uncommitted changes remain there.

The file-by-file hashes are in [studio-sync-manifest.json](studio-sync-manifest.json). Pre-merge 2D files and the source audit are backed up at:

`/var/folders/dl/cjpbsfmd7p78csrrv82mjk200000gn/T/zancut-2d-studio-merge-3nza8aov/`

Remaining earlier 2D gaps (including automatically safe gestures and brain-directed use of new shot capabilities) are not claimed fixed by this sync. The new helpers are available to scene authors; the own-brain compiler retains its existing camera vocabulary.
