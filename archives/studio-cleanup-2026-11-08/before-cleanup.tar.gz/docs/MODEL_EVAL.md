# MODEL EVAL — Zancut's own brain (trained from scratch, no pretrained model)
Run `node scripts/brain-train.mjs`. Last run: 2026-11-06T18:03:15.579Z.
**What it is:** hashed word + character n-gram features → softmax/sigmoid regression, pure JS, trained on our own labelled sentences (brain/seed.jsonl, 2400 generated rows, Bangla + English) plus the owner's approved corrections (2 so far). Training time 2445 ms. It predicts, per sentence: place, action, face, who is in it.
| head | held-out phrases (n=749) | real sentences (n=34) | old rules planner (real) |
|---|---|---|---|
| place | 76% | 85% | 50% |
| action | 78% | 91% | 85% |
| face | 86% | 88% | 82% |
| roles (F1) | 98% | 98% | 85% |
Notes: "held-out phrases" tests wording the model never saw in training (phrase variant 4), but it is still generated language, so it is optimistic. The **real sentences** column (hand-written, hand-labelled, never trained on) is the honest number; it is small (34). Place accuracy on real sentences that name a place: brain 79% vs rules 50%. Names (e.g. Bangla names) are not read by this model yet. It improves as approved corrections are added: more data, retrain, re-measure.
