# TEST RESULTS (2026-11-06) — all run on this Mac
- `node scripts/cartoon-test.mjs` → "cartoon test passed" (engine, 150 real frames through the body gate).
- `node scripts/film-kit-test.mjs`, `node scripts/parts-test.mjs` → ok.
- `node scripts/codefilm-test.mjs` → body gate ok; stills in examples/out/shot*.jpg.
- Render: `examples/out/rafi-no-ai.mp4` (voice + scene file, 1920×1080, 30 fps, 9.3 s). Contact strip: examples/out/render-strip.jpg.
- Render: `examples/out/bangla-plan-test.mp4` — Bangla script → rules planner → render. Known weakness: Bangla names are not recognised, hero became a generic boy.
- `node scripts/qa-test.mjs` → 3 seeded defects found (out-of-frame x=-6.5 at 2.5 s, overlap 0.2 m at 5.5 s, 0.2 s shot at 9.8 s), 3 repaired, 0 remaining; before/after pictures docs/evidence/qa/before-after.jpg.
- NOT measured yet: render time per 10 s, peak memory, 720p timing, LLM benchmark (no LLM installed).
