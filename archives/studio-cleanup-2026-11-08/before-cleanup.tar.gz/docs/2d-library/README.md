# The 2D library: what to make outside, and how it comes in

The 2D films get cheaper when the shot designers place ready, checked parts instead of drawing and animating everything by hand
in every shot. The parts are made **outside Zancut** (by another AI, from the briefs below), checked here, and then added.

Every brief is written for an AI that knows **nothing** about Zancut: the rules, the formats and complete working examples are
inside each file. Give it only what this table says.

| Brief | What it makes | Give the AI |
|---|---|---|
| [01-people-motion-prompt.md](01-people-motion-prompt.md) | Actions (whole body), gestures (arms), hand shapes | The brief. Optional, so it can check itself: `engine/cartoon/anatomy.js`, `engine/cartoon/hands.js`, `tools/selfcheck.js` |
| [02-places-prompt.md](02-places-prompt.md) | Set pieces: nature, village, city, vehicles, rooms in parts | The brief + `tools/preview.html` |
| [03-animals-prompt.md](03-animals-prompt.md) | Animals and birds that move | This brief + Brief 2 + `tools/preview.html` |
| [04-props-prompt.md](04-props-prompt.md) | Things people hold, carry and give | This brief + Brief 2 + `tools/preview.html` |
| [05-world-sizes-prompt.md](05-world-sizes-prompt.md) | Real sizes (metres) and contact points (seat, handle, roof) of every part | The brief + `library-items.json` (packed) |
| [06-body-proportions-prompt.md](06-body-proportions-prompt.md) | A measured body chart: female and male, toddler to elder, three builds | The brief |
| [07-acting-cards-prompt.md](07-acting-cards-prompt.md) | Feelings as face + body + timing, transitions, gaze, acting by age | The brief |
| [08-natural-motion-prompt.md](08-natural-motion-prompt.md) | Relaxed stands, feelings in the body, object acts, people touching | This brief + Brief 1 + its check files + `existing-motion.json` (packed) |
| [09-camera-shots-prompt.md](09-camera-shots-prompt.md) | Shot sizes, angles, moves, cuts as numbers; checkable camera rules; shot recipes per story moment | The brief |

Each brief has P1 / P2 / P3. Ask for P1 first. `node scripts/library-briefs.mjs` packs every brief as a folder that stands alone
(outside the repo), with the generated lists (`library-items.json`, `existing-motion.json`) read from the library itself.
Briefs 5–7 are numbers, not drawings: they come back as `sizes.json`, `proportions.json`, `acting.json` and are checked and
turned into engine data here (see `docs/2D-WORLD-PLAN.md`).

## What is NOT made outside

- **Clothes.** The engine's garments bend with the body at every joint (rules H19–H21); a drawn outfit cannot. A character's
  clothes are chosen once, in the director's cast list at the start of a film, and the same spec is used in every shot by code.
  New outfit types (lungi, gamchha, school uniforms, jackets, burqa…) are engine work, done here.
- **Faces and expressions** (16 already), **people's looks** (from the spec), **finished scenes or backgrounds** (never: a
  place is always composed for its story from parts).

## When a delivery comes back

1. Put it in a folder with `actions/ gestures/ hands/ set/ props/` inside.
2. `node scripts/library-check.mjs <folder>`: numbers (bones, limits, floor, sliding, randomness), then every part on the real
   pages in Chrome through the body gate, and one picture of everything (`<folder>/library-board.jpg`). No AI, no tokens.
3. Look at the picture together; fix or send back what is wrong.
4. Copy the folders into `engine/cartoon/library/`, run `node scripts/build-library.mjs`, then `node scripts/cartoon-test.mjs`
   and `node scripts/film-kit-test.mjs`.

Keep every part that passes, including bonus parts beyond the brief: a story may need them. A piece whose name is already a
built-in (`engine/cartoon/set.js`, e.g. `rickshaw`, `sofa`) is renamed, not dropped (`cycleRickshaw`, `sofaSet`). The delivery's
notes and manifest go in `engine/cartoon/library/notes/`; previews, pictures and zips stay outside the repo.

## How the parts are found (no AI, no whole list in any prompt)

`server/parts.mjs` searches the library: the director writes each shot's `needs` in plain words ("Dada sits down on the bench",
"CNG", "tea stall") without ever seeing the library; code finds the closest parts and their near alternatives (a child's or an
elderly person's own version when the cast says so), and for each place the pieces its look names plus the things that usually go
with that kind of place. One small file per film (`edit/film-parts.json`); each designer gets only its own rows' slice, the
film-kit designer only its places', and `find_parts` finds anything else. Close = use it, near = adapt it, nothing = author it.
The search words live in `engine/cartoon/library/words.json` (aliases in English and Bangla, word forms, place groups) and in a
part's own `"aliases"`. A miss is fixed there and added to `node scripts/parts-test.mjs` (no AI).

## Who uses the parts, and how the story decides

Parts are never dropped in as they are: someone thinks about the story first.
- **The director** (Opus) writes the blocking and the shot's `needs` in plain words; it never reads the library.
- **The film-kit designer** (one call per film) composes each place from set pieces and animals for this story: picks them,
  sizes them, colours them to the place's palette and light, and adds the little touches the script names.
- **The shot designers** put the actions together on the place: the timing on the words, the facing, the eyelines, the
  hand-overs with props, and the special moment no library part covers (which they still author by hand).
- **The reviewer** checks each batch right after it is built; code checks every frame against the body rules.
