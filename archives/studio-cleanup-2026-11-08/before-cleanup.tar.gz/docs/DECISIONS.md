# DECISIONS
- (2026-11-06) **No pretrained AI model in the product.** The owner's rule: animation is made by our own system that we keep training. A Qwen3.5-4B via Ollama was installed and benchmarked (10/10 valid plans, median 17.7 s, ~15–47 % free RAM while loaded) and then **removed on the owner's instruction** (model files deleted, Ollama uninstalled). Its code and benchmark were deleted.
- (2026-11-06) Own brain = hashed word + char-n-gram features, softmax/sigmoid regression, pure JS. Chosen because it trains in seconds on the M4, is inspectable, works for Bangla word endings, and can be retrained after every correction.
- (2026-11-06) Learning only from the owner's corrected shots (changed vs proposed). Learning from unchanged shots would reinforce the brain's own mistakes. Roles are not learned from storyboards: the hero stays in every shot so presence says little about the sentence. Found by testing, fixed, polluted test rows deleted.
- (2026-11-06) Evaluation keeps a hand-labelled real-sentence set out of training; I removed phrases from the seed that mirrored test sentences after noticing leakage.
- (2026-11-06) Scene file is the editable project; the DSL is closed (unknown place/action/person rejected).
- Express 5 route patterns do not allow regex groups: undo/redo are two routes.
- (2026-11-07) **Owner decision: keep WhisperX for listening only.** It turns the voice into words and their times (local, offline). It never plans, draws or animates. Every other part stays model-free.
