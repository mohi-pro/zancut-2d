# 2D films: world scale, bodies, acting, camera (the fix plan after the first film)

The first full film showed size, body and acting problems. Checked in the code (Nov 2026), they are real:

| Finding | In the code |
|---|---|
| No real-world size | Every piece takes `h` in pixels (`engine/cartoon/set.js`, all 310 library pieces). Props and animals say their cm only as free text in `about`; places say nothing. |
| No female body | `PROFILES` = adult, child, elderly, broad (`anatomy.js`). A woman differs from a man only by `hipWidth` 1.04 vs 0.98 (`people.js biometrics`); `limbThick` is the same 1.0. |
| Puffy child | child `scaleY 0.72` but `limbThick 0.86`, `scaleWidth 0.78`: thicker for its height than an adult. |
| Robotic arms | the reference stand: elbow → wrist nearly straight, left = right mirrored, weight on both legs, no breath. |
| Faces act alone | 16 faces (`ZC.FACES`: smile, raise, inner, lid, open) and no link to the body's `TRIM` dials or to timing. |
| Flat camera | `W.cam(x, y, width, tilt)` + `ZC.shots`: framing and slides over one front view. |

## What comes from outside (numbers, not drawings): `docs/2d-library/05–08`

| Brief | Comes back as | Becomes |
|---|---|---|
| 05 world sizes | `sizes.json`: every one of the 341 parts in metres + contacts (seat, handle, roofUnder, grip, an animal's back) + standards | `engine/cartoon/library/sizes.json` |
| 06 body proportions | `proportions.json`: female/male × toddler, 6, 9, 12, teen, adult, elder; ratios with a cartoon range; builds; motion by age | the new profiles + the proportion test |
| 07 acting cards | `acting.json`: ~36 feelings × mild/strong (face + body + timing), 12 transitions, gaze rules, acting by age | `ZC.feel` data |
| 08 natural motion | actions in the library format + `rest`, `contacts`, `sounds` | `engine/cartoon/library/actions/` |
| 09 camera shots | `camera.json`: shot sizes by body landmarks, angles (with how to fake each in flat 2D and what needs new drawings), moves, cuts, checkable rules, ~20 shot recipes per story moment | camera helpers + the camera check + the director's shot section |

Each delivery is checked by code before anything is used: valid shape, every id covered, every number in its range, and the
numbers agreeing with each other (lengths add up to the stature, a ratio matches its measures, the `bench` seat equals the
`busStop` seat). One new script, `scripts/world-data-check.mjs <folder>`; no AI.

## What is built here (engine, in this order; each with its no-AI test)

1. **One world scale.** `engine/cartoon/world.js`: a place has a camera height and a horizon; pixels per metre follow from the
   depth, so far is smaller and higher. `put(piece, { x, depth })` in metres; a person's height comes from the cast (age, gender)
   at the same depth. Each piece's drawing is measured once in Chrome (how tall it really draws for its `h`) so metres map
   exactly. Low and high angles come from the horizon line (no new drawings needed).
2. **The world gate** next to the body gate: sizes against each other (a person against a door, a roof, a seat, a vehicle, an
   animal), feet on the ground at their depth, a nearer thing covering a farther one, a person under a roof really under it, no
   rain under a `covers`, and the same positions, sides and light across cuts in one place. Each failure says what to fix.
3. **Bodies for anyone.** Female and male profiles for every age from the chart; thickness per part (arms, legs, torso
   separately, so a woman's arms are thin while her hips are wide); builds that change the body. The proportion test in
   `cartoon-test.mjs`: every age × gender × build inside the chart's cartoon ranges.
4. **A natural rest.** The default stand with soft elbows, two different sides, weight on one leg, breathing. A soft-arm layer
   over every library action that leaves the arms at rest (the old 136 actions keep working). A gate rule: arms held out at the
   camera for over 0.5 s unless the action reaches.
5. **Acting.** `ZC.feel(person, "sad", "strong", at)`: face, body dials and timing together, with notice → change → settle. New
   face dials (one brow, squint, mouth shapes, eye look, blink rate, tears) and body dials (chest, shoulders, weight, breath, tremble).
   Gaze on full bodies: eyes, then head, then chest turn toward a target (a person or a thing).
6. **Shot grammar.** A short section in the director's skill (shot sizes, angles, moves, cuts, the 180° line) and ready
   helpers: frame a person by shot size, over the shoulder between two people, a point of view. A camera check: headroom, lead
   room, eyelines meeting, screen direction (the side rule S1 already exists).

Steps 1, 2 and 4 do not wait for the deliveries; 3, 5 and 6 get their plumbing first and their numbers when the files arrive
(06, 07, 09). Only the recipes go into the director's skill, short; the numbers stay in data the helpers read.

## Status (6 Nov 2026)

- **Done, tested:** 1 world scale (`world.js`, `sizes.json` starter of ~150 parts + standards, `drawn.json` from
  `measure-pieces.mjs`, places carry `P.Z`, people and pieces depth-sorted together), 2 world gate Z1/Z2 (size at depth, feet in the
  sky), 3 bodies from the Brief 6 delivery (14 rows × 3 builds, the measured proportion test), 4 relaxed stand + natural `hold` +
  `ZC.idle` + A1 note. Tests: `world-test`, `film-kit-test` §9–10, `cartoon-test` §0.
- **Brief 6 delivery, judged:** shapes taken; its adult statures (1.57 / 1.69 m, a student sample) and WHO teen heights replaced by
  Bangladeshi national averages (1.51 / 1.64 m) in `sizes.json`. Its extras (`action-timings.json`, `rig-rules.json`) are for
  step 5 and Brief 8.
- **Brief 5 sizes adopted:** all 341 parts + 65 extras (kept for later parts), every source listed (`notes/world-sizes-SOURCES.md`),
  checked and merged by `node scripts/world-data-check.mjs <folder> --merge` (0 problems). National statures 1.65 / 1.53 m; the default
  camera is eye level (1.5 m, floor line at 72% of the frame, above the captions); wall parts mount at their height above the floor.
  Kept ours: the built-in `book` (drawn upright) and `bench` (drawn without a backrest). Its `actionMechanics` (50 verbs → contacts and
  joints), `animalActMechanics` and walking / vehicle speeds are in `sizes.json` standards for the contact work and Brief 8.
- **Step 5 acting, done and tested:** the Brief 7 delivery (64 feelings, 24 transitions, gaze, ages, 40 gesture timings) checked
  (every dial in range, every reference resolved), stored in `engine/cartoon/library/acting.json` (+ Bangla aliases, which it
  lacked), played by `engine/cartoon/acting.js` (`ZC.feel`): resolution defaults → level → age, notice → change → settle with the
  leads order, strong → mild after the hold, transition beats, hands blended over at least 0.5 s, a hand to the face = the card's own
  gesture from the library. New skeleton dials `shoulderLift`, `chestLift`; faces accept dial objects. Tests: `film-kit-test` §11;
  picture: `node scripts/acting-board.mjs <out.jpg> [feelings] [--mild]`. Not yet drawn: one-brow raise, squint, mouth shapes, tears,
  sweat, eye look on full bodies (the face renderers' work), target gaze between people, weight shift; joy/excited fling one arm
  out a little stiffly; grief bends nearly to a bow (review).
- **Step 6 camera, done and tested:** the Brief 9 rule book (11 sizes, 15 angles, 21 moves, 21 cuts, 37 rules, 35 recipes, safe
  zones, Bangladesh rules) stored in `engine/cartoon/library/camera.json`; `engine/cartoon/camera.js`: `ZC.frame` (landmarks read off
  each person's own skeleton; bowed / seated people framed by their standing size), `ZC.twoShot`, `ZC.shotSize` (person-aware: the
  book's head-fraction ladder misreads children), `ZC.shots` frames that follow people with eased pushes. Gate: C1 prayer shot close
  (fault), C2 jump cut, C3 four close-ups in a row, C4 eyes out of the 15–65% band (notes). Director skill §4c, designer skill.
  Tests: `film-kit-test` §12. Kept for later: the other 33 rules (eyelines, headroom by size, joint cuts, horizon consistency, surface
  tops, mirror safety…), the recipes as director data, the platform safe zones vs Zancut's own caption lane (78–92%), new drawings.
- **Brief 8 natural motion, judged and adopted in part:** 166 files; all passed `library-check` (bones, reach, floor on 4 profiles),
  then judged by eye on man / woman / child / elder (notes: `engine/cartoon/library/notes/natural-motion-NOTES.md`). Taken: 91 actions
  (rest idles, feelings, looks, objects, the Bangladesh work and boat actions; `row_boat` replaces ours for its contacts and sounds),
  5 gestures. Feelings and rests had the head dropping 25–34° past the chest (face hidden, a long neck): capped at 18° on adoption,
  and `library-check` now warns past 22°. Not taken: its 22 hand shapes (edits of ours, a few worse), `help_up_a/b` (ours read
  better), `fear_shrink` (leans in, not back), 7 gestures (two-hand ones cross into an X from the front; lantern, placard, belly pat
  miss their target), and all 38 pair files: their contacts are written for two equal adults and our engine does not yet bend an arm
  to a partner's joint, so hands miss (salam, hug, touch feet, lifting a child). They wait for the contact solver.
  Also fixed: the search punished `who: "any"`; the person's own variant of the same move now goes first. The chin shade on the
  full body now follows the rule (soft, under the jaw only, longer when the head bows, none when it looks up, on the throat side in
  profile), not a dark band over the whole neck.
- **Unblocking a film with no AI designer (7 Nov 2026):** (1) search: words.json `phrases` ([pattern, meaning]: "lifts his head" =
  look up, "presses it into his hand" = give…), `who: "any"` fits everyone, a move's modifier ("run_scared") needs its word, the
  person's own variant of the same move goes first; `parts-test` now also demands the right FIRST answer on 57 real film phrases
  (57/57). (2) Hands reach: `b.jointAt(name)`, `b.reach(pose, side, point, w, at)` (arm IK, depth kept, exact to the pixel),
  `ZC.pair(a, b, id, u)` (partner placed by the file, every `partner.<joint>` contact reached, two hands meet halfway, the reach
  arrives by the contact's `from`); the 38 pair files are in the library; `film-kit-test` §13 measures the contacts (< 6% of the
  body). The skeleton is mirrored against the files' left/right; the pair code reads the real side from the shoulders.
  (3) Face: the full-body head draws `browL/R`, `squint`, `wink`, `look`, `tears`, `sweat` and the 15 named mouths (front and side);
  `ZC.feel` passes them through; `ZC.nod` / `ZC.headShake` (head trims). Not yet: the waist-up head (rig.js) has none of them.
  Library gaps found (no drawing exists): spoon, notice board, biriyani pot/plate, bill (paper stands in), for a short brief.
- **Bodies close up (7 Nov 2026, after the owner caught what the gate passed):** the cloth stops at a collar below the neck's base and the neck runs on under it, flatter shoulders, softer stand elbows, no crease dash on bare arms, a smaller lower bag, the three-quarter camera at 8° (level shoes), a floor shadow under every body, the waist-up head has every face dial. Gate C5: a full body framed close is a fault (close shots = `ZC.person`). `film-kit-test` §14 measures the neck above the cloth for four outfits. Tall frames are judged by width too. Before a render: the 30 fps gate, then real frames of each person zoomed in. Not fixed: the three-quarter head is still the front face slid sideways.
- **Open:** the scene reader (no-AI director) and the film kit by code, the waist-up head's new dials, the neck reads long in
  profile, builds read too alike (heavy/thin multipliers are mild; push them for readability), elder stoop invisible from the front,
  legs/pelvis capped at 1.0 until the drape is retuned, leg length by age (toddlers' legs are a little long), the world gate's
  contact / cover / continuity rules, steps 5–6.

- **After the first full film through the customer route (Nov 2026):** 116 s, 22 scenes, $17.30 at API prices, about 95% of a 5-hour window: output $8.80, cache writes $5.05,
  cache reads $3.45; first build $9.65, fix rounds $5.47; 168 edits, about half on hands and arms. 36% of the needs used a found part. Causes, all fixed: the waist-up person could not play
  library moves (`r.pose`), no way to hold a sheet (`ZC.sheet`, named hands), A1 fired on every seated lap, the search offered outdoor pieces indoors and standing moves to seated people, the
  library was optional, conversations ran to 12 scenes (now 3) and scenes to 8 steps (now 6). The next film measures what these saved.

## Later (not in this round)

- **Sound**: library actions now declare their `sounds` (Brief 8); footsteps from the walk cycle by `surface` (Brief 5). An
  ambience-per-place and foley brief comes once those ids exist. Music only from licensed sources.
- **Several views of a piece** (side, back, top) for the pieces people walk around (vehicles, furniture) only, after the world
  scale works; top-down shots last.
- **Clothes by role, season, region and occasion; states (wet, muddy, tired); weather and light on people**: engine work here
  (garments bend with the body), after the new body profiles.

## After the first real film: second round of fixes

- Place search: a shared word ("room", "hall") never brings another room's furniture; a room inside a building never brings the building's
  front; a room with no word list gets `plain room` in `words.json`. New groups: meeting rooms, waiting rooms, cabins, chambers, clinics, shops,
  restaurants, lobbies, corridors, courts, labs, hostels.
- Gemini: every request has a time limit, and a network failure is tried again (`server/gemini.mjs`).
- Hands change shape over three frames, solid: the old hand shrinks behind the new one. A see-through fade showed as a dark ghost beside the hand.
- The storyboard and editor show the full track length when `job.keepTail` is set.
- New parts, made as a separate delivery and put through `library-check`: `noticeBoard`, `whiteboard`, `meetingTable`, `laptopSide`, `weightBench`, `dumbbellRack`, `salonChair`, `bakeryShelf`, `cartonStack`, `metalRack`, `podium`, with real sizes and search words.
