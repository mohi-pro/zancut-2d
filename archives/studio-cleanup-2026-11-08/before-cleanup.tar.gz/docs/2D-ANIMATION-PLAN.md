# 2D Animation: the plan (branch `2d-animation`)

Current direction (2026-11-04): [Authored shots](ANIMATION-AUTHORED-SHOTS.md) supersedes the historical compiler, table lineup, people caps and waist-up restrictions described below. These older implementation notes are history, not current requirements.

A new design system, **2D Animation**: a customer gives a story, a script or just an idea; Zancut writes the
animation script (spoken lines + visual direction), casts the characters and voices, designs the people, animals and
places for that story, acts it out and renders it. Proven by the Rafi film (`~/animated-shorts-test/rafi-homework/video-v3`).

The one decision everything rests on: **the AI does not draw people frame by frame.** Code draws them from one
universal body model with fixed rules; the AI writes data (who, where, what pose, looking at whom, which line). A
checker tests every frame against the rules before anything is rendered, and an independent reviewer looks at every shot.

Work happens in parts, one at a time, each shown to the owner and approved before the next.

---

## Part 1 · Tools: what is new, what is risky

### Already in Zancut (used as is)
| Need | Already there |
|---|---|
| Drawing + motion | SVG + GSAP in the HyperFrames page (`engine/compose/`), `vendor/gsap.min.js` |
| Rendering | `npx hyperframes render` (npm shipped in the desktop apps) |
| Seeing frames | `puppeteer-core` + Chrome, `engine/check-dom.mjs`, the editor's `look` |
| Audio | ffmpeg/ffprobe 9 (bundled for Mac and Windows), loudness, music, `engine/sfx/` |
| AI voices | Gemini TTS in Node, REST (`server/gemini.mjs` `ttsChunk` / `speak`), 30 voices listed |
| Voice with no key | local voices: Kokoro (English), the Bangla onnx model (`server/studio.mjs`) |
| Words and timings | Gemini words + WhisperX (`server/gemini.mjs`, transcriber) |
| Thinking | Claude (Opus director, designers, reviewers) via `@anthropic-ai/claude-agent-sdk` |
| Sounds | `find_sound` (Lots of Sounds / Openverse) + the shared kit |

### New, and all of it is our own code (no new package, no new program)
> Early plan, kept for history. The files named below were replaced: see `CLAUDE.md` and the 2026-11-04 log entry for today's engine.

| New piece | Where | Made from |
|---|---|---|
| Universal body model + rig + IK + body rules | `engine/cartoon/body/` | the Rafi rig, rebuilt as Part 2 |
| Hand library + one-shape arm | `engine/cartoon/hands.js` | `rafi-homework/hands-lab/hands.js` |
| Rule checker (every frame, no AI) | `engine/cartoon/check-body.mjs` | `video-v3/check-rig.mjs` |
| Character / animal / set builder from a spec | `engine/cartoon/build/` | new (Part 3) |
| Scene player: shots, camera, acting keys → page | `engine/cartoon/player.js` | the Rafi `renderAt` |
| Lip-sync from per-line audio | `engine/cartoon/lipsync.mjs` | the Rafi `lipsync.json` step |
| Captions with speaker tags + per-shot placement | `engine/cartoon/captions.mjs` | `gen-captions.mjs` |
| Multi-voice voiceover | `server/voiceover.mjs` | the Python `voiceover-tool`, ported to Node (Part 4) |

### Not needed (considered and dropped)
- **Python, Flask, google-genai** (the voice tool's stack): Zancut already calls Gemini TTS over REST from Node, so the
  voice tool is ported, not shipped. The desktop apps stay as they are.
- **Spine / Rive / Live2D / Lottie**: they animate drawn art; ours is generated per story. Our own SVG rig does it.
- **A physics engine**: gait, jumps and falls are keyed cycles with rules (Part 2), deterministic and seek-safe.
- **Image generation for people**: never consistent from shot to shot; people come from the body model. (Gemini images
  stay possible later for painted backdrops, behind a flag.)

### Risks and what we do about them
| Risk | Answer |
|---|---|
| Desktop builds (Mac + Windows) | No new binaries or packages: `engine/**` and `skills/**` are already in `build.files`. Rebuild both and smoke-test one 2D video per platform before release. |
| Many TTS calls (one per line) hit Gemini limits | Cache per line (hash of text + voice + tone, as the voice tool does), 3 at a time, retry on 429 with the server's wait, the existing `aliveModels` fallback. |
| No Gemini key | Narrator-only on the local voice, or the customer records and marks who speaks where. The CTO reports it. |
| Bangla voice quality | The voices that won the Bangla test (Charon / Orus for men) go first in casting. |
| Render time (big SVG pages) | Characters are built once and only moved (transforms), the way the Rafi film runs; measured per film. |
| Cost (Opus director + animators + reviewer) | One director pass, animators per 10 shots, reviewer on stills; `scripts/usage-report.mjs` on every test film. |
| "১" and other Bangla glyphs too small in Hind Siliguri | Bundle a second Bangla face for numbers (check licence) in Part 3. |

---

## Part 2 · The universal human ("ZanHuman"): one body, fixed rules, every view

One unisex base body. Every person in every film (mother, father, child, grandparent, neighbour, a crowd) is this body
with different numbers, so a fix in the base fixes everyone, and no character can break a joint.

**Skeleton and proportions (in head units, so any age works):** pelvis, spine (3), neck, head; shoulder, upper arm,
forearm, hand (hand library); hip, thigh, shin, foot (foot library: flat, toe-off, heel-strike, tiptoe). Parameters:
age (toddler → elderly sets head-to-body ratio: 1:4 child … 1:7.5 adult), height, build (thin ↔ heavy: limb widths,
belly, chest), shoulder/hip width, posture (upright, stooped).

**Views:** front, 3/4 front, side, 3/4 back, back (and their mirrors). Each body part has a drawing per view; the view is
picked from the body's facing angle, and a turn plays the in-between views (no pop). Turnaround sheet for every character.

**Joint rules (extend R1–R10 into a full table):** every joint's range in degrees (elbow 0–150 one way, knee 0–150 the
other way, wrist ±70/±60 and ±20/30, ankle −20…+45, neck turn ±70 / tilt ±40, spine bend ±30, shoulder …, hip …),
fingers and toes curl one way, bone lengths fixed, feet never slide while planted, hands and feet never pass through the
body, a prop or the ground, centre of mass over the feet when standing.

**Moves as rule-checked cycles:** idle (breathing, weight shift), sit down / stand up, walk, run, jump (crouch → push →
air → land with knees bending), turn, reach, pick up, carry, wave, point, clap, hug, fall and get up. Each cycle: keys
for the hips and feet with contact frames, the arms swing opposite to the legs, timing by build and age (a child's
walk is quicker, an elderly walk slower and shorter).

**Proof before use:** sheets the owner approves (like the hand sheet): turnaround in all views; joint-range sheet; one
loop per move in every view; the same moves on a child, an adult, a heavy adult and an elderly person.
The checker gains: knee and ankle ranges, planted feet not sliding, ground contact, centre of mass.

**Animals** follow the same idea with their own base bodies and rules: four-legged (dog, cat, cow, goat, horse:
proportions differ, gait = walk / trot / gallop), bird (stand, hop, fly), fish. Same views and sheets.

## Part 3 · Characters and places made for each story (no fixed library)

From the script and any visual notes, the director (Opus) writes a **cast sheet** and a **set sheet**:
- a person = base-body parameters + face (shape, eyes, nose, brows, skin tone across the full human range, marks such as
  moles, freckles, lines, glasses, beard) + hair (style drawn per view) + clothes (layers drawn per view: kurti, saree,
  lungi, shirt, school uniform, hijab, cap…) + voice;
- an animal = its base body + coat, colours, size;
- a place = layered SVG drawn for the story (background, middle, foreground in front of the actors), light direction,
  the floor line and where people can stand and sit, props with their grip points.
The designers draw the clothes, hair and places as SVG layers on the rig (code checks they follow the body); the
customer sees the cast and set sheets before anything is animated and can change them.

## Part 4 · The voice tool inside Zancut

Port `~/voice tool/voiceover-tool` to `server/voiceover.mjs` (Node, no Python):
1. **Script → lines:** its extraction prompt and schema (spoken lines only, verbatim; speaker, tone; characters with
   gender, age, acting note, voice), run on Claude (or Gemini flash when the key exists), with the regex parser for
   `**Name — tone:** text` scripts when no AI is needed.
2. **Voice casting:** narrator voice chosen by the customer (male / female / which voice); characters cast by gender and
   age, the acting note adjusting delivery (a child: younger, brighter; elderly: slower). Each voice used once if possible.
3. **Generate:** one TTS call per line through `gemini.mjs` (cache, 3 at a time, retries), lines joined with pauses
   (350 ms same speaker, 600 ms on a change, longer where the visual plan holds a silent beat).
4. **Exact timings for free:** because lines are generated one by one, we know each line's speaker, start and end:
   `voice.json` drives lip-sync per character (mouth from that line's own audio), captions and shot cuts. No guessing
   who speaks.
5. **Edit one line → only that line is redone** (cache), as in the voice tool.
Modes: narrator only · narrator + characters · characters only. No key: local voice or the customer's recording.

## Part 5 · Script and visual direction

The customer gives a story, a script, an idea or notes. Opus writes the **animation script**: the spoken lines in the
voice tool's format, and under each line the visual direction (place, who is in the shot, what they do, the shot size,
inserts such as a phone screen or a page, silent beats where something happens without words, a pause before a reveal).
If the customer gave only a story, Opus plans all of it. The customer sees it as two columns (what we hear / what we
see), edits, approves; only then are voices made. The chat (ZanBro / the script writer, `skills/chat/script.md`,
`idea.md`, `plan.md`) learns the 2D format so a customer can discuss and write 2D scripts there.

## Part 6 · The making process, matched to Zancut

**What the customer sees:** a new card **2D Animation** under design systems (`skills/styles.json`, `ready: false`
until Part 7 passes). Start it inside a project or straight from the home page.

**Steps:** Setup (format, language, narrator voice) → **Script** (Part 5, approve) → **Cast & places** (sheets, approve)
→ **Voice** (listen per line, re-cast or re-do a line, approve) → **Storyboard** (one card per shot with a still; comment on
a shot) → Render → **Review** (timed comments; "redo this shot's acting").

**Behind it:** director (Opus: shots, staging, acting intentions) → animators (acting keys per shot, the hand and move
libraries only) → `check-body` (no AI, every frame) → `look` + the reviewer per shot → fixes in the same animator
conversation → compose → finish (music, loudness). Skill folder `skills/2d-animation/` with the five files + `atoms.css`
+ `cast.md`; `skills/check.md` gains the character checklist. New editor tools: `cast_character`, `design_place`,
`write_acting`, `check_body`, `look_shot`, `assign_voices`. CTO: rule failures and voice fallbacks in its list; desktop
apps send theirs. Tests: `node scripts/check-prompts.mjs`, a new `node scripts/cartoon-test.mjs` (no AI: builds the Rafi film
from data and runs the checker), the real cost with `scripts/usage-report.mjs`.

## Part 7 · Order of work

| # | Milestone | Done when |
|---|---|---|
| 1 | Branch + plan + tool check (this document) | owner approves |
| 2 | `engine/cartoon/` skeleton: the Rafi film rebuilt from data (cast, set, shots, acting, voice JSON) | same film, checker ✓ |
| 3 | ZanHuman front + 3/4 views, joint table, checker extended; sheets | owner approves sheets |
| 4 | Side + back views, turns; walk / run / jump / sit cycles; body variety sheets | owner approves loops |
| 5 | Faces, hair, clothes, skin tones per view; cast sheet builder; animals base | owner approves sheets |
| 6 | Voice tool in Node (`server/voiceover.mjs`), voice casting, `voice.json`, lip-sync from lines | a story voiced end to end |
| 7 | Script + visual direction skill, director and animator skills, tools, reviewer stage | 3 stories made by the AI |
| 8 | App: design system card, script / cast / voice / storyboard screens, chat support | owner tries it in the app |
| 9 | Desktop builds (Mac + Windows) smoke test, CTO checks, cost report | ready: true |

---

## Progress

- **2026-11-03 · Milestone 1 done:** branch, plan, tool check (nothing new to install; the voice tool ports to Node).
- **2026-11-03 · Milestone 2 done:** `engine/cartoon/` = `hands.js` (drawn hands + one-shape arm), `rig.js` (the person,
  rules R1–R10), `acting.js` (acting as data: keys, spans, wobbles, pulses, follow, blinks), `player.js` (shots, camera,
  depth, pose blends), `captions.mjs`, `build.mjs` (film folder → HyperFrames project), `check-body.mjs` (every frame).
  Reference film `engine/cartoon/test/rafi-homework/` (film.json + set.html/set.js + lipsync + words), test
  `node scripts/cartoon-test.mjs`. Quality: snapshots of the data-built film are byte-identical to v3 (md5) at 12 times;
  rendered the Zancut way (`--quality delivery --experimental-fast-capture`, latest HyperFrames) it matches the v3 video
  at 44–49 dB PSNR (encoder noise only) and renders in 37 s. Fonts now come from `engine/fonts` (same Hind Siliguri).
  Still to rebuild: the lip-sync maker (its script was not kept; Part 4 makes lip-sync from per-line voice audio).
- **2026-11-03 · Branch brought up to date:** `origin/main` merged (21 commits: website, backend, `web/` → `studio/`); no conflicts.
- **2026-11-03 · The working flow (first version, testable in the app):**
  - People: `engine/cartoon/people.js` (ZanHuman looks from a spec: gender, age, skin 1–8, build, 8 hair styles incl. hijab
    and cap, 7 outfits, glasses / beard / moustache / bindi / marks); the rig gained `hairBehind`, `overFace`, `overHead`.
    Sheet: `engine/cartoon/lab/cast-sheet.html` (+ `.png`).
  - Places: `engine/cartoon/setkit.js` (room / classroom / shop / outdoor, time of day, things, table props that disappear
    while held; close-ups: phone chat, page, clock, title).
  - Direction: `engine/cartoon/direct.mjs` compiles the animation script (+ voice line times) into film.json: seats behind
    the table, actions (talk, nod, surprised, raise_fists, wave, point, shrug, hold_phone, write…) as hand routes timed by
    distance, side swings only where no neighbour sits, straight-arm elbow switches, gaze, blinks, shots, captions.
    Test story `engine/cartoon/test/sample/` passes every frame.
  - Voice tool, ported (no Python): `server/animation.mjs` voices every line on its own with Zancut's voice
    (`speakScript`, Gemini → local fallback; `speak()` / `speakScript()` now take a character acting `style`), caches each
    line, joins them with pauses, exact line times, word times, lip-sync from each line's own sound.
  - Skill: `skills/2d-animation/script.md` (story → animation script: what we hear / what we see, cast, voices, set, shots).
  - App: design system "2D Animation" (`styles.json`, `kind: "animation"`, opens `#/animation`; never a video's graphics
    style), screen `studio/src/zc/Animation.jsx` (story → script review: cast, voices, lines, shots, actions → make → watch,
    download), sidebar + dashboard entries. API `/api/animation…`.
  - End-to-end test (sample story, real Gemini voices): 9 lines voiced, film built, every frame passed, rendered, 45 s.
- **Not done yet (next):** ZanHuman's side / back / 3/4 views and legs (walk, run, jump, sit cycles) — people are still
  waist-up behind a table, front view; animals; an independent reviewer stage inside the pipeline; inserts drawn by the
  AI per story; more hand poses (cup, hands on hips, arms crossed); desktop builds smoke-tested with a 2D video.
- **2026-11-03 · Inside the normal pipeline (the owner's correction: no separate tab):** 2D Animation is the third video type
  in the Video Editor's Setup (story box, narrator voice, language, size; colours / light-dark / design style hidden).
  Start editing → `server/animpipe.mjs plate()` (planner + a voice per line → `plate/voice.wav` + `voice.words.json`, the
  same files Storytelling's AI voice writes) → the transcript step shows who says what → Storyboard → `animpipe.board()`
  (compile, build into `job/edit/hf` with a `.cartoon` marker, check every frame, one row per shot, stills drawn by
  HyperFrames) → comments on a scene / timed comments → `animpipe.change()` (acting, shots, looks; never the recorded
  words) → `zen finish` renders the built page (compose skipped) → music, loudness, `exports/vN.mp4` → review as usual.
  The separate `#/animation` page, its sidebar entry and its design-system tile were removed. Tested on a throwaway project:
  plate → board (every frame ✓) → 9/9 stills → `zen finish` → export.
- **ZanHuman full body, first pass for approval:** `engine/cartoon/body.js` + `lab/body-sheet.html` (`.png`): one unisex
  body from the front, 3/4, side and back; walk (8 steps), run, jump (crouch, push, air, land); leg rules L1–L6.
  Not used in films yet (people are waist-up behind a table) until the owner approves the sheet.
- **2026-11-03 · 2D Animation in the whole project pipeline (Plan → Script → Voices → Video) and on its own:**
  - A project can be 2D Animation (New Project, Planner, Script Writer: "Kind of video"; who speaks = `animFormat`
    narrator / characters / mixed). The chat skills know it: `skills/chat/plan.md` plans a film (people, place, who
    speaks), `skills/chat/script.md` writes the `animscript` block (scenes, `See:` lines, `NAME (tone): words`), kept as
    written (`server/chat.mjs` saveResult, autopilot).
  - **Text to Dialogue** in the Voice Artist (same screen; "Who reads it": Single voice / Only Narrator / Only Characters /
    Narrator + Characters): `server/animation.mjs castDialogue` (Opus, `skills/2d-animation/dialogue.md`: the script decides
    who speaks when it is clear, the pick is the fallback, a note says why) → distinct voices (`castVoices`) → a voice per
    line (`recordLines`, cached by voice + delivery + words). Takes keep their reading in `voices/<user>/<id>/`; change a
    character's voice → only those lines again. No Claude: a plain reader (`parseDialogue`).
  - Video Editor: from a project the take's lines are reused (`/api/projects/:id/dialogue`, plate/dialogue.json: the
    planner only adds what we see); on its own: language → Script (box + who speaks + narrator male/female) or Voiceover
    (upload; `animpipe.fromRecording` decides who says each sentence). Settings: size, additional files, instructions.
    Trim: play any line, cut lines (`applyTrims` moves the rest up); an uploaded voice uses the normal trimmer.
  - Every text box of these screens has the 🎤 (`MicArea` / `MicInput` in `studio/src/zc/ToolKit.jsx`, the existing Mic).
- **2026-11-03 · The writers are free, the picture is safe (owner: "nothing should be restricted"):** the Planner and the
  Script Writer write any story (any people, places, actions, length up to "more than 5 minutes"). The animation planner
  shows what the engine cannot draw yet the simplest honest way (a close shot, a title insert, the clock, voices off
  screen) and writes `missing` on that line; `tidyScript` collects them into `script.missing`. Up to 4 people are seated
  (the first 4 = the ones who matter most), the rest speak off screen (`offscreen`). 3) Done: each line's `missing` = { part, what }
  (a fixed list of parts); `learn.mjs wantParts` (called by `animpipe.board`) keeps one Admin → Skill adoption item per
  part (key `part-<part>`, the same on every install, so the cloud counts them together), one count per film, with a ready
  Claude Code prompt. Next: 4) 2D Animation change rounds feed the learner (`server/learn.mjs`);
  5) customers' references and new ideas become proposals in Admin to approve.
- **2026-11-04 · The owner's review of the first full film ("very bad") → the production rules (Zancut's 5-module spec):**
  - Skills: planning is brainstorm only (`skills/chat/plan.md`); the script is scene by scene with scene sheets
    (`skills/chat/script.md`, `skills/2d-animation/script.md`: hook, narrator ~70%, silent beats, the 3.5 s rule, B-roll
    for every thing, motion graphics for ideas, badges, rich `see`); the art director `skills/2d-animation/review.md`
    (8 checks on the storyboard stills, fixes the picture, never the recorded lines) runs right after the storyboard
    is built (`animpipe.review`, once; report in `job/work/review.json`).
  - Voices (`server/animation.mjs recordLines`): one locked voice per speaker (the narrator's voice is never a
    character's), each speaker's lines in takes (`gemini.mjs speakTake`, up to 8 lines a call), cut at the silences
    (`sliceTake`), a line too short / long or whose words do not match (WhisperX confidence) recorded again alone, never
    by the local voice (`noLocalVoice`), one TTS model all film (`ttsModel`: pro and flash sound different). Words are
    timed while recording (`plate/aligned.json`), so the transcript step has nothing left to hear. Report:
    `plate/voice-report.json`.
  - Engine: a production script compiles into scenes (`direct.mjs compileFilm`), each its own HyperFrames composition
    (`build.mjs`, ids prefixed per scene): places market / tea_stall / street / office in three layers (blurred lane with
    a walking ZanHuman crowd, the stall, the front), fronts counter / stall / desk / railing with things on them, people
    in spots left / center / right, `enter` / `exit` walks, `front` customers nearer the camera, a second angle on shots
    over 4.5 s, close shots show only whole faces, first-appearance badges, camera push / pan. Motion graphics
    (`engine/cartoon/mg.mjs`, Glossy's atoms.css on Zancut tokens, real 3D emoji): title, compare, price, stat, recap,
    stamp, clock, chat, pay, call, tabletop, each with its sounds (engine/sfx). Captions stay in the lower third in a pill.
    Test film `engine/cartoon/test/jacket-market/script.json` in `node scripts/cartoon-test.mjs`.
  - Not yet: over-the-shoulder views (people are front / 3/4 waist up), hugs and handshakes, animals, vehicles that move.
- **2026-11-04 · One body, a real gate (the owner's review of the rigging):** `anatomy.js` is the only full body (the old 2D body and the compiler's files `build.mjs`, `player.js`, `setkit.js`, `captions.mjs`, `mg.mjs`, `acting.js`, `direct.mjs` are gone); it draws the same head, hair, hijab, glasses and beard as the waist-up person. New postures, a chair without a table, fingers, drawn saree / dupatta / abaya. `check-body.mjs` runs every frame in real Chrome inside the pipeline (`look`, `bodyGate`, `zen finish`). `ZC.clock` redraws on any seek, so stills and checkers see the real frame. `ZC.world` takes the real frame size. An uploaded voice gets a production script (`animpipe.fromRecording`). The director's script includes badges, sounds, captions and gaps, and leaves out trimmed lines. Current flow: `docs/ANIMATION-AUTHORED-SHOTS.md`; the Progress notes above are history.
- **2026-11-04 · The owner's picture corrections, in the engine:** slimmer chest; a thin, short neck with no outline, always behind the head; the hijab hides the neck; the standard heeled shoe with its mouth inside the hem, no foot showing; no coloured hem beside the shoe in side view. Each one is checked in `scripts/cartoon-test.mjs`.
