#!/usr/bin/env node
// Scene joins, the review and the step cap, tested with NO AI (stand-ins for every Claude call):
//   1. a join measured in pixels (server/joins.mjs): a flipped background and an empty start are caught, a carried-on join is not
//   2. the stage carries on (ZK.stage in a headless browser): each scene of a run starts exactly where the last one ended
//   3. the final review is a short fresh conversation on the builders' (cached) system prompt; the old way stays behind a switch
//   4. a scene's steps are capped over every retry; a fix or a change starts its own count
//   5. the real storyboard rules for the ground (tidyStoryboard) end to end, with the plan marking the carried scenes
//   node scripts/continuity-test.mjs
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { registerHooks } from 'node:module';
import { joinScore, joinLine } from '../server/joins.mjs';
import { builderSystem, videoHandoff, tidyStoryboard, parseStoryboard, placeGraphic, jobDir, skillPart, voicePace, graphicBudget } from '../server/director.mjs';
import { openPage } from '../engine/readcheck.mjs';

// Only this test registers the editor's local handlers. Production keeps no-ai.mjs's inert tools and blocked query.
const editorURL = new URL('../server/editor.mjs', import.meta.url).href;
const localTools = `export const tool = (name, description, schema, handler) => ({ name, handler });
export const createSdkMcpServer = ({ tools }) => ({ instance: { _registeredTools: Object.fromEntries(tools.map(t => [t.name, t])) } });`;
const hook = registerHooks({ resolve(specifier, context, next) {
  if (specifier === './no-ai.mjs' && context.parentURL === editorURL) return { url: 'data:text/javascript,' + encodeURIComponent(localTools), shortCircuit: true };
  return next(specifier, context);
} });
const { review, spendStep, stepsLeft, turnsFor, startWork, SCENE_STEPS, desk, applyEdits, runsOf } = await import(editorURL);
hook.deregister();

let n = 0, bad = 0;
const ok = (cond, why) => { n++; if (!cond) { bad++; console.error(`FAIL: ${why}`); } };
const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'zancut-continuity-'));
const ffmpeg = (...a) => { const r = spawnSync('ffmpeg', ['-v', 'error', '-y', ...a]); if (r.status) throw new Error(String(r.stderr)); };

// ---------- 1. joins in pixels ----------
// a frame = a ground colour with a centre shape (a hero), drawn by ffmpeg
const frame = (name, ground, shape) => { const f = path.join(tmp, `${name}.jpg`); ffmpeg('-f', 'lavfi', '-i', `color=c=${ground}:s=270x480`, '-vf', shape ? `drawbox=x=85:y=190:w=100:h=100:color=${shape}:t=fill` : 'null', '-frames:v', '1', f); return f; };
const dark = frame('dark', '0x0b0d14', '0x2dd4bf'), dark2 = frame('dark2', '0x0e1018', '0x2dd4bf'), teal = frame('teal', '0x1f6f6a', '0xffffff'), empty = frame('empty', '0x0b0d14', null);
const same = await joinScore(dark, dark2), flip = await joinScore(dark, teal), blank = await joinScore(dark, empty);
ok(!same.jump && same.ground < 8, `a join that carries on must not jump: ${JSON.stringify(same)}`);
ok(flip.jump && flip.groundJump, `a flipped background must be a ground jump: ${JSON.stringify(flip)}`);
ok(!blank.groundJump && blank.whole > 0 && blank.whole < flip.whole, `a scene that starts empty on the same ground changes the whole frame but not the ground: ${JSON.stringify(blank)}`);
ok(/JUMP: the whole background/.test(joinLine('8→9', flip)) && /carries on/.test(joinLine('1→2', same)), 'the lines for the builder and the lead say what jumped');
// a big hero that vanishes must count as a jump even on the same ground
const big = frame('big', '0x0b0d14', '0xffffff'), bigGone = await joinScore(path.join(tmp, 'big.jpg'), empty);
ok(typeof bigGone.whole === 'number', 'the whole-frame score exists');

// ---------- 2. the stage carries on, in a real page ----------
const HOME = path.resolve(path.dirname(new URL(import.meta.url).pathname), '..', 'engine');
const page = path.join(tmp, 'hf'); fs.mkdirSync(page);
fs.copyFileSync(path.join(HOME, 'vendor', 'gsap.min.js'), path.join(page, 'gsap.min.js'));
const css = fs.readFileSync(path.join(HOME, 'compose', 'runtime.css'), 'utf8'), kit = fs.readFileSync(path.join(HOME, 'compose', 'kit.js'), 'utf8');
const KINDS = ['stage-radial-tint', 'stage-spotlight-cone', 'stage-perspective-floor', 'stage-eclipse-horizon'];
fs.writeFileSync(path.join(page, 'index.html'), `<!doctype html><html><head><meta charset="utf-8"><style>:root{--zk-bg-mid:#1c2a3a;--zk-bg-deep:#0b0d14;--zk-grid:rgba(255,255,255,.08);--zk-a:#2dd4bf;--zk-b:#6366f1;--zk-a-tint:#99f6e4;--u:5.4px}body{margin:0;background:#000}${css}</style></head>
<body><div id="root" data-composition-id="t" data-width="540" data-height="960" style="position:relative;width:540px;height:960px;overflow:hidden">${[0, 1, 2].map((k) => `<section id="s${k}" class="zc" ${k ? `data-carry="${k}" data-from-x="30" data-from-y="60"` : ''} style="position:absolute;inset:0"></section>`).join('')}</div>
<script src="gsap.min.js"></script><script>${kit}</script>
<script>window.__run = function (kind) { var tl = gsap.timeline({ paused: true }); [0, 1, 2].forEach(function (k) { ZK.stage(tl, document.getElementById("s" + k), { kind: kind, t: k * 3, d: 3 }); }); window.__timelines = { main: tl }; window.__tl = tl; }; window.__run('stage-radial-tint');</script></body></html>`);
const o = await openPage(page).catch((e) => { console.error('browser:', e.message); return null; });
if (!o) { console.log('SKIP: the stage test needs the headless browser (puppeteer-core + Chrome)'); } else {
  try {
    for (const kind of KINDS) {
      // each scene starts where the one before ended: the same value at the last frame and the first frame of the next
      const at = await o.page.evaluate((kind) => {
        document.querySelectorAll('.zk-stage').forEach((e) => e.remove()); window.__run(kind);
        const q = (k, sel) => document.querySelector('#s' + k + ' ' + sel);
        const read = (k) => ({ ax: gsap.getProperty(q(k, '.zk-orb.a'), 'x'), ay: gsap.getProperty(q(k, '.zk-orb.a'), 'y'), bx: gsap.getProperty(q(k, '.zk-orb.b'), 'x'), grid: gsap.getProperty(q(k, '.zk-grid'), 'opacity'),
          cone: q(k, '.zk-cone') ? gsap.getProperty(q(k, '.zk-cone'), 'rotation') : null, floor: q(k, '.zk-floor') ? getComputedStyle(q(k, '.zk-floor')).backgroundPositionY : null, ecl: q(k, '.zk-eclipse') ? gsap.getProperty(q(k, '.zk-eclipse'), 'yPercent') : null });
        const out = {}; for (const [k, a, b] of [[0, 2.999, 3.0], [1, 5.999, 6.0]]) { window.__tl.seek(a); out['end' + k] = read(k); window.__tl.seek(b); out['start' + (k + 1)] = read(k + 1); }
        window.__tl.seek(0.001); out.start0 = read(0); window.__tl.seek(2.999); out.end0 = read(0);
        out.orbx = [getComputedStyle(document.querySelector('#s1')).getPropertyValue('--orb-x'), getComputedStyle(document.querySelector('#s0')).getPropertyValue('--orb-x')];
        return out;
      }, kind);
      const near = (a, b, tol = 0.6) => (a == null && b == null) || (typeof a === 'string' ? Math.abs(parseFloat(a) - parseFloat(b)) < 1.5 : Math.abs(a - b) < tol);
      for (const [from, to] of [['end0', 'start1'], ['end1', 'start2']]) for (const f of ['ax', 'ay', 'bx', 'grid', 'cone', 'floor', 'ecl']) ok(near(at[from][f], at[to][f], f === 'grid' ? 0.02 : 0.6), `${kind}: ${f} must carry on across the join (${from} ${at[from][f]} → ${to} ${at[to][f]})`);
      ok(Math.abs(at.start0.ax - at.end0.ax) > 3, `${kind}: the first scene of a run drifts (it is not frozen)`);
      ok(/^\d+(\.\d+)?px$/.test(at.orbx[0]) && Math.abs(parseFloat(at.orbx[0]) - 0.3 * 540) < 1, `${kind}: a carried scene's grid light starts at the anchor's place (${at.orbx[0]})`);
    }
    // the eclipse of a carried scene does not rise again
    const rise = await o.page.evaluate(() => { document.querySelectorAll('.zk-stage').forEach((e) => e.remove()); window.__run('stage-eclipse-horizon'); window.__tl.seek(3.0); const a = gsap.getProperty(document.querySelector('#s1 .zk-eclipse'), 'yPercent'); window.__tl.seek(0.0); const b = gsap.getProperty(document.querySelector('#s0 .zk-eclipse'), 'yPercent'); return [a, b]; });
    ok(rise[0] === 0 && rise[1] === 12, `the eclipse rises once in a run, not at every join: ${rise}`);
  } finally { await o.close(); }
}

// ---------- 3. the final review is fresh and on the builders' system prompt ----------
const p = { id: 't', name: 'T', kind: 'faceless', format: '9:16', theme: 'dark', designStyle: 'glossy', language: 'en', pace: null, mode: 'faceless', footage: [], assets: [], styleMemory: [], prompt: '', instructions: '', transcript: { removed: [], lines: [] } };
const sb = tidyStoryboard(p, parseStoryboard('```json\n' + JSON.stringify({ memory: { mood: 'calm' }, rows: Array.from({ length: 4 }, (_, k) => ({ from: k * 3, to: k * 3 + 2, say: `scene ${k}`, piece: 'custom', archetype: k + 1, bgStage: 'stage-radial-tint', anchorOut: { type: 'orb', xPct: 50, yPct: 50, wPx: 100, hPx: 100 } })) }) + '\n```'), 12);
const calls = [];
const E = { p, sb, extra: { facts: 'F' }, lead: 'LEAD-SESSION', model: 'm', J0: tmp, d: { ws: tmp }, looks: {}, domIssues: new Map(), saved: new Set(), changed: new Map(), lock: (f) => f(), step() {}, job: {}, runQuery: async (prompt, model, opts) => { calls.push({ prompt, model, opts }); return { result: '{"fixes":[]}' }; } };
const sysExpected = `${builderSystem(p)}\n\n${videoHandoff(p, sb, E.extra)}`;
await review(E, E.extra, 'Call look_video once.', 'lead: review');
ok(calls[0].opts.systemPrompt === sysExpected, 'the fresh review must use the builders\' system prompt (so it is read from the cache)');
ok(!calls[0].opts.resume && !calls[0].opts.fork, 'the fresh review must not resume the lead\'s conversation');
ok(calls[0].opts.maxTurns === 5 && /reviewer/.test(String(calls[0].prompt)) && /look_video/.test(String(calls[0].prompt)), 'the fresh review is short (5 turns) and told its role');
ok(calls[0].opts.cache5m === true, 'editor calls use the 5-minute prompt cache');
ok(Object.keys(calls[0].opts.mcp ? { x: 1 } : {}).length === 1 && calls[0].opts.allowed.includes('mcp__zancut__look_video'), 'the reviewer has the look_video tool');
process.env.ZANCUT_REVIEW = 'lead';
await review(E, E.extra, 'Call look_video once.', 'lead: review');
ok(calls[1].opts.resume === 'LEAD-SESSION' && calls[1].opts.maxTurns === 6, 'ZANCUT_REVIEW=lead keeps the old way (a resume of the lead)');
delete process.env.ZANCUT_REVIEW;
process.env.ZANCUT_REVIEW_FORK = '1';
await review(E, E.extra, 'x', 'lead: review');
ok(calls[2].opts.resume === 'LEAD-SESSION' && calls[2].opts.fork === true, 'ZANCUT_REVIEW_FORK=1 reviews on a copy of the lead\'s conversation');
delete process.env.ZANCUT_REVIEW_FORK;

// ---------- 4. a scene's steps over every retry ----------
const cap = SCENE_STEPS();
const F = { p: { editor: {} }, sb, looks: {}, domIssues: new Map(), saved: new Set(), changed: new Map(), lock: (f) => f() };
let used = 0; while (spendStep(F, 0)) used++;
ok(used === cap && stepsLeft(F, 0) === 0, `a scene gets exactly ${cap} steps over all its retries (used ${used})`);
ok(F.p.editor.steps[0] === cap, 'the count is kept on the project, so a stop and a Retry do not give it a fresh allowance');
ok(turnsFor(F, [1]) === 8 + 2 && turnsFor(F, [0]) === 2, `a call gets its usual turns, and the least when nothing is left (${turnsFor(F, [1])}, ${turnsFor(F, [0])})`);
spendStep(F, 1); for (let k = 0; k < cap - 4; k++) spendStep(F, 1);
ok(stepsLeft(F, 1) === 3 && turnsFor(F, [1]) === 4, `a retry gets what is left of the steps, plus one for its answer (${stepsLeft(F, 1)} left, ${turnsFor(F, [1])} turns)`);
startWork(F, [{ i: 0 }, { i: 1, note: 'the carry-on', again: true }]);
ok(stepsLeft(F, 0) === 0 && stepsLeft(F, 1) === 3, 'the first build and a carry-on of a stopped one keep counting');
startWork(F, [{ i: 0, note: 'a fix from the review' }]);
ok(stepsLeft(F, 0) === cap, 'a fix from the review (or a customer change) starts its own count');
// the builder tools say so when it is over
const tools = Object.fromEntries(Object.entries(desk(F, { scenes: [2] }).instance._registeredTools).map(([k, v]) => [k, (a) => (v.handler || v.callback)(a, {})]));
F.p.editor.steps[2] = cap;
const txt = (r) => r.content.map((c) => c.text || '').join(' ');
ok(/used all its steps/.test(txt(await tools.save_scene({ scene: 3, html: '<div></div>' }))), 'save_scene refuses when the scene has used all its steps');
ok(/used all its steps/.test(txt(await tools.edit_scene({ scene: 3, find: 'a', replace: 'b' }))), 'edit_scene refuses when the scene has used all its steps');
ok(/used all its steps/.test(txt(await tools.look({ scene: 3 }))), 'look refuses when the scene has used all its steps');
const leadTools = Object.fromEntries(Object.entries(desk(F, { lead: true }).instance._registeredTools).map(([k, v]) => [k, (a) => (v.handler || v.callback)(a, {})]));
ok(!/used all its steps/.test(txt(await leadTools.save_scene({ scene: 3, html: 'x' }))), 'the lead\'s tools do not spend a scene\'s steps');

// ---------- 5. the ground through the real rules ----------
const R = sb.rows;
ok(R.every((r) => r.bgStage === R[0].bgStage) && R.map((r) => r.groundRun).join() === '0,1,2,3', `four joined scenes keep one ground: ${R.map((r) => `${r.bgStage}/${r.groundRun}`)}`);
ok(R.slice(1).every((r) => r.transition === 'cut' && r.anchorIn), 'and they join on the anchor with a cut');

// ---------- 6. the skill split, multi-edit, runs of joined scenes, a changed pivot ----------
const parted = 'all\n<!-- director -->\nD1\n<!-- graphic -->\nG1\n<!-- both -->\nB1\n<!-- director -->\nD2';
ok(skillPart(parted, 'director', 'both') === 'all\n\nD1\n\nB1\n\nD2' && skillPart(parted, 'graphic', 'both') === 'all\n\nG1\n\nB1', 'each reader gets its own parts of a skill file, and the parts for both');
ok(skillPart('T\n<!-- graphic -->\nG', 'director', 'director') === 'T' && skillPart('T\n<!-- graphic -->\nG', 'graphic', 'director') === 'G', 'a video type file: the director part before the marker, the builder part after');
const ed = applyEdits('<a>1</a><b>2</b>', [{ find: '<a>1', replace: '<a>9' }, { find: '9</a>', replace: '8</a>' }]);
ok(ed.html === '<a>8</a><b>2</b>', `several replacements in one edit, applied in order (${ed.html})`);
ok(/appears 2 times/.test(applyEdits('xx', [{ find: 'x', replace: 'y' }]).error || '') && /not in the file/.test(applyEdits('abc', [{ find: 'a', replace: 'b' }, { find: 'zzz', replace: 'q' }]).error || ''), 'an edit that does not match exactly once stops it and nothing is saved');
const RW = { sb: { rows: [{ piece: 'custom', groundRun: 0, transition: 'cut' }, { piece: 'custom', groundRun: 1, transition: 'cut' }, { piece: 'custom', groundRun: 2, transition: 'cut' }, { piece: 'custom', groundRun: 0, transition: 'blur', pivot: true }, { piece: 'custom', groundRun: 1, transition: 'cut' }, { piece: 'speaker' }, { piece: 'custom', groundRun: 0, transition: 'zoom-blur' }] } };
const runs = runsOf(RW, [0, 1, 2, 3, 4, 6].map((i) => ({ i })), 4).map((c) => c.map((x) => x.i).join(','));
ok(runs.join(' | ') === '0,1,2 | 3,4,6', `scenes go to designers in order, split evenly at a pivot, never inside a joined run (${runs.join(' | ')})`);
ok(runsOf(RW, [0, 1, 2].map((i) => ({ i })), 2).map((c) => c.length).join() === '2,1', 'a long run is cut at the designer limit');
ok(runsOf(RW, [0, 1, 2, 3, 4, 6].map((i) => ({ i }))).length === 1, 'a short video is one designer');
// change_scenes on a pivot keeps it a pivot (its own transition, no anchor); a speaker turned graphic joins and takes the ground
{
  const W = path.join(tmp, 'cs'); fs.mkdirSync(path.join(W, 'work'), { recursive: true });
  const rows = Array.from({ length: 5 }, (_, k) => ({ from: k * 3, to: k * 3 + 2, say: 's' + k, piece: k === 4 ? 'speaker' : 'custom', archetype: k + 1, bgStage: k === 3 ? 'stage-eclipse-horizon' : 'stage-radial-tint', anchorOut: { type: 'orb', xPct: 50, yPct: 50, wPx: 100, hPx: 100 }, ...(k === 3 ? { pivot: true } : {}) }));
  const pt = { ...p, kind: 'talking', mode: 'face', footage: [{ file: 'a.mov', duration: 9 }] };
  const S = tidyStoryboard(pt, parseStoryboard('```json\n' + JSON.stringify({ rows }) + '\n```'), 15);
  const C = { p: pt, sb: S, J0: W, changed: new Map(), looks: {}, saved: new Set(), domIssues: new Map(), lock: (f) => f() };
  const t = desk(C, { lead: true }).instance._registeredTools.change_scenes;
  await (t.handler || t.callback)({ json: JSON.stringify({ 4: { ...S.rows[3], design: 'new', change: 'x' } }) }, {});
  const r4 = C.sb.rows[3];
  ok(r4.pivot === true && r4.transition !== 'cut' && !r4.anchorIn && r4.bgStage === 'stage-eclipse-horizon', `a changed pivot stays a pivot: ${JSON.stringify([r4.transition, !!r4.anchorIn, r4.bgStage])}`);
  ok(S.rows[4]?.piece === 'speaker', 'the talking-head test row is a speaker row');
  {
    await (t.handler || t.callback)({ json: JSON.stringify({ 5: { ...S.rows[4], piece: 'custom', thMode: 'full-broll-takeover', bgStage: 'stage-spotlight-cone', change: 'make it a graphic' } }) }, {});
    const r5 = C.sb.rows[4];
    ok(r5.piece === 'custom' && r5.anchorIn && r5.transition === 'cut' && r5.bgStage === C.sb.rows[3].bgStage && r5.groundRun === (C.sb.rows[3].groundRun || 0) + 1, `a speaker turned graphic joins on the anchor and carries the ground: ${JSON.stringify([r5.transition, !!r5.anchorIn, r5.bgStage, r5.groundRun])}`);
  }
}

// ---------- 7. the voice sets the pace ----------
{
  const say = (texts, rateSecs, pauseAfter = {}) => { let t = 0; return texts.map((x, i) => { const w = { text: x, start: t, end: t + rateSecs * 0.8 }; t += rateSecs + (pauseAfter[i] || 0); return w; }); };
  const calm = voicePace(say(['one', 'two', 'three', 'four.', 'five', 'six', 'seven', 'eight', 'nine?', 'ten', 'eleven', 'twelve'], 0.5));
  ok(calm.feel === 'calm' && calm.ends.join() === '3,8' && calm.rate < 2.4, `a calm voice: its sentence ends are the only places a scene may end (${JSON.stringify({ feel: calm.feel, ends: calm.ends, rate: calm.rate })})`);
  const noPunct = voicePace(say(['a', 'b', 'c', 'd', 'e', 'f'], 0.25, { 2: 0.5 }));
  ok(noPunct.ends.join() === '2' && noPunct.feel === 'brisk', `without punctuation a clear pause ends a sentence (${JSON.stringify(noPunct)})`);
  const pf = { ...p, kind: 'faceless' };
  ok(graphicBudget(pf, 60, null, 2.0) === 10 && graphicBudget(pf, 60, null, 3.2) === 14 && graphicBudget({ ...pf, pace: 'calm' }, 60, null, 2.0) === 8, `a slower voice and a calm pace get fewer, longer scenes (${[graphicBudget(pf, 60, null, 2.0), graphicBudget(pf, 60, null, 3.2), graphicBudget({ ...pf, pace: 'calm' }, 60, null, 2.0)]})`);
  const calmRows = tidyStoryboard(p, parseStoryboard('```json\n' + JSON.stringify({ video: { mood: 'calm, caring' }, rows: [{ from: 0, to: 4, piece: 'custom', archetype: 1, bgStage: 'stage-radial-tint', wordLocks: [0, 1, 2, 3, 4].map((w) => ({ word: w, event: 'x' })) }, { from: 5, to: 9, piece: 'stock-photo', stock: { search: 'x' } }, { from: 10, to: 14, piece: 'custom', archetype: 2, bgStage: 'stage-spotlight-cone' }, { from: 15, to: 19, piece: 'stock-photo', stock: { search: 'x' } }, { from: 20, to: 24, piece: 'custom', archetype: 3, bgStage: 'stage-radial-tint' }] }) + '\n```'), 25).rows;
  ok(calmRows[0].wordLocks.length === 5, 'the director\'s word locks stay as it wrote them (code only stops a runaway above 8)');
  const chosen = tidyStoryboard(p, parseStoryboard('```json\n' + JSON.stringify({ video: { mood: 'calm' }, rows: [{ from: 0, to: 4, piece: 'custom', archetype: 2, bgStage: 'stage-radial-tint' }, { from: 5, to: 9, piece: 'stock-photo', stock: { search: 'x' } }, { from: 10, to: 14, piece: 'custom', archetype: 2, bgStage: 'stage-radial-tint', transition: 'zoom-blur', rise: true }] }) + '\n```'), 15);
  ok(chosen.rows[2].transition === 'zoom-blur' && chosen.rows[2].rise === true && chosen.rows[2].archetype === 2 && chosen.rows[2].bgStage === 'stage-radial-tint', `the director's own choices stay: transition, riser mark, archetype, stage (${JSON.stringify(chosen.rows[2])})`);
  ok(chosen.v === 3, 'a storyboard planned now carries its version (the engine then places risers only where the director marked)');
  ok(calmRows.filter((r, i) => i > 0).every((r) => r.transition === 'blur'), `a calm video changes scenes with the soft blur only (${calmRows.map((r) => r.transition)})`);
}

// the plan marks the carried scenes (the page reads it): how many scenes into the run, and where the anchor is
const ws = path.join(tmp, 'ws'), J0 = jobDir(ws); fs.mkdirSync(path.join(J0, 'edit'), { recursive: true }); fs.mkdirSync(path.join(J0, 'work'), { recursive: true }); fs.mkdirSync(path.join(J0, 'graphics'), { recursive: true });
fs.writeFileSync(path.join(J0, 'graphics', 'g.html'), '<div class="gx-a">x</div><style>.gx-a{color:red}</style><script>ZK.unit(root);</script><!--cues []-->');
fs.writeFileSync(path.join(J0, 'edit', 'plan.json'), JSON.stringify({ scenes: sb.rows.map((r, row) => ({ row, uid: `u${row}`, carry: 9, carryFrom: { x: 1, y: 1 } })) }));
placeGraphic({ ws }, p, sb, 0, 'graphics/g.html', 3); placeGraphic({ ws }, p, sb, 2, 'graphics/g.html', 3);
const plan = JSON.parse(fs.readFileSync(path.join(J0, 'edit', 'plan.json'), 'utf8')).scenes;
ok(plan[0].carry === undefined && plan[0].carryFrom === undefined, 'the first scene of a run is not marked as carried (and an old mark is cleared)');
ok(plan[2].carry === 2 && plan[2].carryFrom.x === sb.rows[2].anchorIn.xPct && plan[2].carryFrom.y === sb.rows[2].anchorIn.yPct, `a carried scene is marked in the plan with its run number and the anchor's place: ${JSON.stringify([plan[2].carry, plan[2].carryFrom])}`);

fs.rmSync(tmp, { recursive: true, force: true });
console.log(bad ? `${bad} of ${n} checks FAILED` : `ok: ${n} checks, no AI used`);
process.exit(bad ? 1 : 0);
