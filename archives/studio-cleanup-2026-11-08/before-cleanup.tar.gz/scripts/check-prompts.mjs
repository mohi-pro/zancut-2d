// Checks that every setup choice a customer can make reaches the AI's tasks, for every combination, and that code keeps
// the storyboard to the skill's hard rules. Run after changing a skill, a prompt or a setup option:
//   node scripts/check-prompts.mjs
// Exits 1 on the first problem, printing the combination and the prompt.
import fs from 'node:fs';
import path from 'node:path';
import { directorSystem, builderSystem, skillPart, videoHandoff, leadPrompt, builtPrompt, changePrompt, sceneTask, tidyStoryboard, parseStoryboard, cuesOf } from '../server/director.mjs';
import { tokensFor, styleSystem, palettes, FORMATS, KINDS, PACES } from '../server/studio.mjs';
import { SKILLS_DIR } from '../server/config.mjs';

let checks = 0;
const die = (why, c, out = '') => { console.error(`FAIL: ${why}\n${c ? `Options: ${JSON.stringify(c)}\n` : ''}${out ? `---\n${out.slice(0, 4000)}` : ''}`); process.exit(1); };
const ok = (cond, why, c, out) => { checks++; if (!cond) die(why, c, out); };

// ---------- the skill folders: every ready design system has its five files ----------
const SIX = ['core-director', 'core-graphic', 'talking-head', 'storytelling', 'interview-broll'];
const ready = styleSystem().list.filter((x) => x.ready);
ok(ready.length > 0, 'no design system is ready (skills/styles.json)');
// a design system with its own screen (kind "animation": 2D Animation) has its own skill instead of the five files
for (const st of ready.filter((x) => x.kind === 'animation')) ok(fs.existsSync(path.join(SKILLS_DIR, st.id, 'script.md')), `skills/${st.id}/script.md is missing`);
for (const st of ready.filter((x) => x.kind === 'animation')) ok(/## Who speaks/.test(fs.existsSync(path.join(SKILLS_DIR, st.id, 'dialogue.md')) ? fs.readFileSync(path.join(SKILLS_DIR, st.id, 'dialogue.md'), 'utf8') : ''), `skills/${st.id}/dialogue.md (Text to Dialogue, its "## Who speaks" rule) is missing`);
for (const st of ready.filter((x) => !x.kind)) {
  for (const f of SIX) ok(fs.existsSync(path.join(SKILLS_DIR, st.id, `${f}.md`)), `skills/${st.id}/${f}.md is missing`);
  for (const f of SIX.slice(2)) ok(fs.readFileSync(path.join(SKILLS_DIR, st.id, `${f}.md`), 'utf8').includes('<!-- graphic -->'), `skills/${st.id}/${f}.md has no <!-- graphic --> part for the motion designer`);
  if (st.inspiration) ok(fs.existsSync(path.join(SKILLS_DIR, '..', st.inspiration)), `${st.inspiration} is missing`);
  for (const f of Object.values(st.preview || {})) ok(fs.existsSync(path.join(SKILLS_DIR, '..', f)), `${f} (the ${st.id} preview video) is missing`);
}
ok(fs.readFileSync(path.join(SKILLS_DIR, 'check.md'), 'utf8').length > 200, 'skills/check.md (the art director) is empty');

// ---------- every combination of the setup ----------
const DIMENSIONS = {
  designStyle: ready.filter((x) => !x.kind).map((x) => x.id), // (2D Animation has its own screen, not a video graphics style)
  kind: Object.keys(KINDS).filter((k) => k !== 'animation'), // Animation has dedicated shot-director/designer skills, checked by animation-direction-test.mjs
  format: Object.keys(FORMATS),
  theme: ['light', 'dark'],
  palette: [null, palettes().at(-1)?.id],
  language: ['en', 'bn'],
  pace: [null, 'fast'],
  media: [false, true],
  notes: [false, true],
  styleMemory: [[], ['Prefers bigger captions placed low']],
};
const WORDS = 'আজকে আমরা দেখবো AI কীভাবে তোমার income তিনগুণ করতে পারে মাত্র ৩০ দিনে'.split(' ').map((text, i) => ({ text, start: i * 0.4, end: i * 0.4 + 0.3 }));
const TYPE = { talking: 'talking-head', faceless: 'storytelling', interview: 'interview-broll' };
const skill = (st, f) => fs.readFileSync(path.join(SKILLS_DIR, st, `${f}.md`), 'utf8');
const firstLine = (s) => s.trim().split('\n')[0];
// a line only that file has, to prove the right files (and only them) reach each task
const directorLine = (st, f) => firstLine(skillPart(skill(st, f), 'director', 'director'));
// the first real sentence of the builder's part (headings like "## Your scene" are shared by several files)
const graphicLine = (st, f) => skillPart(skill(st, f), 'graphic', 'director').split('\n').map((l) => l.trim()).find((l) => l.length > 24 && !l.startsWith('#')) || '';

function build(c) {
  const assets = c.media ? [{ file: 'photo0.jpg', role: 'image', note: 'Show this when I say income' }, { file: 'clip0.mp4', role: 'broll', duration: 6, note: '' }] : [];
  return {
    id: 'test', name: 'Test video', kind: c.kind, format: c.format, theme: c.theme, palette: c.palette, designStyle: c.designStyle, language: c.language, pace: c.pace,
    prompt: 'ORDER-WANT: a calm video', instructions: 'ORDER-ONE: never use red\nORDER-TWO: when I say income show money',
    mode: c.kind === 'faceless' ? 'faceless' : 'face', footage: c.kind === 'faceless' ? [] : [{ file: 'take1.mov', duration: 6 }], assets, styleMemory: c.styleMemory,
    transcript: { removed: [], lines: [{ from: 0, to: 8, hint: c.notes ? 'make it go boom' : '', file: c.notes && c.media ? 'photo0.jpg' : null }, { from: 9, to: 13, hint: '' }] },
  };
}
function verify(c) {
  const p = build(c), T = tokensFor(p), st = c.designStyle, own = TYPE[c.kind];
  const pose = { type: 'card', xPct: 50, yPct: 40, wPx: 400, hPx: 120, color: 'var(--zk-a)', scale: 1 };
  const sb = { memory: { look: 'glass' }, rows: [
    { from: 0, to: 6, say: 'আজকে আমরা দেখবো AI', piece: 'custom', archetype: 2, bgStage: 'stage-radial-tint', anchorOut: pose },
    { from: 7, to: 13, say: 'income তিনগুণ', piece: 'custom', archetype: 3, bgStage: 'stage-spotlight-cone', anchorIn: pose }] };
  const ctx = { n: 2, secs: 2.8, sceneWords: [{ i: 7, w: 'income', at: 0.1 }, { i: 9, w: 'তিনগুণ', at: 0.9, isEmphasis: true }], zones: { right: [540, 0, 540, 1920] }, holdOut: false, note: 'Move the card above the face.', current: '<div class="gx-a"></div>' };
  const r = { ...sb.rows[1], wordLocks: [{ word: 9, event: 'the number lands' }], metaphor: 'a coin stack triples' };
  // the system prompt holds the skill (every editor call, cached); the messages hold this video (no skill text in them)
  const tasks = [['director system', directorSystem(p)], ['builder system', builderSystem(p)], ['lead', leadPrompt(p, '# Brief', { words: WORDS })], ['built', builtPrompt(p, '# Brief', sb, { words: WORDS })],
    ['change', changePrompt(p, sb, [{ where: 'scene 2', text: 'make it calmer', image: true, attach: [{ file: 'logo.png', role: 'image', name: 'Logo' }, { file: 'clip.mp4', role: 'broll', name: 'Clip', duration: 4.2 }, { file: 'ding.mp3', role: 'sound', name: 'Ding', duration: 1.2 }] }])], ['scene', sceneTask(p, r, ctx)], ['handoff', videoHandoff(p, sb, { facts: 'The price is 500 taka.' })]];
  for (const [what, out] of tasks) {
    if (what === 'handoff') {
      ok(out.includes("## The customer's setup") && out.includes(T['--zk-a']), 'handoff: the setup and colours a builder needs', c, out);
      ok(out.includes('1. graphic') && out.includes('2. graphic') && out.includes('"look":"glass"'), 'handoff: every scene in one line and the memory card', c, out);
      ok(out.includes('500 taka'), 'handoff: the facts from the customer files', c, out);
      ok(!out.includes('The 20 compositional mechanics'), 'handoff: no skill text (the skill is the system prompt before it)', c, out);
      for (const bad of ['undefined', '[object', 'NaN', '<!-- graphic -->']) ok(!out.includes(bad), `handoff: broken value (unexpected "${bad}")`, c, out);
      continue;
    }
    const has = (s, why) => ok(out.includes(s), `${what}: ${why} (missing "${s}")`, c, out);
    const not = (s, why) => ok(!out.includes(s), `${what}: ${why} (unexpected "${s}")`, c, out);
    for (const bad of ['undefined', '[object', 'NaN', 'MG-0', 'CAP-0']) not(bad, 'broken value or a library leftover');
    for (const m of ['<!-- graphic -->', '<!-- director -->', '<!-- both -->']) not(m, 'a skill split marker leaked');
    if (what.endsWith('system')) {
      // each reader gets its own parts of the skill, and only those
      const dir = what === 'director system';
      has(firstLine(fs.readFileSync(path.join(SKILLS_DIR, 'check.md'), 'utf8')), 'skills/check.md (the checks)');
      has('The 20 compositional mechanics', 'the shared making playbook (read by both)'); has('Zancut 4-Pass Sound System', 'the shared sound system');
      not("## The customer's setup", 'this video in the cached system prompt'); not(T['--zk-a'], 'the colour theme in the cached system prompt');
      for (const f of Object.values(TYPE)) if (f !== own && f !== 'interview-broll') { not(directorLine(st, f), `${f}.md (another type)`); not(graphicLine(st, f), `${f}.md (another type)`); }
      if (dir) {
        has(firstLine(skill(st, 'core-director')), 'core-director.md'); not(firstLine(skill(st, 'core-graphic')), 'core-graphic.md (the builder\'s)');
        has(directorLine(st, own), `the director part of ${own}.md`); not(graphicLine(st, own), `the graphic part of ${own}.md (the builder's)`);
        has('A person on camera', "the playbook's directing part"); not('How the scene file carries it out', "the playbook's building part"); not('ONE html file', 'the scene file contract (the builder\'s)');
        has('save_storyboard', 'the director\'s tools');
        if (c.media && own !== 'interview-broll') has("The customer's own pictures and clips", 'how to place the customer\'s pictures and clips');
        ok(out.indexOf(firstLine(skill(st, 'core-director'))) < out.indexOf('The 20 compositional mechanics'), 'the design system must come before the shared playbook', c, out);
      } else {
        has(firstLine(skill(st, 'core-graphic')), 'core-graphic.md'); not(firstLine(skill(st, 'core-director')), 'core-director.md (the director\'s)');
        has(graphicLine(st, own), `the graphic part of ${own}.md`); not(directorLine(st, own), `the director part of ${own}.md (the director's)`);
        has('How the scene file carries it out', "the playbook's building part"); not('A person on camera', "the playbook's directing part");
        has('ONE html file', 'the scene file contract'); has('How you place sound', 'the sound cue rules'); has('Ready parts', 'the ready parts of the design system');
        ok(out.indexOf(firstLine(skill(st, 'core-graphic'))) < out.indexOf('The 20 compositional mechanics'), 'the design system must come before the shared playbook', c, out);
      }
      continue;
    }
    not(firstLine(skill(st, 'core-director')), 'the skill outside the system prompt (it is paid again, uncached)');
    if (what === 'change') { has('make it calmer', "the customer's note"); has('their drawing follows', 'their drawing'); has('"n":2', 'the storyboard as built'); has('change_scenes', 'the tool to answer with'); has('assets/mine/logo.png', 'the attached picture'); has('assets/mine/clip.mp4', 'the attached clip'); has('"sound": {"file":"ding.mp3"', 'the attached sound'); continue; }
    if (what === 'scene') {
      has(c.theme.toUpperCase(), 'light or dark'); has(T['--zk-a'], 'the colour theme accent');
      has('0.10s "income"', 'scene-relative word times'); has('0.90s "তিনগুণ" ★', 'emphasis words'); has('at(0.90) "তিনগুণ" → the number lands', 'word locks');
      has('"xPct":50', 'the anchor pose'); has('Move the card above the face.', 'what to change'); has('<div class="gx-a"></div>', 'the scene file now'); has('a coin stack triples', 'the metaphor');
      has('ONE edit_scene call', 'the save-and-fix loop'); has('real frames', 'the frames come back with every save'); has('ORDER-ONE: never use red', 'the orders reach the scene builder');
      if (c.notes) has('make it go boom', "the customer's line note");
      continue;
    }
    has(T['--zk-a'], 'the colour theme accent'); has(c.theme.toUpperCase(), 'light or dark');
    has(FORMATS[c.format].label, 'the frame'); has(KINDS[c.kind].label, 'the video type'); has(c.language === 'bn' ? 'Bangla' : 'English', 'the language');
    has(PACES[c.pace || 'normal'], 'the pace');
    if (c.styleMemory.length) has(c.styleMemory[0], "the customer's taste");
    if (c.media) { has('assets/mine/photo0.jpg', "the customer's picture"); has('Show this when I say income', "the picture's note"); }
    if (c.notes) has('make it go boom', "the customer's line note");
    has('ORDER-WANT: a calm video', "the customer's wish"); has('ORDER-TWO: when I say income show money', 'the Prompt of orders'); has('follow every line exactly', 'the orders are called orders');
    if (what === 'lead') {
      has(c.kind === 'faceless' ? '"mode": "full-broll-takeover"' : '"thMode"', 'the layout modes for this type');
      if (c.kind === 'interview') not('popout-box-split', 'an interview has no pop-out');
      has('save_storyboard', 'the tool to answer with');
    } else { has('"say":"income তিনগুণ"', 'the storyboard as built'); not('call save_storyboard', 'a built video is not planned again'); }
  }
}
const keys = Object.keys(DIMENSIONS);
let combos = 0;
(function walk(i, c) {
  if (i === keys.length) { verify(c); combos++; return; }
  for (const v of DIMENSIONS[keys[i]]) walk(i + 1, { ...c, [keys[i]]: v });
})(0, {});

// ---------- colour tokens: every role exists, in both themes ----------
for (const theme of ['light', 'dark']) for (const pal of palettes()) {
  const T = tokensFor({ theme, palette: pal.id });
  for (const k of ['--zk-a', '--zk-b', '--zk-c', '--zk-pos', '--zk-neg', '--zk-bg-deep', '--zk-bg-mid', '--zk-glass', '--zk-ink', '--zk-mute', '--zk-line', '--zk-grid']) ok(typeof T[k] === 'string' && T[k].length > 3, `token ${k} missing for ${pal.id} ${theme}`);
}

// ---------- code keeps the storyboard to the hard rules ----------
const p = build({ kind: 'talking', format: '9:16', theme: 'dark', designStyle: ready[0].id, language: 'en', styleMemory: [], media: false, notes: false });
const raw = parseStoryboard('```json\n' + JSON.stringify({ rows: [
  { from: 2, to: 6, piece: 'custom', archetype: 4, bgStage: 'stage-radial-tint', anchorOut: { type: 'orb', xPct: 30, yPct: 30, wPx: 80, hPx: 80 } },
  { from: 5, to: 9, piece: 'custom', archetype: 4, bgStage: 'stage-radial-tint', anchorIn: { xPct: 'x' }, wordLocks: [{ word: 7, event: 'x' }, { word: 40, event: 'outside' }] },
  { from: 10, to: 11, piece: 'speaker', thMode: 'speaker' }] }) + '\n```');
ok(raw, 'parseStoryboard read nothing');
const R = tidyStoryboard(p, raw, 14).rows;
ok(R[0].from === 0 && R.at(-1).to === 13, `rows must cover every word from the first to the last: ${JSON.stringify(R.map((x) => [x.from, x.to]))}`);
for (let i = 1; i < R.length; i++) ok(R[i].from === R[i - 1].to + 1, `rows ${i} and ${i + 1} must follow each other with no gap or overlap: ${JSON.stringify(R.map((x) => [x.from, x.to]))}`);
ok(R[1].bgStage === R[0].bgStage && R[1].groundRun === 1 && R[0].groundRun === 0, 'scenes joined on an anchor must keep ONE ground (the stage carried on)');
// a pivot: the ground changes only there, after a run of 3 scenes, with a visible transition and no anchor
const chain = (n, extra = {}) => tidyStoryboard(p, parseStoryboard('```json\n' + JSON.stringify({ rows: Array.from({ length: n }, (_, k) => ({ from: k * 3, to: k * 3 + 2, piece: 'custom', archetype: (k % 7) + 1, bgStage: k === 0 ? 'stage-eclipse-horizon' : 'stage-elevated-wash', anchorOut: { type: 'orb', xPct: 40 + k, yPct: 50, wPx: 100, hPx: 100, look: 'a clear glass orb' }, ...(extra[k] || {}) })) }) + '\n```'), n * 3).rows;
const C = chain(6, { 3: { pivot: true, bgStage: 'stage-eclipse-horizon' }, 1: { pivot: true } });
ok(C.map((r) => r.groundRun).join() === '0,0,1,0,1,2' && C[2].bgStage === C[1].bgStage && C[1].bgStage !== C[0].bgStage, `a run keeps one ground and restarts its count at each pivot the director marks: ${C.map((r) => r.groundRun)}`);
ok(C[1].pivot === true && !C[1].anchorIn && C[1].transition !== 'cut', 'a pivot the director marks is honoured wherever it falls');
ok(C[3].pivot === true && C[3].bgStage !== C[2].bgStage && C[3].anchorIn === null && C[3].transition !== 'cut', `a pivot changes the ground with a visible transition and no anchor: ${JSON.stringify([C[3].bgStage, C[3].transition, C[3].anchorIn])}`);
ok(C[4].bgStage === C[3].bgStage, 'the scenes after a pivot keep the new ground');
ok(C[2].anchorIn?.look === 'a clear glass orb', 'an anchor pose keeps its look line');
const sp = tidyStoryboard(p, parseStoryboard('```json\n' + JSON.stringify({ rows: [{ from: 0, to: 2, piece: 'custom', archetype: 1, bgStage: 'stage-radial-tint' }, { from: 3, to: 5, piece: 'speaker', thMode: 'speaker' }, { from: 6, to: 8, piece: 'custom', archetype: 2, bgStage: 'stage-radial-tint' }] }) + '\n```'), 9).rows;
ok(sp[2].groundRun === 0, 'after a speaker row a graphic starts a new run');
ok(R[1].archetype === R[0].archetype, 'the director\'s archetype stays as it chose it (code no longer swaps it)');
ok(JSON.stringify(R[1].anchorIn) === JSON.stringify(R[0].anchorOut) && R[1].transition === 'cut', 'a graphic-to-graphic join must start from the last anchor with a cut');
ok(R[1].wordLocks.length === 1, 'a word lock outside its row must be dropped');
ok(cuesOf('<!--cues [["wh-deep",0.6],["boom",1],["tx-shimmer",9]]-->', 3).every((x) => x[0] !== 'boom' && x[1] < 3), 'sound cues: only kit families inside the scene');
const cs = cuesOf('<!--cues [["tx-reward",0.5],["rs-bass",1.2],["hit",1.2],["wh-soft",0.1]]-->', 3).map((x) => x[0]);
ok(cs.includes('tx-success') && cs.includes('rs-bass') && cs.includes('hit') && cs.includes('wh-wind'), `sound cues: pack names map to the kit and risers/hits are allowed (${cs})`);

// the 2D picture rules reach everyone who writes or judges a film, for every person (not one film's cast)
{ const anim = { kind: 'animation', studio: { format: '9:16', design: '2d-animation' }, assets: [] }, read = (f) => fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', f), 'utf8');
  for (const [who, text] of [['designers', builderSystem(anim)], ['director', directorSystem(anim)]]) for (const rule of ['No outlines on any body part', 'Shoulders slope', 'A raised hand', 'Carried bag', 'every human']) ok(text.includes(rule), `2D ${who} get the rule: ${rule}`);
  ok(builderSystem(anim).includes('ZC.fingerUp()') && builderSystem(anim).includes('bag: { color }'), '2D designers are told how to raise a finger and carry a bag');
  for (const rule of ['Knees and elbows bend only the natural way', 'head turn ±75°', 'four fingers and a thumb', 'hips on a real seat', 'stays in its hand', 'A hard cut changes the camera', 'waist-up person']) ok(builderSystem(anim).includes(rule), `2D designers get the strict rule: ${rule}`);
  ok(/"bag": \{ "color"/.test(read('script.md')), 'the planner can give any person a bag');
  ok(/drawn by hand/.test(read('review.md')) && /a dark outline on a body/.test(read('review.md')), 'the reviewer sends back hand-drawn parts and body outlines'); }

console.log(`ok: ${checks} checks over ${combos} setup combinations`);
