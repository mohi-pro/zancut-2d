#!/usr/bin/env node
// A voice take is cut into its lines where the words end, even when the voice pauses longer inside a line than between lines (no AI).
import assert from 'node:assert/strict';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { sliceTake, lineEnds, holdsLine } from '../server/animation.mjs';
const RATE = 24000;
// sound / quiet in seconds: [speech, pause, speech, pause, …]
const track = (parts) => { const n = Math.round(parts.reduce((a, b) => a + b, 0) * RATE), p = new Int16Array(n); let at = 0; parts.forEach((d, k) => { const e = at + Math.round(d * RATE); if (k % 2 === 0) for (let i = at; i < e; i++) p[i] = 9000 * Math.sin(i / 9); at = e; }); return p; };
const secs = (seg) => seg.pcm.length / RATE;
// line 1 = 2 sentences with a LONG pause inside (0.9 s), then only 0.37 s before line 2, as the real narrator did
const texts = ['এক দুই তিন চার। পাঁচ ছয় সাত আট।', 'নয় দশ এগারো বারো।'];
const pcm = track([2, 0.9, 2, 0.37, 2]);
assert.equal(sliceTake(pcm, texts).length, 2);
assert.ok(secs(sliceTake(pcm, texts)[0]) < 3, 'the old cut, by pauses alone, stops at the long pause inside line 1: this test must show that case');
const heard = ['এক', 'দুই', 'তিন', 'চার', 'পাঁচ', 'ছয়', 'সাত', 'আট', 'নয়', 'দশ', 'এগারো', 'বারো'].map((w, i) => ({ w, s: i * 0.45, e: i < 8 ? (i < 4 ? 0.5 * (i + 1) : 2.9 + 0.5 * (i - 3)) : 5.3 + 0.5 * (i - 7) }));
const ends = lineEnds(texts, heard);
assert.ok(Math.abs(ends[0] - 4.9) < 0.01, `line 1 ends with its last word (${ends})`);
const cut = sliceTake(pcm, texts, ends);
assert.ok(secs(cut[0]) > 4.8 && secs(cut[0]) < 5.2 && secs(cut[1]) < 2.6, `heard ends cut at the line end (${cut.map(secs)})`);
// the listener joined two words: the last word of the line is still found by its sound
const fewer = [...heard.slice(0, 2), { ...heard[2], w: 'তিনচার', e: heard[3].e }, ...heard.slice(4)];
assert.ok(Math.abs(lineEnds(texts, fewer)[0] - 4.9) < 0.01);
// two lines run together, no pause between them: a piece that lost its end, or starts with another line's words, is refused
const said = ['ফাহাদ', 'তুই', 'নাকি', 'কোন', 'তিনটা', 'এই', 'দেখ'].map((w, i) => ({ w, s: i, e: i + 0.8 }));
assert.equal(holdsLine('ফাহাদ তুই নাকি কোন তিনটা?', said, 0, 4.9), true, 'the whole line');
assert.equal(holdsLine('ফাহাদ তুই নাকি কোন তিনটা?', said, 0, 2.9), false, 'lost its end');
assert.equal(holdsLine('এই দেখ!', said, 3, 6.9), false, 'starts with the line before');
assert.equal(holdsLine('এই দেখ!', said, 5, 6.9), true);
assert.equal(holdsLine('এই দেখ!', said, 8, 9), false, 'nothing heard in it');
assert.equal(lineEnds(texts, []), null); assert.equal(lineEnds(texts, null), null);

// Gemini's network: one failed request is tried again instead of ending the take, a real refusal is not; a stop stays a stop
{
  process.env.GEMINI_API_KEY ||= 'test';
  const { speakTake } = await import('../server/gemini.mjs');
  const real = globalThis.fetch, out = path.join(os.tmpdir(), `zancut-retry-${process.pid}.wav`);
  const silence = Buffer.alloc(4800).toString('base64'), audio = { ok: true, status: 200, json: async () => ({ candidates: [{ content: { parts: [{ inlineData: { data: silence, mimeType: 'audio/L16;rate=24000' } }] } }], usageMetadata: {} }) };
  let n = 0, sig = null;
  globalThis.fetch = async (u, o) => { n++; sig = o.signal; if (n === 1) throw new TypeError('fetch failed'); return audio; };
  const r = await speakTake([{ text: 'hello' }], 'g-charon', 'en', out, { model: 'gemini-test-tts' });
  assert.equal(n, 2, 'a failed request is tried again'); assert.equal(r.model, 'gemini-test-tts'); assert.ok(sig instanceof AbortSignal, 'every request has a time limit'); assert.ok(fs.existsSync(out));
  // a request that never answers is given up on at its time limit and tried again; it does not wait out the network
  n = 0; const t0 = Date.now();
  globalThis.fetch = async (u, o) => { n++; if (n === 2) return audio; return new Promise((_, no) => o.signal.addEventListener('abort', () => no(o.signal.reason))); };
  const alive = setInterval(() => {}, 100); // a time limit alone does not keep this script running; a server is always running
  await speakTake([{ text: 'hello' }], 'g-charon', 'en', out, { model: 'gemini-test-tts', ms: 300 });
  clearInterval(alive);
  assert.equal(n, 2, 'a hung request is tried again'); assert.ok(Date.now() - t0 < 8000, 'the hang ended at the time limit');
  n = 0; const stop = new AbortController();
  globalThis.fetch = async () => { n++; stop.abort(); throw new TypeError('fetch failed'); };
  await assert.rejects(speakTake([{ text: 'hello' }], 'g-charon', 'en', out, { model: 'gemini-test-tts', signal: stop.signal }));
  assert.equal(n, 1, 'a stopped job is not tried again');
  globalThis.fetch = real; fs.rmSync(out, { force: true });
}
console.log('ok: takes are cut where the words end, not at the longest pause; a failed request is tried again');
