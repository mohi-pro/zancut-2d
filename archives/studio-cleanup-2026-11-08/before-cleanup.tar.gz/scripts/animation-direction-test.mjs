// No network or AI calls. Checks that authored visual direction survives preparation.
import assert from 'node:assert/strict';
import fs from 'node:fs';
import vm from 'node:vm';
import { tidyScript } from '../server/animation.mjs';
import { scriptText } from '../server/animpipe.mjs';
import { directorSystem, builderSystem, ordersText } from '../server/director.mjs';
import os from 'node:os';
import path from 'node:path';

const characters = Array.from({ length: 14 }, (_, i) => ({ id: `c${i}`, name: `Person ${i}`, spec: { gender: 'male' } }));
const project = { kind: 'animation', designStyle: '2d-animation', format: '9:16', language: 'bn' };
assert.match(directorSystem(project), /Universal Human Anatomy & Rigging Rules/);
assert.match(builderSystem(project), /Universal Human Anatomy & Rigging Rules/);
assert.match(directorSystem(project), /Scene-specific blocking and shot coverage/);
assert.match(builderSystem(project), /no resting pose|missing direction is an error/);
const staging = characters.map((c, i) => ({ who: c.id, at: [75 + i * 53, 1400 - i * 10], facing: i % 2 ? 'back' : 'profile', posture: 'seated' }));
const shots = [{ id: 'reverse', from: 0, to: 2, camera: { position: 'behind seller', direction: 'toward Rafi' }, visible: ['c0', 'c5'], action: 'Rafi picks up an orange' }];
const prepared = tidyScript({ characters, scenes: [{ id: 'market', type: 'character', staging, shots }], lines: [
  { scene: 'market', speaker: 'c0', text: 'এই নাও।', shot: { type: 'OTS', on: 'c5' }, acts: [{ who: 'c13', do: 'sit', look: 'c0' }] },
  { scene: 'market', speaker: 'narrator', text: 'সে এগিয়ে গেল।' },
] });
assert.equal(prepared.characters.length, 14);
assert.deepEqual(prepared.scenes[0].staging, staging);
assert.deepEqual(prepared.scenes[0].shots, shots);
assert.equal(prepared.lines[0].shot.type, 'OTS');
assert.equal(prepared.lines[0].acts[0].who, 'c13');
assert.equal(prepared.lines[1].shot, undefined);
assert.ok(prepared.characters.every(c => !c.offscreen));
const unstaged = tidyScript({ characters, scenes: [{ id: 'river', type: 'character' }], lines: [{ scene: 'river', speaker: 'c4', text: 'এসো।' }] });
assert.equal(unstaged.scenes[0].staging, undefined);
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'zancut-direction-'));
try {
  fs.mkdirSync(path.join(temp, 'plate'));
  fs.writeFileSync(path.join(temp, 'plate/ANIMATION.json'), JSON.stringify(prepared));
  assert.match(scriptText({ ws: temp }), /behind seller/);
  assert.match(scriptText({ ws: temp }), /Rafi picks up an orange/);
} finally { fs.rmSync(temp, { recursive: true, force: true }); }

// Minimal DOM/rig adapter exercises the actual ZC API, including rejected implicit poses.
class Node {
  constructor() { this.attrs = {}; this.children = []; this.style = {}; }
  setAttribute(k, v) { this.attrs[k] = v; }
  appendChild(n) { n.ownerSVGElement = this.ownerSVGElement || this; this.children.push(n); return n; }
  querySelector() { return null; }
}
let lastState;
const ctx = { document: { createElementNS: () => new Node() }, ZPEOPLE: { look: () => ({ s: 1, arms: [{}, { up: 100, fo: 100, sh: [30, 50] }] }) }, ZRIG: { create: () => ({ person: () => ({ update: s => { lastState = s; } }) }) } };
ctx.window = ctx;
vm.runInNewContext(fs.readFileSync(new URL('../engine/cartoon/zc.js', import.meta.url), 'utf8'), ctx);
const world = ctx.ZC.world(new Node());
assert.throws(() => world.cam(), /Author this shot's camera/);
world.cam(400, 900, 1200, 3);
const person = ctx.ZC.person(world.layer('people'), { x: 100, y: 300 });
assert.throws(() => person.draw({}), /no resting pose is implied/);
assert.throws(() => person.draw({ hands: 'unrecognized' }), /no resting pose is implied/);
assert.throws(() => person.draw({ hands: [[0, 1]] }), /two finite/);
person.draw({ hands: [[50, 480], [160, 460]], blink: .8 });
assert.equal(lastState.blink, .8);
person.draw({ hands: 'hold' }); // explicitly selected helper remains available
assert.equal(lastState.blink, 0);
// New one-hand holds leave the other elbow automatic; blending them must preserve that null target.
for (const [a, b] of [['cup', 'sip'], ['sip', 'table'], ['table', 'cup']]) {
  const blended = person.blend(person.named(a), person.named(b), 0.5);
  assert.equal(blended.elbows[0], null);
  assert.ok(blended.elbows[1].every(Number.isFinite));
  person.draw(blended);
}

// the customer's film-wide directions survive the planner and reach everyone as orders; the planner's skill asks for them
const orders = ordersText({ filmOrders: 'No thought bubbles or floating icons.', instructions: 'Keep it short.' });
assert.match(orders, /No thought bubbles/); assert.match(orders, /Keep it short/);
assert.deepEqual(tidyScript({ characters: [], lines: [{ speaker: 'narrator', text: 'x' }], directions: ['No floating icons'] }).directions, ['No floating icons']);
assert.match(fs.readFileSync(new URL('../skills/2d-animation/script.md', import.meta.url), 'utf8'), /"directions"/);
// the planner reads a long script whole, and a project keeps it whole
assert.match(fs.readFileSync(new URL('../server/animpipe.mjs', import.meta.url), 'utf8'), /story\.slice\(0, 40000\)/);

// the storyboard and the editor show the whole track when it keeps a silent end; other videos end at the last word
{
  const { lengthOf } = await import('../server/board.mjs');
  const J0 = fs.mkdtempSync(path.join(os.tmpdir(), 'zancut-length-')), words = [{ end: 116.2 }];
  fs.mkdirSync(path.join(J0, 'cut')); fs.writeFileSync(path.join(J0, 'cut', 'segments.json'), JSON.stringify({ segments: [{ outEnd: 122.47 }] }));
  assert.equal(lengthOf(J0, words), 116.2);
  fs.writeFileSync(path.join(J0, 'job.json'), JSON.stringify({ keepTail: true }));
  assert.equal(lengthOf(J0, words), 122.47);
  assert.equal(lengthOf(J0, []), 122.47);
  fs.rmSync(J0, { recursive: true, force: true });
}

// the director's on-screen words survive the tidy and reach the builder
{
  const src = fs.readFileSync(new URL('../server/director.mjs', import.meta.url), 'utf8');
  assert.match(src, /r\.texts = Array\.isArray\(r\.texts\)/); assert.match(src, /Words on screen, use them exactly/);
  assert.match(fs.readFileSync(new URL('../skills/2d-animation/core-director.md', import.meta.url), 'utf8'), /"texts"/);
}

console.log('ok: authored cast, staging, shots, hand targets and camera direction preserved; implicit visuals rejected; film-wide directions reach everyone');
