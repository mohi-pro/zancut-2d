# Zancut 2D
Voice + story in, finished 2D film out. Made by our own code and our own trained brain: **no outside AI**.
Run: `npm start` → http://localhost:4500 (Story → Storyboard → Render). Frames 16:9 / 9:16 / 1:1 / 4:5.
The brain learns from you: fix shots in the storyboard, press Make or "Teach the brain". See docs/MODEL_EVAL.md for measured accuracy and docs/STATUS.md for what is and is not done.
