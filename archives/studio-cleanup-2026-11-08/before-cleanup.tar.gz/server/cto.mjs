// The CTO: the agent behind the scenes that keeps Zancut working, on the cloud server and on every customer's computer.
//   - health checks at start and every 30 min: Claude, the Gemini key, ffmpeg, the engine's Python, WhisperX, the disk
//   - fallbacks: a Gemini key that does not work is taken out of use (words → WhisperX / whisper, AI voice → the local voice);
//     a missing tool is installed from the fixed list below (desktop app: the customer agreed to it in the installer)
//   - every failed job: the cause is found (the rules below, else Claude reads the error and the log) and fixed, then the
//     job runs again by itself (a Claude limit: when it resets); what cannot be fixed is "critical" and sent to the owner
//   - every bug report a customer sends (or ZanBro sends for them): diagnosed the same way, its video fixed when it can be
// One list for the owner (Admin → CTO), each item tagged: fixed (fixed automatically), critical, bug, code (a ready prompt
// for Claude Code to fix it for every computer); the skill lessons (learn.mjs) and bug reports (reports.mjs) are shown with
// it. The same problem again only counts up on its item. A desktop app sends its items to the cloud server.
//   data/cto.json = { items: [{ id, tag, key, title, detail, action, ok, status, count, firstAt, at, where, projectId, ... }] }
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { query, createSdkMcpServer, tool } from './no-ai.mjs';
import { z } from 'zod';
import { npx } from '../engine/media/lib.mjs';
import * as win from './cto-windows.mjs';
import { DATA_DIR, APP_DIR, CLAUDE_PATH, OWN_CLAUDE, MODE, CLOUD_URL, venvPython } from './config.mjs';
import * as store from './store.mjs';
import * as admin from './admin.mjs';
import * as users from './users.mjs';
import * as claude from './claude-auth.mjs';
import { setGeminiDown, geminiDown, geminiKeySet, geminiPing } from './gemini.mjs';
import { serviceToken } from './desktop-client.mjs';
import { pricing } from './pricing.mjs';
// the owner's Claude login reads failed jobs and bug reports (web: every customer has their own; the CTO uses the owner's)
const ownerId = () => users.all().find((u) => u.role === 'admin' && !u.test && !u.disabled)?.id || null;
import { DEMO } from './demo.mjs';

const FILE = path.join(DATA_DIR, 'cto.json');
const load = () => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return { items: [] }; } };
const save = (db) => { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(`${FILE}.tmp`, JSON.stringify(db, null, 1)); fs.renameSync(`${FILE}.tmp`, FILE); };
const newId = () => `c${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
const str = (x, n) => String(x ?? '').trim().slice(0, n);
const WIN = process.platform === 'win32';
const APP_VERSION = (() => { try { return JSON.parse(fs.readFileSync(path.join(APP_DIR, 'package.json'), 'utf8')).version; } catch { return '?'; } })();
export const TAGS = { fixed: 'Fixed automatically', critical: 'Critical', bug: 'Bug report', asked: 'Customer question', lesson: 'Skill lesson', code: 'Code task' };
// installing: on a customer's computer the installer's consent covers it; on a server only when the owner sets ZANCUT_CTO_INSTALL=1
// (not on Windows: the Windows app ships its own Python and downloads the rest in its first run, server/first-run.mjs)
// the Mac app: the consent screen at its first start (desktop/main.cjs) covers it
const INSTALL = WIN ? false : win.DESKTOP_APP || MODE === 'desktop' ? process.env.ZANCUT_CTO_INSTALL !== '0' : process.env.ZANCUT_CTO_INSTALL === '1';

const where = () => ({ os: `${os.platform()} ${os.release()} ${os.arch()}`, app: APP_VERSION, mode: MODE, host: os.hostname().slice(0, 40) });
const run = (cmd, args, o = {}) => new Promise((ok, no) => execFile(cmd, args, { timeout: o.timeout || 60000, maxBuffer: 1 << 24, windowsHide: true, ...o }, (e, so, se) => (e ? no(Object.assign(e, { out: String(se || so || '').slice(-600) })) : ok(String(so)))));

// ---------- the log: the last lines the server wrote, for diagnosis ----------
const LOG = [];
function keepLog() {
  for (const k of ['error', 'warn']) {
    const orig = console[k].bind(console);
    console[k] = (...a) => { try { LOG.push({ t: Date.now(), line: a.map((x) => (x instanceof Error ? `${x.message}\n${String(x.stack || '').split('\n').slice(1, 4).join('\n')}` : typeof x === 'string' ? x : JSON.stringify(x))).join(' ').slice(0, 800) }); if (LOG.length > 600) LOG.splice(0, LOG.length - 600); } catch {} orig(...a); };
  }
}
const logFor = (projectId, since) => LOG.filter((l) => l.t >= since && (!projectId || l.line.includes(projectId) || l.t >= Date.now() - 10 * 60000)).slice(-60).map((l) => `${new Date(l.t).toISOString().slice(11, 19)} ${l.line}`).join('\n');

// ---------- the list ----------
const told = new Map(); // key → when the owner was last told (a critical item at most once an hour)
export function record(x) {
  const db = load(), key = str(x.key || x.title, 200), now = Date.now();
  let it = db.items.find((i) => i.key === key && i.status === 'open');
  if (it) Object.assign(it, { at: now, count: (it.count || 1) + 1, detail: str(x.detail, 2000) || it.detail, ...(x.action ? { action: str(x.action, 400) } : {}), ...(x.ok !== undefined ? { ok: x.ok } : {}), ...(x.tag === 'critical' || it.tag !== 'critical' ? { tag: x.tag || it.tag } : {}) });
  else {
    it = { id: newId(), tag: TAGS[x.tag] ? x.tag : 'fixed', key, title: str(x.title, 200), detail: str(x.detail, 2000), action: str(x.action, 400), ok: x.ok ?? null, status: 'open', count: 1, firstAt: now, at: now,
      where: x.where || where(), ...(x.projectId ? { projectId: x.projectId } : {}), ...(x.reportId ? { reportId: x.reportId } : {}), ...(x.code ? { code: str(x.code, 4000) } : {}), ...(x.device ? { device: str(x.device, 80) } : {}) };
    db.items.unshift(it); db.items = db.items.slice(0, 3000);
  }
  save(db);
  if ((it.tag === 'critical' || x.notify) && now - (told.get(key) || 0) > 3600e3) { told.set(key, now); admin.notify(`🛠 CTO · ${TAGS[it.tag]}${it.count > 1 ? ` (×${it.count})` : ''}\n\n${it.title}\n${it.detail ? `\n${it.detail.slice(0, 500)}\n` : ''}${it.action ? `\nDone: ${it.action}` : ''}\n${it.where.os} · app ${it.where.app} · ${it.where.mode}\n\nAdmin → CTO.`); }
  if (MODE === 'desktop' && !x.fromCloud) forward(it);
  return it;
}
// a fallback that already happened (the job went on): one "fixed" item per kind of fallback
export const fallback = (kind, x) => { try { return record({ ...x, tag: 'fixed', key: `fallback:${kind}`, ok: true, action: x.action || 'switched to the fallback' }); } catch (e) { console.log('[cto]', e.message); } };
export function update(id, fields) {
  const db = load(), it = db.items.find((i) => i.id === id); if (!it) return null;
  if (['open', 'done'].includes(fields.status)) it.status = fields.status;
  if (typeof fields.note === 'string') it.note = fields.note.slice(0, 2000);
  save(db); return it;
}
export function remove(id) { const db = load(), n = db.items.length; db.items = db.items.filter((i) => i.id !== id); save(db); return db.items.length < n; }
// a fix's result: worked (stays "fixed") or not (becomes "critical" and the owner is told)
const settle = (id, ok, action) => {
  const db = load(), it = db.items.find((i) => i.id === id); if (!it) return;
  it.ok = ok; if (action) it.action = str(`${it.action ? `${it.action} → ` : ''}${action}`, 400);
  if (!ok) it.tag = 'critical';
  save(db);
  if (!ok) admin.notify(`🛠 CTO · Critical\n\n${it.title}\n\nDone: ${it.action}\n${it.where?.os || ''} · app ${it.where?.app || ''}\n\nAdmin → CTO.`);
};

// ---------- a desktop app's items and bug reports go to the cloud server (the owner's lists) ----------
// One outbox on disk (data/cloud-outbox.json): kept while offline or signed out and across restarts, sent oldest first
// whenever something new is added and every 5 minutes, until the cloud server takes it.
const OUTBOX = path.join(DATA_DIR, 'cloud-outbox.json');
const readOut = () => { try { return JSON.parse(fs.readFileSync(OUTBOX, 'utf8')); } catch { return []; } };
const writeOut = (l) => { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(`${OUTBOX}.tmp`, JSON.stringify(l.slice(-300))); fs.renameSync(`${OUTBOX}.tmp`, OUTBOX); };
export function toCloud(route, body) {
  if (MODE !== 'desktop') return;
  writeOut([...readOut(), { route, body, at: Date.now() }]);
  flushOutbox();
}
let flushing = false;
export async function flushOutbox() {
  if (flushing || MODE !== 'desktop') return;
  flushing = true;
  try {
    const token = serviceToken(); if (!token) return; // signed out: kept for later (the most recent sign-in signs it)
    for (let l = readOut(); l.length; l = readOut()) {
      const r = await fetch(`${CLOUD_URL}${l[0].route}`, { method: 'POST', headers: { 'Content-Type': 'application/json', 'x-api-key': token }, body: JSON.stringify(l[0].body), signal: AbortSignal.timeout(60000) }).catch(() => null);
      if (!r || (!r.ok && ![400, 413].includes(r.status))) break; // offline, or the server is down: later (a bad item is dropped, never retried forever)
      writeOut(readOut().slice(1));
    }
  } finally { flushing = false; }
}
const forward = (it) => toCloud('/api/desktop/cto', { ...it, device: os.hostname() });
// the last lines the server wrote, for a bug report that leaves this computer
export const recentLog = (n = 80) => LOG.slice(-n).map((l) => `${new Date(l.t).toISOString().slice(11, 19)} ${l.line}`).join('\n');
// on the cloud server: an item sent by a customer's desktop app
export const fromDesktop = (u, b) => record({ tag: b.tag, key: `${str(b.key, 160)}`, title: b.title, detail: b.detail, action: b.action, ok: b.ok, where: { os: str(b.where?.os, 80), app: str(b.where?.app, 20), mode: 'desktop', host: str(b.device, 40) }, device: `${u.email} · ${str(b.device, 40)}`, code: b.code, fromCloud: true });

// ---------- the repairs: a fixed list, tested, from trusted sources only (the CTO's Claude chooses among them, nothing else) ----------
const REPAIRS = {
  cleanup: { what: 'free disk space: the render history, frame checks and old screen frames (never a customer\'s file)', run: async () => `freed ${(cleanup() / 1e9).toFixed(1)} GB` },
  'gemini-off': { what: 'take the Gemini key out of use for 2 h (words then come from the local transcriber, the AI voice from the local voice)', run: async () => { setGeminiDown(2 * 3600e3); return 'Gemini off for 2 h'; } },
  ...(win.WIN_APP ? {
    ffmpeg: { what: `replace ffmpeg with a working ffmpeg 7+ (the engine needs \`-/filter_complex <file>\`; "Unrecognized option '/filter_complex'" = too old)`, run: async () => ((await win.repairFfmpeg()) ? 'ffmpeg replaced' : 'not replaced') },
  } : {}),
  ...(win.DESKTOP_APP ? {
    parts: { what: 'download again what the app fetches on first run: the video tools (HyperFrames), the renderer (Chrome), the English speech-to-text model (Parakeet), the speaker cut-out model, the AI voice', run: async () => { await win.repairParts(); return 'all parts downloaded'; } },
  } : {}),
  ...(INSTALL ? {
    python: { what: 'install the engine\'s Python (OpenCV, numpy) for face tracking and screen tracking', run: async () => ((await ensureVenv(ENGINE_PY, 'The engine\'s Python (face track, screen tracking)')) ? 'installed' : 'could not install') },
    whisperx: { what: 'install WhisperX (exact word timings)', run: async () => ((await ensureVenv(WX, 'WhisperX (exact word timings)')) ? 'installed' : 'could not install') },
  } : {}),
};

// what the CTO's Claude may look at on this computer: fixed checks, read only
const CHECKS = {
  health: { what: 'all health checks now (ffmpeg, Python, WhisperX, Gemini, Claude, disk, and on Windows the downloaded parts and the app\'s own programs)', run: async () => JSON.stringify((await checkHealth()).checks) },
  ffmpeg: { what: 'ffmpeg and ffprobe: where they are and their version', run: async () => { const v = async (b) => { try { return String(await run(b, ['-hide_banner', '-version'])).split('\n')[0]; } catch (e) { return `not working: ${e.message}`; } }; return `ffmpeg: ${await v('ffmpeg')}\nffprobe: ${await v('ffprobe')}\nPATH: ${process.env.PATH}`; } },
  python: { what: 'the engine\'s Python and whether OpenCV and numpy import', run: async () => { try { return `${ENGINE_PY.py}: ${await run(ENGINE_PY.py, ['-c', 'import sys, cv2, numpy; print(sys.version.split()[0], "cv2", cv2.__version__, "numpy", numpy.__version__)'])}`; } catch (e) { return `${ENGINE_PY.py}: not working: ${e.out || e.message}`; } } },
  'video-tools': { what: 'HyperFrames\' own check (Node, Chrome, ffmpeg, the speech model)', run: async () => { try { const [c, a, o] = npx(['hyperframes', 'doctor']); return str(await run(c, a, { ...o, timeout: 120e3 }), 3000); } catch (e) { return str(e.out || e.message, 3000); } } },
  'first-run': { what: 'the desktop app: which of the first-run downloads are there', run: async () => JSON.stringify(win.DESKTOP_APP ? (await import('./first-run.mjs')).firstRun() : { on: false }) },
  computer: { what: 'the computer: system, free disk, memory', run: async () => { const s = fs.statfsSync(DATA_DIR); return `${where().os}; ${(s.bavail * s.bsize / 1e9).toFixed(1)} GB free; ${(os.freemem() / 1e9).toFixed(1)} of ${(os.totalmem() / 1e9).toFixed(1)} GB memory free; ${os.cpus().length} cores`; } },
};

// ---------- Claude's diagnosis: the CTO as an agent on this computer: reads the log and the job, runs checks, repairs ----------
// → { cause, ours, fix, customer, code, repairs: [what it repaired] } or null
export async function diagnose({ what, text, logs = '', context = '', projectId = null }) {
  if (DEMO) throw new Error('no AI diagnosis in the demo app');
  const repairs = [];
  const prompt = `You are the CTO of Zancut, an AI video editing app (Node server + a video engine: ffmpeg, Python, WhisperX, HyperFrames
render, Claude and Gemini), working on the computer where it runs: ${where().os}, app ${APP_VERSION}${win.WIN_APP ? ' (the Windows app: it ships its own node.exe, ffmpeg, Python and AI program, and downloads the rest on first run)' : win.DESKTOP_APP ? ' (the Mac app: it ships its own ffmpeg 9, Python and AI program, and downloads the rest on first run)' : ''}.
Something went wrong. Find the cause and fix it on this computer, like an engineer would:
1. Look first: read_log for more of the log, check to test a tool (several checks are fine).
2. When a repair on the list fixes the cause, run it (repair), then check that it worked.
3. Answer.

## What happened (${what})
${str(text, 3000)}
${context ? `\n## Context\n${str(context, 3000)}\n` : ''}
## The server's log around it
${str(logs, 6000) || '(nothing logged)'}

## Checks you can run
${Object.entries(CHECKS).map(([k, v]) => `- ${k}: ${v.what}`).join('\n')}

## Repairs you can run (only these: nothing else may be installed or changed)
${Object.entries(REPAIRS).map(([k, v]) => `- ${k}: ${v.what}`).join('\n')}

Your last message: JSON only:
{"cause": "one or two plain sentences: what broke and why",
 "ours": true,
 "fix": "retry | retry-later | none",
 "customer": "one short friendly line for the customer (no technical words), or empty",
 "code": "when our code must change so it never happens again on any computer (a bug, or a tool that needs a repair not on the list): a ready prompt for Claude Code (files, what to change, why); else empty"}
"retry" = running the same step again will work now (a busy service, a timeout, a tool you just repaired);
"retry-later" = it works after a wait (a usage limit); "none" = a person must act (the customer's file is broken, a key is missing).`;
  const tools = createSdkMcpServer({ name: 'cto', version: '1.0.0', tools: [
    tool('read_log', 'The last lines the server wrote (errors and warnings), newest last.', { lines: z.number().optional() }, async ({ lines }) => ({ content: [{ type: 'text', text: LOG.slice(-Math.min(200, Math.max(10, Math.round(lines || 80)))).map((l) => `${new Date(l.t).toISOString().slice(11, 19)} ${l.line}`).join('\n') || '(empty)' }] })),
    tool('read_job', 'The failed video\'s state: status, error shown, the steps of its last job.', {}, async () => {
      const p = projectId && store.get(projectId);
      return { content: [{ type: 'text', text: p ? JSON.stringify({ status: p.status, error: p.error, kind: p.kind, language: p.language, lastJob: p.lastJob, footage: (p.footage || []).map((f) => ({ file: f.file, duration: f.duration, hasAudio: f.hasAudio })) }).slice(0, 6000) : '(no video)' }] };
    }),
    tool('check', `Run one check: ${Object.keys(CHECKS).join(', ')}.`, { name: z.string() }, async ({ name }) => {
      const c = CHECKS[name]; if (!c) return { content: [{ type: 'text', text: `No such check. Checks: ${Object.keys(CHECKS).join(', ')}` }] };
      try { return { content: [{ type: 'text', text: str(await c.run(), 6000) }] }; } catch (e) { return { content: [{ type: 'text', text: `the check failed: ${e.message}` }] }; }
    }),
    tool('repair', `Run one repair from the list: ${Object.keys(REPAIRS).join(', ') || '(none on this computer)'}.`, { name: z.string() }, async ({ name }) => {
      const r = REPAIRS[name]; if (!r) return { content: [{ type: 'text', text: `Not a repair on the list. Repairs: ${Object.keys(REPAIRS).join(', ') || 'none'}` }] };
      if (repairs.filter((x) => x.name === name).length >= 2) return { content: [{ type: 'text', text: 'Already run twice: not again.' }] };
      try { const out = await r.run(); repairs.push({ name, ok: true, out }); console.log(`[cto] repair ${name}: ${out}`); return { content: [{ type: 'text', text: `done: ${out}` }] }; }
      catch (e) { repairs.push({ name, ok: false, out: e.message }); console.log(`[cto] repair ${name} failed: ${e.message}`); return { content: [{ type: 'text', text: `the repair failed: ${str(e.message, 600)}` }] }; }
    }),
  ] });
  const allowed = ['read_log', 'read_job', 'check', 'repair'].map((t) => `mcp__cto__${t}`);
  const options = { model: pricing().models.short || 'claude-sonnet-5-5', maxTurns: 16, tools: [], settingSources: [], cwd: os.tmpdir(), permissionMode: 'dontAsk',
    mcpServers: { cto: tools }, allowedTools: allowed, // (tools: [] = none of Claude Code's own tools: only these four)
    env: { ...process.env, ...claude.envFor(ownerId()), ENABLE_CLAUDEAI_MCP_SERVERS: 'false', CLAUDE_CODE_DISABLE_CLAUDE_MDS: '1' }, ...(CLAUDE_PATH ? { pathToClaudeCodeExecutable: CLAUDE_PATH } : {}) };
  let out = '';
  for await (const ev of query({ prompt, options })) {
    claude.seeFor(ownerId())(ev);
    if (ev.type === 'result') out = String(ev.result || '');
  }
  try { const j = JSON.parse(out.match(/\{[\s\S]*\}/)?.[0] || ''); return { cause: str(j.cause, 600), ours: j.ours !== false, fix: ['retry', 'retry-later', 'none'].includes(j.fix) ? j.fix : 'none', customer: str(j.customer, 200), code: str(j.code, 4000), repairs }; }
  catch { return repairs.length ? { cause: '', ours: true, fix: repairs.some((r) => r.ok) ? 'retry' : 'none', customer: '', code: '', repairs } : null; }
}
const repairText = (d) => (d?.repairs?.length ? d.repairs.map((r) => `${r.name}: ${r.ok ? r.out : `failed (${str(r.out, 80)})`}`).join('; ') : '');

// ---------- failed jobs: the known causes and their fixes (the first that matches) ----------
const RULES = [
  // the app's own npm is missing its parts (an installer built without npm's node_modules): nothing that starts npx can work, and
  // no download fixes it; the app must be installed again from a good installer
  { id: 'app-npm', test: (t) => /(npx|npm)-cli\.js/.test(t) && /MODULE_NOT_FOUND|Cannot find module/.test(t), fix: 'none', title: "The app's own npm is incomplete on this computer: install Zancut again (a new installer)" },
  { id: 'claude-login', test: (t, e) => e?.code === 'login' || /not (signed|logged) in|connect (your )?claude|invalid api key|authentication/i.test(t), fix: 'none', title: 'Claude is not connected on this computer' },
  { id: 'claude-limit', test: (t, e) => e?.code === 'limit' || /usage limit|rate.?limit|limit is reached|429|overloaded_error/i.test(t), fix: 'retry-later', title: "Claude's usage limit stopped a job" },
  { id: 'gemini', test: (t) => /gemini|generativelanguage|API key not valid|PERMISSION_DENIED/i.test(t), fix: 'retry', title: 'Gemini failed during a job', act: () => setGeminiDown(2 * 3600e3) },
  { id: 'disk', test: (t) => /ENOSPC|no space left/i.test(t), fix: 'retry', title: 'The disk is full', act: () => cleanup() },
  // (logs: also looked for in the log around the job, where the engine's own error is: the customer sees a plain sentence)
  { id: 'ffmpeg-old', logs: true, test: (t) => /Unrecognized option '?\/filter_complex|Option \/filter_complex not found/i.test(t), fix: win.WIN_APP ? 'retry' : 'none', title: 'ffmpeg is too old for the engine (it needs ffmpeg 7+)', act: win.WIN_APP ? () => win.repairFfmpeg() : null },
  { id: 'parts', logs: true, test: (t) => /whisper_unavailable|models install parakeet|Could not find (Chrome|expected browser)|browser ensure/i.test(t), fix: win.DESKTOP_APP ? 'retry' : 'none', title: 'A part Zancut downloads is missing (speech model, renderer or cut-out)', act: win.DESKTOP_APP ? () => win.repairParts() : null },
  { id: 'tools', test: (t) => /spawn \S+ ENOENT|command not found|is not recognized as|No module named|Cannot find module|python3?: can't open/i.test(t), fix: 'retry', title: 'A tool is missing on this computer', act: () => repairTools() },
  { id: 'symlink', test: (t) => /EPERM.*symlink|symlink.*EPERM/i.test(t), fix: 'retry', title: 'Symbolic links are not allowed on this computer' },
  { id: 'network', test: (t) => /ETIMEDOUT|ECONNRESET|ECONNREFUSED|EAI_AGAIN|socket hang up|fetch failed|network|timed? ?out|5\d\d /i.test(t), fix: 'retry', wait: 60e3, title: 'A network problem stopped a job' },
  { id: 'render', test: (t) => /render did not finish|rendered file is broken|hyperframes|chrome/i.test(t), fix: 'retry', title: 'The render failed', act: async () => { if (win.DESKTOP_APP) await (await import('./first-run.mjs')).ensureRenderer(); } }, // the desktop app: the renderer's browser downloaded again when it is missing
];
// customer messages that are not the customer's doing (the rest, e.g. "upload your video first", are left alone)
const SYSTEMISH = /could not be prepared|render did not finish|rendered file is broken|something went wrong|busy right now|limit|press retry/i;
let enqueueJob = null, startGuard = null; // startGuard(project, kind): null = may start, else why not
const tries = new Map(); // project:kind → [times of automatic retries]
const waiting = new Map(); // project id → { itemId, reportId } until its retried job ends
const timers = new Map();

export async function jobEnded({ project: p, job, ok }) {
  if (!p || job.cancelled) return;
  const w = waiting.get(p.id);
  if (ok) {
    if (w) { waiting.delete(p.id); settle(w.itemId, true, 'ran again: it worked'); if (w.reportId && w.saveReport) w.saveReport({ status: 'fixed', note: 'Fixed by the CTO: the video was made again and it worked.' }); }
    return;
  }
  if (w) { waiting.delete(p.id); settle(w.itemId, false, 'ran again: failed again'); }
  const e = job.error, text = `${e?.message || ''} ${p.error || ''}`.trim();
  if (e?.customer && !SYSTEMISH.test(text)) return;
  const k = `${p.id}:${job.kind}`, recent = (tries.get(k) || []).filter((t) => t > Date.now() - 3600e3);
  const logs = logFor(p.id, (p.lastJob?.steps?.[0]?.t || Date.now()) - 60e3);
  const rule = RULES.find((r) => r.test(text, e)) || RULES.find((r) => r.logs && r.test(logs, e));
  let d = null;
  // no known cause, a failed render (its real error says why: the renderer, Chrome, a font, ffmpeg) or the same job failing again:
  // the CTO's Claude looks into it on this computer and may run a repair from the list before it runs again
  if (!rule || rule.id === 'render' || recent.length >= 1) { try { d = await diagnose({ what: `a "${job.kind}" job of the video ${p.id} failed`, text: `${e?.stack || text}`, logs, projectId: p.id, context: `Steps: ${(p.lastJob?.steps || []).slice(-8).map((s) => s.text).join(' · ')}` }); } catch (x) { console.log('[cto] diagnose:', x.message); } }
  const fix = rule?.fix || d?.fix || 'retry', title = rule?.title || `A "${job.kind}" job failed${d?.cause ? `: ${d.cause.slice(0, 120)}` : ''}`;
  const base = { key: `job:${rule?.id || 'other'}:${job.kind}`, title, detail: `${d?.cause ? `${d.cause}\n\n` : ''}${repairText(d) ? `Repaired: ${repairText(d)}\n\n` : ''}${text.slice(0, 1200)}`, projectId: p.id, ...(d?.code ? { code: d.code } : {}) };
  // a desktop app's AI step needs a new pass from the cloud for each run: the customer presses Retry there
  const canRetry = enqueueJob && fix !== 'none' && recent.length < 2 && !job.extra?.cloudJobId;
  if (!canRetry) { record({ ...base, tag: 'critical', ok: false, action: fix === 'none' ? 'needs a person' : recent.length >= 2 ? 'tried twice already' : 'left for the customer to retry' }); if (d?.code) record({ ...base, key: `code:${base.key}`, tag: 'code', title: `Code fix: ${title}` }); return; }
  try { await rule?.act?.(); } catch (x) { console.log('[cto] fix:', x.message); }
  let delay = rule?.wait || 5000;
  // a video paused by Claude's limit carries on by itself only when its customer said so (their setting or the pause card)
  const paused = p.status === 'PAUSED_QUOTA_LIMIT';
  if (fix === 'retry-later' && paused && p.quota?.autoResume !== true) { record({ ...base, tag: 'fixed', ok: null, action: p.quota?.autoResume === false ? 'paused: the customer resumes it' : 'paused: the customer is asked whether it carries on by itself' }); return; }
  if (fix === 'retry-later') { const b = claude.blockedFor(p.ownerId); delay = b ? b.until - Date.now() + 90e3 : 15 * 60e3; if (delay > 8 * 3600e3 && !paused) { record({ ...base, tag: 'critical', ok: false, action: 'the limit resets in more than 8 hours' }); return; } }
  const at = new Date(Date.now() + delay).toLocaleTimeString([], { hour: 'numeric', minute: '2-digit' });
  const did = rule?.act ? { gemini: 'Gemini taken out of use for 2 h (fallbacks on)', disk: 'old caches cleared', tools: 'missing tools installed', render: 'the video renderer checked (downloaded again if missing)', 'ffmpeg-old': 'ffmpeg replaced', parts: 'missing parts downloaded again' }[rule.id] || 'fixed' : repairText(d);
  const it = record({ ...base, tag: 'fixed', ok: null, action: `${did ? `${did}; ` : ''}runs again ${delay > 60e3 ? `at ${at}` : 'now'}` });
  if (d?.code) record({ ...base, key: `code:${base.key}`, tag: 'code', title: `Code fix: ${title}` });
  tries.set(k, [...recent, Date.now()]);
  if (delay > 60e3) { const q = store.get(p.id); if (q && !q.job) { q.error = `${d?.customer || 'Something on our side needs a moment.'} Zancut will carry on by itself at ${at}.`; if (q.quota) q.quota = { ...q.quota, resetAt: Date.now() + delay, autoResume: true, scheduledFor: Date.now() + delay }; store.save(q, { immediate: true }); } }
  later(p.id, delay, () => rerun(p.id, job.kind, job.extra || {}, it.id));
}
// The one place a stopped job runs again by itself. Not when the customer stopped the automatic run (a paused video's
// "Don't carry on by itself"), ran it again already, or may not start it (credits on the web).
function rerun(id, kind, extra, itemId = null) {
  const q = store.get(id); if (!q || q.job || ['queued', 'editing'].includes(q.status)) return;
  if (q.quota?.autoResume === false || !(q.error || q.status === 'PAUSED_QUOTA_LIMIT')) return;
  const no = startGuard?.(q, kind);
  if (no) { q.error = no; store.save(q, { immediate: true }); if (itemId) settle(itemId, false, `could not start: ${no}`); return; }
  if (itemId) waiting.set(id, { ...(waiting.get(id) || {}), itemId });
  try { enqueueJob(id, kind, extra); } catch (x) { if (itemId) settle(itemId, false, `could not start: ${x.message}`); }
}
// a paused video (Claude's limit): the customer's own choice in its pause card
export function cancelLater(id) { clearTimeout(timers.get(id)); timers.delete(id); }
export function resumeLater(id, kind, extra, at) { later(id, at - Date.now(), () => rerun(id, kind, extra)); }
const later = (id, ms, fn) => { clearTimeout(timers.get(id)); timers.set(id, setTimeout(() => { timers.delete(id); fn(); }, Math.max(1000, ms))); };

// ---------- bug reports: diagnosed, the video fixed when it can be (reports.mjs calls this) ----------
// r: the report · saveReport(fields): stores fields on it (diagnosis, status, note)
export async function onReport(r, saveReport) {
  const p = r.projectId ? store.get(r.projectId) : null;
  let d = null;
  try { d = await diagnose({ what: `a customer's bug report${r.user ? ` from ${r.user}` : ''}`, text: `${r.text}${r.expected ? `\nThey expected: ${r.expected}` : ''}`, logs: logFor(r.projectId, Date.now() - 30 * 60e3), projectId: r.projectId || null, context: p ? `Their video ${p.id} "${p.name}": status ${p.status}, last step ${p.lastJob?.kind || '-'}${p.lastJob?.failed ? ' (failed)' : ''}${p.error ? `, error shown: ${p.error}` : ''}. Steps: ${(p.lastJob?.steps || []).slice(-8).map((s) => s.text).join(' · ')}` : `Page: ${r.page || '-'}` }); } catch (x) { console.log('[cto] report:', x.message); }
  if (!d) return;
  saveReport({ diagnosis: d });
  if (d.code) record({ tag: 'code', key: `report:${r.id}`, title: `Code fix from a bug report: ${str(r.text, 90)}`, detail: d.cause, code: d.code, reportId: r.id, projectId: r.projectId });
  // their video's last step failed and running it again will work: the CTO runs it again now
  if (p && p.lastJob?.failed && !p.job && d.fix === 'retry' && enqueueJob) {
    const it = record({ tag: 'fixed', key: `report-retry:${r.id}`, title: `Bug report: the failed "${p.lastJob.kind}" step is run again`, detail: d.cause, reportId: r.id, projectId: p.id, ok: null, action: 'runs the step again' });
    waiting.set(p.id, { itemId: it.id, reportId: r.id, saveReport });
    try { enqueueJob(p.id, p.lastJob.kind, {}); } catch (x) { settle(it.id, false, `could not start: ${x.message}`); }
  }
}

// ---------- the tools: checks, and installs from a fixed list (pinned versions, official sources only) ----------
const HOME = process.env.HOME || process.env.USERPROFILE || os.homedir();
const ENGINE_PY = { dir: path.join(HOME, '.cache', 'zancut', 'py'), py: process.env.ZANCUT_PYTHON || venvPython('py'), pkgs: ['opencv-python-headless==5.0.0.93', 'numpy==2.0.2'], test: 'import cv2, numpy' };
const WX = { dir: path.join(HOME, '.cache', 'zancut', 'wx'), py: venvPython('wx'), pkgs: ['whisperx==3.8.6'], test: 'import whisperx' };
// a Python 3.9–3.12 to make a venv from
async function basePython() {
  // the Mac app's own Python first (a full Python that makes venvs: no system Python, no "install developer tools" dialog)
  for (const [c, a] of [...(process.env.ZANCUT_PYTHON && !WIN ? [[process.env.ZANCUT_PYTHON, []]] : []), ['python3.12', []], ['python3', []]]) { try { const v = await run(c, [...a, '-c', 'import sys; print(sys.version_info[0]*100+sys.version_info[1])']); const n = Number(v.trim()); if (n >= 309 && n <= 312) return [c, a]; } catch {} }
  return null;
}
const working = new Set();
async function ensureVenv(v, name) {
  try { await run(v.py, ['-c', v.test], { timeout: 120e3 }); return true; } catch {}
  if (!INSTALL || working.has(name)) return false;
  working.add(name);
  try {
    const base = await basePython(); if (!base) throw new Error('no Python 3.9–3.12 on this computer');
    if (!fs.existsSync(v.py)) await run(base[0], [...base[1], '-m', 'venv', v.dir], { timeout: 10 * 60e3 });
    await run(v.py, ['-m', 'pip', 'install', '--disable-pip-version-check', '--no-input', ...v.pkgs], { timeout: 60 * 60e3 })
      .catch(() => run(v.py, ['-m', 'pip', 'install', '--disable-pip-version-check', '--no-input', ...v.pkgs.map((x) => x.split('==')[0])], { timeout: 60 * 60e3 })); // that version has no build for this computer: the newest from PyPI
    await run(v.py, ['-c', v.test], { timeout: 120e3 });
    record({ tag: 'fixed', key: `install:${name}`, title: `${name} was missing: installed`, detail: `${v.pkgs.join(', ')} in ${v.dir}`, ok: true, action: 'installed' });
    return true;
  } catch (e) { record({ tag: 'critical', key: `install:${name}`, title: `${name} is missing and could not be installed`, detail: str(e.out || e.message, 1500), ok: false, action: 'install failed' }); return false; }
  finally { working.delete(name); }
}
export async function repairTools() { if (win.DESKTOP_APP) return win.repairTools(); await ensureVenv(ENGINE_PY, 'The engine\'s Python (face track, screen tracking)'); }
// frees space: the render history, the editor's frame checks and old screen frames in the jobs (never a customer's file)
export function cleanup() {
  let freed = 0;
  const rm = (p) => { try { const st = fs.statSync(p); freed += st.isDirectory() ? 0 : st.size; fs.rmSync(p, { recursive: true, force: true }); } catch {} };
  rm(path.join(os.homedir(), '.cache', 'zancut', 'hf-history'));
  try { for (const id of fs.readdirSync(path.join(DATA_DIR, 'projects'))) for (const d of ['screen-frames', 'screen-aim', 'check']) rm(path.join(DATA_DIR, 'projects', id, 'ws', 'job', 'work', d)); } catch {}
  return freed;
}

// ---------- health ----------
let health = { at: 0, checks: [] };
export const healthView = () => health;
export async function checkHealth() {
  const checks = [];
  const add = (id, ok, detail) => checks.push({ id, ok, detail: str(detail, 300) });
  // ffmpeg: every cut and encode (bundled in the desktop app)
  try { const enc = await run('ffmpeg', ['-hide_banner', '-encoders']); add('ffmpeg', /libx264/.test(enc), /libx264/.test(enc) ? 'ok' : 'no libx264 encoder'); }
  catch (e) { if (!win.DESKTOP_APP) { add('ffmpeg', false, e.message); record({ tag: 'critical', key: 'health:ffmpeg', title: 'ffmpeg is missing: no video can be cut or rendered', detail: e.message, ok: false, action: MODE === 'desktop' ? 'the app must be installed again' : 'install ffmpeg' }); } }
  // the desktop app (Windows or Mac): ffmpeg new enough, the first run's downloads, its own programs (repaired where they can be)
  if (win.DESKTOP_APP) await win.checkWindows(add, record, { claudePath: CLAUDE_PATH });
  else {
    // elsewhere: an ffmpeg older than 7 fails every cut (the engine's `-/filter_complex <file>`): a code task for the owner
    try { const major = await win.ffmpegMajor(); add('ffmpeg-version', win.ffmpegNewEnough(major), `ffmpeg ${major ?? 'git build'}`); if (!win.ffmpegNewEnough(major)) record({ tag: 'code', key: 'health:ffmpeg-old', title: `ffmpeg ${major} is too old for the engine`, detail: 'The engine passes long filter graphs as `-/filter_complex <file>`, which needs ffmpeg 7 or newer: cutting and rendering fail with "Unrecognized option \'/filter_complex\'".', code: `This computer's ffmpeg is version ${major}; the engine needs 7+. In desktop/prepare.mjs ship an ffmpeg 7+ build for this platform (the Windows app ships Gyan's 9.0.2 essentials build), or install a newer ffmpeg on the server.` }); } catch {}
  }
  // the engine's Python (face track, screen tracking, the cut-out clean-up): installed when missing
  const py = await ensureVenv(ENGINE_PY, 'The engine\'s Python (face track, screen tracking)'); add('python', py, py ? 'ok' : 'missing');
  // WhisperX (exact word timings): without it the words come from whisper alone (a fallback); installed in the background
  const wx = fs.existsSync(WX.py); add('whisperx', wx, wx ? 'ok' : 'missing: whisper alone gives the timings');
  if (!wx && INSTALL) ensureVenv(WX, 'WhisperX (exact word timings)').catch(() => {});
  // Gemini: a key that does not work is taken out of use (the fallbacks carry on) and comes back when it works
  if (geminiKeySet()) {
    try {
      const r = await geminiPing(); // the desktop app asks the backend, which uses the key from Admin → Settings
      if (MODE === 'desktop' && r.status === 401) add('gemini', true, 'not signed in to Zancut: checked again after sign-in'); // not a key problem
      else if (MODE === 'desktop' && [402, 503].includes(r.status)) { setGeminiDown(30 * 60e3); add('gemini', true, r.status === 402 ? 'subscription ended: local fallbacks' : 'no Gemini key on the Zancut server yet: local fallbacks'); }
      else if (r.ok) { if (geminiDown()) { setGeminiDown(0); record({ tag: 'fixed', key: 'health:gemini', title: 'The Gemini key works again: back in use', ok: true }); } add('gemini', true, 'ok'); }
      else if ([400, 401, 403].includes(r.status)) { setGeminiDown(6 * 3600e3); add('gemini', false, `key rejected (${r.status})`); record({ tag: 'fixed', key: 'health:gemini', title: 'The Gemini key does not work: Zancut uses the fallbacks', detail: `Gemini answered ${r.status}. Bangla words come from WhisperX / whisper, the AI voice from the local voice. ${MODE === 'desktop' ? 'Put a working Gemini key in Admin → Settings → API keys.' : 'Put a working GEMINI_API_KEY in .env.'}`, ok: true, action: 'Gemini taken out of use; checked again every 30 min', notify: true }); }
      else add('gemini', true, `answered ${r.status} (kept in use)`);
    } catch (e) { add('gemini', true, `not reachable now (${e.message}); kept in use`); }
  } else add('gemini', true, 'no key: Zancut uses WhisperX, whisper and the local voices');
  // Gemini models Google retired for this key (gemini.mjs skips them and uses the next one): shown, and told once
  try { const gone = Object.keys(JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'gemini-models.json'), 'utf8'))); if (gone.length) { add('gemini-models', true, `retired for this key, the next model is used: ${gone.join(', ')}`); record({ tag: 'fixed', key: 'health:gemini-models', title: `Gemini model${gone.length > 1 ? 's' : ''} retired by Google: ${gone.join(', ')}`, detail: 'Every Gemini call skips it and uses the next model in its list (transcription: gemini-pro-latest). Set GEMINI_TRANSCRIBE_MODEL in .env to choose another.', ok: true, action: 'switched to the next model' }); } } catch {}
  // Claude (the owner's own login): not connected is critical; a usage limit is handled (jobs wait and carry on)
  if (claude.MINE) {
    try { const s = await claude.authStatus(false, claude.dirOf(ownerId()) ?? undefined); const ok = !!s?.connected; add('claude', ok, ok ? (claude.blockedFor(ownerId()) ? claude.limitText(claude.blockedFor(ownerId())) : 'ok') : 'not connected'); if (!ok) record({ tag: 'critical', key: 'health:claude', title: 'Claude is not connected: no AI step can run', detail: 'Connect Claude in Account → Claude.', ok: false, action: 'needs the owner or customer to connect' }); }
    catch (e) { add('claude', false, e.message); }
  }
  // the disk: old caches are cleared when space runs low
  try {
    const s = fs.statfsSync(DATA_DIR), free = s.bavail * s.bsize, gb = (n) => `${(n / 1e9).toFixed(1)} GB`;
    if (free < 5e9) { const freed = cleanup(), after = fs.statfsSync(DATA_DIR); const f2 = after.bavail * after.bsize; add('disk', f2 >= 2e9, `${gb(f2)} free`); record({ tag: f2 < 2e9 ? 'critical' : 'fixed', key: 'health:disk', title: f2 < 2e9 ? 'The disk is almost full' : 'The disk was low: old caches cleared', detail: `${gb(free)} free before, ${gb(f2)} after (freed ${gb(freed)})`, ok: f2 >= 2e9, action: 'caches cleared' }); }
    else add('disk', true, `${gb(free)} free`);
  } catch (e) { add('disk', true, `not measured (${e.message})`); }
  health = { at: Date.now(), checks };
  return health;
}

// ---------- start ----------
let started = false;
// ---------- stuck jobs: one job runs at a time, so a job that hangs makes every other video "wait in line" ----------
// No new step for 20 min (a render: 70) = stuck: stopped, reported, and (prepare, render) run once more; the cause is looked into
let cancelJob = null, jobStatus = null;
const stuckSeen = new Set();
function watchdog() {
  ghosts();
  const id = jobStatus?.().running; if (!id) return;
  const p = store.get(id); if (!p?.job?.startedAt) return;
  const last = Math.max(p.job.startedAt, ...(p.job.steps || []).map((s) => s.t || 0)), kind = p.job.kind;
  if (Date.now() - last < (kind === 'render' ? 70 : 20) * 60e3) return; // a designer step writes a line every few min; 20 quiet min is stuck
  unstick(id, 'no progress for a long time');
}
// a running job that does not move: stopped, run again (prepare / render, twice an hour at most) or left to the customer's Retry,
// and what made it hang looked into. why: "no progress for a long time" (the watchdog) or "a customer asked" (ZanBro)
function unstick(id, why) {
  const p = store.get(id); if (!p?.job?.startedAt) return false;
  const last = Math.max(p.job.startedAt, ...(p.job.steps || []).map((s) => s.t || 0)), kind = p.job.kind;
  if (stuckSeen.has(`${id}:${p.job.startedAt}`)) return false;
  stuckSeen.add(`${id}:${p.job.startedAt}`);
  const k = `${id}:${kind}`, recent = (tries.get(k) || []).filter((t) => t > Date.now() - 3600e3);
  const again = ['prepare', 'render'].includes(kind) && recent.length < 2;
  const stepNow = p.job.steps?.at(-1)?.text || 'starting', logs = logFor(id, last - 5 * 60e3);
  console.error(`[cto] stuck: ${kind} of ${id}, no progress for ${Math.round((Date.now() - last) / 60e3)} min at "${stepNow}"`);
  cancelJob(id);
  const it = record({ tag: again ? 'fixed' : 'critical', key: `stuck:${kind}`, title: `A "${kind}" job was stuck: the other videos were waiting behind it`, detail: `No progress for ${Math.round((Date.now() - last) / 60e3)} min at: ${stepNow}\n\n${logs.slice(-1500)}`, projectId: id, ok: again ? null : false, action: again ? 'stopped and run again' : 'stopped; the customer presses Retry' });
  // after the stop has released the job (agent.mjs: 15 s): run it again, or tell the customer
  later(id, 25e3, () => {
    const q = store.get(id); if (!q || q.job) return;
    if (again) { tries.set(k, [...recent, Date.now()]); waiting.set(id, { itemId: it.id }); try { enqueueJob(id, kind, {}); } catch (x) { settle(it.id, false, `could not start: ${x.message}`); } }
    else { q.error = 'This step got stuck and was stopped. Press Retry to run it again.'; store.save(q, { immediate: true }); }
  });
  // what made it hang, looked into on this computer (a repair from the list when one fits) while the job runs again
  diagnose({ what: `a "${kind}" job of the video ${id} hung (${why}) and was stopped`, text: `Last step: ${stepNow}`, logs, projectId: id }).then((d) => {
    if (d?.cause || d?.repairs?.length) record({ tag: 'fixed', key: `stuck-cause:${kind}`, title: `Why a "${kind}" job hung: ${str(d.cause, 120) || 'looked into'}`, detail: `${d.cause}${repairText(d) ? `\n\nRepaired: ${repairText(d)}` : ''}`, projectId: id, ok: null, action: repairText(d) || 'diagnosed', ...(d.code ? { code: d.code } : {}) });
  }).catch((x) => console.log('[cto] stuck diagnose:', x.message));
  return true;
}

// what the guard (guard.mjs, outside the server) did: listed here, each once (data/guard.read = how far it was read)
const GUARD_LOG = path.join(DATA_DIR, 'guard.jsonl'), GUARD_READ = path.join(DATA_DIR, 'guard.read');
function fromGuard() {
  if (!fs.existsSync(GUARD_LOG)) return;
  const size = fs.statSync(GUARD_LOG).size; let from = Number(fs.existsSync(GUARD_READ) ? fs.readFileSync(GUARD_READ, 'utf8') : 0) || 0;
  if (from > size) from = 0;
  if (from === size) return;
  const fd = fs.openSync(GUARD_LOG, 'r'), buf = Buffer.alloc(size - from); fs.readSync(fd, buf, 0, buf.length, from); fs.closeSync(fd);
  fs.writeFileSync(GUARD_READ, String(size));
  for (const l of buf.toString('utf8').split('\n').filter(Boolean)) {
    let x; try { x = JSON.parse(l); } catch { continue; }
    if (x.kind === 'recovered') continue; // the freeze item already says what was done
    const bad = x.kind === 'frozen' || x.kind === 'error';
    // sent: the guard already told the backend itself (the desktop app's freeze), so it is listed here but not sent twice
    record({ fromCloud: Boolean(x.sent), tag: bad || x.sent ? 'critical' : 'fixed', key: x.sent ? 'guard:frozen' : `guard:${x.kind}`, title: x.title, detail: x.detail || '', projectId: x.id || null, ok: bad ? false : null, action: { freeze: 'the guard stopped the stuck tool', restart: x.sent !== undefined ? 'the app started its server again' : 'the guard started the server again', slow: 'noted what was busy', frozen: 'needs the app opened again' }[x.kind] || 'guard' });
  }
}
// the guard's view of a slow step: what is busy right now (guard-status.json, at most 2 min old)
function guardBusy(projectId) {
  try { const g = JSON.parse(fs.readFileSync(path.join(DATA_DIR, 'guard-status.json'), 'utf8')); if (Date.now() - g.at > 120e3 || g.slow?.id !== projectId) return ''; const b = g.slow.busy || []; return b.length ? `Busy right now: ${b.map((x) => `${x.what} (${Math.round(x.sec / 60)} min)`).join(', ')}.` : 'Busy right now: only the AI, waiting on its answer.'; } catch { return ''; }
}

// A video shown as "waiting in line" or "working" that the job runner does not have (its job died before it could close, or the
// app was killed half-way): freed, told to the owner, and its step run once more. Seen twice in a row (a minute apart) first,
// so a job that is just being handed over is never touched.
const ghostSeen = new Map();
function ghosts() {
  const st = jobStatus?.() || {}, live = new Set([st.running, ...(st.queued || [])].filter(Boolean));
  for (const p of store.list((q) => ['queued', 'editing'].includes(q.status))) {
    if (live.has(p.id)) { ghostSeen.delete(p.id); continue; }
    if (!ghostSeen.has(p.id)) { ghostSeen.set(p.id, Date.now()); continue; }
    ghostSeen.delete(p.id);
    const kind = p.job?.kind, k = `${p.id}:${kind}`, recent = (tries.get(k) || []).filter((t) => t > Date.now() - 3600e3);
    p.status = store.idleStatus(p); p.lastJob = { kind, steps: (p.job?.steps || []).slice(-60), failed: true }; p.job = null; p.error = null;
    store.save(p, { immediate: true });
    const again = kind && enqueueJob && recent.length < 2;
    const it = record({ tag: again ? 'fixed' : 'critical', key: `ghost:${kind || 'job'}`, title: `A video was shown as "${kind ? 'waiting in line' : 'working'}" with nothing running: freed${again ? ' and started again' : ''}`, detail: `Video ${p.id} "${p.name}" (${kind || 'no job'}). The job had stopped without closing; the log around it:\n${logFor(p.id, Date.now() - 30 * 60e3).slice(-1500)}`, projectId: p.id, ok: again ? null : false, action: again ? 'freed; runs the step again' : 'freed; the customer presses Retry' });
    if (again) { tries.set(k, [...recent, Date.now()]); waiting.set(p.id, { itemId: it.id }); try { enqueueJob(p.id, kind, {}); } catch (x) { settle(it.id, false, `could not start: ${x.message}`); } }
    else { p.error = 'This step stopped on its own. Press Retry to run it again.'; store.save(p, { immediate: true }); }
  }
}
// ---------- how a job is going (ZanBro reads it with every message about a video that is being made) ----------
const NAMES = { prepare: 'reading the media and making the transcript', storyboard: 'planning and building the storyboard', render: 'rendering the video', revise: 'making the changes from the comments', scene: 'remaking one scene', replan: 'planning the storyboard again', refresh: 'adding the cut-out to the scenes' };
// how long a step of this kind usually takes here (the median of the last 40 finished ones, from every video's spend list)
let typicalCache = { at: 0, by: {} };
function typicalMin(kind) {
  if (Date.now() - typicalCache.at > 10 * 60e3) {
    const by = {};
    for (const p of store.list()) for (const s of p.spend || []) if (s.sec > 5) (by[s.kind] ||= []).push([s.at || 0, s.sec]);
    typicalCache = { at: Date.now(), by: Object.fromEntries(Object.entries(by).map(([k, v]) => { const x = v.sort((a, b) => b[0] - a[0]).slice(0, 40).map((y) => y[1]).sort((a, b) => a - b); return [k, Math.round(x[x.length >> 1] / 60)]; })) };
  }
  return typicalCache.by[kind] ?? { prepare: 6, storyboard: 18, render: 3, revise: 12, scene: 4, replan: 15, refresh: 2 }[kind] ?? 8;
}
// minutes with no step written before a job counts as not moving (a render writes few steps: its whole usual time, twice)
const quietLimit = (kind) => (kind === 'render' ? Math.max(15, typicalMin('render') * 2) : 10);
export function progress(projectId) {
  const p = store.get(projectId); if (!p?.job || !['queued', 'editing'].includes(p.status)) return null;
  const st = jobStatus?.() || {}, job = p.job, steps = job.steps || [], now = Date.now();
  const started = job.startedAt || null, lastMove = Math.max(started || job.queuedAt || now, ...steps.map((s) => s.t || 0));
  let done = null, total = null;
  for (const s of [...steps].reverse()) { const m = String(s.text || '').match(/(\d+) of (\d+)/); if (m) { done = +m[1]; total = +m[2]; break; } }
  const at = (st.queued || []).indexOf(p.id), typ = typicalMin(job.kind), ran = started ? (now - started) / 60e3 : 0, quiet = (now - lastMove) / 60e3;
  return { kind: job.kind, what: NAMES[job.kind] || job.kind, queued: p.status === 'queued', running: st.running === p.id, ghost: st.running !== p.id && at < 0,
    ahead: at < 0 ? 0 : at + (st.running ? 1 : 0), aheadName: st.running && st.running !== p.id ? store.get(st.running)?.name || null : null,
    step: String(steps.at(-1)?.text || 'starting').slice(0, 160), done, total, ranMin: Math.round(ran), quietMin: Math.round(quiet), typicalMin: typ,
    leftMin: started ? Math.max(1, Math.round(typ - ran)) : null, notMoving: !!started && quiet >= quietLimit(job.kind) };
}
export function progressText(projectId) {
  const g = progress(projectId); if (!g) return '';
  if (g.ghost) return `It is shown as ${g.queued ? 'waiting in line' : 'being made'}, but nothing is running for it: it is stuck (check_and_fix frees it and starts it again).`;
  if (g.queued) return `Waiting in line: ${g.ahead ? `${g.ahead} job${g.ahead > 1 ? 's' : ''} ahead${g.aheadName ? ` (now making "${g.aheadName}")` : ''}` : 'it starts in a moment'}. Then: ${g.what}, usually about ${g.typicalMin} min.`;
  return [`Now ${g.what}: "${g.step}"${g.done != null ? ` (${g.done} of ${g.total} done)` : ''}.`,
    g.ranMin > g.typicalMin ? `Running ${g.ranMin} min: longer than usual (this step usually takes about ${g.typicalMin} min).` : `Running ${g.ranMin} min; this step usually takes about ${g.typicalMin} min, about ${g.leftMin} min left.`,
    g.notMoving ? `Nothing has moved for ${g.quietMin} min: it may be stuck (check_and_fix looks at it now).` : `Last progress ${g.quietMin < 1 ? 'just now' : `${g.quietMin} min ago`}: it is moving.`,
    g.notMoving || g.ranMin > g.typicalMin ? guardBusy(projectId) : ''].filter(Boolean).join(' ');
}

// What is wrong with one video right now and what the CTO did about it. ZanBro asks this for a customer (zanbro.mjs), with
// their question: it is kept in the owner's list (Customer question), and it wakes the CTO up: a job that is not moving is
// stopped and run again now (not after the watchdog's long wait), one shown as waiting with nothing running is freed.
export async function checkVideo(projectId, question = '') {
  const p = store.get(projectId); if (!p) return 'That video is not there any more.';
  const st = jobStatus?.() || {}, out = [], g = progress(p.id);
  if (g?.ghost) { ghostSeen.set(p.id, 0); ghosts(); out.push('It was shown as waiting or being made with nothing running: freed and started again.'); }
  else if (g?.running && g.notMoving) { unstick(p.id, `a customer asked (${str(question, 120) || 'is it stuck?'}) and nothing had moved for ${g.quietMin} min`); out.push(`It had not moved for ${g.quietMin} min, so it was stopped and ${['prepare', 'render'].includes(g.kind) ? 'is starting again now' : 'can be started again with Retry'}; the cause is being looked into.`); }
  else if (g) out.push(progressText(p.id));
  if (p.lastJob?.failed && !p.job && !out.length) {
    const d = await diagnose({ what: `a customer asked why their video ${p.id} is not working${question ? `: "${str(question, 200)}"` : ''}`, text: `${p.error || 'The last step failed.'}`, logs: logFor(p.id, Date.now() - 60 * 60e3), context: `Last step ${p.lastJob.kind}: ${(p.lastJob.steps || []).slice(-8).map((s) => s.text).join(' · ')}`, projectId: p.id }).catch(() => null);
    if (d?.fix === 'retry' && enqueueJob) { const it = record({ tag: 'fixed', key: `asked:${p.lastJob.kind}`, title: `A customer asked about a failed "${p.lastJob.kind}" step: run again`, detail: d.cause, projectId: p.id, ok: null, action: 'runs the step again' }); waiting.set(p.id, { itemId: it.id }); try { enqueueJob(p.id, p.lastJob.kind, {}); out.push(`${d.customer || 'Found the problem.'} Started it again.`); } catch (x) { out.push(`Could not start it again: ${x.message}`); } }
    else out.push(d ? `${d.customer || d.cause}${d.fix === 'none' ? ' (the team was told)' : ''}` : 'The last step failed; the team was told.');
    if (d && d.fix === 'none') record({ tag: 'critical', key: `asked-none:${p.lastJob.kind}`, title: `A customer's "${p.lastJob.kind}" step cannot be fixed by itself`, detail: d.cause, projectId: p.id, ok: false, ...(d.code ? { code: d.code } : {}) });
  }
  if (!out.length) out.push(p.error ? `It shows: "${p.error}"` : 'Nothing is wrong with it right now.');
  const answer = out.join(' ');
  record({ tag: 'asked', key: `asked:${p.id}:${new Date().toISOString().slice(0, 10)}`, title: `A customer asked about "${str(p.name, 60)}"${question ? `: "${str(question, 120)}"` : ''}`, detail: `${g ? `${progressText(p.id) || ''}\n` : ''}Answer: ${answer}`, projectId: p.id, ok: true, action: 'answered through ZanBro' });
  return answer;
}
// A technical question that is not about one video ("is something wrong with Zancut?"): the health checks now, in plain words;
// kept in the owner's list (Customer question)
const PLAIN = { ffmpeg: 'the video tools', python: 'face and screen tracking', whisperx: 'exact word timing', gemini: 'the transcriber for Bangla and other languages', claude: 'the AI editor', disk: 'disk space' };
export async function askGeneral(question = '') {
  const h = await checkHealth().catch(() => ({ checks: [] }));
  const bad = h.checks.filter((c) => !c.ok), st = jobStatus?.() || {};
  const answer = [bad.length ? `Not fully working right now: ${bad.map((c) => PLAIN[c.id] || c.id).join(', ')}; the backup way is used meanwhile and the team was told.` : 'Everything is working right now.',
    st.running ? `A video is being made at this moment${st.queued?.length ? `, ${st.queued.length} waiting` : ''}.` : 'Nothing is being made at this moment.'].join(' ');
  record({ tag: 'asked', key: `asked-general:${new Date().toISOString().slice(0, 10)}`, title: `A customer asked: "${str(question, 140) || 'is something wrong?'}"`, detail: `Answer: ${answer}\n${h.checks.map((c) => `${c.id}: ${c.ok ? 'ok' : c.detail}`).join(' · ')}`, ok: !bad.length, action: 'answered through ZanBro' });
  return answer;
}
// enqueue / cancel / status: agent.mjs's (given here, so this file never imports the job runner)
export function init({ enqueue, cancel, status, canStart }) {
  if (started) return; started = true;
  enqueueJob = enqueue; startGuard = canStart || null; cancelJob = cancel || null; jobStatus = status || null;
  keepLog();
  // paused videos set to carry on by themselves: their timers are set again after a restart
  for (const p of store.list((x) => x.status === 'PAUSED_QUOTA_LIMIT' && x.quota?.autoResume === true && x.lastJob?.kind)) resumeLater(p.id, p.lastJob.kind, p.lastJob.extra || {}, Math.max(Date.now() + 60e3, p.quota.scheduledFor || p.quota.resetAt || 0));
  win.useOwnFfmpeg(); // the Windows app: an ffmpeg the CTO repaired earlier
  if (MODE === 'desktop') { setTimeout(() => flushOutbox(), 30e3).unref?.(); setInterval(() => flushOutbox(), 5 * 60e3).unref?.(); }
  if (cancelJob && jobStatus) setInterval(() => { try { watchdog(); } catch (e) { console.log('[cto] watchdog:', e.message); } }, 60e3).unref?.();
  setInterval(() => { try { fromGuard(); } catch (e) { console.log('[cto] guard:', e.message); } }, 60e3).unref?.(); setTimeout(() => { try { fromGuard(); } catch {} }, 20e3).unref?.();
  setTimeout(() => checkHealth().catch((e) => console.log('[cto] health:', e.message)), 15000).unref?.();
  setInterval(() => checkHealth().catch((e) => console.log('[cto] health:', e.message)), 30 * 60e3).unref?.();
}
// Admin → CTO: its items, the health checks and the counts by tag (the bug reports and skill lessons come from their own files)
export function view() {
  const items = load().items;
  const counts = Object.fromEntries(Object.keys(TAGS).map((t) => [t, items.filter((i) => i.tag === t && i.status === 'open').length]));
  return { items, health, counts, tags: TAGS, install: INSTALL };
}
