// Bug reports from the app ("Report a bug" in Zancut AI and the profile menu). Kept in data/reports.json with their
// screenshots in data/reports/; the Admin portal lists them (new / seen / fixed) and Telegram gets a notice when it is set up.
import fs from 'node:fs';
import path from 'node:path';
import { customAlphabet } from 'nanoid';
import os from 'node:os';
import { DATA_DIR, MODE } from './config.mjs';
import * as store from './store.mjs';
import * as admin from './admin.mjs';
import * as cto from './cto.mjs';

const newId = customAlphabet('abcdefghijkmnpqrstuvwxyz23456789', 8);
const FILE = path.join(DATA_DIR, 'reports.json'), FILES = path.join(DATA_DIR, 'reports');
const read = () => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return []; } };
const write = (list) => { fs.writeFileSync(`${FILE}.tmp`, JSON.stringify(list, null, 1)); fs.renameSync(`${FILE}.tmp`, FILE); };
const str = (x, n) => String(x ?? '').trim().slice(0, n);

export const STATUSES = ['new', 'seen', 'fixed'];
export const list = () => read().sort((a, b) => b.createdAt - a.createdAt);
export const counts = () => { const l = read(); return { total: l.length, new: l.filter((r) => r.status === 'new').length }; };

// u: the signed-in user · body: { text, expected, page, projectId, step, shot (a data URL), details }
export function add(u, body, ua = '') {
  const all = read(), day = Date.now() - 864e5;
  if (all.filter((r) => r.userId === u.id && r.createdAt > day).length >= 20) throw Object.assign(new Error('You have sent many reports today. Thank you: we are on them.'), { status: 429 });
  const text = str(body.text, 4000);
  if (text.length < 3) throw Object.assign(new Error('Tell us what went wrong.'), { status: 400 });
  const id = newId();
  const shot = saveShot(id, body.shot);
  // the technical details the person can switch off: where they were and what the video's last step said
  const withDetails = body.details !== false, p = withDetails && body.projectId ? store.get(String(body.projectId).replace(/\W/g, '')) : null;
  const mine = p && (p.ownerId === u.id || u.role === 'admin') ? p : null;
  const r = {
    id, createdAt: Date.now(), status: 'new', userId: u.id, user: str(u.name, 80), email: str(u.email, 120), text, expected: str(body.expected, 2000),
    ...(withDetails ? { page: str(body.page, 200), step: Number(body.step) || null, ua: str(ua, 300) } : {}),
    ...(mine ? { projectId: mine.id, project: str(mine.name, 80), projectStatus: mine.status, projectError: str(mine.error, 400), job: mine.lastJob ? { kind: mine.lastJob.kind, failed: !!mine.lastJob.failed } : null } : {}),
    shot, note: '',
  };
  write([r, ...all].slice(0, 2000));
  admin.notify(`🐞 Bug report from ${r.user} (${r.email})\n\n${text.slice(0, 600)}${r.project ? `\n\nVideo: ${r.project}${r.step ? ` · step ${r.step}` : ''}${r.projectError ? `\nError: ${r.projectError}` : ''}` : ''}\n\nThe CTO is diagnosing it: Admin → CTO.`);
  // the CTO reads it with the log of that moment, saves its diagnosis on it and fixes the video when it can; in the desktop
  // app the report then goes to the cloud server too (the owner's Admin → Reports and Telegram), with what the CTO found here
  const log = cto.recentLog();
  cto.onReport(r, (fields) => update(id, fields)).catch((e) => console.log('[cto] report:', e.message)).finally(() => {
    if (MODE !== 'desktop') return;
    const now = read().find((x) => x.id === id) || r;
    cto.toCloud('/api/desktop/report', { text: r.text, expected: r.expected, page: r.page, step: r.step, ua: r.ua, project: r.project, projectStatus: r.projectStatus,
      projectError: r.projectError, job: r.job, diagnosis: now.diagnosis || null, log, device: os.hostname(), ...(body.shot && String(body.shot).length < 8e6 ? { shot: body.shot } : {}) });
  });
  return { id };
}
// a screenshot (a data URL) saved beside the reports; → its file name or null
function saveShot(id, dataUrl) {
  const m = String(dataUrl || '').match(/^data:image\/(png|jpeg|webp);base64,([A-Za-z0-9+/=]+)$/);
  if (!m) return null;
  const buf = Buffer.from(m[2], 'base64'); if (buf.length > 6e6) return null;
  fs.mkdirSync(FILES, { recursive: true });
  const shot = `${id}.${m[1] === 'jpeg' ? 'jpg' : m[1]}`;
  fs.writeFileSync(path.join(FILES, shot), buf);
  return shot;
}
// on the cloud server: a bug report a customer sent from the desktop app, with what the CTO on their computer found
export function fromDesktop(u, b) {
  const all = read(), day = Date.now() - 864e5;
  if (all.filter((r) => r.userId === u.id && r.createdAt > day).length >= 40) throw Object.assign(new Error('Too many reports today.'), { status: 429 });
  const text = str(b.text, 4000);
  if (text.length < 3) throw Object.assign(new Error('Empty report.'), { status: 400 });
  const id = newId(), d = b.diagnosis && typeof b.diagnosis === 'object' ? b.diagnosis : null;
  const r = {
    id, createdAt: Date.now(), status: 'new', userId: u.id, user: str(u.name, 80), email: str(u.email, 120), text, expected: str(b.expected, 2000),
    page: str(b.page, 200), step: Number(b.step) || null, ua: str(b.ua, 300), from: 'desktop', device: str(b.device, 60),
    ...(b.project ? { project: str(b.project, 80), projectStatus: str(b.projectStatus, 20), projectError: str(b.projectError, 400), job: b.job ? { kind: str(b.job.kind, 20), failed: !!b.job.failed } : null } : {}),
    ...(d ? { diagnosis: { cause: str(d.cause, 600), fix: str(d.fix, 20), customer: str(d.customer, 200), code: str(d.code, 4000), repairs: Array.isArray(d.repairs) ? d.repairs.slice(0, 6).map((x) => ({ name: str(x.name, 30), ok: !!x.ok, out: str(x.out, 200) })) : [] } } : {}),
    log: str(b.log, 20000), shot: saveShot(id, b.shot), note: '',
  };
  write([r, ...all].slice(0, 2000));
  admin.notify(`🐞 Bug report from ${r.user} (${r.email}) · desktop app${r.device ? ` on ${r.device}` : ''}\n\n${text.slice(0, 600)}${r.project ? `\n\nVideo: ${r.project}${r.projectError ? `\nError: ${r.projectError}` : ''}` : ''}${d?.cause ? `\n\nThe CTO on their computer: ${str(d.cause, 300)}${r.diagnosis.repairs.length ? `\nRepaired: ${r.diagnosis.repairs.map((x) => `${x.name} ${x.ok ? 'ok' : 'failed'}`).join(', ')}` : ''}` : ''}\n\nAdmin → Reports.`);
  return { id };
}
export function update(id, fields) {
  const all = read(), r = all.find((x) => x.id === id); if (!r) return null;
  if (STATUSES.includes(fields.status)) r.status = fields.status;
  if (typeof fields.note === 'string') r.note = fields.note.slice(0, 2000);
  if (fields.diagnosis && typeof fields.diagnosis === 'object') r.diagnosis = fields.diagnosis; // the CTO's (cto.mjs)
  write(all); return r;
}
export function remove(id) {
  const all = read(), r = all.find((x) => x.id === id); if (!r) return false;
  if (r.shot) fs.rmSync(path.join(FILES, r.shot), { force: true });
  write(all.filter((x) => x.id !== id)); return true;
}
export const shotPath = (id) => { const r = read().find((x) => x.id === id); return r?.shot ? path.join(FILES, r.shot) : null; };
