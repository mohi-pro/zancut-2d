// Plan requests from the landing page, admin settings, and Telegram notifications.
import fs from 'node:fs';
import path from 'node:path';
import { customAlphabet } from 'nanoid';
import { DATA_DIR } from './config.mjs';

const newId = customAlphabet('abcdefghijkmnpqrstuvwxyz23456789', 10);
const REQUESTS = path.join(DATA_DIR, 'requests.json');
const SETTINGS = path.join(DATA_DIR, 'settings.json');

const read = (file, fallback) => { try { return JSON.parse(fs.readFileSync(file, 'utf8')); } catch { return fallback; } };
const write = (file, data) => { fs.writeFileSync(file + '.tmp', JSON.stringify(data, null, 2)); fs.renameSync(file + '.tmp', file); };

let requests = read(REQUESTS, []);
let settings = {
  allowSignup: false,
  telegramToken: process.env.TELEGRAM_BOT_TOKEN || '',
  telegramChatId: process.env.TELEGRAM_CHAT_ID || '',
  supportContact: 'mmmamon70@gmail.com',
  ...read(SETTINGS, {}),
};

export const getSettings = () => settings;
export function publicSettings() {
  return { allowSignup: settings.allowSignup, supportContact: settings.supportContact };
}
export function adminSettings() {
  return { ...settings, telegramToken: settings.telegramToken ? `${settings.telegramToken.slice(0, 6)}…${settings.telegramToken.slice(-4)}` : '', telegramConnected: Boolean(settings.telegramToken && settings.telegramChatId),
    smtp: { ...(settings.smtp || {}), pass: settings.smtp?.pass ? '••••••••' : '' } };
}
export function saveSettings(fields) {
  if (typeof fields.allowSignup === 'boolean') settings.allowSignup = fields.allowSignup;
  if (typeof fields.supportContact === 'string') settings.supportContact = fields.supportContact.slice(0, 200);
  if (typeof fields.telegramToken === 'string' && fields.telegramToken && !fields.telegramToken.includes('…')) {
    settings.telegramToken = fields.telegramToken.trim();
    settings.telegramChatId = '';
  }
  if (typeof fields.telegramChatId === 'string') settings.telegramChatId = fields.telegramChatId.trim();
  // email (SMTP) for the forgot-password code; the password is kept when the masked one comes back
  if (fields.smtp && typeof fields.smtp === 'object') {
    const old = settings.smtp || {}, f = fields.smtp, str = (v, n = 200) => String(v || '').trim().slice(0, n);
    settings.smtp = { host: str(f.host), port: Number(f.port) || 587, user: str(f.user), from: str(f.from), pass: f.pass && !String(f.pass).includes('•') ? String(f.pass).slice(0, 200) : old.pass || '' };
  }
  if (fields.pricing && typeof fields.pricing === 'object') settings.pricing = cleanPricing(fields.pricing, settings.pricing || {});
  write(SETTINGS, settings);
}

// Only known pricing fields, only numbers (and model names), so a typo can't break billing.
function cleanPricing(input, prev) {
  const num = (v, min = 0, max = 1e7) => (Number.isFinite(Number(v)) ? Math.min(max, Math.max(min, Number(v))) : undefined);
  const out = { ...prev };
  for (const k of ['usdToBdt', 'creditsPerTaka', 'minToStart', 'trialSafetyCap']) {
    const v = num(input[k]);
    if (v !== undefined) out[k] = v;
  }
  if (input.plans) {
    out.plans = { ...(prev.plans || {}) };
    for (const id of ['trial', 'starter', 'creator', 'agency']) {
      const src = input.plans[id];
      if (!src) continue;
      const plan = { ...(out.plans[id] || {}) };
      for (const k of ['usd', 'bdt', 'credits', 'versions']) { const v = num(src[k]); if (v !== undefined) plan[k] = v; }
      if (typeof src.who === 'string') plan.who = src.who.slice(0, 200);
      if (typeof src.desktop === 'boolean') plan.desktop = src.desktop;
      out.plans[id] = plan;
    }
  }
  if (input.topUp) out.topUp = { ...(prev.topUp || {}), ...Object.fromEntries(['usd', 'bdt', 'credits'].map((k) => [k, num(input.topUp[k])]).filter(([, v]) => v !== undefined)) };
  if (input.models) out.models = { ...(prev.models || {}), ...Object.fromEntries(['short', 'long'].map((k) => [k, input.models[k]]).filter(([, v]) => /^claude-[a-z0-9-]+$/.test(v || ''))) };
  return out;
}

/* ---------- Telegram ---------- */

async function tg(method, body) {
  if (!settings.telegramToken) throw new Error('Add your Telegram bot token first.');
  const r = await fetch(`https://api.telegram.org/bot${settings.telegramToken}/${method}`, {
    method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body || {}),
  });
  const j = await r.json().catch(() => ({}));
  if (!j.ok) throw new Error(j.description || `Telegram error ${r.status}`);
  return j.result;
}

// After the owner sends any message to their bot, this finds their chat id.
export async function findTelegramChat() {
  const updates = await tg('getUpdates', { limit: 20 });
  const chat = updates.reverse().map((u) => u.message?.chat || u.my_chat_member?.chat).find(Boolean);
  if (!chat) throw new Error('No messages yet. Open your bot in Telegram, press Start (or send "hi"), then try again.');
  settings.telegramChatId = String(chat.id);
  write(SETTINGS, settings);
  return { chatId: settings.telegramChatId, name: chat.first_name || chat.title || chat.username || '' };
}

export async function notify(text) {
  if (!settings.telegramToken || !settings.telegramChatId) return false;
  try {
    await tg('sendMessage', { chat_id: settings.telegramChatId, text, disable_web_page_preview: true });
    return true;
  } catch (e) {
    console.error('[telegram]', e.message);
    return false;
  }
}

/* ---------- plan requests ---------- */

export const listRequests = () => [...requests].sort((a, b) => b.createdAt - a.createdAt);
export const getRequest = (id) => requests.find((r) => r.id === id);

export function addRequest({ name, email, phone, plan, message, ip, renewal = false }) {
  name = String(name || '').trim().slice(0, 80);
  email = String(email || '').trim().toLowerCase().slice(0, 120);
  phone = String(phone || '').trim().slice(0, 30);
  if (!name) throw new Error('Enter your name.');
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email.');
  if (!renewal && phone.replace(/\D/g, '').length < 6) throw new Error('Enter a phone number we can reach you on.'); // a renewal: we know the account
  // Basic flood guard: one open request per email, and few per IP per hour.
  if (requests.some((r) => r.email === email && r.status === 'new')) throw new Error('We already have your request. We\'ll be in touch soon.');
  const hourAgo = Date.now() - 3600e3;
  if (requests.filter((r) => r.ip === ip && r.createdAt > hourAgo).length >= 5) throw new Error('Too many requests. Try again later.');
  const r = {
    id: newId(), name, email, phone, plan: ['trial', 'starter', 'creator', 'agency', 'topup'].includes(plan) ? plan : 'creator',
    message: String(message || '').trim().slice(0, 1000), status: 'new', ip, createdAt: Date.now(),
  };
  requests.push(r);
  write(REQUESTS, requests);
  return r;
}

export function updateRequest(r, fields) {
  if (fields.status && ['new', 'contacted', 'approved', 'declined'].includes(fields.status)) r.status = fields.status;
  if (typeof fields.adminNote === 'string') r.adminNote = fields.adminNote.slice(0, 500);
  if (fields.userId) r.userId = fields.userId;
  r.updatedAt = Date.now();
  write(REQUESTS, requests);
  return r;
}
