// What Claude does where Gemini is not needed (Gemini is only used for the AI voice, Bangla / multilingual or low-confidence
// transcription, and the optional sound-mix test): these are the prompts and the parsers. agent.mjs runs them through its one
// Claude call (runQuery), so cost, cancelling and the sandbox rules are the same as for every other task.
//   tagPrompt / parseTags     English speech with good local timings: emphasis, uiText, literalMetaphor, Magic Cut ranges
//   spokenPrompt              a customer script polished for speaking, or written from an idea (no Gemini)
//   breakdownText             the tags as the short section the director reads (same for Claude's and Gemini's tags)
import { langName } from './studio.mjs';

// ---------- tags for the words of the first cut ----------
const TAG_RULES = `You are the listening editor of Zancut, a video editing studio. You read the numbered words of a first cut and tell the
director (Opus) what each moment MEANS and what a viewer should SEE. You advise; the director decides.

1. CUT (magicCutRanges): word ranges that are not part of the final, clean sentence: fillers (uh, um, er, hmm; Bangla ইয়ে, মানে as
   filler), false starts and repeats (keep only the LAST complete take), retakes (a sentence said again better → remove the first).
   Never remove words that carry meaning, never more than 35% of the words.
2. EMPHASIS: "hero" = the one big word of a line (a number, a name, the twist) · "key" = bold · "feel" = an emotion word · "small" = quiet.
3. MOMENTS: split the kept speech into ideas of 2–5 s. For each: says, meaning, subtext (the intent beyond the literal words), feel and
   energy (calm | normal | fast), kind ("literal" when the words name something a viewer can SEE: a tool, a number, steps, a place, a
   comparison; "metaphor" when they are an idea or a feeling, then describe the motion and colour that carry it), show, visual
   (chart|stat|steps|screenshot|logo|photo|icon|list|compare|headline|speaker|motion), data (numbers or names), importance 1–3,
   emphasisWords (1–2 word numbers where the voice would peak: the power words), literalMetaphor (a concrete physical or UI action that
   ACTS OUT the words, e.g. "when your costs keep rising" → a red cost gauge climbing into a warning zone, then slashed), and uiText
   (a 1–4 word card label, at most 18 characters, in the speaker's language; English tech and brand words stay in Latin letters).
4. HOOK: the strongest 2–3 s line to open with. SPEAKER PLAN: which moments show the speaker (30–50% of the video).
Dead air is measured by code from the timings: do not list pauses.

Answer JSON only:
{"language": "<code>", "topic": "…", "summary": "one sentence", "tone": "…",
 "magicCutRanges": [{"from": a, "to": b, "why": "filler|false start|repeat|retake", "words": "…"}],
 "emphasis": [{"word": n, "kind": "hero|key|feel|small"}],
 "hook": {"from": a, "to": b, "why": "…"},
 "moments": [{"from": a, "to": b, "says": "…", "meaning": "…", "subtext": "…", "feel": "…", "energy": "calm|normal|fast", "kind": "literal|metaphor", "metaphor": "…", "show": "…", "visual": "…", "data": "…", "importance": 1, "emphasisWords": [n], "literalMetaphor": "…", "uiText": "…"}],
 "speaker": "which moments show the speaker"}`;
export function tagPrompt(p, words) {
  const list = words.map((w, i) => `${i}:${w.text}@${Number(w.start).toFixed(2)}`).join(' ');
  return `${TAG_RULES}\n\nThe video: "${p.name || ''}"${p.prompt ? ` — the customer says: ${p.prompt}` : ''}. Language: ${langName(p.language) || 'as spoken'}.\n\n## The first cut's words (number:word@second)\n${list}`;
}
const jsonOf = (text) => { const m = String(text || '').match(/```json\s*([\s\S]*?)```/) || String(text || '').match(/(\{[\s\S]*\})/); if (!m) return null; try { return JSON.parse(m[1]); } catch { return null; } };
// a tags object in one shape for both sources (Claude's answer or Gemini's transcription): `cut` is what board.mjs reads
export function parseTags(text) {
  const j = typeof text === 'object' && text ? text : jsonOf(text);
  return j ? normalizeTags(j) : null;
}
export function normalizeTags(j) {
  const moments = (Array.isArray(j.moments) ? j.moments : []).filter((m) => m && Number.isInteger(+m.from) && Number.isInteger(+m.to)).map((m) => ({ ...m, from: +m.from, to: +m.to, uiText: String(m.uiText || '').slice(0, 18) }));
  const cut = (Array.isArray(j.magicCutRanges) ? j.magicCutRanges : j.cut || []).filter((c) => c && Number.isInteger(+c.from) && Number.isInteger(+c.to)).map((c) => ({ ...c, from: +c.from, to: +c.to }));
  return { language: j.language || '', topic: j.topic || '', summary: j.summary || '', tone: j.tone || '', cut, fix: [], emphasis: Array.isArray(j.emphasis) ? j.emphasis : [], pauses: [], pace: j.pace || {}, hook: j.hook || {}, moments, speaker: j.speaker || '' };
}
// word numbers in the transcript's own list → the first cut's numbers (each first-cut word knows its source number in `src`)
export function toFirstCut(tags, firstCut) {
  if (!tags) return null;
  const at = (src, up) => { // first-cut index of a source word number (the nearest kept one when it was cut)
    if (up) { for (let i = 0; i < firstCut.length; i++) if (firstCut[i].src >= src) return i; return firstCut.length - 1; }
    for (let i = firstCut.length - 1; i >= 0; i--) if (firstCut[i].src <= src) return i; return 0;
  };
  const range = (x) => ({ ...x, from: at(x.from, true), to: Math.max(at(x.from, true), at(x.to, false)) });
  const inside = (c) => { const ids = firstCut.map((w, i) => (w.src >= c.from && w.src <= c.to ? i : -1)).filter((i) => i >= 0); return ids.length ? { ...c, from: ids[0], to: ids.at(-1) } : null; };
  return { ...tags, cut: tags.cut.map(inside).filter(Boolean),
    emphasis: tags.emphasis.map((e) => ({ ...e, word: at(e.word, true) })), hook: tags.hook?.from != null ? range(tags.hook) : tags.hook,
    moments: tags.moments.map((m) => ({ ...range(m), emphasisWords: (m.emphasisWords || []).map((n) => at(n, true)) })) };
}
export function breakdownText(bd) {
  if (!bd) return '';
  const j = (x) => JSON.stringify(x);
  return `\n## The listening breakdown (the meaning and feeling of each moment; every moment marked "must be visual" gets that visual, the others should)
- Language ${bd.language || '?'} · topic: ${bd.topic || ''} · tone: ${bd.tone || ''}
- Summary: ${bd.summary || ''}
- Emphasis (hero = giant word, key = bold, feel = italic, small = quiet): ${j((bd.emphasis || []).map((c) => [c.word, c.kind]))}
- Hook: ${j(bd.hook || {})}
- Speaker plan: ${bd.speaker || ''}
- Moments (meaning, feeling and what to SHOW for what is said):
${(bd.moments || []).map((m) => `  - ${m.from}–${m.to} "${m.says || ''}" · means: ${m.meaning || ''}${m.subtext ? ` · subtext: ${m.subtext}` : ''} · feel: ${m.feel || ''}${m.energy ? ` (${m.energy})` : ''} · ${m.kind || ''}${m.kind === 'metaphor' && m.metaphor ? ` (${m.metaphor})` : ''} → ${m.visual || ''}: ${m.show || ''}${m.data ? ` [${m.data}]` : ''}${m.literalMetaphor ? ` · literal metaphor: ${m.literalMetaphor}` : ''}${m.uiText ? ` · uiText: "${m.uiText}"` : ''}${(m.emphasisWords || []).length ? ` · emphasis words: ${m.emphasisWords.join(', ')}` : ''}${m.importance >= 3 ? ' (must be visual)' : ''}`).join('\n')}
`;
}

// ---------- the script for the AI voice ----------
export const SPOKEN = (lang) => `Spoken rhythm: short, punchy clauses of 6–10 words, one idea each, the way a top creator talks${lang === 'bn' ? ' — natural spoken Bangla (not formal written Bangla), English tech and brand words in Latin letters' : ''}; a strong first line (the hook); [pause: 0.25s] before each key reveal or number; no lists, headings, stage directions or emojis; numbers as they are said.`;


// ---------- proofreading words a local model heard (no Gemini: Bangla and other languages, or unsure English) ----------
// whisper misspells Bangla (জন্ট → জাস্ট, ভেভসাইট → ওয়েবসাইট) and on a pause it can loop one phrase many times. Claude corrects
// each word in place (the times stay: every word keeps its slot) and names the loops to drop; it never rewrites what was said.
export function proofPrompt(p, words, from) {
  const list = words.map((w, i) => `${from + i}:${w.text}`).join(' ');
  return `You proofread a speech transcript for video captions. The words were heard by a local speech model that is weak in ${langName(p.language) || 'this language'}: it misspells words, splits or joins them wrongly, and on a long pause it can repeat one phrase again and again (a loop) that was never said.
Fix ONLY the spelling and the obviously misheard words, so each caption reads as correct, natural ${langName(p.language) || ''} (Bangla: standard spelling, চলিত; English tech and brand words in Latin letters as people write them: ChatGPT, YouTube, Work Mode). Never rewrite the sentence, never add or reorder words, never change the meaning or the speaker's own words and style.
${p.script ? `The script the speaker read (use it for the right spelling of names and words; they may have said it a little differently):\n${String(p.script).slice(0, 4000)}\n` : ''}${p.glossary ? `Names to spell right: ${p.glossary}\n` : ''}
The words (number:word):
${list}

Answer JSON only:
{"fix": [[number, "the corrected word"], ...], "drop": [[from, to], ...]}
- fix: only the words that change. One word in, one word out. When two numbered pieces are really ONE word, give the whole word on the first and "" on the second.
- drop: only a phrase repeated 3 or more times in a row with nothing new (a loop): keep the first time, drop the repeats (number ranges, inclusive). Never drop a word that was really said once.`;
}
export function parseProof(text) {
  const j = jsonOf(text);
  if (!j) return null;
  const fix = (Array.isArray(j.fix) ? j.fix : []).filter((x) => Array.isArray(x) && Number.isInteger(+x[0]) && typeof x[1] === 'string').map((x) => [+x[0], x[1].trim()]);
  const drop = (Array.isArray(j.drop) ? j.drop : []).filter((x) => Array.isArray(x) && Number.isInteger(+x[0]) && Number.isInteger(+x[1]) && +x[1] >= +x[0]).map((x) => [+x[0], +x[1]]);
  return { fix, drop };
}
// the corrected words: fixes in place ("" joins a piece into the word before it, which takes its end time), loops dropped
export function applyProof(words, proof) {
  const fix = new Map(proof.fix), drop = new Set();
  for (const [a, b] of proof.drop) for (let i = a; i <= b && b - a < 200; i++) drop.add(i);
  const out = [];
  words.forEach((w, i) => {
    if (drop.has(i)) return;
    const t = fix.has(i) ? fix.get(i) : w.text;
    if (t === '' && out.length) { out[out.length - 1] = { ...out[out.length - 1], end: Math.max(out[out.length - 1].end, w.end) }; return; }
    out.push(t !== w.text ? { ...w, text: t || w.text, proofread: true } : w);
  });
  return out;
}
