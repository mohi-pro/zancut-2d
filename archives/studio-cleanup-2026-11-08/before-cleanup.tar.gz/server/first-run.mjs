// Desktop app (Windows and Mac): "Getting Zancut ready", once per computer, as soon as the app starts. A new computer has none of what
// HyperFrames downloads on first use, and without it a video fails half-way (no speech model = no transcript = "Your footage
// could not be prepared"). So everything is fetched up front, one bar for all of it (~1.3 GB), with Retry:
//   tools   HyperFrames itself (pinned: ZANCUT_HYPERFRAMES from desktop/main.cjs), into npm's cache
//   chrome  the renderer (chrome-headless-shell)
//   speech  the English speech-to-text model (Parakeet) and its runtime
//   cutout  the speaker cut-out model (background removal) and its runtime
//   voice   the free AI voice (server/voice-setup.mjs), at the same time
// On only where desktop/main.cjs sets ZANCUT_FIRST_RUN (the desktop app; the web: unchanged). Each part is marked done in
// ~/.cache/hyperframes/zancut-ready.json, beside what it downloaded (cache emptied = downloaded again).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { npx } from '../engine/media/lib.mjs';
import { voiceSetup, startVoiceSetup } from './voice-setup.mjs';

const on = () => process.env.ZANCUT_FIRST_RUN === '1';
const HF = path.join(os.homedir(), '.cache', 'hyperframes');
const MARK = path.join(HF, 'zancut-ready.json');
const SPEC = process.env.ZANCUT_HYPERFRAMES || 'hyperframes';
const MB = 1024 * 1024;
const HF_BYTES = 1330 * MB; // what the four parts leave in ~/.cache/hyperframes (0.8.192: chrome 269, parakeet 639, runtimes 256, cut-out 168 MB)
const VOICE_BYTES = 340 * MB;

const PARTS = [
  { id: 'tools', label: 'the video tools', args: ['--version'] },
  { id: 'chrome', label: 'the video renderer (115 MB)', args: ['browser', 'ensure'], dir: 'chrome' },
  { id: 'speech', label: 'the speech-to-text model (about 700 MB)', args: ['models', 'install', 'parakeet', '--json'], dir: 'parakeet' },
  { id: 'cutout', label: 'the speaker cut-out model (about 400 MB)', args: null, dir: 'background-removal' },
];

const marks = () => { try { const m = JSON.parse(fs.readFileSync(MARK, 'utf8')); return m.hyperframes === SPEC ? m.done || [] : []; } catch { return []; } };
// the renderer's browser itself (chrome-headless-shell[.exe]) somewhere under ~/.cache/hyperframes/chrome: its folder alone is not
// enough (a download cut off half-way, or antivirus taking the program away, leaves the folder: every render then failed)
export function chromeExe(dir = path.join(HF, 'chrome'), depth = 0) {
  if (depth > 5) return null;
  let es = []; try { es = fs.readdirSync(dir, { withFileTypes: true }); } catch { return null; }
  for (const e of es) if (e.isFile() && /^chrome-headless-shell(\.exe)?$/i.test(e.name) && fs.statSync(path.join(dir, e.name)).size > 1e6) return path.join(dir, e.name);
  for (const e of es) if (e.isDirectory()) { const f = chromeExe(path.join(dir, e.name), depth + 1); if (f) return f; }
  return null;
}
const isDone = (p) => marks().includes(p.id) && (!p.dir || fs.existsSync(path.join(HF, p.dir))) && (p.id !== 'chrome' || !!chromeExe());
const markDone = (id) => { fs.mkdirSync(HF, { recursive: true }); fs.writeFileSync(MARK, JSON.stringify({ hyperframes: SPEC, done: [...new Set([...marks(), id])] })); };
const voiceOn = () => voiceSetup().on;
const ready = () => PARTS.every(isDone) && (!voiceOn() || voiceSetup().ready);

let job = null; // the run in progress: { part, error, hfBytes }

function sizeOf(dir) {
  let n = 0;
  try { for (const e of fs.readdirSync(dir, { withFileTypes: true })) { const f = path.join(dir, e.name); n += e.isDirectory() ? sizeOf(f) : e.isFile() ? fs.statSync(f).size : 0; } } catch { /* not there yet */ }
  return n;
}

export function firstRun() {
  if (!on()) return { on: false };
  if (ready()) return { on: true, ready: true };
  const v = voiceSetup();
  const hf = Math.min(HF_BYTES, job?.hfBytes ?? sizeOf(HF));
  const done = hf + (!v.on ? 0 : v.ready ? VOICE_BYTES : (v.pct / 100) * VOICE_BYTES);
  const pct = Math.min(99, Math.round((done / (HF_BYTES + (v.on ? VOICE_BYTES : 0))) * 100));
  const parts = [...PARTS.map((p) => ({ id: p.id, label: p.label, done: isDone(p), now: job?.part === p.id })),
    ...(v.on ? [{ id: 'voice', label: 'the AI voice (320 MB)', done: !!v.ready, now: !v.ready && !!v.busy }] : [])];
  return { on: true, ready: false, busy: !!job && !job.error, pct, parts, error: job?.error || (v.on && v.error) || null };
}

export function startFirstRun() {
  if (!on() || ready()) return firstRun();
  if (voiceOn() && !voiceSetup().ready) startVoiceSetup(); // its own download, at the same time (Retry starts it again too)
  if (job && !job.error) return firstRun();
  const j = (job = { part: null, error: null, hfBytes: sizeOf(HF) });
  const tick = setInterval(() => { j.hfBytes = sizeOf(HF); }, 2000);
  install(j).then(() => { if (job === j) job = null; }, (e) => {
    console.error('[first run]', j.part, e.message?.slice(0, 600));
    const p = PARTS.find((x) => x.id === j.part);
    j.error = `Zancut could not download ${p?.label || 'what it needs'}. Check the internet connection, then press Retry.`;
  }).finally(() => clearInterval(tick));
  return firstRun();
}

// Before every render: the renderer's browser is really there, else it is downloaded again now (the render goes on after).
// Throws a clear reason when it cannot be had (no internet). The desktop app only (elsewhere HyperFrames looks after it itself).
export async function ensureRenderer(onStep = () => {}) {
  if (!on() || chromeExe()) return;
  console.error('[renderer] the video renderer (Chrome) is missing: downloading it again');
  onStep('Setting up the video renderer again (one time)');
  try { await run(['browser', 'ensure']); } catch (e) { throw new Error(`The video renderer could not be installed: ${String(e.message).slice(0, 300)}`); }
  if (!chromeExe()) throw new Error('The video renderer was downloaded but its program is missing (antivirus may have removed it).');
  markDone('chrome');
}

// a job that needs these (the desktop app, first days): start or join the run and wait for it, telling progress every 10%
export async function awaitFirstRun(onProgress, signal) {
  startFirstRun();
  for (let told = -1; ; await new Promise((r) => setTimeout(r, 1500))) {
    const s = firstRun();
    if (!s.on || s.ready) return;
    if (s.error) throw new Error(s.error);
    if (signal?.aborted) throw new Error('stopped');
    if (Math.floor(s.pct / 10) > told) { told = Math.floor(s.pct / 10); onProgress(`Getting Zancut ready on this computer, one time only: ${s.pct}%`); }
  }
}

const run = (args, timeout = 30 * 60000) => new Promise((resolve, reject) => {
  const [cmd, a, o] = npx(['hyperframes', ...args]);
  execFile(cmd, a, { ...o, timeout, maxBuffer: 1 << 24, windowsHide: true, cwd: os.tmpdir() }, (e, stdout, stderr) => {
    if (e) return reject(new Error(`${args.join(' ')}: ${String(stderr || e.message).trim().slice(-500)}`));
    resolve(String(stdout));
  });
});

async function install(j) {
  for (const p of PARTS) {
    if (isDone(p)) continue;
    j.part = p.id;
    console.log(`[first run] ${p.id}: ${p.label}`);
    if (p.id === 'cutout') {
      // the cut-out downloads its model and runtime the first time it runs: run it once on a small picture
      const dir = fs.mkdtempSync(path.join(os.tmpdir(), 'zancut-ready-'));
      try {
        await new Promise((res, rej) => execFile('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'testsrc=size=160x120', '-frames:v', '1', path.join(dir, 'in.png')], { windowsHide: true, timeout: 60000 }, (e) => (e ? rej(e) : res())));
        const out = await run(['remove-background', path.join(dir, 'in.png'), '-o', path.join(dir, 'out.png'), '--quality', 'fast', '--json']);
        if (!/"ok":\s*true/.test(out)) throw new Error(`remove-background: ${out.slice(-300)}`);
      } finally { fs.rmSync(dir, { recursive: true, force: true }); }
    } else {
      const out = await run(p.args);
      if (p.args.includes('--json') && !/"ok":\s*true/.test(out)) throw new Error(`${p.args.join(' ')}: ${out.slice(-300)}`);
    }
    markDone(p.id);
  }
  j.part = null;
}
