// Accounts, sign-in sessions, plans, payments and usage. JSON files are enough for the MVP; move to a database
// before scaling.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { customAlphabet } from 'nanoid';
import { DATA_DIR } from './config.mjs';
import { pricing, planInfo, planId, publicPricing, jobSize } from './pricing.mjs';

const FILE = path.join(DATA_DIR, 'users.json');
const newId = customAlphabet('abcdefghijkmnpqrstuvwxyz23456789', 12);
const SESSION_DAYS = 30;

// Web footage limits keep uploads small for a shared server; the desktop app has none.
export const WEB_LIMITS = { maxFootageSec: 120, maxFileMB: 300 };

let db = { users: [], sessions: {}, desktopTokens: {} };
try { db = { desktopTokens: {}, ...JSON.parse(fs.readFileSync(FILE, 'utf8')) }; } catch {}

export function persist() {
  fs.writeFileSync(FILE + '.tmp', JSON.stringify(db, null, 2));
  fs.renameSync(FILE + '.tmp', FILE);
}

function hash(password, salt = crypto.randomBytes(16).toString('hex')) {
  return `${salt}:${crypto.scryptSync(password, salt, 64).toString('hex')}`;
}
function verify(password, stored) {
  const [salt, h] = stored.split(':');
  const a = Buffer.from(h, 'hex');
  const b = crypto.scryptSync(password, salt, 64);
  return a.length === b.length && crypto.timingSafeEqual(a, b);
}

const month = () => new Date().toISOString().slice(0, 7);
const sha = (t) => crypto.createHash('sha256').update(String(t)).digest('hex');
const DESKTOP_TOKEN_DAYS = 90;
export const tempPassword = () => crypto.randomBytes(9).toString('base64url');

function roll(u) {
  if (u.usage?.month !== month()) u.usage = { month: month(), edits: 0, credits: 0, tokensIn: 0, tokensOut: 0, costUsd: 0 };
  u.usage.credits ||= 0;
  u.totals ||= { edits: 0, credits: 0, tokensIn: 0, tokensOut: 0, costUsd: 0 };
  u.totals.credits ||= 0;
  u.payments ||= [];
  u.jobs ||= [];
  u.grants ||= [];
  u.plan = planId(u.plan || 'monthly');
  if (!pricing().plans[u.plan]) u.plan = 'monthly';
  // Balance: monthly plan credits (reset on renewal) + extra credits (top-ups, never expire).
  if (!u.credits) u.credits = { plan: planInfo(u.plan).credits, extra: 0 };
  u.trial ||= { projectId: null, done: false, used: 0 };
  return u;
}

export const balance = (u) => Math.round((roll(u).credits.plan || 0) + (u.credits.extra || 0));

// The plan as the browser sees it, plus the limits that apply on the web.
// Try once: one video of up to 1 minute.
const planView = (u) => ({ ...planInfo(u.plan), ...WEB_LIMITS, versionsPerVideo: planInfo(u.plan).versions });

// Subscription end. null = no end date (admins, or open-ended accounts).
export const isExpired = (u) => Boolean(u.expiresAt && u.expiresAt < Date.now() && u.role !== 'admin');
// what the customer reads when their month is over (or was never started: a new sign-up waits for the admin)
export const expiredText = (u) => (u.payments?.length || u.activated ? 'Your month of Zancut has ended. Renew to keep editing; your videos are safe.' : 'Your account is not active yet. Zancut turns it on once your month is paid.');

export function publicUser(u) {
  if (!u) return null;
  roll(u);
  return {
    id: u.id, email: u.email, name: u.name, phone: u.phone || '', role: u.role || 'user',
    plan: planView(u), usage: { month: u.usage.month, edits: u.usage.edits, credits: Math.round(u.usage.credits) },
    createdAt: u.createdAt, expiresAt: u.expiresAt || null, expired: isExpired(u), pending: isExpired(u) && !(u.payments?.length || u.activated), zanbro: ['playful', 'calm', 'off'].includes(u.zanbro) ? u.zanbro : null, autoResume: u.autoResume === true ? 'on' : u.autoResume === false ? 'off' : 'ask', lang: u.lang || '',
    tokenSaver: Boolean(u.tokenSaver),
    credits: balance(u), creditsPlan: Math.round(u.credits.plan), creditsExtra: Math.round(u.credits.extra),
    trial: null,
    pricing: publicPricing(),
  };
}

// Full record for the admin portal (never the password hash).
export function adminUser(u) {
  roll(u);
  const { password, ...rest } = u;
  const devices = Object.entries(db.desktopTokens).filter(([, t]) => t.userId === u.id)
    .map(([key, t]) => ({ id: key.slice(0, 12), device: t.device, created: t.created, lastUsed: t.lastUsed }));
  return { ...rest, plan: u.plan, planInfo: planInfo(u.plan), expired: isExpired(u), devices, credits: balance(u),
    creditsPlanLeft: Math.round(u.credits.plan), creditsExtraLeft: Math.round(u.credits.extra),
    paidTotal: u.payments.reduce((a, p) => a + Number(p.amount || 0), 0) };
}

// The owner is the first admin account (made on the setup screen). Customers never count.
export const hasOwner = () => db.users.some((u) => !u.test && u.role === 'admin');
export const all = () => db.users;

export function createUser({ email, password, name, phone = '', plan = 'monthly', role = 'user', test = false, notes = '', expiresAt = null, weak = false }) {
  email = String(email || '').trim().toLowerCase();
  if (!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email)) throw new Error('Enter a valid email.');
  if (!weak && String(password || '').length < 8) throw new Error('Use at least 8 characters for the password.');
  if (db.users.some((u) => u.email === email)) throw new Error('An account with this email already exists.');
  const u = roll({
    id: newId(), email, name: String(name || '').trim().slice(0, 60) || email.split('@')[0], phone: String(phone).slice(0, 30),
    password: hash(password), plan: pricing().plans[planId(plan)] ? planId(plan) : 'monthly', role: role === 'admin' ? 'admin' : 'user', test, notes: String(notes).slice(0, 2000),
    disabled: false, createdAt: Date.now(), expiresAt: Number(expiresAt) || null,
    // Only the owner (the first admin) inherits the projects made before accounts existed.
    first: !test && role === 'admin' && !hasOwner(),
  });
  db.users.push(u);
  persist();
  return u;
}

// Kept for scripts/create-test-user.mjs.
export const signUp = (fields, { test = false } = {}) => createUser({ ...fields, test });

export function signIn({ email, password }) {
  const u = db.users.find((x) => x.email === String(email || '').trim().toLowerCase());
  if (!u || !verify(String(password || ''), u.password)) throw new Error('Wrong email or password.');
  if (u.disabled) throw new Error('This account is paused. Contact support.');
  return u;
}

export function createSession(u) {
  const token = crypto.randomBytes(32).toString('hex');
  // Drop expired sessions while we're here.
  for (const [k, v] of Object.entries(db.sessions)) if (v.expires < Date.now()) delete db.sessions[k];
  db.sessions[sha(token)] = { userId: u.id, expires: Date.now() + SESSION_DAYS * 864e5, created: Date.now() };
  persist();
  return token;
}

export function endSession(token) {
  if (token && db.sessions[sha(token)]) { delete db.sessions[sha(token)]; persist(); }
}

export function fromToken(token) {
  if (!token || !/^[a-f0-9]{64}$/.test(token)) return null;
  const s = db.sessions[sha(token)];
  if (!s || s.expires < Date.now()) return null;
  const u = db.users.find((x) => x.id === s.userId);
  return u && !u.disabled ? u : null;
}

// Signs the user out everywhere: browser sessions and desktop apps.
export function revokeAll(u) {
  for (const [k, v] of Object.entries(db.sessions)) if (v.userId === u.id) delete db.sessions[k];
  for (const [k, v] of Object.entries(db.desktopTokens)) if (v.userId === u.id) delete db.desktopTokens[k];
  persist();
}

export function revokeDevice(u, idPrefix) {
  for (const [k, v] of Object.entries(db.desktopTokens)) if (v.userId === u.id && k.startsWith(idPrefix)) delete db.desktopTokens[k];
  persist();
}

// Desktop app logins: a long-lived token the app uses for its account and for AI calls.
export function createDesktopToken(u, device = '') {
  const token = `zcd_${crypto.randomBytes(32).toString('hex')}`;
  db.desktopTokens[sha(token)] = { userId: u.id, device: String(device).slice(0, 60), created: Date.now(), lastUsed: Date.now() };
  persist();
  return token;
}
export function fromDesktopToken(token) {
  if (!token || !/^zcd_[a-f0-9]{64}$/.test(token)) return null;
  const t = db.desktopTokens[sha(token)];
  if (!t || t.created + DESKTOP_TOKEN_DAYS * 864e5 < Date.now()) return null;
  t.lastUsed = Date.now();
  const u = db.users.find((x) => x.id === t.userId);
  return u && !u.disabled ? u : null;
}

export const byId = (id) => db.users.find((u) => u.id === id) || null;

export function update(u, fields) {
  for (const k of ['name', 'phone', 'notes']) if (typeof fields[k] === 'string') u[k] = fields[k].slice(0, k === 'notes' ? 2000 : 60);
  if (fields.plan && pricing().plans[planId(fields.plan)] && planId(fields.plan) !== u.plan) {
    u.plan = planId(fields.plan);
    // A new plan starts with its full monthly credits, minus any overdraft from a job that ran past zero.
    u.credits.plan = planInfo(u.plan).credits + Math.min(0, u.credits.plan || 0);
  }
  if (typeof fields.disabled === 'boolean') {
    u.disabled = fields.disabled;
    if (u.disabled) revokeAll(u);
  }
  if ('expiresAt' in fields) u.expiresAt = fields.expiresAt ? Number(fields.expiresAt) : null;
  if (fields.role === 'admin' || fields.role === 'user') u.role = fields.role;
  if (Array.isArray(fields.styles)) u.styles = fields.styles; // "My style" presets (checked by the server route)
  if (typeof fields.lang === 'string' && /^([a-z]{2,3})?$/.test(fields.lang)) u.lang = fields.lang; // the workspace language: every AI tool answers in it
  persist();
  return u;
}

// Forgot password: a 6-digit code sent by email, kept only as its hash, 10 minutes, 5 tries. In memory: a restart means
// asking for a new code. At most 3 codes per email in 15 minutes.
export const CODE_MINUTES = 10;
const codes = new Map(); // email → { hash, exp, tries, sent: [times] }
export function makeResetCode(u) {
  const now = Date.now(), c = codes.get(u.email) || { sent: [] };
  c.sent = (c.sent || []).filter((t) => now - t < 15 * 60e3);
  if (c.sent.length >= 3) throw new Error('Too many codes asked for. Wait 15 minutes, then try again.');
  const code = String(crypto.randomInt(0, 1e6)).padStart(6, '0');
  codes.set(u.email, { hash: crypto.createHash('sha256').update(`${u.id}:${code}`).digest('hex'), exp: now + CODE_MINUTES * 60e3, tries: 0, sent: [...c.sent, now] });
  return code;
}
export function useResetCode(email, code, password) {
  const u = db.users.find((x) => x.email === String(email || '').trim().toLowerCase());
  const c = u && codes.get(u.email);
  if (!u || !c || c.exp < Date.now()) throw new Error('That code has ended. Ask for a new one.');
  if (c.tries >= 5) { codes.delete(u.email); throw new Error('Too many wrong codes. Ask for a new one.'); }
  const hash = crypto.createHash('sha256').update(`${u.id}:${String(code || '').trim()}`).digest('hex');
  if (hash !== c.hash) { c.tries += 1; throw new Error('That code is not right. Check the email and try again.'); }
  setPassword(u, password);
  codes.delete(u.email);
  persist();
  return u;
}

export function setPassword(u, password) {
  if (String(password).length < 8) throw new Error('Use at least 8 characters.');
  u.password = hash(password);
  revokeAll(u);
}

// Extra credits (a top-up sold over bKash, a goodwill gift…). They never expire.
export function grantCredits(u, credits, note = '') {
  roll(u);
  const n = Math.round(Number(credits));
  if (!Number.isFinite(n) || n === 0) throw new Error('Enter a number of credits.');
  u.credits.extra = Math.max(0, u.credits.extra + n);
  u.grants.push({ at: Date.now(), credits: n, note: String(note).slice(0, 200) });
  persist();
}

// Renewal: the plan's monthly credits are reset (top-ups are kept). An overdraft (a job that finished past zero)
// is paid back from the new month.
export function renewCredits(u) {
  roll(u);
  u.credits.plan = planInfo(u.plan).credits + Math.min(0, u.credits.plan || 0);
  persist();
}

export function addPayment(u, { amount, currency = 'USD', method = '', date, period = '', note = '' }) {
  roll(u);
  const p = {
    id: newId(), amount: Math.round(Number(amount) * 100) / 100, currency: String(currency).slice(0, 8),
    method: String(method).slice(0, 40), date: date || new Date().toISOString().slice(0, 10), period: String(period).slice(0, 40),
    note: String(note).slice(0, 300), createdAt: Date.now(),
  };
  if (!Number.isFinite(p.amount)) throw new Error('Enter an amount.');
  u.payments.push(p);
  persist();
  return p;
}

// Adds months to the subscription, from today or from the current end date if it's still in the future.
export function extend(u, months) {
  const from = u.expiresAt && u.expiresAt > Date.now() ? new Date(u.expiresAt) : new Date();
  from.setMonth(from.getMonth() + Number(months));
  u.expiresAt = from.getTime();
  u.activated = true;
  renewCredits(u);
  return u.expiresAt;
}

export function removePayment(u, id) {
  roll(u);
  u.payments = u.payments.filter((p) => p.id !== id);
  persist();
}

// Credits a job must have before it starts: the low end of what that kind of job usually uses (never less than the
// minimum), so a job can't start on a near-empty balance and run deep into debt. A running job always finishes.
export function creditsNeeded(project, kind) {
  const P = pricing();
  if (!kind || !project?.type) return P.minToStart;
  const est = kind === 'scene' || kind === 'revise' ? P.estimates.change : P.estimates[jobSize(project)] || P.estimates.short;
  return Math.max(P.minToStart, Math.round(est[0]));
}

// Can this person start an AI job on this project? Returns null when yes, or { code, error } when not.
// One monthly plan, no credits: only a month that has ended (or not started) stops new AI steps. A running job always finishes.
export function cannotStart(u) {
  roll(u);
  if (isExpired(u)) return { code: 'expired', error: expiredText(u) };
  return null;
}

// Can this person create another project? Any number while their month is on.
export function cannotCreate(u) {
  roll(u);
  if (isExpired(u)) return { code: 'expired', error: expiredText(u) };
  return null;
}

// Kept for older callers (there is no trial any more)
export function claimTrial() {}
export function finishTrial() {}

export function countEdit(u) {
  roll(u);
  u.usage.edits += 1;
  u.totals.edits += 1;
  persist();
}

// AI usage as it arrives, in credits: numbers for the admin only (this month and in all). Nothing is taken from anyone.
export function spendCredits(u, credits) {
  roll(u);
  if (!(credits > 0)) return;
  u.usage.credits += credits;
  u.totals.credits += credits;
  persistSoon();
}

let persistTimer = null;
function persistSoon() {
  clearTimeout(persistTimer);
  persistTimer = setTimeout(persist, 1000);
}

// Login brute-force guard: 8 failures per email+IP in 15 minutes locks that pair for 15 minutes.
const fails = new Map();
export function checkLock(key) {
  const f = fails.get(key);
  if (f && f.count >= 8 && Date.now() - f.first < 15 * 60e3) throw new Error('Too many attempts. Try again in 15 minutes.');
  if (f && Date.now() - f.first >= 15 * 60e3) fails.delete(key);
}
export function noteFail(key) {
  const f = fails.get(key) || { count: 0, first: Date.now() };
  f.count += 1;
  fails.set(key, f);
}
export const clearFails = (key) => fails.delete(key);


// Tokens and cost of one AI run (from the engine's result, or the desktop AI relay).
export function recordUsage(u, { projectId = null, kind = 'edit', tokensIn = 0, tokensOut = 0, costUsd = 0, credits = 0, ok = true, source = 'web' }) {
  roll(u);
  for (const bucket of [u.usage, u.totals]) {
    bucket.tokensIn = (bucket.tokensIn || 0) + tokensIn;
    bucket.tokensOut = (bucket.tokensOut || 0) + tokensOut;
    bucket.costUsd = Number(((bucket.costUsd || 0) + costUsd).toFixed(4));
  }
  u.jobs.push({ at: Date.now(), projectId, kind, tokensIn, tokensOut, costUsd: Number(costUsd.toFixed(4)), credits: Math.round(credits), ok, source });
  if (u.jobs.length > 500) u.jobs.splice(0, u.jobs.length - 500);
  persist();
}

export const COOKIE = 'zc_session';
export function readCookie(req) {
  const m = (req.headers.cookie || '').match(new RegExp(`(?:^|; )${COOKIE}=([a-f0-9]+)`));
  return m ? m[1] : null;
}
