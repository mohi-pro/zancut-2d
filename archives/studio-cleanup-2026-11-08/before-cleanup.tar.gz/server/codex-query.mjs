// Local Codex login adapter for the existing editor desk. The pipeline still owns
// scene permissions, validation, screenshots, review, and rendering.
import fs from 'node:fs';
import path from 'node:path';
import http from 'node:http';
import crypto from 'node:crypto';
import { spawn } from 'node:child_process';
import { StreamableHTTPServerTransport } from '@modelcontextprotocol/sdk/server/streamableHttp.js';

const sessions = new Set();
export async function codexQuery(prompt, extra, { ws, signal, step, onUsage = () => {} }) {
  const model = 'gpt-6.1-sol';
  const dir = path.join(ws, 'qa', 'codex');
  fs.mkdirSync(dir, { recursive: true });
  const tag = `${Date.now()}-${crypto.randomBytes(4).toString('hex')}`;
  const output = path.join(dir, `${tag}.txt`), log = fs.createWriteStream(path.join(dir, `${tag}.jsonl`));
  const texts = [], images = [];
  if (typeof prompt === 'string') texts.push(prompt);
  else for await (const msg of prompt) for (const block of msg.message?.content || []) {
    if (block.type === 'text') texts.push(block.text);
    else if (block.type === 'image' && block.source?.data) {
      const file = path.join(dir, `${tag}-${images.length}.jpg`);
      fs.writeFileSync(file, Buffer.from(block.source.data, 'base64')); images.push(file);
    }
  }
  let server, transport;
  const token = crypto.randomBytes(24).toString('hex');
  try {
    if (extra.mcp) {
      transport = new StreamableHTTPServerTransport({ sessionIdGenerator: () => crypto.randomUUID() });
      await extra.mcp.instance.connect(transport);
      server = http.createServer(async (req, res) => {
        if (req.headers.authorization !== `Bearer ${token}`) { res.writeHead(401).end(); return; }
        try {
          let body;
          if (req.method === 'POST') { let raw = ''; for await (const part of req) raw += part; body = JSON.parse(raw); }
          await transport.handleRequest(req, res, body);
        } catch (e) { if (!res.headersSent) res.writeHead(500); res.end(String(e.message)); }
      });
      await new Promise((resolve) => server.listen(0, '127.0.0.1', resolve));
    }
    const system = typeof extra.systemPrompt === 'string' ? extra.systemPrompt : extra.systemPrompt?.append || '';
    const instructions = `${system}\n\nYou are operating the Zancut video pipeline. Use the zancut MCP desk tools for all scene writes and visual inspection; do not use shell or filesystem tools to bypass the desk. The desk enforces your assigned scenes and returns real rendered images. Complete the requested work, including looking at frames and making corrections. Do not ask the user questions. Do not invoke Claude or other AI models. All AI work in this run uses ${model}.`;
    const args = ['exec', '--ignore-user-config', '--skip-git-repo-check', '-m', model,
      '-c', 'model_reasoning_effort="medium"', '-c', `developer_instructions=${JSON.stringify(instructions)}`,
      '-s', 'read-only', '--json', '-o', output];
    if (server) args.push('-c', `mcp_servers.zancut={url="http://127.0.0.1:${server.address().port}/mcp",http_headers={Authorization="Bearer ${token}"},default_tools_approval_mode="approve",startup_timeout_sec=60,tool_timeout_sec=600}`);
    for (const file of images) args.push('-i', file);
    if (extra.resume && sessions.has(extra.resume)) args.push(extra.fork ? 'fork' : 'resume', extra.resume);
    args.push('-');
    const env = Object.fromEntries(Object.entries(process.env).filter(([k]) => !/KEY|TOKEN|SECRET|PASSW|CREDENTIAL|PRIVATE|COOKIE|SESSION|AUTH/i.test(k) && !/^(CLAUDE|ANTHROPIC_)/i.test(k)));
    let id, buffer = '', errors = '', failure = '';
    step?.(`GPT-6.1 Sol: ${extra.what || 'video editor'}`);
    await new Promise((resolve, reject) => {
      const child = spawn(process.env.ZANCUT_CODEX_PATH || 'codex', args, { cwd: ws, env, stdio: ['pipe', 'pipe', 'pipe'], signal });
      const timer = setTimeout(() => child.kill('SIGTERM'), 35 * 60e3);
      child.stdout.on('data', (data) => {
        log.write(data); buffer += data;
        const lines = buffer.split('\n'); buffer = lines.pop();
        for (const line of lines) try {
          const event = JSON.parse(line);
          if (event.type === 'thread.started') { id = event.thread_id; sessions.add(id); }
          if (event.type === 'turn.completed') onUsage(event.usage || {});
          if (event.type === 'turn.failed' || event.type === 'error') failure = event.error?.message || event.message || line;
          if (event.type === 'item.started' && event.item?.type === 'mcp_tool_call') console.log(`[codex] ${extra.what}: ${event.item.tool}`);
        } catch {}
      });
      child.stderr.on('data', (data) => { errors = (errors + data).slice(-5000); });
      child.once('error', (e) => { clearTimeout(timer); reject(e); });
      child.once('close', (code) => { clearTimeout(timer); code === 0 && !failure ? resolve() : reject(new Error(`Codex ${extra.what || ''}: ${failure || errors || `exit ${code}`}`)); });
      child.stdin.end(texts.join('\n\n'));
    });
    return { result: fs.readFileSync(output, 'utf8'), session_id: id, is_error: false };
  } finally {
    log.end();
    await transport?.close().catch(() => {});
    server?.closeAllConnections();
    if (server) await new Promise((resolve) => server.close(resolve));
  }
}
