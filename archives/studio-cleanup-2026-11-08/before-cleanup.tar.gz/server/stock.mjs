// Stock photos and videos for a storyboard row that asks for one (director.mjs pickStock): Pexels + Pixabay (free
// licences; need PEXELS_API_KEY / PIXABAY_API_KEY in .env; the desktop app goes through the backend), NASA's image and video library for space / science subjects
// (public domain, no key) and Openverse photos (CC0, public domain, CC BY: no key). Any source may be down: the others
// still answer, and a row with no picture at all becomes a designed graphic (editor.mjs stockToGraphic).
// Runs in the server, so API keys never reach the job. A download goes into assets/stock/ and its licence into
// work/credits.json (CC BY credits go into the version notes).
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { DESKTOP, services, serviceToken } from './desktop-client.mjs';

const run = promisify(execFile);
const UA = { 'User-Agent': 'zancut/1.0' };
const get = async (url, headers = {}, ms = 20000) => {
  const r = await fetch(url, { headers: { ...UA, ...headers }, signal: AbortSignal.timeout(ms) });
  if (!r.ok) throw new Error(`${r.status} from ${new URL(url).host}`);
  return r;
};

// best video file: mp4, long side nearest 1920 (at least 720)
const bestFile = (files) => files.filter((f) => /mp4/.test(f.type || f.url) && Math.max(f.w, f.h) >= 720)
  .sort((a, b) => Math.abs(Math.max(a.w, a.h) - 1920) - Math.abs(Math.max(b.w, b.h) - 1920))[0];

// The desktop app has no keys: the search goes to the Zancut backend (signed in as the customer), which asks Pexels /
// Pixabay with the keys from Admin → Settings and hands back the same answer. The files download straight from them.
export const stockKeys = () => (DESKTOP ? Boolean(serviceToken()) : Boolean(process.env.PEXELS_API_KEY || process.env.PIXABAY_API_KEY));
const pexelsGet = (kind, qs) => (DESKTOP
  ? get(services.pexels(kind === 'video' ? 'videos' : 'photos', qs), services.auth())
  : get(`https://api.pexels.com/${kind === 'video' ? 'videos/search' : 'v1/search'}?${qs}`, { Authorization: process.env.PEXELS_API_KEY }));
const pixabayGet = (kind, qs) => (DESKTOP
  ? get(services.pixabay(kind === 'video' ? 'videos' : 'photos', qs), services.auth())
  : get(`https://pixabay.com/api/${kind === 'video' ? 'videos/' : ''}?key=${process.env.PIXABAY_API_KEY}&${qs}`));

async function pexels(q, kind, orient) {
  if (DESKTOP ? !serviceToken() : !process.env.PEXELS_API_KEY) return [];
  const o = orient ? `&orientation=${orient}` : '';
  if (kind === 'video') {
    const j = await (await pexelsGet('video', `query=${encodeURIComponent(q)}&per_page=8${o}`)).json();
    return (j.videos || []).map((v) => { const f = bestFile((v.video_files || []).map((x) => ({ url: x.link, type: x.file_type, w: x.width, h: x.height }))); return f && { src: 'pexels', kind, url: f.url, w: f.w, h: f.h, seconds: v.duration, thumb: v.image, title: (v.url || '').split('/').filter(Boolean).pop()?.replace(/-\d+$/, '').replace(/-/g, ' ') || q, by: v.user?.name, page: v.url, license: 'Pexels licence (free, no credit needed)', credit: '' }; }).filter(Boolean);
  }
  const j = await (await pexelsGet('photo', `query=${encodeURIComponent(q)}&per_page=8${o}`)).json();
  return (j.photos || []).map((p) => ({ src: 'pexels', kind, url: p.src.large2x || p.src.original, w: p.width, h: p.height, thumb: p.src.medium, title: p.alt || q, by: p.photographer, page: p.url, license: 'Pexels licence (free, no credit needed)', credit: '' }));
}

async function pixabay(q, kind, orient) {
  if (DESKTOP ? !serviceToken() : !process.env.PIXABAY_API_KEY) return [];
  const base = `q=${encodeURIComponent(q.slice(0, 100))}&per_page=8&safesearch=true`;
  if (kind === 'video') {
    const j = await (await pixabayGet('video', base)).json();
    return (j.hits || []).map((v) => { const f = bestFile(['large', 'medium'].map((k) => v.videos?.[k]).filter((x) => x?.url).map((x) => ({ url: x.url, type: 'mp4', w: x.width, h: x.height }))); return f && { src: 'pixabay', kind, url: f.url, w: f.w, h: f.h, seconds: v.duration, thumb: v.videos?.medium?.thumbnail || v.videos?.small?.thumbnail, title: v.tags, by: v.user, page: v.pageURL, license: 'Pixabay licence (free, no credit needed)', credit: '' }; }).filter(Boolean);
  }
  const ori = orient === 'portrait' ? 'vertical' : orient === 'landscape' ? 'horizontal' : 'all';
  const j = await (await pixabayGet('photo', `${base}&image_type=photo&orientation=${ori}`)).json();
  return (j.hits || []).map((p) => ({ src: 'pixabay', kind, url: p.largeImageURL, w: p.imageWidth, h: p.imageHeight, thumb: p.webformatURL, title: p.tags, by: p.user, page: p.pageURL, license: 'Pixabay licence (free, no credit needed)', credit: '' }));
}

// NASA (images-api.nasa.gov, public domain): only for subjects it has (space, earth from orbit, science, weather); a video
// uses its medium file (the originals can be hundreds of MB)
const NASA_TOPIC = /\b(space|earth|planet|moon|mars|jupiter|saturn|rocket|launch|nasa|satellite|astronaut|galaxy|star|stars|sun|solar|orbit|universe|cosmos|telescope|iss|aurora|hurricane|cyclone|storm|climate|science|scientist|lab|laboratory|meteor|asteroid|comet|eclipse)\b/i;
async function nasa(q, kind) {
  if (!NASA_TOPIC.test(q)) return [];
  const j = await (await get(`https://images-api.nasa.gov/search?${new URLSearchParams({ q, media_type: kind === 'video' ? 'video' : 'image' })}`)).json();
  const items = (j.collection?.items || []).slice(0, 4), out = [];
  for (const it of items) {
    try {
      const d = it.data?.[0] || {}, files = await (await get(it.href, {}, 8000)).json();
      const pickF = (re) => files.find((f) => re.test(f));
      const url = kind === 'video' ? pickF(/~medium\.mp4$/) || pickF(/~small\.mp4$/) : pickF(/~large\.jpg$/) || pickF(/~medium\.jpg$/);
      const thumb = (it.links || []).find((l) => l.rel === 'preview')?.href || pickF(/~thumb\.jpg$/);
      if (url) out.push({ src: 'nasa', kind, url: url.replace(/^http:/, 'https:'), w: kind === 'video' ? 1280 : 1920, h: kind === 'video' ? 720 : 1080, seconds: kind === 'video' ? 10 : undefined, thumb: thumb?.replace(/^http:/, 'https:'), title: d.title || q, by: d.center ? `NASA ${d.center}` : 'NASA', page: `https://images.nasa.gov/details/${encodeURIComponent(d.nasa_id || '')}`, license: 'Public domain (NASA)', credit: '' });
    } catch { /* next item */ }
  }
  return out;
}

async function openverse(q, kind, orient) {
  if (kind === 'video') return [];
  const ar = { portrait: 'tall', landscape: 'wide', square: 'square' }[orient];
  const j = await (await get(`https://api.openverse.org/v1/images/?${new URLSearchParams({ q, license: 'cc0,pdm,by', page_size: '20', ...(ar ? { aspect_ratio: ar } : {}) })}`)).json();
  return (j.results || []).filter((r) => !r.width || Math.max(r.width, r.height) >= 1000).map((r) => {
    const lic = r.license === 'by' ? `CC BY ${r.license_version || ''}`.trim() : r.license === 'cc0' ? 'CC0' : 'Public domain';
    return { src: 'openverse', kind, url: r.url, w: r.width, h: r.height, thumb: r.thumbnail, title: r.title || q, by: r.creator || 'unknown', page: r.foreign_landing_url, license: lic, credit: r.license === 'by' ? `"${r.title}" by ${r.creator || 'unknown'} (${lic}) ${r.foreign_landing_url || ''}`.trim() : '' };
  });
}

// The storyboard flow (no AI tool calls): candidates for a search, then download the chosen one.
export async function stockCandidates(q, kind = 'photo', orientation, n = 6) {
  const lists = await Promise.allSettled([pexels(q, kind, orientation), pixabay(q, kind, orientation), nasa(q, kind), openverse(q, kind, orientation)]);
  // the sources take turns (so NASA's or Pexels' best are seen next to Pixabay's); Openverse last
  const good = (x) => (x.kind !== 'video' || (x.seconds || 0) >= 3) && Math.max(x.w || 0, x.h || 0) >= 1000;
  const per = lists.map((r) => (r.status === 'fulfilled' ? r.value.filter(good) : [])), main = per.slice(0, -1), out = [];
  for (let k = 0; out.length < n && main.some((l) => l[k]); k++) for (const l of main) if (l[k] && out.length < n) out.push(l[k]);
  return [...out, ...per.at(-1)].slice(0, n);
}
export async function downloadStock(jobDir, pick, q) {
  const r = await get(pick.url, {}, 90000);
  const buf = Buffer.from(await r.arrayBuffer());
  const ext = pick.kind === 'video' ? '.mp4' : (/png/.test(r.headers.get('content-type') || '') ? '.png' : '.jpg');
  const slug = String(q).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 30) || 'stock';
  const dir = path.join(jobDir, 'assets', 'stock'); fs.mkdirSync(dir, { recursive: true });
  let file = `${slug}${ext}`; for (let k = 2; fs.existsSync(path.join(dir, file)); k++) file = `${slug}-${k}${ext}`;
  fs.writeFileSync(path.join(dir, file), buf);
  const cf = path.join(jobDir, 'work', 'credits.json');
  let credits = {}; try { credits = JSON.parse(fs.readFileSync(cf, 'utf8')); } catch {}
  credits[`assets/stock/${file}`] = { source: pick.src, license: pick.license, by: pick.by, page: pick.page, credit: pick.credit };
  fs.mkdirSync(path.dirname(cf), { recursive: true }); fs.writeFileSync(cf, JSON.stringify(credits, null, 1));
  return { file: `assets/stock/${file}`, seconds: pick.seconds || null };
}
// One picture of every stock moment's candidates: a row per moment, candidates 1–n left to right (grey = no picture).
export async function candidatesSheet(rows, out) {
  const dir = fs.mkdtempSync(path.join(path.dirname(out), 'cand-')), strips = [];
  try {
    for (const [i, list] of rows.entries()) {
      const cells = [];
      for (let j = 0; j < 6; j++) {
        const f = path.join(dir, `r${i}c${j}.jpg`), x = list[j];
        try { if (!x) throw 0; fs.writeFileSync(f, Buffer.from(await (await get(x.thumb, {}, 10000)).arrayBuffer())); } catch { await run('ffmpeg', ['-y', '-v', 'error', '-f', 'lavfi', '-i', 'color=c=0x555555:s=240x180', '-frames:v', '1', f]).catch(() => {}); }
        cells.push(f);
      }
      const strip = path.join(dir, `s${i}.jpg`);
      await run('ffmpeg', ['-y', '-v', 'error', ...cells.flatMap((c) => ['-i', c]), '-filter_complex', `${cells.map((_, k) => `[${k}:v]scale=240:180:force_original_aspect_ratio=decrease,pad=244:184:(ow-iw)/2:(oh-ih)/2:color=white,setsar=1[v${k}]`).join(';')};${cells.map((_, k) => `[v${k}]`).join('')}hstack=inputs=${cells.length}[o]`, '-map', '[o]', '-frames:v', '1', strip]);
      strips.push(strip);
    }
    if (strips.length === 1) fs.copyFileSync(strips[0], out);
    else await run('ffmpeg', ['-y', '-v', 'error', ...strips.flatMap((c) => ['-i', c]), '-filter_complex', `${strips.map((_, k) => `[${k}:v]`).join('')}vstack=inputs=${strips.length}[o]`, '-map', '[o]', '-frames:v', '1', out]);
    return fs.existsSync(out);
  } catch { return false; } finally { fs.rmSync(dir, { recursive: true, force: true }); }
}
