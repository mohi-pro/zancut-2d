// The small AI side tasks (Claude, no tools except reading a picture): the voiceover script when Gemini is not set up, and
// the study of a style reference video. The storyboard, scene fixes and graphics have their own prompts (director.mjs).
import { langName } from './studio.mjs';

export const SYSTEM_APPEND = `
# You are a helper inside Zancut
You do one small task for a customer's video and answer in text. Nobody is watching and nobody can answer questions:
decide, answer, stop. Use only what you are given. Never explore files.
`;

// Faceless with an AI voice and only an idea (when Gemini is not set up): the narration, as plain spoken words
export function scriptPrompt(p) {
  const secs = p.format === '16:9' ? 90 : 45, wps = p.language === 'bn' ? 2.2 : 2.8;
  return `Write the voiceover script for a short ${p.format === '16:9' ? 'YouTube' : 'social'} video in ${langName(p.language)}.
Idea from the customer: ${String(p.prompt || p.script || '').trim() || '(none: use the project title)'}${p.name ? `\nTitle: ${p.name}` : ''}
About ${secs} s spoken = about ${Math.round(secs * wps)} words. A strong first line (hook); short punchy clauses of 6–10 words, one idea
each; ${p.language === 'bn' ? 'natural spoken Bangla, English tech and brand words in Latin letters; ' : ''}[pause: 0.25s] before each key reveal or number;
no lists, headings, stage directions or emojis; numbers as they are said.
Answer with ONLY the spoken words.`;
}

// A style reference video: frame sheets in, a short style brief out (the director follows it; never shown in the video)
export function studyPrompt(sheets, note) {
  return `A Zancut customer gave a reference video and wants their own video in the same feel.${note ? ` Their note: "${String(note).slice(0, 300)}".` : ''}
Read these frame sheets (one frame every 0.5 s, left to right, top to bottom): ${sheets.join(', ')}.
Then answer with a style brief of at most 40 lines, plain and specific, for a director who will NOT see the reference:
layout (where the speaker and graphics sit, how often), colours (hex guesses), type (fonts by feel, sizes, case), captions,
each kind of graphic and when it is used, motion and transitions, pacing (seconds between changes), the opening and the ending,
and five rules that capture this style best. Describe only what you can see.`;
}
