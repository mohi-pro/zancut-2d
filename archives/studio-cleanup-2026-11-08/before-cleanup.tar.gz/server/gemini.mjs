// Gemini, used ONLY where it gives a big quality or cost advantage (everything else is local tools + Claude):
//   transcribeAudio(wav, lang)  Bangla / multilingual speech (or any speech the local WhisperX is unsure of): clean words
//                               in the right script + emphasis, uiText, literalMetaphor, Magic Cut ranges (gemini-2.5-pro)
//   alignWords(whisper, gem)    Gemini's words on WhisperX's exact timings
//   speak(script, voice, lang)  the AI voiceover (expressive TTS, [pause] markers)
//   noteText(wav, lang)         a short spoken note in another language as text
//   testSoundMix(wav, scenes)   OPTIONAL listening test of the finished mix (GEMINI_SOUND_TEST=1 or asked from the editor)
//   chatAnswer(...)             the Home chat's Gemini models
//   makeImage(prompt, refs)     a thumbnail picture (Nano Banana: ZANCUT_IMAGE_MODEL, default gemini-2.5-flash-image)
// Needs GEMINI_API_KEY (.env); the desktop app goes through the backend instead (no key on the computer). Every call returns its token usage so the job can report Gemini's share of the cost.
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { DATA_DIR } from './config.mjs';
import { DESKTOP, services, serviceToken } from './desktop-client.mjs';

const run = promisify(execFile);
// ZANCUT_GEMINI=0 in .env = Gemini off everywhere (the key stays): every step runs on the local fallbacks
// The desktop app has no key: it calls the Zancut backend, signed in as the customer, and the backend calls Gemini with
// the key from Admin → Settings (backend/src/modules/services). Same requests, same answers.
const KEY = () => (process.env.ZANCUT_GEMINI === '0' ? '' : DESKTOP ? serviceToken() : process.env.GEMINI_API_KEY || '');
const gemUrl = (model) => (DESKTOP ? services.gemini(`models/${model}:generateContent`) : `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent`);
const gemAuth = () => (DESKTOP ? services.auth() : { 'x-goog-api-key': KEY() });
// "is Gemini working?" for the CTO's health check
export const geminiPing = () => fetch(DESKTOP ? services.gemini('models') : 'https://generativelanguage.googleapis.com/v1beta/models?pageSize=1', { headers: gemAuth(), signal: AbortSignal.timeout(15000) });
// the CTO (cto.mjs) takes a key that does not work out of use for a while: transcription falls back to WhisperX / whisper,
// the AI voice to the local voices, until the key works again
let downUntil = 0;
export const setGeminiDown = (ms) => { downUntil = ms > 0 ? Date.now() + ms : 0; };
export const geminiDown = () => Date.now() < downUntil;
export const geminiOn = () => !!KEY() && !geminiDown();
export const geminiKeySet = () => !!KEY();
const MODEL = () => process.env.GEMINI_MODEL || 'gemini-2.5-flash';
// the transcriber: Pro (more careful: Flash skipped whole sentences of Bangla), still checked piece by piece against the sound;
// GEMINI_TRANSCRIBE_MODEL=gemini-2.5-flash for the cheap one
const TRANSCRIBE_MODEL = () => process.env.GEMINI_TRANSCRIBE_MODEL || 'gemini-2.5-pro';
const FALLBACK = () => process.env.GEMINI_FALLBACK_MODEL || 'gemini-flash-latest';
// the transcriber's models in order: the Pro one, then Google's newest Pro (when the first is retired for this key)
const TRANSCRIBE_MODELS = () => [TRANSCRIBE_MODEL(), 'gemini-pro-latest'];
// a model Google retired for this key (404 "no longer available" / not found): every call skips it for 7 days and the next one
// in its list answers at once, no error each time (data/gemini-models.json keeps it over restarts)
const DEAD_FILE = path.join(DATA_DIR, 'gemini-models.json'), DEAD_DAYS = 7;
let dead = null;
const deadNow = () => {
  if (!dead) { try { dead = JSON.parse(fs.readFileSync(DEAD_FILE, 'utf8')); } catch { dead = {}; } }
  for (const [m, at] of Object.entries(dead)) if (Date.now() - at > DEAD_DAYS * 864e5) delete dead[m];
  return dead;
};
const markDead = (model, msg) => {
  if (!/\b404\b|no longer available|not found for API version|is not supported for generateContent/i.test(msg)) return false;
  deadNow()[model] = Date.now();
  try { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(DEAD_FILE, JSON.stringify(dead)); } catch {}
  console.error(`[gemini] ${model} is not available to this key: the next model is used from now on`);
  return true;
};
// a list of models without the retired ones (all retired: the list as it is, so the error says why)
export const aliveModels = (list) => { const d = deadNow(), l = [...new Set(list.filter(Boolean))], a = l.filter((m) => !d[m]); return a.length ? a : l; };

// compressed mono audio for Gemini (32 kb/s: about 240 KB a minute, sent inline)
async function audioB64(src, { from = 0, secs = 0 } = {}) {
  const out = path.join(path.dirname(src), `gemini-${secs || 'all'}.mp3`);
  await run('ffmpeg', ['-v', 'error', '-y', ...(from ? ['-ss', String(from)] : []), '-i', src, ...(secs ? ['-t', String(secs)] : []), '-vn', '-ac', '1', '-ar', '16000', '-b:a', '32k', out], { timeout: 300000 });
  return fs.readFileSync(out).toString('base64');
}

// a request that hangs is given up on instead of waiting out the network's own 5 minutes; the customer's stop still works
const within = (signal, ms) => (signal ? AbortSignal.any([signal, AbortSignal.timeout(ms)]) : AbortSignal.timeout(ms));
const TRY_AGAIN = /\b(429|500|503)\b|fetch failed|timeout|timed out|aborted|ECONN|ENOTFOUND|EAI_AGAIN|socket/i;
async function call(model, parts, { json = true, signal, schema, gen = {}, ms = 180000 } = {}) {
  const r = await fetch(gemUrl(model), {
    method: 'POST', signal: within(signal, ms), headers: { 'content-type': 'application/json', ...gemAuth() },
    body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { temperature: 0.2, ...(json ? { responseMimeType: 'application/json' } : {}), ...(json && schema ? { responseSchema: schema } : {}), ...gen } }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const msg = `gemini ${model}: ${r.status} ${JSON.stringify(j.error || j).slice(0, 200)}`; markDead(model, msg); throw new Error(msg); }
  const text = (j.candidates?.[0]?.content?.parts || []).map((x) => x.text || '').join('');
  const u = j.usageMetadata || {}, finish = j.candidates?.[0]?.finishReason || '';
  if (finish && finish !== 'STOP') console.error(`[gemini] ${model} stopped early: ${finish}`); // MAX_TOKENS, SAFETY, RECITATION…: the answer is incomplete
  return { text, model, finish, usage: { in: u.promptTokenCount || 0, out: (u.candidatesTokenCount || 0) + (u.thoughtsTokenCount || 0) } };
}
// the main model, then the fallback; returns { data, usage, model, ms }
async function ask(parts, o = {}) {
  const t = Date.now();
  // busy (503) or over quota (429): wait a little and try again, then the next model (newer ones are often overloaded)
  let res, err;
  const models = aliveModels([...(o.models || [o.model || MODEL()]), 'gemini-2.5-flash', FALLBACK()]);
  outer: for (const m of models) for (const wait of [0, 4000, 10000]) {
    if (wait) await new Promise((r) => setTimeout(r, wait));
    try { res = await call(m, parts, o); break outer; }
    catch (e) { err = e; if (o.signal?.aborted) throw e; console.error(`[gemini] ${e.message.slice(0, 120)}`);
      if (o.schema && /\b400\b/.test(e.message)) { o = { ...o, schema: undefined }; continue; } /* a schema this model rejects: same model, plain JSON */
      if (deadNow()[m] || !TRY_AGAIN.test(e.message)) break; }
  }
  if (!res) throw err;
  let data = null; try { data = JSON.parse(res.text.replace(/^```(json)?|```$/g, '').trim()); } catch {}
  return { data, text: res.text, finish: res.finish, usage: res.usage, model: res.model, ms: Date.now() - t };
}

// ---------- the transcript of non-English (Bangla…) or uncertain speech ----------
// Gemini writes the words (it knows the language: spelling, conjuncts, English words), WhisperX keeps the exact timings: every word is
// then aligned onto WhisperX's words (alignWords). The same call tags the moments for the director.
const T = (type, x = {}) => ({ type, ...x }), O = (props, req) => T('OBJECT', { properties: props, ...(req ? { required: req } : {}) }), A = (items) => T('ARRAY', { items });
const STR = T('STRING'), INT = T('INTEGER'), NUM = T('NUMBER');
const TRANSCRIPT_SCHEMA = O({
  language: STR, topic: STR, summary: STR, tone: STR,
  words: A(O({ w: STR, s: NUM, e: NUM, isEmphasis: T('BOOLEAN') }, ['w', 's', 'e'])),
  magicCutRanges: A(O({ from: INT, to: INT, why: T('STRING', { enum: ['filler', 'false start', 'repeat', 'retake'] }), words: STR }, ['from', 'to', 'why'])),
  sentences: A(O({ from: INT, to: INT, says: STR, meaning: STR, feel: STR, energy: T('STRING', { enum: ['calm', 'normal', 'fast'] }), kind: T('STRING', { enum: ['literal', 'metaphor'] }), metaphor: STR, show: STR, visual: STR, data: STR, importance: INT, emphasisWords: A(INT), literalMetaphor: STR, uiText: STR },
    ['from', 'to', 'says', 'meaning', 'kind', 'show', 'literalMetaphor', 'uiText'])),
  hook: O({ from: INT, to: INT, why: STR }), speaker: STR,
}, ['words']);
// o.from / o.secs: only that stretch of the audio (its word times come back on the whole track's clock)
export async function transcribeAudio(wav, lang, o = {}) {
  const b = await audioB64(wav, { from: o.from || 0, secs: o.secs || 0 });
  const name = { bn: 'Bangla', hi: 'Hindi', ur: 'Urdu', ar: 'Arabic', en: 'English' }[lang] || lang || 'the spoken language';
  const parts = [{ inlineData: { mimeType: 'audio/mp3', data: b } }, { text: `You are the listening editor of a video studio. Transcribe this ${name} speech EXACTLY as spoken, word by word, and tag it.
WORDS: "words" = every spoken word in order, with its start and end second. ${name === 'Bangla' ? 'Write Bangla in clean Bangla Unicode with intact যুক্তবর্ণ (conjuncts) and মাত্রা (matra); ' : `Write ${name} in its own script with correct spelling; `}English tech and brand words and numbers the speaker says (AI, Dashboard, SaaS, API, 300%) stay in clean Latin letters. Keep fillers (উম, আ, মানে, um) and repeated words: an editor decides what to cut. isEmphasis = true on the 1–2 power words of each sentence where the voice peaks.
Below, "from" and "to" are positions (0-based) in YOUR words array.
SENTENCES: one entry per idea of 2–5 s: says, meaning, feel, energy, kind ("literal" = the words name something a viewer can see; "metaphor" = an idea or feeling, then metaphor = the motion and colour that carry it), show, visual (chart|stat|steps|screenshot|logo|photo|icon|list|compare|headline|speaker|motion), data, importance 1–3, emphasisWords (word positions), literalMetaphor (a concrete physical or UI action that ACTS OUT the words, e.g. "when your costs keep rising" → a red cost gauge climbing into a warning zone, then slashed), uiText (a 1–4 word card label, at most 18 characters, in the speaker's language; English tech and brand words in Latin letters).
magicCutRanges: word ranges to remove: fillers, false starts, repeats (keep only the last complete take), retakes; never more than 35% of the words. hook = the strongest 2–3 s line. speaker = which moments should show the speaker (30–50%).
${o.name ? `The video: "${o.name}"${o.prompt ? ` — the customer says: ${o.prompt}` : ''}. ` : ''}${o.glossary ? `Spell these names exactly: ${o.glossary}. ` : ''}Answer JSON only.` }];
  const r = await ask(parts, { signal: o.signal, schema: TRANSCRIPT_SCHEMA, models: TRANSCRIBE_MODELS(), gen: { thinkingConfig: { thinkingBudget: 1024 } }, ms: 180000 + (o.secs || 1800) * 1000 });
  const off = o.from || 0, words = (r.data?.words || []).filter((x) => x && String(x.w || '').trim()).map((x) => ({ w: String(x.w).trim(), s: off + (Number(x.s) || 0), e: off + (Number(x.e) || Number(x.s) || 0), isEmphasis: !!x.isEmphasis }));
  const { words: _w, sentences, ...rest } = r.data || {};
  return { words, tags: { ...rest, moments: sentences || [] }, usage: r.usage, model: r.model, ms: r.ms, finish: r.finish };
}
// A long track in pieces of about 25 s, each cut at its quietest 0.2 s between 20 and 30 s (between two words): Gemini's word
// times hold on a short piece and drift on a long one. The pieces' words, sentences and cut ranges are joined in order.
// → { words, tags, usage: [..], model, ms }
// Stretches of speech (in the sound) with no word near them: (words [{s, e}], from, to) → [[a, b]] over 2 s. rms: mean squares
// in 50 ms steps (8 kHz). Exported for the check scripts.
export function speechHoles(rms) {
  const sorted = rms.filter((v) => v > 1e4).sort((x, y) => x - y), level = sorted.length ? sorted[Math.floor(sorted.length / 2)] : 1e6;
  const voiced = rms.map((v) => v > level * 0.05), end = voiced.length / 20;
  const share = (p, q) => { let v = 0, n = 0; for (let i = Math.floor(p * 20); i < Math.min(voiced.length, Math.ceil(q * 20)); i++) { n++; if (voiced[i]) v++; } return n ? v / n : 0; };
  // every gap between words (and before the first, after the last) over 2 s that is more than a quarter speech
  return (ws, a, b) => {
    const list = [...ws].sort((x, y) => x.s - y.s), edges = [[a, list[0]?.s ?? b], ...list.slice(1).map((w, k) => [list[k].e, w.s]), [list.at(-1)?.e ?? a, Math.min(b, end)]];
    return edges.filter(([p, q]) => q - p > 2 && share(p, q) > 0.25).map(([p, q]) => [+p.toFixed(2), +q.toFixed(2)]);
  };
}
export function levelsOf(wav) {
  const pcm = execFileSync('ffmpeg', ['-v', 'error', '-i', wav, '-ac', '1', '-ar', '8000', '-f', 's16le', '-'], { maxBuffer: 1 << 28, timeout: 120000, stdio: ['ignore', 'pipe', 'pipe'] });
  const n = pcm.length >> 1, step = 400, rms = [];
  for (let i = 0; i + step <= n; i += step) { let a = 0; for (let k = i; k < i + step; k++) { const v = pcm.readInt16LE(k * 2); a += v * v; } rms.push(a / step); }
  return rms;
}
export async function transcribeLong(wav, lang, o = {}) {
  const pcm = execFileSync('ffmpeg', ['-v', 'error', '-i', wav, '-ac', '1', '-ar', '8000', '-f', 's16le', '-'], { maxBuffer: 1 << 28, timeout: 120000, stdio: ['ignore', 'pipe', 'pipe'] });
  const n = pcm.length >> 1, step = 400, rms = []; // 50 ms steps
  for (let i = 0; i + step <= n; i += step) { let a = 0; for (let k = i; k < i + step; k++) { const v = pcm.readInt16LE(k * 2); a += v * v; } rms.push(a / step); }
  const total = n / 8000, cuts = [0];
  while (total - cuts.at(-1) > 32) {
    const a = Math.floor((cuts.at(-1) + 20) * 20), b = Math.min(rms.length - 4, Math.floor((cuts.at(-1) + 30) * 20));
    let best = a, bv = Infinity; for (let i = a; i < b; i++) { const v = rms[i] + rms[i + 1] + rms[i + 2] + rms[i + 3]; if (v < bv) { bv = v; best = i; } }
    cuts.push(+((best + 2) / 20).toFixed(2));
  }
  cuts.push(total);
  // A piece's answer is checked against the sound: Gemini sometimes stops early or skips a stretch (one answer once wrote 11 of a
  // piece's 53 words and nothing for 27 s of continuous speech). A stretch of speech over 2 s with no word in it = a hole: the
  // piece is asked again (twice at most, the fullest answer kept), then each hole that is left on its own.
  const holesOf = speechHoles(rms);
  const words = [], moments = [], magic = [], usage = [], checks = [], t0 = Date.now(); let tags = null, model = '';
  for (let i = 0; i + 1 < cuts.length; i++) {
    const a = cuts[i], b = cuts[i + 1], inPiece = (ws) => ws.filter((w) => w.s >= a - 0.3 && w.s < b + 0.3);
    let r = await transcribeAudio(wav, lang, { ...o, from: a, secs: +(b - a).toFixed(2) }), got = inPiece(r.words), holes = holesOf(got, a, b);
    usage.push(r.usage);
    for (let tries = 0; holes.length && tries < 2; tries++) {
      const r2 = await transcribeAudio(wav, lang, { ...o, from: a, secs: +(b - a).toFixed(2) }); usage.push(r2.usage);
      const got2 = inPiece(r2.words), holes2 = holesOf(got2, a, b), miss = (h) => h.reduce((x, [p, q]) => x + q - p, 0);
      if (miss(holes2) < miss(holes)) { r = r2; got = got2; holes = holes2; }
    }
    for (const [ha, hb] of holes) { // what is still missing: that stretch alone
      const from = Math.max(0, ha - 0.6), r3 = await transcribeAudio(wav, lang, { ...o, from, secs: +(Math.min(total, hb + 0.6) - from).toFixed(2) }); usage.push(r3.usage);
      const fill = r3.words.filter((w) => w.s >= ha - 0.3 && w.s < hb + 0.1 && !got.some((g) => Math.abs(g.s - w.s) < 0.15));
      got = [...got, ...fill].sort((x, y) => x.s - y.s);
    }
    const left = holesOf(got, a, b);
    checks.push({ from: a, to: b, words: got.length, holesLeft: left });
    if (left.length) console.error(`[gemini] piece ${a}–${b} s: speech with no words still at ${JSON.stringify(left)}`);
    const k = words.length, sh = (x) => (Number.isInteger(x) ? x + k : x);
    words.push(...got);
    for (const m of r.tags.moments || []) moments.push({ ...m, from: sh(m.from), to: sh(m.to), emphasisWords: (m.emphasisWords || []).map(sh) });
    for (const c of r.tags.magicCutRanges || []) magic.push({ ...c, from: sh(c.from), to: sh(c.to) });
    if (!tags) tags = { ...r.tags, hook: r.tags.hook };
    else tags.summary = `${tags.summary || ''} ${r.tags.summary || ''}`.trim();
    model = r.model;
  }
  for (let i = 1; i < words.length; i++) if (words[i].s < words[i - 1].e) { words[i].s = words[i - 1].e; words[i].e = Math.max(words[i].e, words[i].s + 0.04); } // strictly in order
  return { words, tags: { ...(tags || {}), moments, magicCutRanges: magic }, usage, model, ms: Date.now() - t0, pieces: cuts.length - 1, checks };
}
const normW = (t) => String(t || '').toLowerCase().replace(/[^\p{L}\p{N}]+/gu, '');
const lev = (a, b) => { if (!a.length || !b.length) return Math.max(a.length, b.length); let prev = Array.from({ length: b.length + 1 }, (_, j) => j);
  for (let i = 1; i <= a.length; i++) { const cur = [i]; for (let j = 1; j <= b.length; j++) cur[j] = Math.min(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + (a[i - 1] === b[j - 1] ? 0 : 1)); prev = cur; } return prev[b.length]; };
// whisper: [{text, start, end, id}] · gem: [{w, s, e}] → whisper-format words with Gemini's text (null if they disagree badly)
export function alignWords(whisper, gem) {
  const n = whisper.length, m = gem.length;
  if (!n || m < n * 0.5) return null;
  const GAP = 0.7, cost = (i, j) => { const a = normW(whisper[i].text), b = normW(gem[j].w), d = lev(a, b) / Math.max(1, a.length, b.length);
    return d + 0.5 * Math.min(1, Math.abs(whisper[i].start - gem[j].s) / 1.5); };
  const D = Array.from({ length: n + 1 }, () => new Float64Array(m + 1)), B = Array.from({ length: n + 1 }, () => new Uint8Array(m + 1));
  for (let i = 1; i <= n; i++) { D[i][0] = i * GAP; B[i][0] = 1; }
  for (let j = 1; j <= m; j++) { D[0][j] = j * GAP; B[0][j] = 2; }
  for (let i = 1; i <= n; i++) for (let j = 1; j <= m; j++) {
    const a = D[i - 1][j - 1] + cost(i - 1, j - 1), up = D[i - 1][j] + GAP, left = D[i][j - 1] + GAP;
    if (a <= up && a <= left) { D[i][j] = a; B[i][j] = 0; } else if (up <= left) { D[i][j] = up; B[i][j] = 1; } else { D[i][j] = left; B[i][j] = 2; }
  }
  const pair = new Array(m).fill(-1);
  for (let i = n, j = m; i > 0 || j > 0;) { const k = B[i][j]; if (i > 0 && j > 0 && k === 0) { pair[j - 1] = i - 1; i--; j--; } else if (i > 0 && (j === 0 || k === 1)) i--; else j--; }
  const out = [];
  for (let j = 0; j < m; j++) {
    const i = pair[j];
    if (i >= 0) { out.push({ text: gem[j].w, start: whisper[i].start, end: whisper[i].end, id: `g${j}`, ...(gem[j].isEmphasis ? { isEmphasis: true } : {}) }); continue; }
    // not in whisper: between the neighbours' times, near Gemini's own time
    const prevEnd = out.length ? out[out.length - 1].end : 0;
    let nx = j + 1; while (nx < m && pair[nx] < 0) nx++;
    const nextStart = nx < m ? whisper[pair[nx]].start : Math.max(prevEnd + 0.2, gem[j].e);
    const span = Math.max(0.06, nextStart - prevEnd), k = nx - j; // k words share the gap
    const st = prevEnd + span * 0.05, len = Math.max(0.05, (span * 0.9) / k);
    out.push({ text: gem[j].w, start: Number(st.toFixed(3)), end: Number((st + len).toFixed(3)), id: `g${j}`, ...(gem[j].isEmphasis ? { isEmphasis: true } : {}) });
  }
  for (let k = 1; k < out.length; k++) if (out[k].start < out[k - 1].end) out[k].start = out[k - 1].end, out[k].end = Math.max(out[k].end, out[k].start + 0.04);
  return out;
}

// ---------- AI voice (Gemini text-to-speech) and the voiceover script ----------
// Gemini speaks every language of the setup (Bangla, English, Hindi, Urdu, Arabic, Spanish…) with natural voices.
export const GEMINI_VOICES = [
  ['Kore', 'Female · firm, clear'], ['Zephyr', 'Female · bright'], ['Aoede', 'Female · breezy, friendly'], ['Leda', 'Female · youthful'], ['Sulafat', 'Female · warm'],
  ['Puck', 'Male · upbeat'], ['Charon', 'Male · informative'], ['Fenrir', 'Male · excitable'], ['Orus', 'Male · firm'], ['Algenib', 'Male · deep, gravelly'],
].map(([name, sub]) => ({ id: `g-${name.toLowerCase()}`, name, label: name, sub, engine: 'gemini' }));
// every language the Gemini voices speak (its TTS list, plus Urdu): the voice list adjusts to the language picked first
export const GEMINI_LANGS = ['en', 'bn', 'hi', 'ur', 'ar', 'es', 'fr', 'de', 'pt', 'id', 'tr', 'it', 'ja', 'ko', 'ru', 'nl', 'pl', 'ro', 'uk', 'th', 'vi', 'mr', 'ta', 'te'];
const TTS_MODELS = () => [process.env.GEMINI_TTS_MODEL || 'gemini-2.5-pro-preview-tts', 'gemini-2.5-flash-preview-tts'];
export const LANG_NAME = { en: 'English', bn: 'Bangla', hi: 'Hindi', ur: 'Urdu', ar: 'Arabic', es: 'Spanish', fr: 'French', de: 'German', pt: 'Portuguese', id: 'Indonesian', tr: 'Turkish', it: 'Italian', ja: 'Japanese', ko: 'Korean', ru: 'Russian', nl: 'Dutch', pl: 'Polish', ro: 'Romanian', uk: 'Ukrainian', th: 'Thai', vi: 'Vietnamese', mr: 'Marathi', ta: 'Tamil', te: 'Telugu' };

// only: one model and no other (2D Animation: the same voice must come from the same model all film long; the flash
// model's "Charon" does not sound like the pro model's)
async function ttsChunk(text, voice, style, signal, only, ms = 150000) {
  let err;
  for (const m of only ? [only] : aliveModels(TTS_MODELS())) for (const wait of [0, 4000, 10000]) {
    if (wait) await new Promise((r) => setTimeout(r, wait));
    try {
      const r = await fetch(gemUrl(m), { method: 'POST', signal: within(signal, ms), headers: { 'content-type': 'application/json', ...gemAuth() },
        body: JSON.stringify({ contents: [{ role: 'user', parts: [{ text: `${style}: ${text}` }] }], generationConfig: { responseModalities: ['AUDIO'], speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: voice } } } } }) });
      const j = await r.json().catch(() => ({}));
      if (!r.ok) { const msg = `gemini ${m}: ${r.status} ${(j.error?.message || '').slice(0, 120)}`; markDead(m, msg); throw new Error(msg); }
      const part = j.candidates?.[0]?.content?.parts?.find((x) => x.inlineData);
      if (!part) throw new Error(`gemini ${m}: no audio`);
      const u = j.usageMetadata || {};
      return { buf: Buffer.from(part.inlineData.data, 'base64'), mime: part.inlineData.mimeType || '', model: m, usage: { in: u.promptTokenCount || 0, out: u.candidatesTokenCount || 0 } };
    } catch (e) { err = e; if (signal?.aborted) throw e; console.error(`[gemini tts] ${e.message.slice(0, 120)}`); if (!TRY_AGAIN.test(e.message) && !/no audio/.test(e.message)) break; }
  }
  throw err;
}
// script → out.wav (48 kHz mono), sentence by sentence with short pauses. Returns { seconds, usage: [{model,in,out,ms}] }.
export const ttsVoiceover = (...a) => speak(...a); // the AI voiceover (the name the spec uses)
export async function speak(script, voiceId, lang, outWav, o = {}) {
  const v = GEMINI_VOICES.find((x) => x.id === voiceId) || GEMINI_VOICES[0];
  // the customer's speed (Step 2): how the voice is asked to speak; the recording is then tightened to it (agent makePlate)
  const pace = { slow: 'at a relaxed, unhurried pace', fast: 'at a fast, energetic pace with short pauses', normal: 'at a lively, natural social-video pace, never slow or dragging' }[o.speed] || 'at a lively, natural social-video pace, never slow or dragging';
  // the Vocal Director: a top creator's delivery (warm studio-condenser tone, a curious hook, an energetic middle, a breath
  // before every key number, a grounded close)
  // o.style: a character's own acting note (2D animation voices); otherwise the creator delivery below
  const style = o.style ? `${o.style} Speak natural, fluent ${LANG_NAME[lang] || ''} ${pace}. Read only the words, never these notes` : `You are a vocal director recording a top-tier tech and business creator. Deliver this ${LANG_NAME[lang] || ''} voiceover with a warm, high-clarity studio-condenser tone, ${pace}: an intrigued, hook-driven inflection in the first 3 seconds, slightly faster through the explanation, a short breath before key numbers, and a grounded, confident close. Say exactly these words`;
  // [pause: 0.25s] markers (before reveals) become real silences between the spoken parts
  const PAUSE = /\[pause:\s*([\d.]+)\s*s?\]/gi;
  const pieces = String(script).replace(/\s+/g, ' ').trim().split(/(\[pause:\s*[\d.]+\s*s?\])/i);
  const pauseAfter = [];
  const parts = [];
  for (const piece of pieces) {
    const m = piece.match(/^\[pause:\s*([\d.]+)/i);
    if (m) { if (parts.length) pauseAfter[parts.length - 1] = Math.min(1.2, Number(m[1]) || 0.25); continue; }
    piece.replace(PAUSE, '').trim().split(/(?<=[.!?।])\s+/).reduce((a, s) => { const l = a[a.length - 1]; if (l && (l + ' ' + s).length < 600) a[a.length - 1] = l + ' ' + s; else a.push(s); return a; }, []).filter((s) => s.trim()).forEach((s) => parts.push(s.trim()));
  }
  const dir = path.join(path.dirname(outWav), 'tts'); fs.mkdirSync(dir, { recursive: true });
  const files = [], usage = [];
  for (let i = 0; i < parts.length; i++) {
    const t = Date.now(), c = await ttsChunk(parts[i], v.name, style, o.signal, o.model), f = path.join(dir, `p${i}.wav`), raw = path.join(dir, `p${i}.bin`);
    fs.writeFileSync(raw, c.buf);
    const rate = (c.mime.match(/rate=(\d+)/) || [])[1];
    await run('ffmpeg', ['-v', 'error', '-y', ...(/L16|pcm/i.test(c.mime) ? ['-f', 's16le', '-ar', rate || '24000', '-ac', '1'] : []), '-i', raw, '-ar', '48000', '-ac', '1', f], { timeout: 120000 });
    files.push(f); usage.push({ model: c.model, ...c.usage, ms: Date.now() - t });
  }
  const gap = path.join(dir, 'gap.wav');
  await run('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=mono', '-t', o.speed === 'fast' ? '0.12' : o.speed === 'slow' ? '0.35' : '0.2', gap]);
  const gapFile = async (i) => { const sec = pauseAfter[i]; if (!sec) return gap; const g2 = path.join(dir, `gap${i}.wav`); await run('ffmpeg', ['-v', 'error', '-y', '-f', 'lavfi', '-i', 'anullsrc=r=48000:cl=mono', '-t', String(sec), g2]); return g2; };
  const gaps = []; for (let i = 0; i < files.length - 1; i++) gaps.push(await gapFile(i));
  const list = path.join(dir, 'list.txt'); fs.writeFileSync(list, files.flatMap((f, i) => [`file '${f}'`, ...(i < files.length - 1 ? [`file '${gaps[i]}'`] : [])]).join('\n'));
  await run('ffmpeg', ['-v', 'error', '-y', '-f', 'concat', '-safe', '0', '-i', list, '-c:a', 'pcm_s16le', outWav], { timeout: 300000 });
  const { stdout } = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', outWav]);
  // where each part of the script is spoken (the words are the script itself: they only need their times)
  const lens = []; for (const f of files) { const r = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', f]); lens.push(Number(r.stdout) || 0); }
  const gapLen = o.speed === 'fast' ? 0.12 : o.speed === 'slow' ? 0.35 : 0.2, chunks = []; let at = 0;
  parts.forEach((text, i) => { chunks.push({ text, start: +at.toFixed(3), end: +(at + lens[i]).toFixed(3) }); at += lens[i] + (pauseAfter[i] || gapLen); });
  return { seconds: Number(stdout) || 0, usage, chunks };
}
/** 2D Animation: several lines of ONE speaker in one take (one call = one voice, no drift between lines), a clear
    silence after each line so they can be cut apart (server/animation.mjs recordLines). lines = [{ text, tone }] → out.wav */
export async function speakTake(lines, voiceId, lang, outWav, o = {}) {
  const v = GEMINI_VOICES.find((x) => x.id === voiceId) || GEMINI_VOICES[0];
  const pace = { slow: 'at a relaxed, unhurried pace', fast: 'at a fast, energetic pace' }[o.speed] || 'at a natural, lively pace';
  const style = `${o.style || ''} Speak natural, fluent ${LANG_NAME[lang] || ''} ${pace}, in the same voice from the first line to the last. `
    + 'Read the lines below in order as one recording. After every line stay completely silent for one second. '
    + 'The feeling of a line is in square brackets before it: let it colour the delivery; never read the brackets aloud, read only the words';
  const text = lines.map((l) => `${l.tone ? `[${String(l.tone).replace(/[[\]]/g, '').slice(0, 60)}] ` : ''}${String(l.text).trim()}`).join('\n');
  const t = Date.now(), c = await ttsChunk(text, v.name, style, o.signal, o.model, o.ms), raw = `${outWav}.bin`;
  fs.writeFileSync(raw, c.buf);
  const rate = (c.mime.match(/rate=(\d+)/) || [])[1];
  try { await run('ffmpeg', ['-v', 'error', '-y', ...(/L16|pcm/i.test(c.mime) ? ['-f', 's16le', '-ar', rate || '24000', '-ac', '1'] : []), '-i', raw, '-ar', '48000', '-ac', '1', outWav], { timeout: 120000 }); }
  finally { fs.rmSync(raw, { force: true }); }
  return { model: c.model, usage: [{ model: c.model, ...c.usage, ms: Date.now() - t }] };
}
// The home page chat (server/chat.mjs): one answer from a Gemini model to the whole conversation (files as inline data)
export async function chatAnswer(model, contents, system, signal) {
  const r = await fetch(gemUrl(model), {
    method: 'POST', signal, headers: { 'content-type': 'application/json', ...gemAuth() },
    body: JSON.stringify({ contents, systemInstruction: { parts: [{ text: system }] }, generationConfig: { temperature: 0.7, maxOutputTokens: 8192 } }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const msg = `gemini ${model}: ${r.status} ${JSON.stringify(j.error || j).slice(0, 200)}`; markDead(model, msg); throw new Error(msg); }
  const u = j.usageMetadata || {};
  return { text: (j.candidates?.[0]?.content?.parts || []).map((x) => x.text || '').join(''), usage: { in: u.promptTokenCount || 0, out: (u.candidatesTokenCount || 0) + (u.thoughtsTokenCount || 0) } };
}

// OPTIONAL listening test of the finished mix (GEMINI_SOUND_TEST=1, or asked from the editor): is the VOICE (0 dB reference) ever
// masked by a whoosh, texture, riser or hit? `scenes` = [{ at, name, family }] sounds placed in the mix (seconds), for the report.
// Returns { data: { ok, summary, issues: [{ at, problem, fix }] }, usage, model, ms }.
const MIX_SCHEMA = O({ ok: T('BOOLEAN'), summary: STR, issues: A(O({ at: NUM, layer: T('STRING', { enum: ['whoosh', 'texture', 'riser', 'hit', 'music', 'other'] }), problem: STR, fix: STR }, ['at', 'problem'])) }, ['ok', 'summary', 'issues']);
export async function testSoundMix(wavPath, scenes = [], signal) {
  const mp3 = path.join(path.dirname(wavPath), `${path.basename(wavPath, path.extname(wavPath))}-mixtest.mp3`);
  await run('ffmpeg', ['-v', 'error', '-y', '-i', wavPath, '-vn', '-ac', '2', '-ar', '24000', '-b:a', '64k', mp3], { timeout: 300000 });
  const data = fs.readFileSync(mp3).toString('base64'); fs.rmSync(mp3, { force: true });
  const placed = scenes.map((x) => `${Number(x.at).toFixed(1)}s ${x.name}${x.family ? ` (${x.family})` : ''}`).join(', ');
  const parts = [{ inlineData: { mimeType: 'audio/mp3', data } }, { text: `Listen to the finished mix of a short video like a careful sound mixer. The VOICE is the reference at 0 dB: it must always be clear. Report every moment where a WHOOSH, TEXTURE, RISER or HIT (or the music) masks the voice, hides a word, clips, or is too loud next to it, with the second and a fix in dB or timing.${placed ? ` Sounds placed in the mix: ${placed}.` : ''} ok = true only when the voice is never masked. Answer JSON only.` }];
  const t = Date.now();
  for (const think of [{ thinkingLevel: 'low' }, { thinkingBudget: 512 }, null]) {
    // room for the thinking and the whole answer (1500 tokens cut the JSON off, so no report ever came back)
    try { const r = await call(aliveModels([...TRANSCRIBE_MODELS(), 'gemini-2.5-flash'])[0], parts, { signal, schema: MIX_SCHEMA, gen: { maxOutputTokens: 8192, ...(think ? { thinkingConfig: think } : {}) } }); let d = null; try { d = JSON.parse(r.text.replace(/^```(json)?|```$/g, '').trim()); } catch { console.error('[sound test] not JSON:', r.text.slice(0, 200)); } return { data: d, usage: r.usage, model: r.model, ms: Date.now() - t }; }
    catch (e) { if (signal?.aborted || !/\b400\b/.test(e.message) || !think) throw e; }
  }
}

// A short spoken note (the 🎤 on note, comment and chat boxes) as plain text: Gemini 2.5 Flash without thinking hears
// Bangla correctly in ~3 s (the newer quick model misspells it; Pro is right but slow)
export async function noteText(wav, lang, signal) {
  const b = await audioB64(wav);
  const name = LANG_NAME[lang] || 'the spoken';
  const parts = [{ inlineData: { mimeType: 'audio/mp3', data: b } }, { text: `Transcribe this ${name} speech exactly, in its own script with correct spelling; English words and names stay in Latin letters. Answer with the plain text only.` }];
  for (const [m, gen] of [['gemini-2.5-flash', { thinkingConfig: { thinkingBudget: 0 } }], [FALLBACK(), {}]].filter(([x], k, l) => aliveModels(l.map((y) => y[0])).includes(x))) {
    try { const r = await call(m, parts, { json: false, signal, gen }); const text = r.text.replace(/\s+/g, ' ').trim(); if (text) return { text, usage: r.usage, model: r.model }; }
    catch (e) { if (signal?.aborted) throw e; console.error('[gemini] note:', e.message.slice(0, 120)); }
  }
  return { text: '' };
}

// ---------- Nano Banana: a picture from a prompt (and the person's own photos as references), for the Thumbnail Maker ----------
// refs: [{ mime, data (base64) }] · aspect: '16:9' | '9:16' | '1:1' | '4:5' · returns { buf, mime, model, usage }
export const IMAGE_MODEL = () => process.env.ZANCUT_IMAGE_MODEL || 'gemini-2.5-flash-image';
export async function makeImage(prompt, refs = [], aspect = '16:9', signal) {
  const model = IMAGE_MODEL();
  const parts = [...refs.slice(0, 3).map((r) => ({ inlineData: { mimeType: r.mime, data: r.data } })), { text: prompt }];
  const r = await fetch(gemUrl(model), {
    method: 'POST', signal, headers: { 'content-type': 'application/json', ...gemAuth() },
    body: JSON.stringify({ contents: [{ role: 'user', parts }], generationConfig: { responseModalities: ['IMAGE'], imageConfig: { aspectRatio: aspect } } }),
  });
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const msg = `gemini ${model}: ${r.status} ${JSON.stringify(j.error || j).slice(0, 200)}`; markDead(model, msg); throw new Error(msg); }
  const img = (j.candidates?.[0]?.content?.parts || []).find((x) => x.inlineData?.data);
  if (!img) throw new Error(`gemini ${model}: no picture came back (${j.candidates?.[0]?.finishReason || 'no reason'})`);
  const u = j.usageMetadata || {};
  return { buf: Buffer.from(img.inlineData.data, 'base64'), mime: img.inlineData.mimeType || 'image/png', model, usage: { in: u.promptTokenCount || 0, out: u.candidatesTokenCount || 0 } };
}
