// Free outside ingredients for the graphics and the sound, always with a way back to our own (skills/shared-making.md
// "Real ingredients"; the kit side is ZK.icon / ZK.emoji / ZK.peep in engine/compose/kit.js):
//   icons + logos   Iconify (3 official hosts) → our built-in Lucide + brand set (icons.js) → the builder draws it
//   emoji stickers  Microsoft Fluent 3D (GitHub, then jsDelivr) ↔ Fluent flat (Iconify's hosts, then GitHub) → Google Noto
//                   (Iconify) → the plain emoji character. All MIT / Apache: no credit in the video. (OpenMoji is CC BY-SA: not used.)
//   sound effects   Lots of Sounds (CC0) → Openverse (CC0 / public domain only) → the shared kit (engine/sfx)
//   people          Open Peeps: built in (engine/compose/peeps.js), never fetched
// Everything fetched once is kept in data/library/ (shared by every video), so a repeat never needs the network again. A
// scene's ingredients are copied into its job (assets/lib/ + assets/lib/lib.json, read by engine/compose/compose.mjs) and
// their licences go into work/credits.json. Nothing here throws: a source that fails is skipped, the next one is tried.
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { DATA_DIR, ENGINE_DIR } from './config.mjs';

const run = promisify(execFile);
const CACHE = path.join(DATA_DIR, 'library');
const UA = { 'User-Agent': 'zancut/1.0 (video editor)' };
const slug = (s) => String(s).toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-|-$/g, '').slice(0, 40) || 'x';
const readJ = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const writeJ = (f, v) => { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, JSON.stringify(v, null, 1)); };
// the first source that answers (each one gets a short time: a slow host must not hold up a build)
// ZANCUT_LIBRARY_OFFLINE=1: every outside source counts as down (to check the fallbacks, or to switch them off)
async function first(urls, as = 'json', ms = 4000) {
  if (process.env.ZANCUT_LIBRARY_OFFLINE === '1') return null;
  for (const url of urls) {
    try {
      const r = await fetch(url, { headers: UA, signal: AbortSignal.timeout(ms) });
      if (!r.ok) continue;
      return as === 'json' ? await r.json() : as === 'text' ? await r.text() : Buffer.from(await r.arrayBuffer());
    } catch { /* next source */ }
  }
  return null;
}

// ---------- icons and logos ----------
// sets whose licences need no credit in a video (MIT, ISC, Apache, CC0); colour logos first for brands
const SETS = ['lucide', 'tabler', 'ph', 'material-symbols', 'mdi', 'simple-icons', 'logos', 'skill-icons', 'flat-color-icons', 'fluent-emoji-flat', 'noto'];
const HOSTS = ['https://api.iconify.design', 'https://api.simplesvg.com', 'https://api.unisvg.com'];
let BUILTIN = null;
const builtin = () => {
  if (BUILTIN) return BUILTIN;
  try { const w = {}; new Function('window', fs.readFileSync(path.join(ENGINE_DIR, 'compose', 'icons.js'), 'utf8'))(w); BUILTIN = w.ZK_ICONS; } catch { BUILTIN = { line: {}, alias: {}, brand: {} }; }
  return BUILTIN;
};
// names for a word: our own first (they always work), then Iconify's
export async function findIcons(query, limit = 16) {
  const q = slug(query), I = builtin(), own = [];
  for (const k of Object.keys(I.brand)) if (k.includes(q.replace(/-/g, ''))) own.push(`logo:${k}`);
  for (const k of [...Object.keys(I.line), ...Object.keys(I.alias)]) if (k === q || k.startsWith(`${q}-`) || k.endsWith(`-${q}`)) own.push(k);
  const j = await first(HOSTS.map((h) => `${h}/search?${new URLSearchParams({ query, limit: '48', prefixes: SETS.join(',') })}`));
  const rank = (n) => SETS.indexOf(n.split(':')[0]);
  const web = (j?.icons || []).sort((a, b) => rank(a) - rank(b)).slice(0, limit);
  return { own: [...new Set(own)].slice(0, 8), web, online: !!j };
}
// one Iconify icon's drawing: { b: svg body, w, h }; cached forever
export async function iconData(name) {
  const [set, icon] = String(name).split(':'); if (!set || !icon || !SETS.includes(set)) return null;
  const f = path.join(CACHE, 'icons', set, `${slug(icon)}.json`), hit = readJ(f); if (hit) return hit;
  const j = await first(HOSTS.map((h) => `${h}/${set}.json?icons=${encodeURIComponent(icon)}`));
  const x = j?.icons?.[icon]; if (!x?.body) return null;
  const out = { b: x.body, w: x.width || j.width || 24, h: x.height || j.height || 24 };
  writeJ(f, out); return out;
}

// ---------- emoji stickers ----------
// the emoji's name ("face with tears of joy") from Unicode's list (only the names are used, not OpenMoji's drawings)
let NAMES = null;
const emojiNames = async () => {
  if (NAMES) return NAMES;
  const f = path.join(CACHE, 'emoji', 'names.json');
  let data = readJ(f);
  if (!data) {
    const j = await first(['https://cdn.jsdelivr.net/npm/openmoji@15.1.0/data/openmoji.json', 'https://unpkg.com/openmoji@15.1.0/data/openmoji.json'], 'json', 20000);
    if (j) { data = j.map((e) => ({ emoji: e.emoji, name: e.annotation })); writeJ(f, data); }
  }
  return (NAMES = data || []);
};
const strip = (s) => s.replace(/\uFE0F/g, '');
// a file for one emoji character in a style ('3d' or 'flat'); the other style when one fails; null = none (the page then
// shows the character itself)
export async function emojiFile(ch, style = '3d') {
  const all = await emojiNames(), e = all.find((x) => x.emoji === ch) || all.find((x) => strip(x.emoji) === strip(ch));
  if (!e?.name) return null;
  const key = slug(e.name), Name = e.name.charAt(0).toUpperCase() + e.name.slice(1), snake = e.name.toLowerCase().replace(/[^a-z0-9]+/g, '_').replace(/^_|_$/g, '');
  const gh = (p) => { const q = p.split('/').map(encodeURIComponent).join('/'); return [`https://raw.githubusercontent.com/microsoft/fluentui-emoji/main/assets/${q}`, `https://cdn.jsdelivr.net/gh/microsoft/fluentui-emoji@main/assets/${q}`]; };
  const svgOf = async (set) => { const d = await iconData(`${set}:${key}`); return d ? Buffer.from(`<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 ${d.w} ${d.h}">${d.b}</svg>`) : null; };
  const SOURCES = {
    '3d': async () => first([...gh(`${Name}/3D/${snake}_3d.png`), ...gh(`${Name}/Default/3D/${snake}_3d_default.png`)], 'buf', 10000),
    flat: async () => (await svgOf('fluent-emoji-flat')) || first([...gh(`${Name}/Color/${snake}_color.svg`), ...gh(`${Name}/Default/Color/${snake}_color_default.svg`)], 'buf', 10000),
    noto: async () => svgOf('noto'),
  };
  for (const st of style === 'flat' ? ['flat', '3d', 'noto'] : ['3d', 'flat', 'noto']) {
    const f = path.join(CACHE, 'emoji', st, `${key}.${st === '3d' ? 'png' : 'svg'}`);
    if (fs.existsSync(f)) return { file: f, style: st };
    const buf = await SOURCES[st]();
    if (buf && buf.length > 200) { fs.mkdirSync(path.dirname(f), { recursive: true }); fs.writeFileSync(f, buf); return { file: f, style: st }; }
  }
  return null;
}

// ---------- sound effects ----------
// candidates for a sound: short, free (CC0 / public domain), named; [] when every source is down
export async function findSounds(query, limit = 6) {
  const out = [];
  const a = await first([`https://api.lotsofsounds.com/api/v1/sounds/sample?q=${encodeURIComponent(query)}`], 'json', 10000);
  for (const s of a?.data || []) if (s.stream_url && (s.duration || 0) <= 8) out.push({ id: `los-${s.id}`, title: s.name, about: s.description || '', seconds: +(+s.duration).toFixed(1), url: `https://api.lotsofsounds.com${s.stream_url}`, source: 'Lots of Sounds', license: 'CC0' });
  if (out.length < limit) {
    const b = await first([`https://api.openverse.org/v1/audio/?${new URLSearchParams({ q: query, license: 'cc0,pdm', page_size: '12' })}`], 'json', 12000);
    for (const s of b?.results || []) if (s.url && (s.duration || 0) > 0 && s.duration <= 8000) out.push({ id: `ov-${s.id}`, title: s.title, about: (s.tags || []).slice(0, 6).map((t) => t.name).join(', '), seconds: +(s.duration / 1000).toFixed(1), url: s.url, source: `Openverse (${s.source})`, license: s.license === 'cc0' ? 'CC0' : 'Public domain', by: s.creator });
  }
  return out.slice(0, limit);
}
// a candidate made ready: our kit's loudness (about -16 LUFS, peaks under -2 dB), at most 4 s, a short fade; cached
async function soundFile(c) {
  const f = path.join(CACHE, 'sfx', `${slug(c.id)}.wav`); if (fs.existsSync(f)) return f;
  // Lots of Sounds answers its stream link with a short-lived signed link to the file
  const url = c.id.startsWith('los-') ? (await first([c.url], 'json', 10000))?.data?.stream_url : c.url;
  const buf = url && await first([url], 'buf', 20000); if (!buf || buf.length < 500) return null;
  fs.mkdirSync(path.dirname(f), { recursive: true });
  const raw = `${f}.src`; fs.writeFileSync(raw, buf);
  try {
    await run('ffmpeg', ['-v', 'error', '-y', '-i', raw, '-af', 'silenceremove=start_periods=1:start_threshold=-50dB,atrim=0:4,afade=t=out:st=3.8:d=0.2,loudnorm=I=-16:TP=-2:LRA=11', '-ar', '48000', '-ac', '2', f], { timeout: 60000 });
  } catch { fs.rmSync(f, { force: true }); return null; } finally { fs.rmSync(raw, { force: true }); }
  return fs.existsSync(f) ? f : null;
}

// ---------- people ----------
// the parts' names (engine/compose/peeps.js is built in: no network)
let PEEPS = null;
export function peepParts() {
  if (PEEPS) return PEEPS;
  try { const w = {}; new Function('window', fs.readFileSync(path.join(ENGINE_DIR, 'compose', 'peeps.js'), 'utf8'))(w); const P = w.ZK_PEEPS; PEEPS = { face: Object.keys(P.faces), hair: [...Object.keys(P.heads), 'none'], body: Object.keys(P.bodies), beard: Object.keys(P.beards), glasses: Object.keys(P.accessories) }; } catch { PEEPS = null; }
  return PEEPS;
}

// ---------- a job's own copy (what its page uses) ----------
const libDir = (J0) => path.join(J0, 'assets', 'lib');
const jobLib = (J0) => readJ(path.join(libDir(J0), 'lib.json'), { icons: {}, emoji: {}, sfx: {} });
const credit = (J0, key, c) => { const f = path.join(J0, 'work', 'credits.json'), all = readJ(f, {}); all[key] = c; writeJ(f, all); };

// a sound chosen by a builder: copied into the job as lib:<name> (a cue name); null when it could not be made ready
export async function addSound(J0, c, name) {
  const f = await soundFile(c); if (!f) return null;
  const id = slug(name || c.title), lib = jobLib(J0);
  fs.mkdirSync(path.join(libDir(J0), 'sfx'), { recursive: true });
  fs.copyFileSync(f, path.join(libDir(J0), 'sfx', `${id}.wav`));
  lib.sfx[id] = { title: c.title, source: c.source, license: c.license }; writeJ(path.join(libDir(J0), 'lib.json'), lib);
  credit(J0, `assets/lib/sfx/${id}.wav`, { source: c.source, license: c.license, by: c.by || '', page: c.url });
  return `lib:${id}`;
}

// A saved scene: every ZK.icon("set:name") and ZK.emoji("…") it uses is fetched into the job before the page builds. Returns
// notes for the builder about anything that fell back (it then shows as our own icon, the other emoji style, or the character).
export async function prepareScene(J0, html) {
  const lib = jobLib(J0), notes = [];
  const icons = [...new Set([...String(html).matchAll(/ZK\.icon\(\s*["'`]([a-z0-9-]+:[a-z0-9-]+)["'`]/gi)].map((m) => m[1].toLowerCase()).filter((n) => !n.startsWith('logo:')))];
  for (const n of icons) {
    if (lib.icons[n]) continue;
    const d = await iconData(n);
    if (d) lib.icons[n] = d; else notes.push(`icon "${n}" could not be fetched: it shows as our own icon for "${n.split(':')[1]}" (or a sparkle). Pick another, or draw it.`);
  }
  const emo = [...String(html).matchAll(/ZK\.emoji\(\s*["'`]([^"'`]{1,16})["'`]\s*(?:,\s*\{[^}]*?style\s*:\s*["'`](3d|flat)["'`])?/g)].map((m) => [m[1], m[2] || '3d']);
  for (const [ch, style] of emo) {
    const key = `${ch}|${style}`; if (lib.emoji[key]) continue;
    const got = await emojiFile(ch, style);
    if (!got) { notes.push(`emoji ${ch} could not be fetched: it shows as the plain emoji character.`); continue; }
    const name = `${slug(path.basename(got.file, path.extname(got.file)))}-${got.style}${path.extname(got.file)}`;
    fs.mkdirSync(path.join(libDir(J0), 'emoji'), { recursive: true });
    fs.copyFileSync(got.file, path.join(libDir(J0), 'emoji', name));
    lib.emoji[key] = `emoji/${name}`;
    if (got.style !== style && !(style === 'flat' && got.style === 'noto')) notes.push(`emoji ${ch} in the ${style} style was not available: it shows in the ${got.style} style.`);
    credit(J0, `assets/lib/emoji/${name}`, got.style === 'noto' ? { source: 'Google Noto Emoji', license: 'Apache 2.0' } : { source: 'Microsoft Fluent Emoji', license: 'MIT' });
  }
  // a brand our own set lacks ("logo:openai"): its real logo from the library (one-colour first, then colour), never a
  // silent sparkle
  const I = builtin(), logos = [...new Set([...String(html).matchAll(/ZK\.icon\(\s*["'`]logo:([a-z0-9 .-]+)["'`]/gi)].map((m) => m[1].toLowerCase()))];
  for (const k of logos) {
    const key = `logo:${k}`, id = k.replace(/[^a-z0-9]+/g, ''); if (I.brand[id] || lib.icons[key]) continue;
    let d = null; for (const n of [`simple-icons:${id}`, `logos:${k.replace(/[^a-z0-9]+/g, '-')}-icon`, `logos:${k.replace(/[^a-z0-9]+/g, '-')}`]) if ((d = await iconData(n))) break;
    if (!d) { // the library names it differently ("googlegemini"): search the logo sets for it
      const j = await first(HOSTS.map((h) => `${h}/search?${new URLSearchParams({ query: k, limit: '12', prefixes: 'simple-icons,logos' })}`));
      const hit = (j?.icons || []).find((n) => n.split(':')[1].replace(/-/g, '').includes(id)); if (hit) d = await iconData(hit);
    }
    if (d) lib.icons[key] = d; else notes.push(`logo "${k}" is in no icon library: it shows as a sparkle. Draw the logo yourself (a simple, faithful mark) or use the brand's name as text.`);
  }
  if (icons.length || emo.length || logos.length) writeJ(path.join(libDir(J0), 'lib.json'), lib);
  return notes;
}
