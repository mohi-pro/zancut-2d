// 2D Animation's voices (the voice tool, ported to Node) and Text to Dialogue:
//   castDialogue(): any script + the format the customer picked → who says which words (Opus, skills/2d-animation/dialogue.md:
//     the script decides, the customer's pick is the fallback when it is unclear) → a distinct voice for every speaker.
//   recordLines(): every line voiced on its own (so each line's speaker, start and end are exact), cached by voice + delivery +
//     words (a changed line is the only one recorded again), joined with pauses → voice.wav, voice.words.json, lines.json.
//   lipsync(): the mouths of every character from their own lines' sound.
// Used by the Voice Artist (server/planner.mjs addDialogue) and the video pipeline (server/animpipe.mjs).
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { query } from './no-ai.mjs';
import { CLAUDE_PATH, SKILLS_DIR } from './config.mjs';
import * as users from './users.mjs';
import * as claude from './claude-auth.mjs';
import { usageCost, usdToCredits, pricing } from './pricing.mjs';
import { GEMINI_VOICES, geminiOn, speakTake, transcribeLong } from './gemini.mjs';

const safe = (s) => String(s || '').replace(/\W/g, '');
const sh = (cmd, args, opts = {}) => new Promise((ok, no) => execFile(cmd, args, { maxBuffer: 1 << 28, timeout: 30 * 60000, encoding: 'buffer', ...opts }, (e, so, se) => (e ? no(new Error(String(se || so || e.message).slice(-400))) : ok(so))));
const FFMPEG = process.env.ZANCUT_FFMPEG || 'ffmpeg';
export const RATE = 24000, FPS = 30;
export const FORMATS = ['narrator', 'characters', 'mixed'];
const skill = (f) => fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', f), 'utf8');

/** one Opus answer as JSON (the customer's own Claude; its cost is taken from their credits) */
export async function ask(u, system, prompt) {
  let out = '', usd = 0;
  const cwd = path.join(os.tmpdir(), 'zancut-chat'); fs.mkdirSync(cwd, { recursive: true });
  for await (const ev of query({ prompt, options: { model: pricing().models?.animation || pricing().models?.director || 'claude-opus-5-5', maxTurns: 1, cwd, settingSources: [], tools: [], systemPrompt: system,
    env: { ...process.env, ...claude.envFor(u.id), ENABLE_CLAUDEAI_MCP_SERVERS: 'false', CLAUDE_CODE_DISABLE_CLAUDE_MDS: '1' }, ...(CLAUDE_PATH ? { pathToClaudeCodeExecutable: CLAUDE_PATH } : {}) } })) {
    claude.seeFor(u.id)(ev);
    if (ev.type === 'result') { out = String(ev.result || ''); usd = ev.total_cost_usd || usd; if (ev.is_error) throw new Error(out || 'Claude did not answer'); }
    if (ev.type === 'assistant' && ev.message?.usage && !usd) usd = usageCost(ev.message.model, ev.message.usage);
  }
  if (usd) users.spendCredits(u, Math.max(0, Math.round(usdToCredits(usd))));
  const m = out.match(/\{[\s\S]*\}(?![\s\S]*\})/);
  if (!m) throw new Error('The AI did not answer with a script');
  return JSON.parse(m[0]);
}

// ---------- voices ----------
const VOICE_IDS = new Set(GEMINI_VOICES.map((v) => v.id));
const genderOf = (id) => (/^Male/.test(GEMINI_VOICES.find((v) => v.id === id)?.sub || '') ? 'male' : 'female');
export const NARRATOR = { male: 'g-charon', female: 'g-sulafat' };
// who sounds right for whom, best first
const PREFER = {
  male: { child: ['g-puck', 'g-fenrir'], teen: ['g-puck', 'g-fenrir'], adult: ['g-orus', 'g-charon', 'g-fenrir', 'g-puck'], elderly: ['g-algenib', 'g-orus', 'g-charon'] },
  female: { child: ['g-leda', 'g-zephyr'], teen: ['g-leda', 'g-zephyr', 'g-aoede'], adult: ['g-kore', 'g-aoede', 'g-sulafat', 'g-zephyr'], elderly: ['g-sulafat', 'g-kore'] },
};
/** a voice for the narrator and every character: the customer's choices first, then each voice once where possible */
export function castVoices(s, { narratorVoice, narratorGender, cast = {} } = {}) {
  const ng = narratorGender === 'male' || narratorGender === 'female' ? narratorGender : null;
  const nv = VOICE_IDS.has(narratorVoice) ? narratorVoice : VOICE_IDS.has(s.narrator?.voice) && (!ng || genderOf(s.narrator.voice) === ng) ? s.narrator.voice : NARRATOR[ng || s.narrator?.gender] || 'g-charon';
  s.narrator = { ...s.narrator, voice: nv, gender: genderOf(nv), style: s.narrator?.style || 'A warm storyteller narrating a short animated story.' };
  const used = new Set([nv]); // the narrator's voice is the narrator's alone: never a character's
  for (const c of s.characters) {
    const g = c.spec?.gender === 'male' || c.gender === 'male' ? 'male' : 'female', age = c.spec?.age || c.age || 'adult';
    const want = VOICE_IDS.has(cast[c.id]) ? cast[c.id] : VOICE_IDS.has(c.voice) && !used.has(c.voice) ? c.voice : null;
    const list = [...(PREFER[g][age] || PREFER[g].adult), ...GEMINI_VOICES.filter((v) => genderOf(v.id) === g).map((v) => v.id)];
    c.voice = want || list.find((v) => !used.has(v)) || list[0];
    used.add(c.voice);
  }
  return s;
}

const SCENE_TYPES = new Set(['character', 'tabletop', 'phone', 'graphic']);
/** make a script safe to compile and voice: ids, voices, scenes and staging that point at real people, shots that
    point at people in their scene, silent beats */
export function tidyScript(s, { narratorVoice, narratorGender, cast } = {}) {
  s.characters = (s.characters || []).map((c, i) => ({ ...c, id: safe(c.id).toLowerCase() || `c${i + 1}`, name: c.name || `Character ${i + 1}`, spec: { ...(c.spec || {}), ...(c.gender && !c.spec?.gender ? { gender: c.gender } : {}), ...(c.age && !c.spec?.age ? { age: c.age } : {}) } }));
  const ids = new Set(s.characters.map((c) => c.id));
  s.inserts = s.inserts || {};
  const who = (x) => { const k = safe(x).toLowerCase(); return ids.has(k) ? k : null; };
  s.lines = (s.lines || []).map((l) => ({ ...l, speaker: String(l.speaker || '').toLowerCase() === 'silent' ? 'silent' : who(l.speaker) || 'narrator' }))
    .filter((l) => l.speaker === 'silent' || String(l.text || '').trim());
  // Keep authored scenes and staging. Never infer a cast, cap the visible people,
  // assign left/centre/right positions, or move extra characters off screen.
  const scenes = Array.isArray(s.scenes) && s.scenes.length ? s.scenes : null;
  if (scenes) {
    s.scenes = scenes.map((sc, i) => ({ ...sc, id: safe(sc.id) || `s${i + 1}`, type: SCENE_TYPES.has(sc.type) ? sc.type : 'character' }));
    const sid = new Set(s.scenes.map((x) => x.id));
    for (const l of s.lines) {
      if (l.scene != null && !sid.has(safe(l.scene))) throw new Error(`Unknown animation scene: ${l.scene}`);
      if (l.scene != null) l.scene = safe(l.scene);
    }
    for (const sc of s.scenes) if (sc.staging) {
      sc.staging = sc.staging.map(x => {
        const id = who(x.who);
        if (!id) throw new Error(`Unknown staged character: ${x.who}`);
        return { ...x, who: id };
      });
    }
  }
  s.lines = s.lines.map((l) => {
    // Camera descriptions are creative direction, including OTS, reverse,
    // ground-level, profiles and inserts. Do not convert them to a wide shot.
    const shot = l.shot == null ? undefined : { ...l.shot };
    const m = l.missing && typeof l.missing === 'object' ? l.missing : { what: l.missing };
    const missing = String(m.what || '').trim() ? { part: String(m.part || 'other').trim().toLowerCase().slice(0, 20), what: String(m.what).trim().slice(0, 200) } : null;
    const { missing: _m, ...rest } = l;
    return { ...rest, text: String(l.text || '').trim(), ...(shot ? { shot } : {}), acts: (l.acts || []).map((a) => ({ ...a, who: who(a.who) })).filter((a) => a.who), ...(missing ? { missing } : {}) };
  });
  // Report implementation gaps to the director; never silently replace the requested action: Admin counts them (learn.mjs wantParts)
  s.missing = s.lines.map((l, i) => l.missing && { line: i + 1, ...l.missing }).filter(Boolean);
  return castVoices(s, { narratorVoice, narratorGender, cast });
}

// ---------- Text to Dialogue: who says which words ----------
// without the AI: `NAME (tone): words` lines are characters, the rest is narration; scene headings and "See:" lines are skipped
const SHEET = /^\s*(?:front|middle|back|staging|camera|graphic|sound)\s*[:：]/i; // the scene sheet's lines (skills/chat/script.md)
const NOT_SPOKEN = /^\s*(?:title|format|see|place|characters?|cast|scene\s*\d*|দৃশ্য\s*\d*|location|setting|visual|shot)\b\s*[:：·.-]?/i;
export function parseDialogue(text, format) {
  const lines = [], chars = new Map();
  let inBlock = false;
  for (const raw of String(text || '').split(/\n/)) {
    const t = raw.replace(/[*_#`]/g, '').trim();
    if (!t) { inBlock = false; continue; }
    if (/^(CHARACTERS|CAST|PLACE)\b/i.test(t)) { inBlock = true; continue; }
    if (inBlock || NOT_SPOKEN.test(t) || SHEET.test(t) || /^\[.*\]$/.test(t) || /^\(.*\)$/.test(t)) continue;
    const m = /^([\p{L}][\p{L}\p{M}\p{N} .'-]{0,30}?)\s*(?:\(([^)]{0,60})\))?\s*[:：—–-]\s*(.+)$/u.exec(t);
    const words = (x) => x.replace(/\[[^\]]*\]/g, '').trim();
    if (m && !/^narrator$|^ন্যারেটর$|^কথক$|^voice ?over$/i.test(m[1].trim())) {
      const name = m[1].trim(), id = safe(name).toLowerCase() || `c${chars.size + 1}`;
      if (!chars.has(id)) chars.set(id, { id, name, gender: chars.size % 2 ? 'female' : 'male', age: 'adult', style: '' }); // unknown: the voices alternate
      if (words(m[3])) lines.push({ speaker: id, tone: m[2] || '', text: words(m[3]) });
    } else {
      const n = /^(?:narrator|ন্যারেটর|কথক|voice ?over)\s*(?:\(([^)]{0,60})\))?\s*[:：—–-]\s*(.+)$/iu.exec(t);
      for (const s of words(n ? n[2] : t).split(/(?<=[.!?।])\s+/).filter(Boolean)) lines.push({ speaker: 'narrator', tone: n?.[1] || '', text: s });
    }
  }
  const talk = lines.filter((l) => l.speaker !== 'narrator').length, tell = lines.length - talk;
  // the script decides when it is clear; the customer's pick when it is not
  let mode = format;
  if (talk >= 2 && format === 'narrator') mode = tell ? 'mixed' : 'characters';
  else if (talk && tell >= 2 && format === 'characters') mode = 'mixed';
  else if (!talk && format !== 'narrator') mode = 'narrator';
  if (mode === 'narrator') for (const l of lines) l.speaker = 'narrator';
  const note = mode === format ? '' : mode === 'narrator' ? 'Nobody talks in this script, so the narrator reads all of it.' : format === 'characters' ? 'Your script also tells the story between the lines, so a narrator reads those parts.' : 'Your script has people talking to each other, so they got their own voices.';
  return { mode, note, narrator: {}, characters: mode === 'narrator' ? [] : [...chars.values()], lines };
}

/** any script → { script (lines, speakers, voices), mode used, note when the script overruled the customer's pick } */
export async function castDialogue(u, { text, lang = 'en', format = 'mixed', narratorGender = 'male', narratorVoice, cast } = {}) {
  const src = String(text || '').trim().slice(0, 12000);
  if (!src) throw Object.assign(new Error('Write or paste the script first.'), { status: 400 });
  const chosen = FORMATS.includes(format) ? format : 'mixed';
  let r;
  try {
    r = await ask(u, skill('dialogue.md'), `Language of the words: ${lang}. The customer picked the format: ${chosen}. Narrator: ${narratorGender}.\n\nThe script:\n\n${src}\n\nAnswer with the JSON only.`);
  } catch (e) { console.error('[dialogue]', String(e.message).slice(0, 160)); r = null; }
  if (r?.ask) throw Object.assign(new Error(String(r.ask).slice(0, 300)), { status: 400 });
  if (!r?.lines?.length) r = parseDialogue(src, chosen); // no AI answer: the plain reading
  if (!r.lines.length) throw Object.assign(new Error('There are no words to read in this script. Paste the lines people should say.'), { status: 400 });
  const mode = FORMATS.includes(r.mode) ? r.mode : chosen;
  const S = tidyScript({ title: '', language: lang, narrator: { gender: narratorGender, style: r.narrator?.style }, characters: mode === 'narrator' ? [] : r.characters || [], lines: r.lines.map((l) => ({ speaker: mode === 'narrator' ? 'narrator' : l.speaker, tone: l.tone || '', text: l.text })) }, { narratorVoice, narratorGender, cast });
  S.format = { chosen, used: mode, note: mode === chosen ? '' : String(r.note || '').slice(0, 300) };
  return S;
}

// ---------- recording: a voice per line, joined ----------
export async function pcmOf(file) { return new Int16Array((await sh(FFMPEG, ['-v', 'error', '-i', file, '-f', 's16le', '-ac', '1', '-ar', String(RATE), 'pipe:1'])).buffer.slice(0)); }
export function wavFile(file, pcm) {
  const h = Buffer.alloc(44), n = pcm.length * 2;
  h.write('RIFF', 0); h.writeUInt32LE(36 + n, 4); h.write('WAVEfmt ', 8); h.writeUInt32LE(16, 16); h.writeUInt16LE(1, 20); h.writeUInt16LE(1, 22);
  h.writeUInt32LE(RATE, 24); h.writeUInt32LE(RATE * 2, 28); h.writeUInt16LE(2, 32); h.writeUInt16LE(16, 34); h.write('data', 36); h.writeUInt32LE(n, 40);
  fs.writeFileSync(file, Buffer.concat([h, Buffer.from(pcm.buffer, pcm.byteOffset, n)]));
}
export const voiceOf = (S, who) => (who === 'narrator' ? S.narrator : S.characters.find((c) => c.id === who)) || S.narrator;
// a line's own file: the same voice, delivery and words are never recorded twice (a dialogue take brought into a video is reused)
// every 2D line is spoken fast and keeps moving: a viewer who hears a slow start or a pause scrolls away
const PACE = 'Pace: brisk and lively, like a storyteller who keeps the listener hooked; the words flow on with no long pauses, never slow or dragging.';
export const lineFile = (S, l, lang) => {
  const v = voiceOf(S, l.speaker), style = [v.style, l.tone ? `Emotion and delivery for this line: ${l.tone}.` : '', PACE].filter(Boolean).join(' ');
  return { voice: v.voice, style, name: `${crypto.createHash('sha1').update(`${v.voice}|${style}|${lang}|${l.text}`).digest('hex').slice(0, 16)}.wav` };
};

// a take of one speaker's lines → each line's sound, cut at the silences the voice was asked to leave after every line.
// The cuts are the longest silences nearest to where each line should end (by its length in letters); a line much
// shorter or longer than its words need is flagged (said only in part, or something extra) and recorded again alone.
// heardEnds (seconds, one per line but the last): where each line's words were heard to end. A voice can pause longer inside a
// line than between two lines, so with them the cuts are the silences at those moments and the letters only break no tie.
export function sliceTake(pcm, texts, heardEnds = null) {
  const F = RATE / 100, n = texts.length, N = Math.floor(pcm.length / F), rms = new Float32Array(N);
  for (let f = 0; f < N; f++) { let s = 0; for (let i = f * F; i < (f + 1) * F; i++) s += pcm[i] * pcm[i]; rms[f] = Math.sqrt(s / F); }
  const thr = Math.max(40, ([...rms].sort((x, y) => x - y)[Math.floor(N * 0.95)] || 0) * 0.06), on = (f) => rms[f] > thr;
  let first = 0, last = N - 1; while (first < N && !on(first)) first++; while (last > first && !on(last)) last--;
  if (last - first < 20) return null;
  const runs = []; for (let f = first; f <= last; f++) if (!on(f)) { const a = f; while (f <= last && !on(f)) f++; if (f - a >= 18) runs.push({ a, b: f, len: f - a, mid: (a + f) / 2 }); }
  if (runs.length < n - 1) return null;
  const w = texts.map((t) => String(t).length + 8), W = w.reduce((x, y) => x + y, 0), L = last - first;
  const want = []; let acc = 0; for (let k = 0; k < n - 1; k++) { acc += w[k]; want.push(first + (acc / W) * L); }
  // pick n-1 silences in order: near where each line should end, the longer the better (the asked-for pause is ~1 s)
  const off = (k, j) => Math.max(0, runs[j].a - heardEnds[k] * 100, heardEnds[k] * 100 - runs[j].b); // frames from the heard end to this silence
  const cost = (k, j) => (heardEnds ? off(k, j) / 25 - (Math.min(runs[j].len, 120) / 120) * 0.2 : (Math.abs(runs[j].mid - want[k]) / L) * 4 - (Math.min(runs[j].len, 120) / 120) * 3), M = runs.length;
  const best = Array.from({ length: n - 1 }, () => new Array(M).fill(Infinity)), from = Array.from({ length: n - 1 }, () => new Array(M).fill(-1));
  for (let j = 0; j < M; j++) best[0][j] = cost(0, j);
  for (let k = 1; k < n - 1; k++) for (let j = k; j < M; j++) for (let i = k - 1; i < j; i++) { const c = best[k - 1][i] + cost(k, j); if (c < best[k][j]) { best[k][j] = c; from[k][j] = i; } }
  const cuts = []; if (n > 1) { let j = 0; for (let x = 1; x < M; x++) if (best[n - 2][x] < best[n - 2][j]) j = x; for (let k = n - 2; k >= 0; k--) { cuts.unshift(runs[j]); j = from[k][j]; } }
  const segs = []; let s0 = first;
  for (let k = 0; k < n; k++) { const e0 = k < n - 1 ? cuts[k].a : last + 1, nx = k < n - 1 ? cuts[k].b : N;
    const a = Math.max(0, s0 - 3), b = Math.min(nx, e0 + 8); segs.push({ pcm: pcm.slice(a * F, b * F), dur: (e0 - s0) / 100, from: s0 / 100, to: e0 / 100 }); if (k < n - 1) s0 = cuts[k].b; }
  const per = segs.reduce((x, g) => x + g.dur, 0) / texts.reduce((x, t) => x + String(t).length, 0);
  return segs.map((g, k) => { const r = g.dur / Math.max(0.3, String(texts[k]).length * per); return { pcm: g.pcm, from: g.from, to: g.to, ok: r > 0.45 && r < 2.2, ratio: Math.round(r * 100) / 100 }; });
}

// where each line of a take ends, from the words heard in it: the same count of words per line (scaled when the listener split
// or joined a few), then the heard word nearest that count that sounds most like the line's last word. Exported for the test.
const bare = (x) => String(x).toLowerCase().replace(/[^\p{L}\p{M}\p{N}]/gu, '');
const sameStart = (w, word) => { const h = bare(w), t = bare(word); let n = 0; while (n < h.length && n < t.length && h[n] === t[n]) n++; return n / Math.max(1, t.length); };
// a piece cut from a take holds its own line: the words heard in it start and end like the line (a voice can run two lines
// together with no pause to cut at; a sentence would then slide into the next line). Exported for the test.
export function holdsLine(text, heard, from, to) {
  const t = String(text).split(/\s+/).filter(Boolean), ws = (heard || []).filter((w) => { const m = (w.s + w.e) / 2; return m >= from - 0.05 && m <= to + 0.05; });
  if (!ws.length) return false;
  return sameStart(ws[0].w, t[0]) >= 0.4 && sameStart(ws.at(-1).w, t.at(-1)) >= 0.4;
}
export function lineEnds(texts, heard) {
  const counts = texts.map((t) => String(t).split(/\s+/).filter(Boolean).length), all = counts.reduce((x, y) => x + y, 0), ends = []; let acc = 0;
  if (!heard?.length || !all) return null;
  for (let k = 0; k < texts.length - 1; k++) {
    acc += counts[k];
    const guess = Math.round((acc / all) * heard.length) - 1, last = bare(String(texts[k]).split(/\s+/).filter(Boolean).at(-1));
    const like = (w) => sameStart(w, last);
    let best = Math.max(0, Math.min(heard.length - 1, guess)), top = like(heard[best].w);
    for (const d of [-1, 1, -2, 2]) { const j = guess + d; if (j >= 0 && j < heard.length && like(heard[j].w) > top + 0.25) { best = j; top = like(heard[j].w); } }
    ends.push(heard[best].e);
  }
  return ends;
}

const TAKE_LINES = 8, TAKE_CHARS = 900;
/** every line in its speaker's ONE voice → dir/voice.wav, voice.words.json, lines.json, voice-report.json; returns the track.
    Each speaker's lines are recorded together in takes (Gemini: one call per take, so the voice never drifts), cut apart,
    checked, and a bad line is recorded again alone in the same voice. The words are then timed (WhisperX) right here, so
    the transcript step has nothing left to hear. "silent" lines are quiet beats of their `hold` seconds. */
export async function recordLines(S, dir, { speak, step = () => {}, id = 'anim', lang = S.language || 'en', onUsage = () => {}, signal } = {}) {
  const LD = path.join(dir, 'lines'); fs.mkdirSync(LD, { recursive: true });
  const L = S.lines, files = new Array(L.length).fill(null), report = L.map((l, i) => ({ line: i + 1, speaker: l.speaker }));
  const fileOf = (i) => path.join(LD, lineFile(S, L[i], lang).name);
  const todo = L.map((l, i) => i).filter((i) => L[i].speaker !== 'silent' && String(L[i].text || '').trim());
  let done = 0; const tick = () => step(`Recording the voices: ${++done} of ${todo.length}`);
  // one line alone (the fallback, and a line that failed its check): the same voice and delivery; never another voice
  const alone = async (i) => {
    const o = lineFile(S, L[i], lang), f = fileOf(i); let err;
    for (const wait of [0, 8000, 20000]) {
      if (wait) await new Promise((r) => setTimeout(r, wait));
      try { await speak({ id, voiceId: o.voice, voiceSpeed: 'normal', language: lang, voiceStyle: o.style, noLocalVoice: true, ttsModel: model }, L[i].text, f, lang); mark(i); return f; } catch (e) { err = e; fs.rmSync(f, { force: true }); }
    }
    throw err;
  };
  // the takes: per speaker, in story order, the lines not recorded yet, up to 8 lines / 900 letters a take
  const takes = [];
  for (const who of [...new Set(todo.map((i) => L[i].speaker))]) {
    let cur = [];
    for (const i of todo.filter((k) => L[k].speaker === who && !fs.existsSync(fileOf(k)))) {
      if (cur.length && (cur.length >= TAKE_LINES || cur.reduce((n, k) => n + L[k].text.length, 0) + L[i].text.length > TAKE_CHARS)) { takes.push(cur); cur = []; }
      cur.push(i);
    }
    if (cur.length) takes.push(cur);
  }
  for (const i of todo) if (fs.existsSync(fileOf(i))) { files[i] = fileOf(i); tick(); }
  const tempo = 1.15; // a 2D story is told fast (a little quicker than the single-line voice's 1.1); the words stay clear
  // one voice model for the whole film: the first take's (a line recorded before is kept in its file's own .model note)
  let model = todo.map((i) => { try { return fs.readFileSync(`${fileOf(i)}.model`, 'utf8').trim(); } catch { return null; } }).find(Boolean) || null;
  const mark = (i) => model && fs.writeFileSync(`${fileOf(i)}.model`, model);
  const one = async (take) => {
    const v = voiceOf(S, L[take[0]].speaker);
    let segs = null;
    if (geminiOn() && v.voice?.startsWith('g-')) {
      const tf = path.join(LD, `take-${crypto.randomBytes(4).toString('hex')}.wav`);
      try {
        const r = await speakTake(take.map((i) => ({ text: L[i].text, tone: L[i].tone })), v.voice, lang, tf, { style: v.style, signal, model });
        onUsage(r.usage); model ||= r.model;
        await sh(FFMPEG, ['-v', 'error', '-y', '-i', tf, '-af', `atempo=${tempo}`, '-ar', String(RATE), '-ac', '1', `${tf}.t.wav`]);
        const texts = take.map((i) => L[i].text);
        let heard = null, heardEnds = null; // the take is listened to before it is cut: its pauses alone do not show where a line ends
        if (take.length > 1) try { const h = await transcribeLong(`${tf}.t.wav`, lang, { signal }); onUsage(h.usage || []); heard = h.words; heardEnds = lineEnds(texts, heard); } catch (e) { if (signal?.aborted) throw e; console.error('[voice take] not heard:', String(e.message).slice(0, 160)); }
        segs = sliceTake(await pcmOf(`${tf}.t.wav`), texts, heardEnds);
        if (segs && heardEnds) segs.forEach((g, k) => { if (g.ok && !holdsLine(texts[k], heard, g.from, g.to)) { g.ok = false; g.cut = true; } });
      } catch (e) { if (signal?.aborted) throw e; console.error('[voice take]', String(e.message).slice(0, 160)); }
      finally { fs.rmSync(tf, { force: true }); fs.rmSync(`${tf}.t.wav`, { force: true }); }
      // a take that could not be cut at its pauses (the voice ran lines together): two smaller takes in the same voice, never
      // straight to one line at a time (single lines drift apart)
      if (!segs && take.length > 2) { console.error(`[voice take] ${take.length} lines of ${L[take[0]].speaker} could not be cut: two takes of ${Math.ceil(take.length / 2)}`); const h = Math.ceil(take.length / 2); await one(take.slice(0, h)); await one(take.slice(h)); return; }
      if (!segs) for (const i of take) report[i].alone = 'its take could not be cut at its pauses';
    }
    for (let k = 0; k < take.length; k++) {
      const i = take[k], g = segs?.[k];
      if (g?.ok) { wavFile(fileOf(i), g.pcm); mark(i); files[i] = fileOf(i); report[i].take = true; }
      else { if (g) report[i].redone = g.cut ? 'its piece of the take did not hold its own words' : `length ${g.ratio}× what its words need`; files[i] = await alone(i); }
      tick();
    }
  };
  // the first take alone (it fixes the voice model), then two at a time
  let next = 0; if (takes.length) await one(takes[next++]);
  await Promise.all([0, 1].map(async () => { while (next < takes.length) await one(takes[next++]); }));
  let T = await join(S, files, dir);
  // the words: timed on the sound (WhisperX); a line whose words do not match its sound (a word skipped, something else
  // said) is recorded again alone, once
  step('Timing every word');
  const aligned = await alignWords(T, dir, lang, signal);
  if (aligned) {
    const bad = T.times.map((t, i) => ({ t, i })).filter(({ t, i }) => L[i].speaker !== 'silent' && t.w1 - t.w0 >= 3 && !report[i].redone && (() => {
      const ws = aligned.slice(t.w0, t.w1), good = ws.filter((w) => (w.conf ?? 1) >= 0.3).length; return good / ws.length < 0.6; })()).map(({ i }) => i);
    if (bad.length && bad.length <= Math.max(2, L.length / 3)) {
      step(`Recording ${bad.length} line${bad.length > 1 ? 's' : ''} again`);
      for (const i of bad) { fs.rmSync(fileOf(i), { force: true }); files[i] = await alone(i); report[i].redone = 'its words did not match the sound'; }
      T = await join(S, files, dir); await alignWords(T, dir, lang, signal);
    }
    fs.writeFileSync(path.join(dir, 'aligned.json'), JSON.stringify({ at: Date.now() }));
  }
  T.times.forEach((t, i) => { report[i].start = t.start; report[i].end = t.end; });
  fs.writeFileSync(path.join(dir, 'voice-report.json'), JSON.stringify(report, null, 1));
  return T;
}
async function alignWords(T, dir, lang, signal) {
  const wf = path.join(dir, 'voice.words.json');
  try { const { alignScript } = await import('./transcribe.mjs'); await alignScript(path.join(dir, 'voice.wav'), wf, lang, signal); } catch (e) { if (signal?.aborted) throw e; return null; }
  const w = JSON.parse(fs.readFileSync(wf, 'utf8'));
  return w.some((x) => x.conf != null) ? w : null;
}
// the lines joined, the story never stops: the voice starts at once (the hook), a quick breath between lines of one speaker,
// a little more when the speaker changes; the script's own quiet before / after a line (pre / post) and a silent beat are kept
// short. A viewer scrolls away from a slow start or a pause.
export const GAP = { start: 0.05, same: 0.12, change: 0.25, pre: 0.2, post: 0.3, silent: [0.3, 0.6] };
async function join(S, files, dir) {
  const L = S.lines, pcm = [], times = [], words = []; let at = Math.round(RATE * GAP.start), prev = null;
  for (let i = 0; i < L.length; i++) {
    const l = L[i], quiet = l.speaker === 'silent';
    const a = quiet ? new Int16Array(Math.round(RATE * Math.max(GAP.silent[0], Math.min(GAP.silent[1], +l.hold || GAP.silent[0])))) : await pcmOf(files[i]);
    if (prev !== null) at += Math.round(RATE * ((prev === l.speaker ? GAP.same : GAP.change) + Math.min(GAP.post, +L[i - 1].post || +L[i - 1].pauseAfter || 0) + Math.min(GAP.pre, +l.pre || 0)));
    let ws = null; if (!quiet) try { ws = JSON.parse(fs.readFileSync(files[i].replace(/\.wav$/, '.words.json'), 'utf8')); } catch { }
    if (!quiet && !ws?.length) { const t = l.text.split(/\s+/).filter(Boolean), tot = t.reduce((x, w) => x + w.length + 1, 0); let k = 0; ws = t.map((w) => { const s = (k / tot) * (a.length / RATE); k += w.length + 1; return { text: w, start: s, end: (k / tot) * (a.length / RATE) }; }); }
    const w0 = words.length;
    if (!quiet) { const last = Math.max(...ws.map((w) => w.end ?? w.e ?? 0)) || 1, sc = a.length / RATE / last;
      for (const w of ws) words.push({ text: w.text ?? w.w ?? w.word, start: Math.round((at / RATE + (w.start ?? w.s) * sc) * 1000) / 1000, end: Math.round((at / RATE + (w.end ?? w.e) * sc) * 1000) / 1000 }); }
    times.push({ start: at / RATE, end: (at + a.length) / RATE, speaker: l.speaker, w0, w1: words.length });
    pcm.push([at, a]); at += a.length; prev = l.speaker;
  }
  const track = new Int16Array(at + Math.round(RATE * 1.2));
  for (const [a, x] of pcm) track.set(x, a);
  const wav = path.join(dir, 'voice.wav');
  wavFile(wav, track);
  fs.writeFileSync(path.join(dir, 'voice.words.json'), JSON.stringify(words));
  fs.writeFileSync(path.join(dir, 'lines.json'), JSON.stringify(times));
  return { wav, track, times, words };
}

/** the mouth of one line, from its own sound: open = loudness, round = few zero crossings (o / u sounds) */
export function mouthOf(pcm) {
  const per = RATE / FPS, n = Math.ceil(pcm.length / per), rms = [], zcr = [];
  for (let f = 0; f < n; f++) { let s = 0, z = 0; const a = Math.floor(f * per), b = Math.min(pcm.length, Math.floor((f + 1) * per)); for (let i = a; i < b; i++) { s += pcm[i] * pcm[i]; if (i > a && (pcm[i] >= 0) !== (pcm[i - 1] >= 0)) z++; } rms.push(Math.sqrt(s / Math.max(1, b - a))); zcr.push(z / Math.max(1, b - a)); }
  const top = [...rms].sort((x, y) => x - y)[Math.floor(rms.length * 0.92)] || 1;
  let o = 0; const open = [], round = [];
  rms.forEach((r, f) => { const v = Math.max(0, Math.min(1, (r / top - 0.12) / 0.8)); o = v > o ? o + (v - o) * 0.75 : o + (v - o) * 0.45; open.push(Math.round(o * 100) / 100); round.push(Math.round(Math.max(0, Math.min(1, 1 - zcr[f] / 0.09)) * o * 80) / 100); });
  return { open, round };
}
/** every character's mouth over the whole track, each from the sound of their own lines */
export function lipsync(track, lines, times) {
  const N = Math.ceil((track.length / RATE) * FPS), lip = { fps: FPS };
  lines.forEach((l, i) => {
    if (l.speaker === 'narrator' || l.speaker === 'silent') return; // only a character's own line moves their mouth
    const a = Math.round(times[i].start * RATE), b = Math.round(times[i].end * RATE), m = mouthOf(track.subarray(a, b)), f0 = Math.round(times[i].start * FPS);
    const D = (lip[l.speaker] ||= { open: new Array(N).fill(0), round: new Array(N).fill(0) });
    m.open.forEach((v, k) => { if (f0 + k < N) { D.open[f0 + k] = v; D.round[f0 + k] = m.round[k]; } });
  });
  return lip;
}
