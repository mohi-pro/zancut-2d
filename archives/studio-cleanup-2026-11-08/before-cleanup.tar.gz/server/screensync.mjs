// A video whose voice is its own (a Storytelling video's recording or AI voice, or a Talking head's camera video) with one or
// more screen recordings among its extra files: after every cut, the cut's picture is rebuilt from the recordings so it follows the voice. Each spoken
// line gets the recording and the stretch that show what it talks about: Claude looks at frames of every recording (with their
// seconds) next to the lines, the customer's note on each recording and their brief (the Prompt); the answer is kept in
// work/screen-sync.json by the words' own numbers (src), so a later re-cut only re-times it (it is asked again only when the
// recordings, their notes, the brief or the voice change). Each stretch is sped up or slowed down to fill its line (0.5×–4×; longer: its end is kept, where the result
// shows; shorter: its last frame holds). No answer (Claude busy, bad JSON): the screen is spread evenly over the voice.
// The cut's sound is never touched. A talking head's camera cut is never touched either: its screen is cut/screen.mp4.
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash } from 'node:crypto';
import { screenLed, voiceSource } from './studio.mjs';

const run = promisify(execFile);
const r2 = (x) => Math.round(x * 100) / 100;
const J = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const probe = async (f) => { const { stdout } = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration:stream=width,height,codec_type', '-of', 'json', f]); const j = JSON.parse(stdout), v = (j.streams || []).find((s) => s.codec_type === 'video') || {}; return { duration: Number(j.format?.duration || 0), width: v.width, height: v.height }; };
// slower than 0.8× reads as slow motion (a 6 s stretch at 0.5× over 19 s looked broken): a short stretch holds its last frame
const MIN_SPEED = 0.8, MAX_SPEED = 4;
const AIM_AT = [0.12, 0.65]; // where in a line's stretch the aim's two frames are taken (A, B)

// the cut's words → lines (a sentence, or a breath longer than 0.7 s); a bit under 1 s joins its shorter neighbour (so each
// instruction keeps its own line and its own stretch of the screen)
export function linesOf(words) {
  const out = []; let from = 0;
  words.forEach((w, i) => {
    const next = words[i + 1], end = /[.?!।]["')\]]*$/.test(String(w.text || '')) || !next || next.start - w.end > 0.7;
    if (end) { out.push({ from, to: i }); from = i + 1; }
  });
  const len = (l) => words[l.to].end - words[l.from].start;
  for (;;) {
    const k = out.findIndex((l) => len(l) < 1); if (k < 0 || out.length < 2) break;
    const into = k === 0 ? 1 : k === out.length - 1 ? k - 1 : len(out[k - 1]) <= len(out[k + 1]) ? k - 1 : k + 1;
    out[into] = { from: Math.min(out[into].from, out[k].from), to: Math.max(out[into].to, out[k].to) }; out.splice(k, 1);
  }
  // no line over ~5 s (a transcript without punctuation and a voice without pauses would make one 30 s line, one stretch of the
  // screen for many steps): a long one is split at its longest breath, again and again
  const split = (l) => {
    if (len(l) <= 5.5 || l.to - l.from < 3) return [l];
    let at = -1, gap = -1;
    for (let i = l.from + 1; i <= l.to - 1; i++) { const g = words[i].start - words[i - 1].end, mid = Math.abs((words[i].start - words[l.from].start) / len(l) - 0.5); const score = g - mid * 0.2; if (score > gap) { gap = score; at = i; } }
    return at < 0 ? [l] : [...split({ from: l.from, to: at - 1 }), ...split({ from: at, to: l.to })];
  };
  return out.flatMap(split);
}

// frames of the recordings (up to 48 in all, shared by length, at least 6 each), each with its recording and second
async function frames(recs, dir) {
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  const total = recs.reduce((a, r) => a + r.dur, 0) || 1, out = [];
  for (const [n, r] of recs.entries()) {
    const want = Math.max(6, Math.round((48 * r.dur) / total)), every = Math.max(1, r.dur / want);
    for (let t = 0, i = 0; t < r.dur - 0.2; t += every, i++) {
      const f = path.join(dir, `r${n}-${String(i).padStart(3, '0')}.jpg`);
      await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(r2(t)), '-i', r.path, '-frames:v', '1', '-vf', "scale='if(gt(iw,ih),384,-2)':'if(gt(iw,ih),-2,384)'", '-q:v', '5', f]).catch(() => {});
      if (fs.existsSync(f)) out.push({ rec: n, t: r2(t), file: f });
    }
  }
  return out;
}

// Claude's pick for every line: [{k, rec, from, to}] (a recording's number and its seconds), or null
async function askClaude(lines, words, recs, shots, brief, runQuery, model) {
  const say = lines.map((l, k) => `${k}. (${r2(words[l.from].start)}–${r2(words[l.to].end)} s of the voice, ${r2(words[l.to].end - words[l.from].start)} s) ${words.slice(l.from, l.to + 1).map((w) => w.text).join(' ')}`).join('\n');
  const list = recs.map((r, n) => `- Recording ${n + 1}: "${r.name}", ${r2(r.dur)} s${r.note ? `. The customer's note: ${r.note}` : ''}`).join('\n');
  const text = `A video with screen recordings. The voice (a voiceover, or a person talking on camera) was recorded on its own, so the screen
recordings must be cut to follow it: what is on screen at every moment must be what the voice is saying then.

The screen recordings (frames of each follow below, each after its recording number and second):
${list}
${brief ? `\nWhat the customer says about this video (follow it):\n${brief}\n` : ''}
For EVERY line of the voice, choose the recording and the stretch of it that shows what the line talks about (the click, the
typing, the page, the result it names). Rules:
- The customer's notes and words above come first: a recording meant for a part is used for that part.
- A walkthrough goes forward: within a recording keep the stretches mostly in order. A line may reuse an earlier stretch when the
  voice returns to it.
- Prefer stretches where the action happens; skip waiting, loading and idle mouse moves.
- A stretch is sped up or slowed down to fill its line (from ${MIN_SPEED}× to ${MAX_SPEED}×): choose stretches roughly as long as the line,
  at most ${MAX_SPEED} times longer.
- An intro or outro line with no matching action: the first or the last screen of the fitting recording (a short stretch).
- "focus": where on the screen the viewer must look during that line (the button, field, menu, link or result it names), as
  [x, y, w, h] in % of the recording's frame. The video zooms there (the viewer watches on a phone), so make it TIGHT: the
  element itself with a little room around it, usually 12–30% wide; a whole page or nothing in particular: null.

The voice's lines:
${say}

Answer with JSON only: [{"k": 0, "rec": 1, "from": 0.0, "to": 4.5, "focus": [62, 8, 24, 14]}, …], one entry per line; rec is
the recording's number, from / to its seconds.`;
  const blocks = [{ type: 'text', text }, ...shots.flatMap((x) => [{ type: 'text', text: `Recording ${x.rec + 1} at ${x.t.toFixed(1)} s:` }, { type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(x.file).toString('base64') } }])];
  const message = (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
  const res = await runQuery(message, model, { tools: [], maxTurns: 1, what: 'screen sync' });
  const m = String(res?.result || '').match(/\[[\s\S]*\]/); if (!m) return null;
  const got = JSON.parse(m[0]);
  return Array.isArray(got) ? got.filter((x) => Number.isInteger(x?.k) && Number.isFinite(+x.from) && Number.isFinite(+x.to)) : null;
}

// The second look, sharper: for every line, two large frames of the stretch it got (near its start, and later: a player or a
// dialog that pops up during the line is on the second only). Claude says whether the line is really about something on the
// screen there (else a designed graphic carries it: an intro, advice, a blank or loading frame, or "go to elevenlabs.io",
// better typed in a designed browser bar) and, when it is, the tight box of the exact element it names on each frame (the
// "Upload" button, not "Record" beside it). → [{k, show: 'screen' | 'graphic', start, focus, what}] or null
async function aim(lines, words, recs, picks, runQuery, model, dir) {
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  const items = [];
  for (const [k, l] of lines.entries()) {
    const s0 = Number.isInteger(words[l.from].src) ? words[l.from].src : l.from, s1 = Number.isInteger(words[l.to].src) ? words[l.to].src : l.to;
    const hit = picks.segs.find((x) => x.s0 <= s1 && x.s1 >= s0), r = hit && recs.find((x) => x.rel === hit.rec); if (!hit || !r) continue;
    const shot = async (at, tag) => { const f = path.join(dir, `k${k}${tag}.jpg`); await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(r2(hit.a + (hit.b - hit.a) * at)), '-i', r.path, '-frames:v', '1', '-vf', "scale='min(1280,iw)':-2", '-q:v', '4', f]).catch(() => {}); return fs.existsSync(f) ? f : null; };
    const a = await shot(AIM_AT[0], 'a'), b = await shot(AIM_AT[1], 'b');
    if (a && b) items.push({ k, a, b, said: words.slice(l.from, l.to + 1).map((w) => w.text).join(' ') });
  }
  if (!items.length) return null;
  const text = `A video with its own voice and screen recordings. For each line below you get two frames of the screen recording
chosen for it: A near the start of the line, B later in it (the screen can change between them: a player or a dialog pops up,
a page loads, a menu opens). The video zooms on a phone to what you mark, so the viewer must never be shown an empty or dark
part of the screen. Decide, per line:
- "show": "screen" only when the line talks about something the viewer must SEE on these frames (a button, field, menu, tab,
  page or result named in the line, and it is visible). "graphic" when the line is an intro, an opinion, advice, a warning or
  an outro; when both frames are blank, loading or do not show what is said; or when the line only says to go to a website or
  app (a designed browser bar typing the address carries that better).
- "start" (only for "screen"): on frame A, the TIGHT box [x, y, w, h] in % of the frame around what the viewer should look at
  first (the element the line names, or what is clicked to get there). null when frame A shows nothing useful yet.
- "focus" (only for "screen"): the same on frame B (often the same element; the result when it has appeared there). With a
  little room (usually 10–35% wide). When two similar things sit side by side (Record and Upload, Sign up and Log in), box the
  one the line names. Not a whole page. Never a box around an empty or dark area.
- "what": a few words for the editor, e.g. "the Upload audio button", "type play.cartesia.ai in a browser bar", "advice: clone
  only your own voice".
Answer JSON only: [{"k": 0, "show": "screen", "start": [62, 88, 12, 8], "focus": [40, 62, 22, 12], "what": "…"}, …], one per
line below.`;
  const img = (f) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(f).toString('base64') } });
  const blocks = [{ type: 'text', text }, ...items.flatMap((x) => [{ type: 'text', text: `Line ${x.k}: "${x.said}" · frame A:` }, img(x.a), { type: 'text', text: `Line ${x.k} · frame B:` }, img(x.b)])];
  const message = (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
  const res = await runQuery(message, model, { tools: [], maxTurns: 1, what: 'screen aim' });
  const m = String(res?.result || '').match(/\[[\s\S]*\]/); if (!m) return null;
  const got = JSON.parse(m[0]);
  return Array.isArray(got) ? got.filter((x) => Number.isInteger(x?.k)) : null;
}

// The project's screen recordings in order, with their notes: [{rel, path, name, note}]
export const screensOf = (d, p) => (p.assets || []).filter((a) => a.role === 'screen').map((a) => ({ rel: `assets/${a.file}`, path: path.join(d.ws, 'assets', a.file), name: a.original || a.file, note: String(a.note || '').trim() })).filter((r) => fs.existsSync(r.path));
// does this video's picture come from fitting its screen recordings to a voice of its own?
export const fitsScreens = (p) => screenLed(p) && ['voice', 'ai', 'video'].includes(voiceSource(p));

// what the kept picks were made for (the recordings, their notes, the brief, the lines): another = ask again
const LINES_V = 4; // 3: the second, sharper look (screen or graphic per line, the exact element); 4: two frames per line
function sigOf(d, p, recs, lines, words) {
  const src = (i) => (Number.isInteger(words[i].src) ? words[i].src : i);
  return createHash('md5').update(JSON.stringify([LINES_V, recs.map((r) => [r.rel, fs.statSync(r.path).size, r.note]), String(p.instructions || '').trim(), lines.map((l) => [src(l.from), src(l.to)])])).digest('hex');
}
// are the kept picks out of date (or missing)? (the storyboard then asks Claude again)
export function syncStale(d, p) {
  const J0 = path.join(d.ws, 'job'), recs = screensOf(d, p).filter((r) => fs.existsSync(r.path)), raw = J(path.join(J0, 'cut', 'transcript.json'), []);
  const words = (Array.isArray(raw) ? raw : raw.words || []).filter((w) => Number.isFinite(w.start) && Number.isFinite(w.end));
  if (!recs.length || !words.length) return false;
  return J(path.join(J0, 'work', 'screen-sync.json'))?.sig !== sigOf(d, p, recs, linesOf(words), words);
}
// opts: { runQuery, model, step } (without runQuery: the kept picks if they still fit, else the even spread)
export async function syncScreen(d, p, opts = {}) {
  const J0 = path.join(d.ws, 'job'), cutFile = path.join(J0, 'cut', 'cut.mp4'), recs0 = screensOf(d, p);
  const raw = J(path.join(J0, 'cut', 'transcript.json'), []), words = (Array.isArray(raw) ? raw : raw.words || []).filter((w) => Number.isFinite(w.start) && Number.isFinite(w.end));
  if (!fs.existsSync(cutFile) || !recs0.length || !words.length) return { ok: false, why: 'nothing to sync' };
  const cut = await probe(cutFile), D = cut.duration;
  const recs = []; for (const r of recs0) { const i = await probe(r.path).catch(() => null); if (i?.duration) recs.push({ ...r, dur: i.duration, w: i.width, h: i.height }); }
  if (!recs.length) return { ok: false, why: 'no readable recording' };
  const lines = linesOf(words), srcOf = (i) => (Number.isInteger(words[i].src) ? words[i].src : i), brief = String(p.instructions || '').trim();
  // the picks, by the words' own numbers: made by Claude, kept while the recordings, their notes, the brief and the voice stay
  const keep = path.join(J0, 'work', 'screen-sync.json'), sig = sigOf(d, p, recs, lines, words);
  let picks = J(keep);
  if (!picks || picks.sig !== sig) {
    picks = null;
    if (opts.runQuery) {
      opts.step?.('Matching your screen recordings to your voice');
      try {
        const shots = await frames(recs, path.join(J0, 'work', 'screen-frames'));
        const got = shots.length ? await askClaude(lines, words, recs, shots, brief, opts.runQuery, opts.model) : null;
        if (got?.length) picks = { sig, by: 'claude', segs: got.filter((x) => lines[x.k]).map((x) => {
          const n = Math.max(0, Math.min(recs.length - 1, (Math.round(+x.rec) || 1) - 1)), dur = recs[n].dur;
          const a = Math.max(0, Math.min(dur - 0.3, +x.from)), b = Math.max(a + 0.3, Math.min(dur, +x.to));
          const f = Array.isArray(x.focus) && x.focus.length === 4 && x.focus.every((v) => Number.isFinite(+v)) ? x.focus.map((v) => Math.max(0, Math.min(100, +v))) : null;
          return { s0: srcOf(lines[x.k].from), s1: srcOf(lines[x.k].to), rec: recs[n].rel, a: r2(a), b: r2(b), ...(f && f[2] >= 3 && f[3] >= 3 ? { focus: f } : {}) };
        }) };
      } catch (e) { console.error('[screen sync] claude:', String(e.message).slice(0, 160)); }
      // the sharper second look: screen or graphic per line, and the exact element to zoom to
      if (picks) {
        try {
          const aimed = await aim(lines, words, recs, picks, opts.runQuery, opts.model, path.join(J0, 'work', 'screen-aim'));
          for (const x of aimed || []) {
            const l = lines[x.k]; if (!l) continue;
            const s0 = srcOf(l.from), s1 = srcOf(l.to), seg = picks.segs.find((y) => y.s0 <= s1 && y.s1 >= s0); if (!seg) continue;
            seg.show = x.show === 'graphic' ? 'graphic' : 'screen'; seg.what = String(x.what || '').slice(0, 120);
            const box = (v) => { const f = Array.isArray(v) && v.length === 4 && v.every((n) => Number.isFinite(+n)) ? v.map((n) => Math.max(0, Math.min(100, +n))) : null; return seg.show === 'screen' && f && f[2] >= 3 && f[3] >= 3 ? f : null; };
            const f0 = box(x.start), f = box(x.focus) || f0;
            if (f) seg.focus = f; else delete seg.focus;
            if (f0 && f0.join() !== f.join()) seg.focus0 = f0; else delete seg.focus0;
          }
          picks.aimed = !!aimed;
        } catch (e) { console.error('[screen sync] aim:', String(e.message).slice(0, 160)); }
      }
    }
    if (picks) fs.writeFileSync(keep, JSON.stringify(picks, null, 1));
  }
  // the even spread (no picks): the recordings one after another, laid evenly over the voice
  const total = recs.reduce((a, r) => a + r.dur, 0);
  const evenAt = (x) => { let t = x * total; for (let n = 0; n < recs.length; n++) { if (t <= recs[n].dur || n === recs.length - 1) return [n, Math.min(t, recs[n].dur)]; t -= recs[n].dur; } return [0, 0]; };
  // today's lines on the cut's timeline, each with its recording and stretch (a kept pick that shares its words, else the even share)
  const segs = lines.map((l, k) => {
    const t0 = k === 0 ? 0 : words[l.from].start, t1 = k === lines.length - 1 ? D : words[lines[k + 1].from].start, T = t1 - t0;
    if (T <= 0.05) return null;
    const s0 = srcOf(l.from), s1 = srcOf(l.to), hit = (picks?.segs || []).find((x) => x.s0 <= s1 && x.s1 >= s0);
    let n, a, b;
    const hn = hit ? recs.findIndex((r) => r.rel === hit.rec) : -1;
    if (hit && hn >= 0) { n = hn; a = hit.a; b = Math.min(hit.b, recs[n].dur); }
    else { const [n0, x0] = evenAt(t0 / D), [n1, x1] = evenAt(t1 / D); n = n0; a = x0; b = n1 === n0 ? x1 : recs[n0].dur; if (b - a < 0.3) { a = Math.max(0, b - 0.3); } }
    if ((b - a) / T > MAX_SPEED) a = b - T * MAX_SPEED; // too long: its end (the result) is kept
    return { t0: r2(t0), T: r2(T), rec: n, a: r2(a), b: r2(b), speed: r2(Math.max(MIN_SPEED, (b - a) / T)), by: hit && hn >= 0 ? picks.by : 'even', ...(hit?.focus ? { focus: hit.focus } : {}), ...(hit?.focus0 ? { focus0: hit.focus0 } : {}), show: hit?.show || 'screen', what: hit?.what || '', from: l.from, to: l.to };
  }).filter(Boolean);
  if (!segs.length) return { ok: false, why: 'no lines' };
  // the picture: every stretch at its speed (held on its last frame when short), back to back, in the cut's size; the cut's sound.
  // A talking head keeps its camera cut: the screen is a video of its own (cut/screen.mp4, the recording's size) for its scenes
  const beside = voiceSource(p) === 'video', even = (x) => x - (x % 2);
  const W = beside ? even(recs[0].w) : cut.width || recs[0].w, H = beside ? even(recs[0].h) : cut.height || recs[0].h, fit = `scale=${W}:${H}:force_original_aspect_ratio=decrease,pad=${W}:${H}:(ow-iw)/2:(oh-ih)/2:color=black,setsar=1`;
  const used = [...new Set(segs.map((s) => s.rec))], inputOf = (n) => used.indexOf(n), per = {};
  segs.forEach((s) => { per[s.rec] = (per[s.rec] || 0) + 1; });
  const splits = used.map((n) => `[${inputOf(n)}:v]split=${per[n]}${segs.map((s, k) => (s.rec === n ? `[i${k}]` : '')).join('')}`);
  const chains = segs.map((s, k) => `[i${k}]trim=start=${s.a}:end=${s.b},setpts=(PTS-STARTPTS)/${s.speed},fps=30,${fit},tpad=stop_mode=clone:stop_duration=${s.T},trim=duration=${s.T},setpts=PTS-STARTPTS[v${k}]`);
  const graph = `${splits.join(';')};${chains.join(';')};${segs.map((_, k) => `[v${k}]`).join('')}concat=n=${segs.length}:v=1:a=0,format=yuv420p[v]`;
  const pic = path.join(J0, 'cut', 'screen-sync.mp4'), out = path.join(J0, 'cut', 'cut.synced.mp4');
  await run('ffmpeg', ['-v', 'error', '-y', ...used.flatMap((n) => ['-i', recs[n].path]), '-filter_complex', graph, '-map', '[v]', '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '18', pic], { timeout: 20 * 60000, maxBuffer: 1 << 24 });
  if (beside) fs.renameSync(pic, path.join(J0, 'cut', 'screen.mp4'));
  else {
    await run('ffmpeg', ['-v', 'error', '-y', '-i', pic, '-i', cutFile, '-map', '0:v', '-map', '1:a', '-c', 'copy', '-shortest', '-movflags', '+faststart', out], { timeout: 10 * 60000 });
    fs.renameSync(out, cutFile); fs.rmSync(pic, { force: true });
  }
  fs.writeFileSync(path.join(J0, 'work', 'screen-sync.applied.json'), JSON.stringify(segs.map((s) => ({ ...s, rec: recs[s.rec].name })), null, 1)); // what each line shows (for a check)
  // where to look during each line, on the cut's frame (a recording of another shape sits centred in it): the zooms
  // (two looks in a line when the aim saw something else first: the first until the time between its two frames)
  const focus = segs.filter((s) => s.focus && s.show !== 'graphic').flatMap((s) => {
    const r = recs[s.rec], k = Math.min(W / r.w, H / r.h), ox = (W - r.w * k) / 2, oy = (H - r.h * k) / 2;
    const onCut = (f) => [r2(((ox + (f[0] / 100) * r.w * k) / W) * 100), r2(((oy + (f[1] / 100) * r.h * k) / H) * 100), r2(((f[2] / 100) * r.w * k / W) * 100), r2(((f[3] / 100) * r.h * k / H) * 100)];
    const from = r2(s.t0 + 0.15), to = r2(s.t0 + s.T - 0.1), mid = r2(s.t0 + s.T * (AIM_AT[0] + AIM_AT[1]) / 2);
    if (s.focus0 && mid - from > 0.6 && to - mid > 0.6) return [{ from, to: mid, focus: onCut(s.focus0), action: 'look' }, { from: mid, to, focus: onCut(s.focus), action: 'look' }];
    return [{ from, to, focus: onCut(s.focus), action: 'look' }];
  });
  fs.writeFileSync(path.join(J0, 'work', 'screen-focus.json'), JSON.stringify(focus, null, 1));
  // for the director: every line, its word numbers, what it says, and whether the screen or a designed graphic should carry it
  fs.writeFileSync(path.join(J0, 'work', 'screen-lines.json'), JSON.stringify(segs.map((s) => ({ from: s.from, to: s.to, t0: s.t0, T: s.T, show: s.show, what: s.what, says: words.slice(s.from, s.to + 1).map((w) => w.text).join(' ') })), null, 1));
  return { ok: true, lines: segs.length, by: picks?.by || 'even' };
}
