// The check of every finished video, on its real frames, before the customer sees it. For each scene that shows a screen
// recording: a few moments (near its start, the middle, near its end), each looked at twice. Code measures whether the window
// is empty (a black or blank area: nothing to see); Claude's eyes see what the viewer sees on the phone next to the whole
// screen at that moment, with the words said then, and say whether it shows the thing talked about, readable. A moment that
// fails gets a new zoom (the box Claude marks on the whole screen; without Claude, where the screen is busy), and the video is
// rendered once more. The other scenes: a frame that is empty all over is reported. → { ok, fixed, issues: [{at, problem}] }
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { zen } from './director.mjs';

const run = promisify(execFile);
const r2 = (x) => Math.round(x * 100) / 100;
const J = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const MAX_LOOKS = 24; // moments sent to Claude in one look (two pictures each)

// the page's data: the scenes (times, the screen window) and the zoom events, read from the composed index.html
function pageData(html) {
  const arr = (key) => { const i = html.indexOf(`"${key}":[`); if (i < 0) return []; let d = 0, j = i + key.length + 3; for (; j < html.length; j++) { if (html[j] === '[') d++; else if (html[j] === ']' && --d === 0) break; } try { return JSON.parse(html.slice(i + key.length + 3, j + 1)); } catch { return []; } };
  return { scenes: arr('scenes'), events: arr('events') };
}

// a frame as small grey pixels: how much is drawn on it (edges) and how even it is (sd)
async function gray(file, t, crop, w = 120, h = 120) {
  const { stdout } = await run('ffmpeg', ['-v', 'error', '-ss', String(r2(t)), '-i', file, '-frames:v', '1', '-vf', `${crop ? `crop=${crop.w}:${crop.h}:${crop.x}:${crop.y},` : ''}scale=${w}:${h},format=gray`, '-f', 'rawvideo', '-'], { encoding: 'buffer', maxBuffer: 1 << 24 });
  return { px: stdout, w, h };
}
const edgeAt = (g, x, y) => { const v = g.px[y * g.w + x]; return Math.abs(v - g.px[y * g.w + x + 1]) > 18 || Math.abs(v - g.px[(y + 1) * g.w + x]) > 18; };
function stats(g) {
  let e = 0, n = 0, s = 0, q = 0;
  for (let y = 0; y < g.h - 1; y++) for (let x = 0; x < g.w - 1; x++) { const v = g.px[y * g.w + x]; s += v; q += v * v; n++; if (edgeAt(g, x, y)) e++; }
  const m = s / n; return { busy: e / n, sd: Math.sqrt(Math.max(0, q / n - m * m)) };
}
// measured on real renders: a black window is ~0.02 / sd 4, a dark app with small text is 0.06+ / sd 13+
const blank = (st) => st.busy < 0.03 && st.sd < 8;
// where the whole screen is busy (its drawn part), as [x, y, w, h] in % — the zoom when nothing better is known
function busyBox(g) {
  const cols = new Array(g.w).fill(0), rows = new Array(g.h).fill(0);
  for (let y = 0; y < g.h - 1; y++) for (let x = 0; x < g.w - 1; x++) if (edgeAt(g, x, y)) { cols[x]++; rows[y]++; }
  const span = (a, min) => { const i = a.findIndex((v) => v >= min), j = a.length - 1 - [...a].reverse().findIndex((v) => v >= min); return i < 0 ? null : [i, j]; };
  const c = span(cols, 3), r = span(rows, 3); if (!c || !r) return null;
  return [r2((c[0] / g.w) * 100), r2((r[0] / g.h) * 100), r2(((c[1] - c[0] + 1) / g.w) * 100), r2(((r[1] - r[0] + 1) / g.h) * 100)];
}

// Claude's look: per moment, what the viewer sees and the whole screen → [{k, ok, problem, box}]
async function look(moments, runQuery, model) {
  const img = (f) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(f).toString('base64') } });
  const text = `You check a finished video before the customer sees it. It shows a screen recording zoomed inside a window on a phone.
For each moment below you get: picture 1, what the viewer sees in that window; picture 2, the whole screen at that moment; and
the words said then. A moment is ok only when picture 1 clearly shows what the words talk about (the button, field, menu, page
or result they name, or what is happening), readable on a phone. Not ok: an empty, black or dark part of the screen; the wrong
element (the words say Upload, picture 1 shows Record); too small to read; cut off so the named thing is not visible.
For a moment that is not ok, "box": the TIGHT box [x, y, w, h] in % of picture 2 around what should be shown then (the named
element with a little room, usually 12–35% wide), or null when the whole screen has nothing that fits the words.
Answer JSON only: [{"k": 0, "ok": true}, {"k": 1, "ok": false, "problem": "a few words", "box": [62, 80, 20, 10]}, …], one per moment.`;
  const blocks = [{ type: 'text', text }, ...moments.flatMap((m) => [{ type: 'text', text: `Moment ${m.k} (${m.t.toFixed(1)} s)${m.what ? `, the plan: ${m.what}` : ''}. Words: "${m.says}"` }, img(m.seen), img(m.whole)])];
  const message = (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
  const res = await runQuery(message, model, { tools: [], maxTurns: 1, what: 'video check' });
  const m = String(res?.result || '').match(/\[[\s\S]*\]/); if (!m) return null;
  const got = JSON.parse(m[0]);
  return Array.isArray(got) ? got.filter((x) => Number.isInteger(x?.k)) : null;
}

// the zoom events with [a, b] given to one new look (the old ones there trimmed away; a bit under 0.5 s left is dropped)
function replace(events, a, b, focus) {
  const out = [];
  for (const e of events) {
    if (e.to <= a || e.from >= b) { out.push(e); continue; }
    if (e.from < a && a - e.from >= 0.5) out.push({ ...e, to: r2(a) });
    if (e.to > b && e.to - b >= 0.5) out.push({ ...e, from: r2(b) });
  }
  out.push({ from: r2(a), to: r2(b), focus, action: 'look' });
  return out.sort((x, y) => x.from - y.from);
}

// opts: { n (the version), file (the rendered mp4), runQuery, model, step }
export async function checkVideo(d, p, opts) {
  const J0 = path.join(d.ws, 'job'), hf = path.join(J0, 'edit', 'hf'), planFile = path.join(J0, 'edit', 'plan.json');
  const html = fs.existsSync(path.join(hf, 'index.html')) ? fs.readFileSync(path.join(hf, 'index.html'), 'utf8') : '';
  const { scenes } = pageData(html), screen = path.join(hf, 'assets', 'media', 'aroll.mp4');
  if (!scenes.length || !fs.existsSync(opts.file)) return { ok: true, fixed: 0, issues: [] };
  const lines = J(path.join(J0, 'work', 'screen-lines.json'), []) || [];
  const words = (() => { const t = J(path.join(J0, 'cut', 'transcript.json'), []); return Array.isArray(t) ? t : t?.words || []; })();
  const saidAt = (a, b) => words.filter((w) => w.end > a && w.start < b).map((w) => w.text).join(' ');
  const lineAt = (t) => lines.find((l) => t >= l.t0 && t < l.t0 + l.T);
  opts.step?.('Checking every scene of the finished video');
  const issues = [], moments = [];
  // the moments: in each screen scene near its start, the middle, near its end; each covers its share of the scene
  for (const sc of scenes) {
    if (!sc.scr || !(sc.e > sc.s)) {
      if (sc.e - sc.s > 1) { try { const st = stats(await gray(opts.file, (sc.s + sc.e) / 2, null, 108, 192)); if (st.busy < 0.004 && st.sd < 4) issues.push({ at: r2((sc.s + sc.e) / 2), problem: 'the frame is empty' }); } catch {} }
      continue;
    }
    const r = sc.scr.rect, ch = sc.scr.chrome || 0, crop = { x: r.x, y: r.y + ch, w: r.w, h: r.h - ch };
    const ts = [sc.s + 0.7, (sc.s + sc.e) / 2, sc.e - 0.35].filter((t) => t > sc.s + 0.3 && t < sc.e - 0.15).filter((t, i, a) => i === 0 || t - a[i - 1] >= 0.8);
    ts.forEach((t, i) => moments.push({ sc, t, crop, a: i === 0 ? sc.s + 0.15 : (ts[i - 1] + t) / 2, b: i === ts.length - 1 ? sc.e - 0.1 : (t + ts[i + 1]) / 2 }));
  }
  for (const m of moments) { try { m.st = stats(await gray(opts.file, m.t, m.crop)); } catch { m.st = null; } }
  // Claude's eyes on the screen moments (the blank ones first when there are too many)
  const dir = path.join(J0, 'work', 'check'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  let verdict = null;
  const sent = [...moments].sort((x, y) => (blank(y.st || { busy: 1, sd: 99 }) ? 1 : 0) - (blank(x.st || { busy: 1, sd: 99 }) ? 1 : 0)).slice(0, MAX_LOOKS);
  if (opts.runQuery && sent.length && fs.existsSync(screen)) {
    try {
      for (const [k, m] of sent.entries()) {
        m.k = k; m.seen = path.join(dir, `m${k}-seen.jpg`); m.whole = path.join(dir, `m${k}-whole.jpg`);
        const l = lineAt(m.t); m.says = (l ? saidAt(l.t0, l.t0 + l.T) : saidAt(m.t - 1.5, m.t + 1.5)).slice(0, 300); m.what = l?.what || '';
        await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(r2(m.t)), '-i', opts.file, '-frames:v', '1', '-vf', `crop=${m.crop.w}:${m.crop.h}:${m.crop.x}:${m.crop.y},scale=420:-2`, '-q:v', '4', m.seen]);
        await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(r2(m.t)), '-i', screen, '-frames:v', '1', '-vf', "scale='min(1100,iw)':-2", '-q:v', '4', m.whole]);
      }
      verdict = await look(sent, opts.runQuery, opts.model);
    } catch (e) { console.error('[video check] look:', String(e.message).slice(0, 160)); }
  }
  // what fails: Claude's "not ok", and every blank moment code measured
  const box = (v) => (Array.isArray(v) && v.length === 4 && v.every((x) => Number.isFinite(+x)) && +v[2] >= 3 && +v[3] >= 3 ? v.map((x) => r2(Math.max(0, Math.min(100, +x)))) : null);
  const bad = [];
  for (const m of moments) {
    const v = verdict && Number.isInteger(m.k) ? verdict.find((x) => x.k === m.k) : null;
    if (v && v.ok === false) bad.push({ m, problem: String(v.problem || 'does not show what is said').slice(0, 120), box: box(v.box) });
    else if (m.st && blank(m.st)) bad.push({ m, problem: 'an empty part of the screen', box: null });
  }
  if (!bad.length) return { ok: !issues.length, fixed: 0, issues, looked: !!verdict };
  // the fix: a new zoom for each failing moment (Claude's box; else where the screen is busy then), and one more render
  const plan = J(planFile);
  if (!plan || !fs.existsSync(screen)) return { ok: false, fixed: 0, issues: [...issues, ...bad.map((b) => ({ at: r2(b.m.t), problem: b.problem }))] };
  let events = (plan.screenEvents || []).filter((e) => Array.isArray(e.focus) && e.to > e.from), fixed = 0;
  for (const b of bad) {
    let f = b.box;
    if (!f) { try { f = busyBox(await gray(screen, b.m.t, null, 160, 96)); } catch { f = null; } }
    if (!f) { issues.push({ at: r2(b.m.t), problem: b.problem }); continue; }
    events = replace(events, b.m.a, b.m.b, f); fixed++;
  }
  if (!fixed) return { ok: false, fixed: 0, issues, looked: !!verdict };
  plan.screenEvents = events; fs.writeFileSync(planFile, JSON.stringify(plan, null, 1));
  opts.step?.(`Fixing ${fixed} moment${fixed > 1 ? 's' : ''} on the screen and rendering again`);
  const r = await zen(d.ws, ['finish', `v${opts.n}`]); if (!r.ok) { console.error('[video check] render:', r.error); return { ok: false, fixed: 0, issues: [...issues, { at: null, problem: 'the fixed render failed' }] }; }
  // the fixed moments measured again (code only): one still blank is reported
  for (const b of bad) { try { if (blank(stats(await gray(opts.file, b.m.t, b.m.crop)))) issues.push({ at: r2(b.m.t), problem: 'still an empty part of the screen' }); } catch {} }
  return { ok: !issues.length, fixed, issues, looked: !!verdict };
}
