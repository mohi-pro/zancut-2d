// The editor: how Step 3 and every change are made, the way an editor works in a chat. Two kinds of conversation, each with the
// part of the design system's skill that is its job (director.mjs directorSystem / builderSystem), so each reads only what it uses.
//   lead     the director: reads this video (setup, the Brief, the customer's cut, notes and files, a sheet of frames from the
//            footage) and plans the storyboard (save_storyboard). Its session is kept on the project (p.editor.lead): every
//            change resumes it, so it remembers the whole video like a chat does.
//   crew     designers, 4 at a time (ZANCUT_CREW), each a fresh session: the building skill + this video in short (director.mjs
//            videoHandoff: setup, orders, facts, memory card, every scene in one line) as its system prompt (the same for every
//            designer, so it is cached), its scenes in full as the message. A designer builds a run of joined scenes in order
//            (ZANCUT_RUN_MAX, 10), so it knows how the scene before really ends; ZANCUT_DESIGNERS=scene: one scene each. (ZANCUT_BUILDERS=fork:
//            the old way, a fork of the lead's session.) It works in a loop: save_scene → the real frames come back with what code
//            measured (and the joins) → one edit_scene with every fix → the frames again … until the scene passes skills/check.md
//            (ZANCUT_LOOKS rounds of frames). The icons a row names are looked up before it starts. A scene the lead marked
//            "reuse" starts from that scene's file.
//   review   a short fresh conversation (the designers' system prompt, so it is cached; ZANCUT_REVIEW=lead: the old way, a resume
//            of the lead's chat) looks at one frame of every scene and at every join between two graphic scenes (look_video, with
//            each join measured in pixels by server/joins.mjs) and sends the ones that break the video's look or jump at a join
//            back to the crew (a fix comes with the real frames of the neighbours).
//   steps    a scene's designer has SCENE_STEPS steps (save / edit / look) in all, over every retry and Retry after a stop.
// The tools are ours only: no terminal, no files outside this video. Code checks every call and builds the page.
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import { execFile } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { createSdkMcpServer, tool } from './no-ai.mjs';
import * as library from './library.mjs';
import { z } from 'zod';
import { ENGINE_DIR, PYTHON, SKILLS_DIR } from './config.mjs';
import { anchorTimes } from './transcribe.mjs';
import { directorSystem, builderSystem, videoHandoff, leadPrompt, builtPrompt, batchTask, graphicBudget, videoSecs, voicePace, changePrompt, replanPrompt, parseStoryboard, tidyStoryboard, parseRow, buildPlan, sceneContexts, writeGraphic, placeGraphic, firstCutWords, jobDir, zen, ordersText, mineName } from './director.mjs';
import { sceneSheets } from './board.mjs';
import { pricing } from './pricing.mjs';
import { joinScore, joinLine } from './joins.mjs';
import { saveKit, kitTask, kitBlock, writeCast, needsKit, kitFile } from './filmkit.mjs';
import { writeFilmParts, findPartsText, skippedParts, skippedText } from './parts.mjs';
import { clipLogs, missingSteps, stepTrouble, unattached, clipOf } from './clipsync.mjs';
import * as stock from './stock.mjs';

const J = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const run = (cmd, args) => new Promise((ok, no) => execFile(cmd, args, { timeout: 180000, maxBuffer: 1 << 24 }, (e, so, se) => (e ? no(new Error(String(se || e.message).slice(-300))) : ok(so))));
const r2 = (n) => Math.round(n * 100) / 100;
const CREW = (count = 0) => {
  if (process.env.ZANCUT_CREW) return Math.max(1, Number(process.env.ZANCUT_CREW));
  if (count >= 25) return 8;
  if (count >= 17) return 6;
  return 4;
};
const BATCH = () => Math.max(1, Number(process.env.ZANCUT_BATCH || 4)); // fork builders: scenes one builder makes in one session
// fresh (default): every builder a new session with the video in short; fork: a copy of the lead's whole session (8× the tokens)
const FRESH = () => process.env.ZANCUT_BUILDERS !== 'fork';
// one designer builds a run of joined scenes in order, in one conversation (like one editor in a chat): it knows how the scene
// before really ends, so the joins are right and its understanding of the video is reused. ZANCUT_DESIGNERS=scene: one scene each.
const RUNS = () => process.env.ZANCUT_DESIGNERS !== 'scene';
// one designer carries up to 10 scenes (it reads the skill once and knows the whole run); more than 10: another designer
const RUN_MAX = () => Math.max(1, Number(process.env.ZANCUT_RUN_MAX || 10));
// each designer's run is reviewed the moment it is built, and the notes go back into that designer's own conversation (still
// in the cache, it knows the scenes); the joins between two designers' runs are checked once all are built. ZANCUT_RUN_REVIEW=0:
// the old way (one review of the whole video at the end, its fixes built by a new designer).
const RUN_REVIEW = () => process.env.ZANCUT_RUN_REVIEW !== '0';
// 2D: after round 2 the reviewer looks once more at the fixed scenes only; a note that did not land goes back once (ZANCUT_RECHECK=0: off)
const RECHECK = () => process.env.ZANCUT_RECHECK !== '0';
// test switch: the final review works on a copy of the lead's conversation (side-by-side runs of one plan stay independent)
const REVIEW_FORK = () => process.env.ZANCUT_REVIEW_FORK === '1';
// rounds of frames per scene: as many as it needs (it stops the moment it passes); the step cap (SCENE_STEPS) is the runaway guard
const LOOKS = () => Math.max(1, Number(process.env.ZANCUT_LOOKS || SCENE_STEPS()));
// the final review: fresh (default) = a short new conversation (the same system prompt as the builders, so it is cached, and the
// video in short); lead = the old way, a resume of the lead's whole planning conversation
const REVIEW = () => (process.env.ZANCUT_REVIEW === 'lead' || REVIEW_FORK() ? 'lead' : 'fresh');
// a scene's builder steps (every save, edit and look) in all, over every retry and every Retry after a stop; a fix or a change the
// customer asks for starts its own count. Kept on the project, so a stop and resume does not give a scene a fresh allowance.
export const SCENE_STEPS = () => Math.max(4, Number(process.env.ZANCUT_SCENE_STEPS || 14));
const stepsOf = (E) => (E.p.editor ? (E.p.editor.steps ||= {}) : (E.steps ||= {}));
// a 2D scene builds from the film's kit and has the gate's lines before any picture: 6 steps, then the review judges it. Every step
// rebuilds the scene and answers with pictures, so the steps of one scene are where a film's cost goes
// a 2D scene: each round is fast (save, one look, one fix): round 1 builds, the review is read once, round 2 fixes once
const capOf = (E) => (E.p?.kind === 'animation' ? Math.max(2, Number(process.env.ZANCUT_SCENE_STEPS || 3)) : SCENE_STEPS());
export const stepsLeft = (E, i) => Math.max(0, capOf(E) - (stepsOf(E)[i] || 0));
export function spendStep(E, i) { if (!stepsLeft(E, i)) return false; stepsOf(E)[i] = (stepsOf(E)[i] || 0) + 1; return true; }
const NO_STEPS = 'This scene has used all its steps: it stays as it is. Answer with your one line.';
// a builder call's turns: its usual allowance, cut to what is left of the scene's steps (+1 for the answer line)
export const turnsFor = (E, idx) => (E.p?.kind === 'animation'
  // a 2D builder: its scenes' steps (save / edit / look, capped per scene by the tools) + room for its library searches and icons
  // and one answer per scene, so a search never uses up a scene's turn (the step cap, not the turn cap, keeps it fast)
  ? idx.reduce((a, i) => a + stepsLeft(E, i), 0) + idx.length + 4
  : Math.max(2, Math.min(8 * idx.length + 2, idx.reduce((a, i) => a + stepsLeft(E, i), 0) + 1)));
// a fix or a change is new work with its own steps; the first build and the carry-on of a stopped one (again) keep counting
export function startWork(E, list) { for (const x of list) if (x.note && !x.again) stepsOf(E)[x.i] = 0; }
// the system prompt of a builder (and of the fresh reviewer, so the cache is shared): the building skill + this video in short
const crewSystem = (E, extra = E.extra) => `${builderSystem(E.p)}\n\n${videoHandoff(E.p, E.sb, extra || {})}`;
// builders: Opus by default; Token Saver mode or ZANCUT_BUILDER_MODEL uses Sonnet. A 2D film's builders are always Opus: one
// conversation builds every scene (the cartoon from the library, its motion graphics and B-roll designed)
const MODEL_FOR = (E) => BUILDER_MODEL(E.p);
const BUILDER_MODEL = (p) => {
  if (p?.kind === 'animation') return process.env.ZANCUT_BUILDER_MODEL || pricing().models.plan || 'claude-opus-5-5';
  if (p?.tokenSaver) return pricing().models.short || 'claude-sonnet-5-5';
  return process.env.ZANCUT_BUILDER_MODEL || pricing().models.plan || 'claude-opus-5-5';
};
const LEAD_MODEL = () => process.env.ZANCUT_LEAD_MODEL || pricing().models.plan || 'claude-opus-5-5';
const THINK = {
  lead: (sceneCount = 0) => {
    if (process.env.ZANCUT_DIRECTOR_THINK) return Number(process.env.ZANCUT_DIRECTOR_THINK);
    return 16000; // as every video so far was planned (sceneCount kept for a later long-video setting)
  },
  scene: () => Number(process.env.ZANCUT_SCENE_THINK || 6000),
  fix: () => Number(process.env.ZANCUT_FIX_THINK || 3000), // a fix or a change: a targeted edit of a designed scene
  review: () => Number(process.env.ZANCUT_REVIEW_THINK || 6000),
};
const text = (t) => ({ content: [{ type: 'text', text: t }] });
const picture = (file, t) => ({ content: [{ type: 'image', data: fs.readFileSync(file).toString('base64'), mimeType: 'image/jpeg' }, { type: 'text', text: t }] });
// one user message with pictures (the SDK's streaming input)
const message = (blocks) => (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
const jpeg = (file) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(file).toString('base64') } });
// one at a time: building the page and drawing frames share the page folder; instruments lock wait and hold times
const serial = (name = 'E.lock') => {
  let last = Promise.resolve();
  return (fn, op = 'op') => {
    const queueStart = Date.now();
    const waitPromise = last.then(() => {}, () => {});
    last = (async () => {
      await waitPromise;
      const waitMs = Date.now() - queueStart;
      const holdStart = Date.now();
      try {
        return await fn();
      } finally {
        const holdMs = Date.now() - holdStart;
        if (waitMs > 1500 || holdMs > 1500) {
          console.log(`[${name}] ${op} queued ${waitMs}ms, held ${holdMs}ms`);
        }
      }
    })();
    return last;
  };
};

// ctx (from agent.mjs): { d, p, job, step(text), ask (stock picks), runQuery(prompt, model, extra), model }
export function editor(ctx) {
  const J0 = jobDir(ctx.d.ws);
  return { ...ctx, J0, hf: path.join(J0, 'edit', 'hf'), sb: J(path.join(J0, 'work', 'storyboard.json')), lead: ctx.p.editor?.lead || null, lock: serial('E.lock'), looks: {}, domIssues: new Map(), saved: new Set(), changed: new Map() };
}

// ---------- the desk: the tools every editor call has (the same list for all, so the cached prefix stays the same) ----------
// role: { lead: true } or { scenes: [row] }: what this call may change. (Exported for scripts/editor-dry.mjs.)
export function desk(E, role) {
  const mine = new Set(role.scenes || []);
  const sceneOf = (n) => { const i = Math.round(Number(n)) - 1; return mine.has(i) ? i : null; };
  const notMine = () => text(role.lead ? 'You are the lead: the scene builders build scenes. Use change_scenes for changes.' : `You build scene ${[...mine].map((i) => i + 1).join(', ')} only.`);
  const build = async (i, html) => {
    // a clip cut to this scene's words (its row's media.steps, clipsync.mjs) plays straight through: seeking it breaks the match
    if (E.sb?.rows?.[i]?.media?.steps?.length && /\.currentTime\s*=(?!=)|\.playbackRate\s*=(?!=)/.test(String(html))) return { r: text('Not saved: your clip is already cut to this scene\'s words (each step is on screen while it is said). Play it straight through as the engine gives it: never set currentTime or playbackRate on it.') };
    // the customer's own clip sits under the design until the code places it: a scene that never touches it covers it (a drawn
    // stand-in on top), and their recording is never seen
    if (E.sb?.rows?.[i]?.media?.mine && /\.(mp4|mov|m4v|webm)$/i.test(E.sb.rows[i].media.file || '') && !/gx-media|querySelector(All)?\(\s*["'`][^"'`]*\b(video|clip)\b/.test(String(html))) return { r: text('Not saved: the customer\'s own clip is in this scene (`.gx-media`, the first element of root, full frame) but your code never places it, so your design covers it and their real recording is never seen. Think about where it lives in your design (a device screen, a card, the whole ground…), move `.gx-media` there (size it, clip it to the frame\'s corners, or append it into your screen element) and design around what it really shows; never draw a copy of it.') };
    const w = writeGraphic(E.J0, `s${i + 1}-${Date.now().toString(36)}`, html);
    if (w.error) return { r: text(`Not saved: ${w.error}`) };
    // the outside icons and emoji it uses are fetched into the job first (each falls back to our own when a source is down)
    const notes = await library.prepareScene(E.J0, html).catch(() => []), extra = `${notes.length ? `\nNote: ${notes.join(' ')}` : ''}${w.fixed?.length ? `\nCode changed your file (edit the new text): ${w.fixed.join('; ')}.` : ''}${(E.p.kind === 'animation' && role.first ? '' : libNote(E, i, html))}`;
    return E.lock(async () => {
      placeGraphic(E.d, E.p, E.sb, i, w.rel, sceneContexts(E.d, E.p, E.sb)[i].secs);
      const c = await zen(E.d.ws, ['compose']);
      if (!c.ok) return { r: text(`Saved, but the page did not build: ${String(c.error).slice(-500)}${extra}`) };
      // its first save is a step of the job: a designer building a long run writes progress as it goes (the stuck-job watch
      // counts quiet minutes)
      if (!E.saved.has(i) && !role.lead) E.step?.(`Scene ${i + 1} saved by its designer`);
      E.saved.add(i);
      return { ok: true, extra };
    });
  };
  // a builder's save or edit answers with the scene's real frames (one step instead of a save and a look). Several edits of one
  // scene sent at once: only the last one brings the frames back. The lead only saves.
  const saved = async (i, b) => {
    if (!b.ok) return b.r;
    if (role.lead) return text(`Saved and built. Call look (scene ${i + 1}) to see it.${b.extra}`);
    if (pending(i)) return text(`Saved and built.${b.extra} More changes of this scene are coming: their frames come with the last one.`);
    const maxLooks = LOOKS() + (E.domIssues?.get(i) ? 1 : 0);
    if ((E.looks[i] = (E.looks[i] || 0) + 1) > maxLooks) return text(`Saved and built.${b.extra} No more looks for this scene: answer with your one line.`);
    // a 2D film's first build: a scene that passes the body gate and the code checks gets one line, no picture (the reviewer
    // looks at the whole film next); a measured fault still sends the frames with the faults
    const seen = await E.lock(() => lookScene(E, i, { textWhenClean: E.p.kind === 'animation' && !!role.first }));
    return { content: [{ type: 'text', text: `Saved and built.${b.extra}${seen.content.some((c) => c.type === 'image') ? ' Here it is:' : ''}` }, ...seen.content] };
  };
  // one scene's saves and edits run one after another (read, change, write), so two edits sent at once never undo each other
  E.sceneQ ||= {}; E.waiting ||= {};
  const pending = (i) => (E.waiting[i] || 0) > 0;
  const inOrder = (i, fn) => { E.waiting[i] = (E.waiting[i] || 0) + 1; const run = (E.sceneQ[i] || Promise.resolve()).then(() => { E.waiting[i]--; return fn(); }); E.sceneQ[i] = run.catch(() => {}); return run; };
  return createSdkMcpServer({ name: 'zancut', version: '1.0.0', tools: [
    tool('save_storyboard', 'Save the storyboard: the JSON object your task describes (video, memory, cut, rows). Code checks it, keeps it to the hard rules and answers with what it saved or what is wrong.', { json: z.string() }, async ({ json }) => {
      if (!role.lead) return notMine();
      const sb = parseStoryboard(json);
      if (!sb) return text('Not saved: that is not a storyboard. Send one JSON object with "rows" (and "video", "memory", "cut").');
      const n = firstCutWords(E.J0).length;
      if (role.range) return saveRange(E, role.range, sb, n);
      const t = tidyStoryboard(E.p, sb, n);
      if (!t) return text('Not saved: no row has whole word numbers in "from" and "to".');
      const noSteps = t.rows.map((r, k) => [k + 1, missingSteps(E.p, r)]).filter(([, f]) => f);
      if (noSteps.length) return text(`Not saved: ${noSteps.map(([n, f]) => `scene ${n} shows the screen recording ${f}`).join('; ')} without "steps". Give each "media": {"mine": …, "steps": [[word, second], …]} from its "what happens when" list (only the part that scene talks about), then save again.`);
      const loose = t.rows.map((r, k) => [k + 1, unattached(E.p, r)]).filter(([, f]) => f);
      if (loose.length) return text(`Not saved: ${loose.map(([n, f]) => `scene ${n} plans to show the customer's clip ${f}`).join('; ')}, but its row does not carry it in "media", so its designer gets no clip and could only draw a fake of it. Decide for each: if the scene shows it, give the row "media": {"mine": …} (with "steps" for a screen recording); if it should not, take it out of that scene's plan. Then save again.`);
      // a walkthrough goes forward and each step is on its own words (sent back once: a second plan that goes back on purpose,
      // the voice returning to an earlier step, is kept)
      const order = stepTrouble(E.p, t.rows);
      if (order.length && !E.stepOrder) { E.stepOrder = true; return text(`Not saved: ${order.join('; ')}. A walkthrough follows the clip forward: each spoken step shows its own moment, on its own words, in the clip's order. Go back only where the voice really returns to an earlier step; then save again.`); }
      // the graphic budget is a guide the director reads; code sends a plan back once only when it is far above it (1.5×: a
      // runaway, not a choice), and keeps the second answer as it is
      const g0 = t.rows.filter((r) => r.piece === 'custom').length, max = Math.ceil(1.5 * graphicBudget(E.p, videoSecs(firstCutWords(E.J0)), J(path.join(E.J0, 'work', 'screen-lines.json')), voicePace(firstCutWords(E.J0))?.rate));
      if (g0 > max && !E.overBudget) { E.overBudget = true; return text(`Not saved: ${g0} graphic scenes is far above what this video can carry (at most ${max}). Merge neighbouring graphics into longer scenes${E.p.kind === 'faceless' || E.p.mode === 'faceless' ? '' : ', turn the weaker ones into speaker rows with punch'}, or reuse an earlier design, then save again.`); }
      // a person on camera: where the person is seen, and every punch-in, is the director's call (the skill guides it). Code only
      // makes sure the person is on screen somewhere (sent back once).
      if (['talking', 'interview'].includes(E.p.kind)) {
        const SEEN = new Set(['popout-box-split', 'behind-head-depth', 'bg-replace-stage', 'over-torso-glass', 'lower-third-kinetic', 'masked-pip-stage']);
        const seen = t.rows.some((r) => r.piece === 'speaker' || r.piece === 'screen' || (r.piece === 'custom' && SEEN.has(r.thMode)));
        if (!seen && !E.overLong) { E.overLong = true; return text('Not saved: the person speaking is never on screen. Show them where their presence carries the words (a speaker row, or a layout that keeps them in the frame), then save again.'); }
      }
      E.sb = t;
      fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(t, null, 1));
      const g = t.rows.filter((r) => r.piece === 'custom').length;
      return text(`Saved: ${t.rows.length} scenes (${g} graphic) covering words 0–${n - 1}. Code kept only what the page needs (rows back to back, valid values, joins chained, the ground carried on through joined scenes); every choice is as you made it.`);
    }),
    tool('save_kit', 'Save the film kit: the JavaScript with every place of this film. Code builds it and answers with a board of real frames and what is wrong.', { code: z.string() }, async ({ code }) => {
      if (!role.kit) return text('Only the film kit\'s designer saves the kit.');
      E.kitCode = code; // edit_kit changes this text, so a fix is a small replacement, never the whole kit again
      const r = await E.lock(() => saveKit(E, code, ENGINE_DIR));
      // a 2D builder that draws the places first: once they pass, the other builders may start, and it is told how to use them
      if (r.ok) { E.kitDone?.(); if (role.scenes) r.text += `\n${kitBlock(E.sb)}\nNow build your scenes.`; }
      return r.file ? picture(r.file, r.text) : text(r.text);
    }),
    tool('edit_kit', 'Fix the film kit you saved with exact replacements: "edits" is a list of {find, replace} applied in order to your last save_kit code (each "find" must appear exactly once); every fix of one round in ONE call. Code builds it again and answers like save_kit.', { edits: z.array(z.object({ find: z.string(), replace: z.string() })) }, async ({ edits }) => {
      if (!role.kit) return text('Only the film kit\'s designer changes the kit.');
      if (!E.kitCode) return text('Nothing saved yet: use save_kit first.');
      const out = applyEdits(E.kitCode, edits || []);
      if (out.error) return text(`Not changed (nothing was saved): ${out.error}`);
      E.kitCode = out.html;
      const r = await E.lock(() => saveKit(E, out.html, ENGINE_DIR));
      if (r.ok) { E.kitDone?.(); if (role.scenes) r.text += `\n${kitBlock(E.sb)}\nNow build your scenes.`; }
      return r.file ? picture(r.file, r.text) : text(r.text);
    }),
    tool('save_scene', 'Save the whole html file of your scene (the file format in your rules). Code checks it, builds the page and answers with the scene\'s real frames and what it measured in them.', { scene: z.number(), html: z.string() }, async ({ scene, html }) => {
      const i = sceneOf(scene); if (i == null) return notMine();
      if (!spendStep(E, i)) return text(NO_STEPS);
      return inOrder(i, async () => saved(i, await build(i, html)));
    }),
    tool('edit_scene', 'Change your saved scene file with exact replacements: "edits" is a list of {find, replace} applied in order (each "find" must appear exactly once at that point); send every change of one round in ONE call. Code checks it, builds the page and answers with the scene\'s real frames.', { scene: z.number(), edits: z.array(z.object({ find: z.string(), replace: z.string() })).optional(), find: z.string().optional(), replace: z.string().optional() }, async ({ scene, edits, find, replace }) => {
      const i = sceneOf(scene); if (i == null) return notMine();
      const list = [...(Array.isArray(edits) ? edits : []), ...(typeof find === 'string' ? [{ find, replace: replace ?? '' }] : [])];
      if (!list.length) return text('Nothing to change: send "edits": [{"find": "…", "replace": "…"}].');
      if (!spendStep(E, i)) return text(NO_STEPS);
      return inOrder(i, async () => {
        const file = E.sb.rows[i].file && path.join(E.J0, E.sb.rows[i].file);
        if (!file || !fs.existsSync(file)) return text('Nothing saved yet: use save_scene first.');
        const out = applyEdits(fs.readFileSync(file, 'utf8'), list);
        if (out.error) return text(`Not changed (nothing was saved): ${out.error}`);
        return saved(i, await build(i, out.html));
      });
    }),
    // real ingredients (skills/shared-making.md "Real ingredients"): icons and logos, a person's reaction, a specific sound
    tool('find_icons', 'Icon and logo names for a word (an object, an idea, a brand: "rocket", "bkash", "openai"). Our own names first (always work), then more from the icon library; use one with ZK.icon("name"). Nothing fits: draw it.', { query: z.string() }, async ({ query }) => {
      const r = await library.findIcons(query);
      if (!r.own.length && !r.web.length) return text(r.online ? `No icon for "${query}". Try a simpler word (a brand by its company name), or draw it.` : `The icon library is not reachable now: use our own names (ZK.icon("word")) or draw it.`);
      return text(`${r.own.length ? `Ours: ${r.own.join(', ')}\n` : ''}${r.web.length ? `Library: ${r.web.join(', ')}` : ''}\nColour logos are in "logos:" and "skill-icons:"; one-colour logos in "simple-icons:"; line icons in "lucide:", "tabler:", "ph:".`);
    }),
    tool('find_parts', 'The 2D library on this computer (actions, gestures, hand shapes, set pieces, props, animals, parts kept from earlier films): the closest parts for each thing you need, in plain words ("old man sits on a bench", "CNG", "hospital ward"), with how to call them. Close = use it; near = adapt it; nothing close = author it. Ask for EVERYTHING all your scenes need in ONE call (up to 40), never one thing at a time.', { queries: z.array(z.string()).min(1).max(40) }, async ({ queries }) => text(findPartsText(queries))),
    tool('find_people', 'The parts of the hand-drawn people for ZK.peep({face, hair, body, beard, glasses, skin, hairColor, top, outline}): every face (expression), hair, body (pose / clothes), beard and glasses name.', {}, async () => {
      const P = library.peepParts();
      return text(P ? Object.entries(P).map(([k, v]) => `${k}: ${v.join(' ')}`).join('\n') : 'The people library is missing: draw the person or use an emoji.');
    }),
    tool('find_sound', 'A specific sound effect the kit does not have (a cash register, a rickshaw bell, a crowd cheering, rain): searches free sounds and adds the one you pick (number from the list) to this video as a cue name "lib:…". First call without pick to see the list.', { query: z.string(), pick: z.number().optional() }, async ({ query, pick }) => {
      E.soundLists ||= {};
      const list = E.soundLists[query] ||= await library.findSounds(query);
      if (!list.length) return text(`No free sound found for "${query}" (or the sound libraries are not reachable now): use the kit's nearest family instead.`);
      if (!pick) return text(list.map((s, k) => `${k + 1}. ${s.title} (${s.seconds} s)${s.about ? ` — ${s.about.slice(0, 90)}` : ''}`).join('\n') + '\nCall again with pick: <number>.');
      const c = list[Math.round(pick) - 1]; if (!c) return text('No such number in the list.');
      const name = await library.addSound(E.J0, c, query);
      return text(name ? `Added. Use it in your cues as ["${name}", <second>]. It is set to the kit's loudness.` : 'That sound could not be downloaded now: pick another number, or use the kit.');
    }),
    tool('look', 'See a scene the way a viewer does: real frames across all of it (its first moment, one every ~2 s with the key word landing among them, its last frame) and what code measured in them. A builder gets these frames after every save and edit already.', { scene: z.number() }, async ({ scene }) => {
      const i = Math.round(Number(scene)) - 1;
      if (!E.sb?.rows?.[i]) return text('There is no such scene.');
      if (!role.lead && !mine.has(i)) return notMine();
      const maxLooks = LOOKS() + (E.domIssues?.get(i) ? 1 : 0);
      if (!role.lead && (E.looks[i] = (E.looks[i] || 0) + 1) > maxLooks) return text('No more looks for this scene: answer with your one line.');
      if (!role.lead && !spendStep(E, i)) return text(NO_STEPS);
      return E.lock(() => lookScene(E, i));
    }),
    tool('look_video', 'See one frame of every scene of the video, numbered in order, and the joins between them (lead only). from / to: only those scene numbers.', { from: z.number().optional(), to: z.number().optional() }, async ({ from, to }) => {
      if (!role.lead) return text('Only the lead looks at the whole video.');
      return E.lock(() => lookVideo(E, from ? Math.round(from) - 1 : 0, to ? Math.round(to) - 1 : Infinity));
    }),
    tool('check_sync', 'Measure whether the word times match the voice between two video seconds (lead only): whisper listens to that stretch again and every word it clearly hears is compared with the time we use. Use it on any note about sync, timing or "the visual comes before/after the words".', { from: z.number(), to: z.number() }, async ({ from, to }) => {
      if (!role.lead) return text('Only the lead checks the sync.');
      return syncCheck(E, from, to, false);
    }),
    tool('retime', 'Correct the word times between two video seconds from what whisper hears there (lead only). The scenes there are rebuilt on the right times, their design kept.', { from: z.number(), to: z.number() }, async ({ from, to }) => {
      if (!role.lead) return text('Only the lead retimes.');
      return syncCheck(E, from, to, true);
    }),
    tool('mix', 'Change the whole video\'s sound and frame (lead only): effects_db (all sound effects up or down, e.g. -6), risers (false = no risers or hits), music_db (e.g. -6; -40 = no music), speaker_zoom (1–1.8: the speaker closer, about the face), captions ("on" | "off"), caption_size (0.7–1.5). Only what you send changes.', { effects_db: z.number().optional(), risers: z.boolean().optional(), music_db: z.number().optional(), speaker_zoom: z.number().optional(), captions: z.enum(['on', 'off']).optional(), caption_size: z.number().optional() }, async (a) => {
      if (!role.lead) return text('Only the lead changes the mix.');
      const m = { ...(E.sb.video?.mix || {}) };
      if (a.effects_db != null) m.sfxDb = Math.round(Math.max(-24, Math.min(6, (m.sfxDb || 0) + a.effects_db)) * 10) / 10;
      if (a.risers != null) m.risers = a.risers;
      if (a.music_db != null) m.musicDb = Math.round(Math.max(-40, Math.min(6, (m.musicDb || 0) + a.music_db)) * 10) / 10;
      if (a.speaker_zoom != null) m.zoom = Math.max(1, Math.min(1.8, a.speaker_zoom));
      if (a.captions) m.captions = a.captions;
      if (a.caption_size != null) m.capScale = Math.max(0.7, Math.min(1.5, a.caption_size));
      E.sb.video = { ...(E.sb.video || {}), mix: m }; E.global = true;
      fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(E.sb, null, 1));
      return text(`Saved for the whole video: ${JSON.stringify(m)} (effects and music in dB against our default, zoom about the face).`);
    }),
    tool('report', 'Your report for Zancut\'s team (never shown to the customer), once, at the end (lead only): for every note, what caused it, whether it was our mistake, what you did, and what you could not do and why.', { notes: z.array(z.object({ note: z.number(), cause: z.enum(['timing', 'design', 'sound', 'framing', 'captions', 'cut', 'taste', 'other']), ours: z.boolean(), severity: z.enum(['low', 'medium', 'high']), found: z.string(), did: z.string(), couldnt: z.string().optional() })) }, async ({ notes }) => {
      if (!role.lead) return text('Only the lead reports.');
      E.report = notes.slice(0, 20).map((x) => ({ ...x, found: x.found.slice(0, 1200), did: x.did.slice(0, 1200), couldnt: String(x.couldnt || '').slice(0, 600) }));
      return text(`Report saved (${E.report.length} notes).`);
    }),
    tool('change_scenes', 'The customer\'s changes (lead only): a JSON object {"<scene number>": <the complete new row, plus "change": what the builder must do>}.', { json: z.string() }, async ({ json }) => {
      if (!role.lead) return notMine();
      let list; try { list = JSON.parse(String(json).match(/\{[\s\S]*\}/)?.[0] || ''); } catch { return text('Not saved: that is not JSON. Send {"3": {…row…, "change": "…"}}.'); }
      const out = [];
      for (const [k, x] of Object.entries(list || {})) {
        const i = Math.round(Number(k)) - 1, old = E.sb.rows[i];
        if (!old || !x || typeof x !== 'object') { out.push(`scene ${k}: no such scene`); continue; }
        const row = parseRow(JSON.stringify(x), old); if (!row) { out.push(`scene ${k}: not a row`); continue; }
        const loose = unattached(E.p, row); if (loose) { out.push(`scene ${k}: not saved: it plans to show the customer's clip ${loose} but does not carry it in "media" (its designer would get no clip). Add "media": {"mine": …} (with "steps" for a screen recording), or take the clip out of its plan, then send it again`); continue; }
        const noSteps = missingSteps(E.p, row); if (noSteps) { out.push(`scene ${k}: not saved: it shows the screen recording ${noSteps} but has no "steps". Add "media": {"mine": …, "steps": [[word, second], …]} from its "what happens when" list (only the part this scene talks about), then send it again`); continue; }
        // locked to the neighbours that do not change: the joins stay exactly where they were. A pivot keeps arriving with its own
        // transition (its ground differs from the scene before); any other graphic after a graphic joins on its anchor and carries
        // the ground on (also a speaker row turned into a graphic).
        const before = E.sb.rows[i - 1], after = E.sb.rows[i + 1];
        if (row.piece === 'custom') {
          const joins = before?.piece === 'custom' && !old.pivot;
          if (joins && before.anchorOut) { row.anchorIn = before.anchorOut; row.transition = 'cut'; }
          if (old.pivot) { row.pivot = true; row.anchorIn = null; if (!row.transition || row.transition === 'cut') row.transition = old.transition && old.transition !== 'cut' ? old.transition : 'blur'; } else delete row.pivot;
          if (after?.anchorIn) row.anchorOut = after.anchorIn;
          if (joins) { row.bgStage = before.bgStage; row.groundRun = (before.groundRun || 0) + 1; }
          else { row.bgStage = after?.piece === 'custom' && after.groundRun > 0 ? after.bgStage : (old.piece === 'custom' && old.bgStage) || row.bgStage; row.groundRun = 0; }
        } else { delete row.groundRun; delete row.pivot; }
        const keep = row.piece === 'custom' && old.piece === 'custom' ? old.file : null; // the builder starts from the scene as it is
        delete row.change; delete row.file;
        E.sb.rows[i] = { ...row, ...(keep ? { file: keep } : {}) };
        E.changed.set(i, String(x.change || '').slice(0, 1500));
        out.push(`scene ${i + 1}: ${row.piece}${row.piece === 'custom' ? ' (a builder makes it next)' : ''}`);
      }
      fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(E.sb, null, 1));
      return text(out.length ? `Saved: ${out.join('; ')}.` : 'Nothing saved: no scene in the JSON.');
    }),
  ] });
}
// edit_scene's replacements on a scene file, in order; any that does not match exactly once stops it (nothing is saved)
export function applyEdits(html, list) {
  let out = String(html);
  for (const [k, e] of list.entries()) {
    const f = String(e?.find ?? ''), n = f ? out.split(f).length - 1 : 0;
    if (n !== 1) return { error: `edit ${k + 1}: ${!f ? '"find" is empty' : n ? `"find" appears ${n} times: include more of the text around it` : '"find" is not in the file: copy it exactly (after the edits before it)'}.` };
    out = out.replace(f, () => String(e.replace ?? ''));
  }
  return { html: out };
}
// A part of the storyboard planned again (words from–to): the new rows replace the old ones there; every other scene stays
// exactly as it was built, and the new rows join them on their anchors.
function saveRange(E, { from, to }, sb, n) {
  const rows = (sb.rows || []).filter((r) => Number.isInteger(+r.from) && Number.isInteger(+r.to)).map((r) => ({ ...r, from: +r.from, to: +r.to })).sort((a, b) => a.from - b.from);
  if (!rows.length || rows[0].from !== from || rows.at(-1).to !== to) return text(`Not saved: the new rows must cover exactly words ${from}–${to} (the first "from" is ${from}, the last "to" is ${to}).`);
  const before = E.sb.rows.filter((r) => r.to < from), after = E.sb.rows.filter((r) => r.from > to);
  const t = tidyStoryboard(E.p, { ...E.sb, rows: [...before.map((r) => ({ ...r, _frozen: true })), ...rows, ...after.map((r) => ({ ...r, _frozen: true }))] }, n);
  if (!t) return text('Not saved: the rows could not be read.');
  const k = t.rows.length - after.length;
  before.forEach((r, i) => { t.rows[i] = r; }); after.forEach((r, i) => { t.rows[k + i] = r; }); // the built scenes stay as they are
  const last = t.rows[k - 1];
  if (after[0]?.anchorIn && last?.piece === 'custom' && after[0].piece === 'custom') last.anchorOut = after[0].anchorIn; // hands over to the kept scene
  t.rows.slice(before.length, k).forEach((r) => { delete r.file; });
  E.sb = t; E.newRows = t.rows.map((r, i) => i).filter((i) => i >= before.length && i < k);
  fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(t, null, 1));
  return text(`Saved: ${E.newRows.length} new scenes (now scenes ${before.length + 1}–${k}) replace the old ones; every other scene stays as built.`);
}
const deskTools = ['save_storyboard', 'save_kit', 'edit_kit', 'save_scene', 'edit_scene', 'find_icons', 'find_parts', 'find_people', 'find_sound', 'look', 'look_video', 'change_scenes', 'check_sync', 'retime', 'mix', 'report'].map((x) => `mcp__zancut__${x}`);

// The word times between two video seconds against the voice: whisper listens to that stretch in short windows (anchors.py) and
// every word it clearly hears gives the time it is really said. write: the corrected times are saved and the scenes there are
// rebuilt on them (their design kept).
async function syncCheck(E, from, to, write) {
  const tf = path.join(E.J0, 'cut', 'transcript.json'), raw = J(tf, []), words = Array.isArray(raw) ? raw : raw.words || [];
  const sel = words.map((w, i) => [w, i]).filter(([w]) => w.start >= from - 0.3 && w.start <= to + 0.3);
  if (!sel.length) return text('There are no words between those seconds.');
  const a = Math.max(0, from - 1), dir = path.join(E.d.ws, 'qa', 'sync'), wav = path.join(dir, 'range.wav'), an = path.join(dir, 'anchors.json');
  fs.mkdirSync(dir, { recursive: true });
  try {
    await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(a), '-t', String(to + 1 - a), '-i', path.join(E.J0, 'cut', 'cut.mp4'), '-vn', '-ac', '1', '-ar', '16000', wav]);
    await run(PYTHON, [path.join(ENGINE_DIR, 'media', 'anchors.py'), wav, an, '--lang', E.p.language || 'en']);
  } catch (e) { return text(`The stretch could not be measured (${e.message.slice(0, 120)}).`); }
  const heard = J(an, []).map((x) => ({ ...x, s: x.s + a, e: x.e + a })), copy = sel.map(([w]) => ({ ...w }));
  if (!anchorTimes(copy, heard)) return text('Whisper did not hear enough of those words clearly to measure them.');
  const d = copy.map((w, j) => w.start - sel[j][0].start), max = Math.max(...d.map(Math.abs)), mean = d.reduce((x, y) => x + y, 0) / d.length;
  const table = copy.map((w, j) => `${w.text} ${sel[j][0].start.toFixed(2)}→${w.start.toFixed(2)}`).join(' · ');
  if (!write) return text(`${from}–${to} s: the words are off by up to ${max.toFixed(2)} s (on average ${mean >= 0 ? 'late by ' : 'early by '}${Math.abs(mean).toFixed(2)} s: positive = really said later than we show it).${max > 0.25 ? ' That is out of sync: call retime on it.' : ' That is in sync.'}\n${table}`);
  if (max <= 0.15) return text(`${from}–${to} s is already in sync (off by at most ${max.toFixed(2)} s): nothing changed.`);
  sel.forEach(([, i], j) => { words[i].start = copy[j].start; words[i].end = copy[j].end; });
  fs.writeFileSync(tf, JSON.stringify(Array.isArray(raw) ? words : { ...raw, words }, null, 1));
  const times = J(path.join(E.hf, 'scenes.json'), []), hit = [];
  E.sb.rows.forEach((r, i) => { const tm = times.find((x) => x.row === i); if (r.piece === 'custom' && tm && tm.s < to + 0.3 && tm.e > from - 0.3) { hit.push(i); E.changed.set(i, `The word times here were corrected (up to ${max.toFixed(2)} s off). Keep the design; move every at(…) to the new word times so each event lands on its word.`); } });
  E.global = true;
  return text(`Retimed ${from}–${to} s (${copy.length} words, up to ${max.toFixed(2)} s moved). Scenes rebuilt on the new times: ${hit.map((i) => i + 1).join(', ') || 'none (only speaker there)'}.\n${table}`);
}
// every editor call: the same system prompt and tools; what differs is the message, the role and the session
// Every editor call: the director's skill unless a system prompt is given (the builders'). Their conversations last minutes, so
// their prompt cache is the 5-minute one (writes cost 1.25× input instead of 2×); ZANCUT_CACHE_1H=1 keeps the hour. A 2D film's
// lead and reviewer keep the hour (the primed reviewer waits for the builders, ~8 min); its builders keep 5 minutes (their calls come
// every few seconds and round 2 resumes ~1 min after the review: the hour's dearer writes bought nothing there).
// Thinking: adaptive (the model decides per step) at an effort per role: the lead high (ZANCUT_EFFORT), the builders medium
// (ZANCUT_BUILDER_EFFORT; low gave too many redesigns; at high, adaptive builders thought 25–28k tokens each, about 40% of a
// video's cost). The review keeps
// its fixed budget; ZANCUT_THINKING=fixed gives every call its fixed budget (THINK).
// a 2D film's lead plans from its one compact file and thinks at medium (its plan at high was 53k tokens for a 2-minute film)
// builders medium (a 2D film's too: building it right once is cheaper than a fix round)
const effortOf = (role, p = null) => (role?.lead ? process.env.ZANCUT_EFFORT || (p?.kind === 'animation' ? 'medium' : 'high')
  : role?.scenes ? process.env.ZANCUT_BUILDER_EFFORT || 'medium' : null);
const call = (E, prompt, { role, what, think, turns, resume = null, fork = false, system = null, model = null }) =>
  E.runQuery(prompt, model || E.model, { systemPrompt: system || directorSystem(E.p), mcp: desk(E, role), allowed: deskTools, tools: [], maxTurns: turns, think, what, resume, fork, cache5m: process.env.ZANCUT_CACHE_1H !== '1' && !(E.p?.kind === 'animation' && !role?.scenes), adaptive: effortOf(role, E.p) });

// ---------- what the editor sees ----------
async function lookScene(E, i, { textWhenClean = false } = {}) {
  const plan = J(path.join(E.J0, 'edit', 'plan.json'));
  if (plan?.scenes?.find((x) => x.row === i)?.kind !== 'graphic') return text(`Scene ${i + 1} has no graphic built yet.`);
  // a 2D scene: the body gate first (no AI). While a rule is broken no picture is sent: the lines say what to fix, at no token cost
  let bodyNotes = [];
  if (E.p.kind === 'animation') {
    try {
      const at = J(path.join(E.hf, 'scenes.json'), []).find((x) => x.row === i);
      if (at) {
        const { checkBody } = await import(pathToFileURL(path.join(ENGINE_DIR, 'cartoon', 'check-body.mjs')).href);
        const before = J(path.join(E.hf, 'scenes.json'), []).find((x) => x.row === i - 1); // the cut into this scene: S1
        const g = await checkBody(E.hf, { from: before ? Math.max(before.s, at.s - 0.6) : at.s, to: at.e, row: i }); bodyNotes = g.notes || [];
        if (!g.ok) { if (E.domIssues) E.domIssues.set(i, true); return text(`Scene ${i + 1} breaks the body rules, so there is no picture yet. Fix these with edit_scene; the frames come when they hold:\n${g.lines.slice(0, 12).map((l) => `- ${l}`).join('\n')}`); }
      }
    } catch (e) { console.error('[look] body', e.message); }
  }
  const sh = (await sceneSheets(E.d, E.p, plan, E.sb, i))[0];
  if (!sh) return text('The scene could not be drawn. Save it again.');
  const s = (J(path.join(E.hf, 'scenes.json'), []).find((x) => x.row === i) || {}).s ?? sh.ts[0];
  const found = [];
  try { const { checkDom } = await import(pathToFileURL(path.join(ENGINE_DIR, 'check-dom.mjs')).href); found.push(...((await checkDom(E.hf, [{ row: i, uid: sh.uid, ts: sh.ts, cues: plan.scenes.find((x) => x.row === i)?.cues || [] }]))[i] || [])); } catch (e) { console.error('[look] dom', e.message); }
  try { const { readCheck } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href); for (const x of await readCheck(E.hf, { range: [sh.ts[0], sh.ts[2]], own: true })) if (x.at >= sh.ts[0] - 0.2 && x.at <= sh.ts[2] + 0.2) found.push(`at ${r2(x.at - s)} s: ${x.problem}`); } catch (e) { console.error('[look] read', e.message); }
  try { const { leakCheck } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href); for (const x of await leakCheck(E.hf, { step: 2, only: [s] })) found.push(`a part of this scene (${x.what}) is seen while the scene is not playing, from ${x.from} s to ${x.to} s of the video: it covers other scenes. Every part stays inside the scene (its own section, its own time)`); } catch (e) { console.error('[look] leak', e.message); }
  found.push(...bodyNotes.map((x) => `Note: ${x}`));
  const hasPhysical = found.some((x) => /runs off|clipped|overflows|collides|covers|Body rule/i.test(x));
  if (E.domIssues) E.domIssues.set(i, hasPhysical);
  // a 2D film's first build: a clean scene needs no picture (the reviewer looks at the whole film next); only a measured fault sends one
  if (textWhenClean && !hasPhysical) return text(`Scene ${i + 1}: the body gate and the code checks are clean. Go straight on to the next scene: no edit, no look.${found.length ? ` Notes for the reviewer (do not edit for them now):\n${found.map((x) => `- ${x}`).join('\n')}` : ''}`);
  const joins = await sceneJoins(E, i, plan).catch((e) => { console.error('[look] joins', e.message); return []; });
  return picture(sh.file, `Scene ${i + 1}: frames at ${sh.ts.map((t) => `${r2(t - s)} s`).join(', ')} of the scene (left to right).\n${found.length ? `Code measured (zero-token exact pixel math):\n${found.map((x) => `- ${x}`).join('\n')}` : 'Code measured nothing wrong (it cannot judge design: you do).'}${joins.length ? `\nThe joins with the scenes next to yours, measured on the real frames:\n${joins.map((x) => `- ${x}`).join('\n')}` : ''}`);
}
// the cut joins of scene i with the neighbours that are built: the real last frame of the one next to the real first frame of
// the other, measured in pixels. Lines for the builder: what jumps, and whose job it is.
async function sceneJoins(E, i, plan) {
  if (E.p.kind === 'animation') return []; // a film cut is meant to change the picture: no join is measured between 2D shots
  const times = J(path.join(E.hf, 'scenes.json'), []), at = (k) => times.find((x) => x.row === k);
  const built = (k) => E.sb.rows[k]?.piece === 'custom' && plan.scenes?.find((x) => x.row === k)?.kind === 'graphic' && at(k);
  const pairs = [];
  if (built(i - 1) && built(i) && E.sb.rows[i].transition === 'cut') pairs.push({ a: i - 1, b: i, label: `Into your scene, from scene ${i} (its real last frame → your first frame)`, mine: true });
  if (built(i) && built(i + 1) && E.sb.rows[i + 1].transition === 'cut') pairs.push({ a: i, b: i + 1, label: `Out of your scene, into scene ${i + 2} (your last frame → its first frame, which is built from your anchorOut pose)`, mine: false });
  if (!pairs.length) return [];
  const dir = path.join(E.d.ws, 'qa', 'near'); fs.mkdirSync(dir, { recursive: true });
  const list = pairs.flatMap((x) => [{ t: r2(Math.max(at(x.a).s, at(x.a).e - 0.07)), file: path.join(dir, `s${i}-${x.a}-a.jpg`) }, { t: r2(at(x.b).s + 0.04), file: path.join(dir, `s${i}-${x.a}-b.jpg`) }]);
  const { stills } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href);
  await stills(E.hf, list);
  return Promise.all(pairs.map(async (x, k) => {
    const sc = await joinScore(list[2 * k].file, list[2 * k + 1].file).catch(() => null);
    return joinLine(x.label, sc) + (sc?.jump && !x.mine ? ' (Only fix this if your last frame does not hold the anchorOut pose.)' : '');
  }));
}
async function lookVideo(E, from = 0, to = Infinity) {
  const plan = J(path.join(E.J0, 'edit', 'plan.json'), { scenes: [] }), times = J(path.join(E.hf, 'scenes.json'), []);
  const dir = path.join(E.d.ws, 'qa', 'video'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  const list = E.sb.rows.map((r, i) => {
    const tm = times.find((x) => x.row === i), uid = plan.scenes.find((x) => x.row === i)?.uid; if (!tm || i < from || i > to) return null;
    const a = tm.s + Math.min(0.3, (tm.e - tm.s) * 0.2), z = Math.max(a, tm.e - 0.15);
    return { ts: [0.35, 0.55, 0.72, 0.86, 1].map((f) => r2(a + (z - a) * f)), uid, i };
  }).filter(Boolean).map((x, k) => ({ ...x, file: path.join(dir, `v-${String(k + 1).padStart(3, '0')}.jpg`) }));
  const { stills, openPage } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href);
  await stills(E.hf, list);
  // the frames in a numbered grid, drawn by the same headless browser (a page that only shows the pictures)
  const cols = 6, cell = 200, ok = list.filter((x) => fs.existsSync(x.file)), sheet = path.join(E.d.ws, 'qa', 'video.jpg');
  const ar = (() => { const pl = J(path.join(E.J0, 'edit', 'plan.json'), {}); const [w, h] = String(pl.canvas || '1080x1920').split('x').map(Number); return h / w || 16 / 9; })();
  const W = cols * (cell + 6) + 6, H = Math.ceil(ok.length / cols) * (Math.round(cell * ar) + 6) + 6;
  fs.writeFileSync(path.join(dir, 'index.html'), `<!doctype html><html><body style="margin:0;background:#111"><div data-composition-id="sheet" data-width="${W}" data-height="${H}" style="display:grid;grid-template-columns:repeat(${cols},${cell}px);gap:6px;padding:6px">${ok.map((x) => `<div style="position:relative"><img src="${path.basename(x.file)}" style="width:${cell}px;display:block"><b style="position:absolute;left:6px;top:6px;font:700 22px sans-serif;color:#fff;background:#000a;padding:2px 8px;border-radius:6px">${x.i + 1}</b></div>`).join('')}</div><script>window.__timelines = { main: {} };</script></body></html>`);
  const o = await openPage(dir);
  if (!o) return text('The video could not be drawn.');
  try { fs.writeFileSync(sheet, await o.page.screenshot({ type: 'jpeg', quality: 75 })); } finally { await o.close(); }
  const res = picture(sheet, `One frame of every scene, numbered (left to right, top to bottom):\n${list.map((x) => `${x.i + 1}. ${E.sb.rows[x.i].piece}${E.sb.rows[x.i].piece === 'custom' ? ` (${E.sb.rows[x.i].file ? 'built' : 'NOT BUILT'})` : ''}: "${String(E.sb.rows[x.i].say || '').slice(0, 60)}"`).join('\n')}`);
  const joins = await joinSheet(E, times, ar, from, to).catch((e) => { console.error('[look_video] joins', e.message); return null; });
  if (joins) res.content.push({ type: 'image', data: fs.readFileSync(joins.file).toString('base64'), mimeType: 'image/jpeg' }, { type: 'text', text: `Every join between two graphic scenes: the last frame of one and the first frame of the next, side by side (labels "4→5"). A join is right when the next scene carries on from the shape, place, colour and light it ends on; a jump (something vanishes, moves or changes colour across the join, a reset to an empty frame) is a fix for the scene after the join. Joins shown: ${joins.pairs.join(', ')}.\nMeasured by code on those same frames (exact pixels, no guess; "background" = the edges of the frame, where the ground is):\n${joins.lines.map((x) => `- ${x}`).join('\n')}\n${joins.jumps.length ? `Measured jumps: ${joins.jumps.map((x) => x.label).join(', ')}. Each is a fix for the scene after the join (the second number), unless the picture shows it is meant.` : 'Code measured no jump.'}` });
  return res;
}
// the joins between graphic scenes: the last frame of scene i next to the first frame of scene i+1, in one sheet
async function joinSheet(E, times, ar, from = 0, to = Infinity) {
  const at = (i) => times.find((x) => x.row === i);
  const pairs = E.sb.rows.map((r, i) => i).filter((i) => i >= from && i < to && E.sb.rows[i].piece === 'custom' && E.sb.rows[i + 1]?.piece === 'custom' && at(i) && at(i + 1));
  if (!pairs.length) return null;
  const dir = path.join(E.d.ws, 'qa', 'joins'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  const list = pairs.flatMap((i) => [{ t: r2(Math.max(at(i).s, at(i).e - 0.07)), file: path.join(dir, `j${i}-a.jpg`) }, { t: r2(at(i + 1).s + 0.04), file: path.join(dir, `j${i}-b.jpg`) }]);
  const { stills, openPage } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href);
  await stills(E.hf, list);
  const cell = 130, ch = Math.round(cell * ar), per = 4, rows = Math.ceil(pairs.length / per), W = per * (2 * cell + 20) + 6, H = rows * (ch + 34) + 6;
  fs.writeFileSync(path.join(dir, 'index.html'), `<!doctype html><html><head><meta charset="utf-8"></head><body style="margin:0;background:#111"><div data-composition-id="joins" data-width="${W}" data-height="${H}" style="display:grid;grid-template-columns:repeat(${per},${2 * cell + 14}px);gap:6px;padding:6px">${pairs.map((i) => `<div><b style="display:block;font:700 18px sans-serif;color:#fff;height:26px">${i + 1}→${i + 2}</b><div style="display:flex;gap:2px"><img src="j${i}-a.jpg" style="width:${cell}px;display:block"><img src="j${i}-b.jpg" style="width:${cell}px;display:block"></div></div>`).join('')}</div><script>window.__timelines = { main: {} };</script></body></html>`);
  const o = await openPage(dir); if (!o) return null;
  const file = path.join(E.d.ws, 'qa', 'joins.jpg');
  try { fs.writeFileSync(file, await o.page.screenshot({ type: 'jpeg', quality: 75 })); } finally { await o.close(); }
  // the same joins measured in pixels (zero tokens); a join with a transition of its own (not a cut) is meant to change
  const lines = [], jumps = [];
  for (const i of pairs) {
    const label = `${i + 1}→${i + 2}`, t = E.sb.rows[i + 1].transition;
    if (t && t !== 'cut') { lines.push(`${label}: arrives with a ${t} transition (meant to change).`); continue; }
    if (E.p.kind === 'animation') { lines.push(`${label}: a film cut (meant to change; judge the story and eyelines by eye).`); continue; }
    const sc = await joinScore(path.join(dir, `j${i}-a.jpg`), path.join(dir, `j${i}-b.jpg`)).catch(() => null);
    lines.push(joinLine(label, sc)); if (sc?.jump) jumps.push({ i: i + 1, label, sc });
  }
  return { file, pairs: pairs.map((i) => `${i + 1}→${i + 2}`), lines, jumps };
}
// a sheet of 12 frames from the first cut (a person or a screen on camera): so the lead sees the framing it designs around
async function footageSheet(E) {
  const p = E.p, src = path.join(E.J0, 'cut', 'cut.mp4');
  if (p.kind === 'faceless' || p.mode === 'faceless' || !fs.existsSync(src)) return null;
  const out = path.join(E.d.ws, 'qa', 'footage.jpg'); fs.mkdirSync(path.dirname(out), { recursive: true });
  try {
    const d = Number(String(await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', src])).trim()) || 30;
    await run('ffmpeg', ['-v', 'error', '-y', '-i', src, '-vf', `fps=${(12 / d).toFixed(4)},scale=240:-2,tile=4x3:padding=4`, '-frames:v', '1', '-q:v', '4', out]);
    return fs.existsSync(out) ? out : null;
  } catch (e) { console.error('[footage sheet]', e.message); return null; }
}

// ---------- the crew: graphic scenes, a few at a time, each a fork of the lead ----------
// Claude's usage or rate limit: the job stops and says so (never a video of stand-ins); Retry carries on where it stopped
const HARD_QUOTA = /5-hour|weekly|daily|usage limit|session limit|claude_limit|hit your .*limit/i;
const RATE_LIMIT = /rate.?limit|429|overloaded|529|too many requests/i;
const LIMIT = /hit your .*limit|usage limit|rate.?limit|session limit|(5-hour|weekly|daily) limit|limit is reached|claude_limit|overloaded|429|529/i;
// the lead's session lives in the Claude account that made it: after a login change (or on another computer) it is gone
const LOST = /No conversation found/i;
export function parseResetTime(msg) {
  if (!msg) return null;
  const str = String(msg);
  const isoMatch = str.match(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(?:\.\d+)?Z?/i);
  if (isoMatch) {
    const t = Date.parse(isoMatch[0]);
    if (!isNaN(t) && t > Date.now()) return t;
  }
  const timeMatch = str.match(/resets?\s+(?:at|in)\s+(\d{1,2}):(\d{2})(?::(\d{2}))?\s*(AM|PM)?/i);
  if (timeMatch) {
    let hours = parseInt(timeMatch[1], 10);
    const mins = parseInt(timeMatch[2], 10);
    const meridian = timeMatch[4]?.toUpperCase();
    if (meridian === 'PM' && hours < 12) hours += 12;
    if (meridian === 'AM' && hours === 12) hours = 0;
    const now = new Date();
    const reset = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hours, mins, 0, 0);
    if (reset.getTime() <= Date.now()) reset.setDate(reset.getDate() + 1);
    return reset.getTime();
  }
  const durMatch = str.match(/(?:in|after)\s+(?:(\d+)\s*(?:hours?|hrs?|h)(?:\s*(?:and\s*)?(\d+)\s*(?:minutes?|mins?|m))?|(\d+)\s*(?:minutes?|mins?|m))/i);
  if (durMatch) {
    const h = parseInt(durMatch[1] || '0', 10);
    const m = parseInt(durMatch[2] || durMatch[3] || '0', 10);
    if (h > 0 || m > 0) return Date.now() + (h * 3600 + m * 60) * 1000;
  }
  return null;
}

const limitError = (e) => {
  const resetAt = parseResetTime(e?.message) || (HARD_QUOTA.test(e?.message || '') ? Date.now() + 5 * 3600 * 1000 : null);
  // Claude's own sentence as it is (it says which limit and until when), then what happens to the video
  const said = String(e?.message || '').replace(/^(\w*Error:\s*)+/, '').replace(/\s*The manual editor still works\.?/, '').trim().slice(0, 200);
  return Object.assign(new Error(`${said ? `${said}${/[.!?]$/.test(said) ? '' : '.'} ` : "Claude's usage limit was reached. "}Everything built so far is kept, and the video continues from where it stopped.`), {
    customer: true,
    quotaLimit: true,
    resetAt,
    originalMessage: e?.message || ''
  });
};
// A fixed scene's neighbours as they really are: the last frame of the scene before it and the first frame of the one after, small,
// so the builder carries on from what is on screen and not from a pose in numbers. Only the neighbours that are built.
async function neighbourFrames(E, i) {
  const plan = J(path.join(E.J0, 'edit', 'plan.json'), { scenes: [] }), times = J(path.join(E.hf, 'scenes.json'), []), at = (k) => times.find((x) => x.row === k);
  const built = (k) => E.sb.rows[k]?.piece === 'custom' && plan.scenes?.find((x) => x.row === k)?.kind === 'graphic' && at(k);
  const dir = path.join(E.d.ws, 'qa', 'near'); fs.mkdirSync(dir, { recursive: true });
  const want = [];
  if (built(i - 1)) want.push({ t: r2(Math.max(at(i - 1).s, at(i - 1).e - 0.07)), file: path.join(dir, `n${i}-before.jpg`), label: `The real LAST frame of scene ${i} (the scene before yours). Your scene starts from exactly this: the same ground, the same shape in the same place.` });
  if (built(i + 1)) want.push({ t: r2(at(i + 1).s + 0.04), file: path.join(dir, `n${i}-after.jpg`), label: `The real FIRST frame of scene ${i + 2} (the scene after yours). Your scene ends on the shape it starts from, and holds the same ground.` });
  if (!want.length) return [];
  const { stills } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href);
  await stills(E.hf, want);
  const out = [];
  for (const w of want) {
    if (!fs.existsSync(w.file)) continue;
    const small = w.file.replace(/\.jpg$/, '-s.jpg');
    try { await run('ffmpeg', ['-v', 'error', '-y', '-i', w.file, '-vf', 'scale=540:-2', '-frames:v', '1', '-q:v', '4', small]); out.push({ label: w.label, file: small }); } catch { out.push({ label: w.label, file: w.file }); }
  }
  return out;
}
// A wave of scenes cut into runs a designer builds in one conversation, in order: about max scenes each, split evenly, each
// split moved (up to 2 scenes) to a place where the scenes do not join on their anchor (a pivot, a gap). Fewer designers =
// the skill and the video read fewer times (6 designers for 18 scenes cost about $1.50 in reading alone). Exported for the tests.
export function runsOf(E, wave, max = 9) {
  const xs = [...wave].sort((a, b) => a.i - b.i), n = xs.length, k = Math.ceil(n / max);
  if (k <= 1) return n ? [xs] : [];
  const joined = (j) => xs[j].i === xs[j - 1].i + 1 && E.sb.rows[xs[j].i]?.groundRun > 0 && E.sb.rows[xs[j].i].transition === 'cut';
  const cuts = [0];
  for (let c = 1; c < k; c++) {
    const want = Math.round((c * n) / k), last = cuts.at(-1);
    cuts.push([0, 1, -1, 2, -2].map((s) => want + s).find((j) => j > last && j < n && !joined(j)) ?? want);
  }
  return cuts.map((a, c) => xs.slice(a, cuts[c + 1] ?? n));
}
const EMOJI = /\p{Extended_Pictographic}/u;
// The icons, logos and emoji the rows named ("icons"): icon words are looked up (ours first, then the icon library), emoji
// are fetched, so the designer has the names that work and needs no search step for them. Each lookup is short; a slow or
// missing library leaves the word to the designer (find_icons, or draw it).
async function readyIcons(E, idx) {
  E.ready ||= {};
  const want = [...new Set(idx.flatMap((i) => E.sb.rows[i]?.icons || []))];
  if (!want.length) return;
  const found = {};
  const within = (pr, ms) => Promise.race([pr, new Promise((ok) => setTimeout(() => ok(null), ms))]);
  await Promise.all(want.filter((w) => !EMOJI.test(w)).map(async (w) => { const r = await within(library.findIcons(w, 4).catch(() => null), 8000); found[w] = r ? [...r.own.slice(0, 2), ...r.web.slice(0, 2)] : []; }));
  const emoji = want.filter((w) => EMOJI.test(w));
  if (emoji.length) await within(library.prepareScene(E.J0, emoji.map((e) => `ZK.emoji("${e}")`).join(' ')).catch(() => []), 15000);
  for (const i of idx) { const r = E.sb.rows[i]; if (r?.icons?.length) E.ready[i] = r.icons.map((w) => (EMOJI.test(w) ? { want: w, emoji: true } : { want: w, use: found[w] || [] })); }
}
// list: [{ i, note }] (note = what to change; the scene's current file goes with it, and stays if the change fails).
// Neighbouring scenes go to one builder together; a scene that reuses another one in the list waits for it (a second wave).
// several notes on one scene are one job for one designer: never one new conversation per note
const oneEach = (fixes) => { const m = new Map(); for (const f of fixes) { const c = m.get(f.i); if (c) c.note += ` Also: ${f.note}`; else m.set(f.i, { ...f }); } return [...m.values()]; };
// A 2D film's cast and places, once, before the shots (server/filmkit.mjs). A kit that fails leaves the shots to draw their own places.
// the parts this film's shots and places need, found by code in the library (server/parts.mjs) from the rows' needs: one small
// file per film, rebuilt whenever the storyboard is (cheap, no AI); each designer gets only its own rows' slice
// once per scene, at its first save: the close library parts it left out (no AI, a line in the save's answer)
function libNote(E, i, html) {
  if (E.p.kind !== 'animation' || (E.libNoted ||= new Set()).has(i)) return '';
  E.libNoted.add(i);
  const xs = skippedParts(E.parts?.rows?.[i], html);
  return xs.length ? `\nLibrary: close parts this scene left out: ${skippedText(xs)}. Use them in your next edit if they fit; a part that does not fit needs no reply.` : '';
}
function filmParts(E) {
  if (E.p.kind !== 'animation' || !E.sb) return null;
  try { E.parts = writeFilmParts(E.J0, E.sb); } catch (e) { console.error('[parts]', e.message.slice(0, 160)); E.parts = null; }
  return E.parts;
}
async function filmKit(E, extra) {
  if (E.p.kind !== 'animation' || !E.sb?.film) return;
  writeCast(E);
  if (!needsKit(E)) return;
  // the first builder draws the places itself (crew, below): it keeps them in its conversation and the cache; ZANCUT_KIT_SEPARATE=1 = the old kit call
  if (process.env.ZANCUT_KIT_SEPARATE !== '1') return;
  E.step(`Drawing this film's ${E.sb.film.places.length} place${E.sb.film.places.length > 1 ? 's' : ''} once, for all its shots`);
  await call(E, kitTask(E.sb, filmParts(E)), { role: { kit: true }, what: 'film kit', model: BUILDER_MODEL(E.p), think: THINK.scene(), turns: 6, system: crewSystem(E, extra) });
  if (needsKit(E)) { console.error('[film kit] not finished: the shots draw their own places'); fs.writeFileSync(kitFile(E), `ZF.cast = ${JSON.stringify(Object.fromEntries((E.sb.film.cast || []).map((c) => [c.id, c.spec])))};\n`); E.sb.film.places = []; }
}
// a 2D scene's builder conversation (kept on the project): a fix or a customer's change resumes it, so it remembers the scene
const builderOf = (E, i) => E.p.editor?.builders?.[i] || null;
// the reusable pieces a 2D builder authored through the library's own calls (round 2 or a change), collected for the library:
// edit/new-parts.json, one entry per id (the latest code wins). No AI; how they reach the shipped library is decided outside.
const NEW_PART = /\b(ZS\.define|ZANATOMY\.addPosture|ZANATOMY\.addGesture|HANDS\.addPose)\s*\(/g;
function callAt(src, open) { // the text of a call from its "(" to the matching ")", skipping strings and comments
  let depth = 0, q = null;
  for (let k = open; k < src.length; k++) {
    const c = src[k];
    if (q) { if (c === '\\') k++; else if (c === q) q = null; continue; }
    if (c === '"' || c === "'" || c === '`') q = c;
    else if (c === '/' && src[k + 1] === '/') k = src.indexOf('\n', k) < 0 ? src.length : src.indexOf('\n', k);
    else if (c === '(') depth++;
    else if (c === ')' && --depth === 0) return src.slice(open, k + 1);
  }
  return null;
}
function newParts(E) {
  const out = path.join(E.J0, 'edit', 'new-parts.json'), have = J(out, []), byId = new Map(have.map((x) => [x.id, x]));
  E.sb.rows.forEach((r, i) => {
    const f = r.file && path.join(E.J0, r.file); if (!f || !fs.existsSync(f)) return;
    const src = fs.readFileSync(f, 'utf8');
    for (const m of src.matchAll(NEW_PART)) {
      const call = callAt(src, m.index + m[0].length - 1); if (!call) continue;
      const id = (/^\(\s*["'`]([A-Za-z0-9_]+)/.exec(call) || /\bid\s*:\s*["'`]([A-Za-z0-9_]+)/.exec(call) || [])[1]; if (!id) continue;
      byId.set(id, { id, kind: m[1], scene: i + 1, code: `${m[1]}${call}`, at: byId.get(id)?.code === `${m[1]}${call}` ? byId.get(id).at : Date.now() });
    }
  });
  if (!byId.size) return;
  fs.mkdirSync(path.dirname(out), { recursive: true });
  fs.writeFileSync(out, JSON.stringify([...byId.values()], null, 1));
}
async function crew(E, list) {
  if (E.p.kind === 'animation') filmParts(E);
  const ctxs = sceneContexts(E.d, E.p, E.sb), inList = new Set(list.map((x) => x.i)), file = (r) => r.file && path.join(E.J0, r.file);
  const later = (x) => !x.note && E.sb.rows[x.i].reuse && inList.has(E.sb.rows[x.i].reuse.scene - 1);
  const waves = [list.filter((x) => !later(x)), list.filter(later)].filter((w) => w.length);
  let done = 0, halt = null;
  startWork(E, list);
  // fresh builders: the skill + this video in short, made once per round so every builder has the same (cached) system prompt
  const system = FRESH() ? crewSystem(E) : null;
  const how = system ? { system } : { resume: E.lead, fork: true, system: builderSystem(E.p) }; // a fork builder still reads the building skill
  // the real code of the built neighbours this scene joins on a shape (the one before when it starts from its anchor, the one
  // after when it hands its anchor on): the builder copies that shape exactly, the way an editor copies it in a chat, instead of
  // drawing it again from a description. Only for the join: its own design stays its own.
  const codeOf = (k) => { const n = E.sb.rows[k]; return n?.piece === 'custom' && file(n) && fs.existsSync(file(n)) ? fs.readFileSync(file(n), 'utf8').replace(/<!--cues[\s\S]*?-->/, '').trim().slice(0, 12000) : null; };
  const handoff = (i) => { const r = E.sb.rows[i]; return { beforeCode: r.anchorIn ? codeOf(i - 1) : null, afterCode: ctxs[i]?.holdOut && r.anchorOut ? codeOf(i + 1) : null }; };
  const prep = (x) => {
    const r = E.sb.rows[x.i], cur = file(r) && fs.existsSync(file(r)) ? fs.readFileSync(file(r), 'utf8') : null, src = r.reuse && E.sb.rows[r.reuse.scene - 1];
    E.looks[x.i] = 0; E.saved.delete(x.i);
    // a reuse: the earlier scene's file becomes this scene's start (edit_scene adapts it); put back if the builder does not save
    if (!x.note && !cur && src?.file && fs.existsSync(file(src))) { r.file = src.file; return { x, r, cur, reused: true, ctx: { ...ctxs[x.i], ...handoff(x.i), current: fs.readFileSync(file(src), 'utf8'), reuse: { n: r.reuse.scene, how: r.reuse.how }, looks: LOOKS(), ready: E.ready?.[x.i], parts: E.parts?.rows?.[x.i] } }; }
    return { x, r, cur, ctx: { ...ctxs[x.i], ...handoff(x.i), note: x.note || null, current: x.note ? cur : null, looks: LOOKS(), ready: E.ready?.[x.i], parts: E.parts?.rows?.[x.i] } };
  };
  // first builds of fresh designers in runs: each run is reviewed when it is built (RUN_REVIEW); fixes and a carry-on are not
  const reviewRuns = Boolean(system) && RUNS() && RUN_REVIEW() && list.every((x) => !x.note);
  const runs = []; // { idx, session }: every built run, to send a fix back into its designer's conversation
  // a reviewer's notes go back into the designer's own conversation: a fix there costs a small edit, not a new designer
  const fixIn = async (session, fixes, again = false) => {
    fixes = oneEach(fixes);
    const idx = fixes.map((f) => f.i), nums = idx.map((i) => i + 1).join(', ');
    startWork(E, fixes); for (const i of idx) E.looks[i] = 0;
    const task = E.p.kind === 'animation' ? `${again ? 'The reviewer looked again after your fix: these notes did not land (or the fix broke something). This is the last fix: no one looks after it, so check each one on your new frames before you answer:' : `Round 2. The reviewer read the script and looked at your scenes. Fix every note${RECHECK() ? ' (the reviewer looks once more at these scenes after your fix)' : ' (there is no other review)'}:`}
${fixes.map((f) => `- Scene ${f.i + 1}: ${f.note}`).join('\n')}
Fix each scene with ONE edit_scene call holding every replacement (save_scene only when a note says the design itself is wrong). Keep
every cartoon shot a ZC.shot: change its beats, positions, props and camera list; never rewrite a shot by hand. Now you may
author what the library lacks (round 2 in your skill: a reusable piece through ZS.define / ZANATOMY.addPosture / addGesture / HANDS.addPose,
with a generic name). Look once at the new frames, fix only a body-gate fault, then answer with one line per scene.`
      : `The reviewer looked at your scenes together with the rest of the video and sends ${idx.length > 1 ? 'these' : 'this'} back:
${fixes.map((f) => `- Scene ${f.i + 1}: ${f.note}`).join('\n')}
Fix ${idx.length > 1 ? 'each one, in order,' : 'it'} with ONE edit_scene call per round holding every replacement (small exact replacements); save_scene only
when a note says the design itself is wrong. The answer shows the new frames: fix again only while something still fails. Then
answer with one line per scene.`;
    try { await call(E, task, { role: { scenes: idx }, what: `scene ${nums} (fix)`, model: MODEL_FOR(E, idx), think: THINK.fix(), turns: turnsFor(E, idx), ...how, resume: session }); }
    catch (e) {
      if (E.job.cancelled) throw e;
      console.error(`[scene ${nums} fix]`, e.message.slice(0, 200));
      if (HARD_QUOTA.test(e.message) || (LIMIT.test(e.message) && !LOST.test(e.message))) halt = e; // a lost session: the scenes stay as built
    }
    if (!halt) for (const i of idx) E.step(`Scene ${i + 1} fixed after the review`);
  };
  const reviewRun = async (idx, session, said = '') => {
    const a = idx[0] + 1, b = idx.at(-1) + 1, mine = new Set(idx), anim = E.p.kind === 'animation';
    E.step(`The editor is looking at scene${a === b ? ` ${a}` : `s ${a}–${b}`}`);
    const fixes = anim
      ? await askReview(E, E.extra, `Round 1 is built: scene${a === b ? ` ${a}` : `s ${a}–${b}`} (other scenes may still be building: judge only ${a === b ? 'this one' : 'these'}).${said ? `\nTheir builder's last answer, with its gap lines:\n${String(said).slice(0, 3000)}` : ''}
Call look_video with from ${a} and to ${b}, then judge each scene, one by one, against its script scene and its row; look at a scene closer only where one frame cannot tell.`,
        `reviewer: ${a}-${b}`, (i) => mine.has(i), idx.length, 'One note per scene with a major problem, in the order of your review skill (logic and the script, then the hook and the pace, then the B-roll, graphics and texts that had to be there, then the rest)')
      : await askReview(E, E.extra, `Scene${a === b ? ` ${a} is` : `s ${a}–${b} are`} built by one designer (other scenes may still be building: judge only ${a === b ? 'this one' : 'these'}). Call look_video with from ${a} and to ${b} to see their frames and joins (and how code measured each join).`,
      `lead: review ${a}-${b}`, (i) => mine.has(i), 4, 'Only scenes in this range that clearly break the design system\'s rules, are unfinished, do not act out their words, do not belong to this video\'s look and motion, or jump at a join inside this range');
    if (fixes.length && !halt && !E.job.cancelled) { E.step(`The editor sends scene${fixes.length > 1 ? 's' : ''} ${fixes.map((f) => f.i + 1).join(', ')} back to its designer`); await fixIn(session, fixes); }
    // 2D: the reviewer looks once more at the fixed scenes only (its own conversation: it knows the script and its notes); a note that
    // did not land, or a new fault the fix made, goes back once. Nothing looks after that second fix (a bounded cost).
    if (anim && RECHECK() && fixes.length && !halt && !E.job.cancelled) {
      const fixed = new Set(fixes.map((f) => f.i)), list = [...fixed].sort((x, y) => x - y), nums = list.map((i) => i + 1).join(', ');
      E.step(`The editor checks the fixed scene${list.length > 1 ? 's' : ''} ${nums} again`);
      const again = await askReview(E, E.extra, `The builder has fixed scene${list.length > 1 ? 's' : ''} ${nums} after your notes:
${fixes.map((f) => `- Scene ${f.i + 1}: ${f.note}`).join('\n')}
Call look_video on ${list.length > 1 ? 'each of these scenes' : 'this scene'} (from and to = the scene) and judge ONLY whether each note landed on the new frames, and whether the fix broke anything visible.`,
        `reviewer: recheck ${nums}`, (i) => fixed.has(i), list.length, 'One note per scene whose note did not land (say exactly what is still wrong on the frame and what to change) or whose fix broke something; an empty list when every note landed');
      if (again.length && !halt && !E.job.cancelled) { E.step(`The editor sends scene${again.length > 1 ? 's' : ''} ${again.map((f) => f.i + 1).join(', ')} back once more`); await fixIn(session, again, true); }
    }
  };
  // once every run is built: the joins where one designer's run meets another's (neither designer saw the other's scene)
  const reviewSeams = async () => {
    if (E.p.kind === 'animation') return; // a 2D film's joins are film cuts: one review, one fix round
    const seams = runs.flatMap((r) => { const j = r.idx[0], o = runs.find((x) => x.idx.includes(j - 1)); return o ? [{ i: j, run: r }] : []; });
    if (!seams.length) return;
    const fixes = await askReview(E, E.extra, `Every scene is built. Different designers built the scenes on each side of ${seams.length > 1 ? 'these joins' : 'this join'} at the same time, so only you can see ${seams.length > 1 ? 'them' : 'it'}: ${seams.map((x) => `${x.i} → ${x.i + 1}`).join(', ')}. For each, call look_video with from the first and to the second scene of the join.`,
      'lead: review joins', (i) => seams.some((x) => x.i === i), seams.length, 'Only the later scene of a join that jumps (name what to carry on from the scene before: its ground, its shape, the place). A join that code measured as a jump is a fix unless the picture shows it is meant');
    for (const x of seams) { const f = fixes.filter((y) => y.i === x.i); if (f.length && !halt && !E.job.cancelled) { E.step(`The editor sends scene ${x.i + 1} back: its join with scene ${x.i}`); await fixIn(x.run.session, f); } }
  };
  // a 2D film's places: the builder of the first run draws them first (save_kit) in its own conversation, then its scenes; the other
  // builders start once the places are saved (or that builder is done), with the kit in their task
  let kitChunk = null, kitReady = null;
  if (E.p.kind === 'animation' && system && needsKit(E) && list.every((x) => !x.note)) kitReady = new Promise((ok) => { E.kitDone = () => { E.kitDone = null; ok(); }; });
  const kitFallback = () => { if (!needsKit(E)) return; console.error('[film kit] not drawn: the shots draw their own places'); fs.writeFileSync(kitFile(E), `ZF.cast = ${JSON.stringify(Object.fromEntries((E.sb.film.cast || []).map((c) => [c.id, c.spec])))};\n`); E.sb.film.places = []; };
  const build = async (chunk, onInitialResponse = null) => {
    let drawsKit = false;
    if (kitReady) { if (!kitChunk) { kitChunk = chunk; drawsKit = true; E.step(`Drawing this film's ${E.sb.film.places.length} place${E.sb.film.places.length > 1 ? 's' : ''} first, in the first builder's conversation`); } else { await kitReady; kitFallback(); } }
    const kitNote = kitReady && !drawsKit && E.sb.film?.kit ? `${kitBlock(E.sb)}\n` : '';
    const items = chunk.map(prep), finished = new Set(); // scenes whose builder ended its own loop (also when another builder hit the limit)
    let session = null, said = '';
    // a 2D change or fix: the builder that made these scenes carries on in its own conversation (it remembers them, read from the cache)
    let back = E.p.kind === 'animation' && system && chunk.every((x) => x.note) ? builderOf(E, chunk[0].i) : null;
    // the fix of a scene: the real neighbours' frames go with the note (the page is built, so they exist); a 2D fix needs only its own scene
    for (const t of items) if (t.x.note && E.p.kind !== 'animation') t.near = await E.lock(() => neighbourFrames(E, t.x.i)).catch((e) => { console.error('[near]', e.message.slice(0, 160)); return []; });
    try {
      let rounds = 0; // builder conversations that ended normally: a second one only when the first saved nothing
      for (let tries = 0; tries < 3 && !E.job.cancelled && !halt; tries++) {
        const todo = items.filter((t) => !E.saved.has(t.x.i) && stepsLeft(E, t.x.i) > 0); if (!todo.length || rounds >= 2) break;
        const nums = todo.map((t) => t.x.i + 1).join(', ');
        // one step cap for a scene over every retry: the call gets what is left of it (+1 for the answer line)
        const kitNow = drawsKit && needsKit(E);
        const turns = turnsFor(E, todo.map((t) => t.x.i)) + (kitNow ? 4 : 0);
        const task = `${kitNow ? `${kitTask(E.sb, E.parts, { thenScenes: true })}\n\n` : kitNote}${batchTask(E.p, todo.map((t) => ({ r: t.r, ctx: t.ctx })))}`, near = todo.flatMap((t) => t.near || []);
        try {
          const res = await call(E, near.length ? message([{ type: 'text', text: task }, ...near.flatMap((n) => [{ type: 'text', text: n.label }, jpeg(n.file)])]) : task, { role: { scenes: todo.map((t) => t.x.i), first: todo.every((t) => !t.x.note), kit: kitNow }, what: `scene ${nums}`, model: MODEL_FOR(E, todo.map((t) => t.x.i)), think: todo.every((t) => t.x.note) ? THINK.fix() : THINK.scene(), turns, ...how, ...(back ? { resume: back } : {}) });
          if (E.p.kind === 'animation') back = null; // a carried-on conversation (below) is resumed once
          session = res?.session_id || session; said = String(res?.result || '');
          for (const t of todo) finished.add(t.x.i);
          rounds++;
          if (onInitialResponse) { onInitialResponse(); onInitialResponse = null; }
        }
        catch (e) {
          if (onInitialResponse) { onInitialResponse(); onInitialResponse = null; }
          if (E.job.cancelled) throw e;
          console.error(`[scene ${nums}]`, e.message.slice(0, 200));
          if (HARD_QUOTA.test(e.message)) { halt = e; break; }
          if (back && LOST.test(e.message)) { back = null; continue; } // its conversation is gone (another computer or account): a new builder
          // a 2D builder stopped part-way (its turns ran out): the SAME conversation carries on with the scenes not saved yet, so
          // it keeps what it found and built, and its scenes still go to the reviewer and to round 2 in it
          if (E.p.kind === 'animation' && e.session_id) { session = e.session_id; back = e.session_id; for (const t of todo) if (E.saved.has(t.x.i)) finished.add(t.x.i); continue; }
          if (RATE_LIMIT.test(e.message)) {
            // Temporary speed limit (429 ITPM/OTPM or 529 overloaded): backoff with random jitter per-worker
            const backoffMs = tries === 0 ? 25000 + Math.random() * 15000 : tries === 1 ? 55000 + Math.random() * 20000 : 110000 + Math.random() * 30000;
            console.log(`[scene ${nums}] transient rate limit / overload; worker backing off ${(backoffMs / 1000).toFixed(1)}s (jittered)`);
            await new Promise((ok) => setTimeout(ok, backoffMs));
            continue;
          }
          if (LIMIT.test(e.message) || LOST.test(e.message)) halt = e;
        }
      }
    } finally {
      if (onInitialResponse) onInitialResponse();
      for (const t of items) if (t.reused && !E.saved.has(t.x.i)) delete t.r.file;
      if (drawsKit) { kitFallback(); E.kitDone?.(); }
    }
    for (const { x: { i }, cur } of items) {
      // finished its look-and-fix loop (or used all its steps: it stays as it is, a Retry does not start it again)
      if (E.saved.has(i) && (finished.has(i) || !stepsLeft(E, i)) && E.p.editor) E.p.editor.done = [...new Set([...(E.p.editor.done || []), i])];
      if (!halt) E.step(`Scene ${i + 1} ${E.saved.has(i) ? 'built and checked' : cur ? 'kept as it was (the change could not be made)' : 'could not be built (a stand-in shows there)'} · ${++done} of ${list.length}`);
    }
    const built = chunk.map((x) => x.i).filter((i) => E.saved.has(i));
    if (session && built.length) runs.push({ idx: built, session });
    if (E.p.kind === 'animation' && session && E.p.editor) { E.p.editor.builders ||= {}; for (const i of built) E.p.editor.builders[i] = session; }
    if (reviewRuns && session && built.length && !halt && !E.job.cancelled) await reviewRun(built, session, said);
  };
  // the chunks: fresh designers take a run of joined scenes each (up to RUN_MAX, in order); the old fork builders take BATCH
  // up to 10 scenes: ONE designer builds them all in one conversation (the skill read once, no second review, no joins between
  // designers to check); more scenes: a designer per 10, in parallel. ZANCUT_CREW / ZANCUT_RUN_MAX still win.
  const crewSize = E.p.kind === 'animation' && !process.env.ZANCUT_CREW ? 3 : CREW(list.length); // 2D: the chunks above decide (1 builder up to 12 scenes)
  const runMax = () => RUN_MAX();
  const size = system ? 1 : Math.max(Math.min(2, BATCH()), Math.min(BATCH(), Math.ceil(list.length / crewSize)));
  const chunksOf = (wave) => {
    if (system && E.p.kind === 'animation') {
      const xs = [...wave].sort((a, b) => a.i - b.i);
      // a change or a fix: one conversation per builder that made those scenes (its session is resumed: it remembers them)
      if (xs.every((x) => x.note)) { const m = new Map(); for (const x of xs) { const k = builderOf(E, x.i) || `new${x.i}`; m.set(k, [...(m.get(k) || []), x]); } return [...m.values()]; }
      // the first build: ONE builder builds every scene in one conversation; a long film: 2–3 builders, each a run in order
      const per = Math.ceil(xs.length / Math.max(1, Math.ceil(xs.length / Number(process.env.ZANCUT_RUN_MAX || 12)))), out = [];
      for (let a = 0; a < xs.length; a += per) out.push(xs.slice(a, a + per));
      return out;
    }
    if (system && RUNS()) return runsOf(E, wave, runMax(wave));
    const out = []; for (let a = 0; a < wave.length; a += size) out.push(wave.slice(a, a + size)); return out;
  };
  const plan0 = chunksOf(waves[0] || []);
  const modelName = /sonnet/i.test(BUILDER_MODEL(E.p)) ? 'Sonnet (Token Saver)' : /opus/i.test(BUILDER_MODEL(E.p)) ? 'Opus' : BUILDER_MODEL(E.p);
  E.step(`Building ${list.length} scene${list.length > 1 ? 's' : ''} with ${modelName}, ${plan0.some((c) => c.length > 1) ? 'joined scenes by one designer in order, ' : ''}${Math.min(crewSize, plan0.length)} designer${Math.min(crewSize, plan0.length) > 1 ? 's' : ''} at a time; ${E.p.kind === 'animation' ? 'the places first, then every scene from the library; then one review and one fix round' : 'each scene is looked at and fixed before it is done'}`);
  // the icons and logos the rows named, looked up before the designers start (no search step for them)
  await readyIcons(E, list.map((x) => x.i)).catch((e) => console.error('[icons]', e.message.slice(0, 160)));

  // Strict Cache-Warm Gate: Designer 1 starts alone and writes cache; Designers 2..N wait for it
  let resolveWarm;
  const warmPromise = new Promise((ok) => { resolveWarm = ok; });
  let warmDone = false;
  const signalWarm = () => { if (!warmDone) { warmDone = true; resolveWarm(); } };

  for (const wave of waves) {
    const chunks = chunksOf(wave);
    let k = 0;
    await Promise.all(Array.from({ length: Math.min(crewSize, chunks.length) }, async (_, w) => {
      if (system && w > 0) {
        // Designers 2..N wait until Designer 1's first request is in the cache (about 12 s), or until it has finished
        await Promise.race([warmPromise, new Promise((ok) => setTimeout(ok, 12000))]);
      }
      while (k < chunks.length && !E.job.cancelled && !halt) {
        const c = chunks[k++];
        await build(c, w === 0 ? signalWarm : null);
      }
    }));
    if (E.job.cancelled || halt) break;
  }
  signalWarm(); // safety unlock
  if (reviewRuns && !halt && !E.job.cancelled) await reviewSeams();
  if (E.p.kind === 'animation') { try { newParts(E); } catch (e) { console.error('[new parts]', e.message.slice(0, 160)); } }
  if (E.job.cancelled) throw new Error('cancelled');
  if (halt) throw LOST.test(halt.message) ? Object.assign(new Error('the lead session is gone'), { lost: true }) : limitError(halt);
  return { reviewed: reviewRuns };
}
const graphicRows = (E, only = null) => E.sb.rows.map((r, i) => (r.piece === 'custom' && (!only || only.has(i)) ? i : -1)).filter((i) => i >= 0);
// a stock row with no picture found becomes a graphic scene (a builder designs it), never a plain text card
function stockToGraphic(E, only = null) {
  const plan = J(path.join(E.J0, 'edit', 'plan.json'), { scenes: [] }), out = [];
  E.sb.rows.forEach((r, i) => { if (/^stock/.test(String(r.piece)) && (!only || only.has(i)) && plan.scenes.find((x) => x.row === i)?.kind !== 'stock') { r.piece = 'custom'; delete r.stock; out.push(i); } });
  if (out.length) fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(E.sb, null, 1));
  return out;
}
const lead = (E, prompt, o) => call(E, prompt, { role: { lead: true }, model: LEAD_MODEL(), ...o }).catch((e) => { throw LIMIT.test(e.message) ? limitError(e) : e; });
// a new lead that reads the video as it is saved (its storyboard), when the old session cannot be found
async function relead(E, extra) {
  E.step('The editor is reading your saved video again (its earlier session is not on this Claude account)');
  const b = await lead(E, builtPrompt(E.p, extra.brief, E.sb, extra), { what: 'lead: reads the video', think: 2000, turns: 1 });
  E.lead = b?.session_id || null;
  E.p.editor = { ...(E.p.editor || {}), lead: E.lead, at: Date.now() };
}
// a step that resumes the lead's session: on a lost session, a new lead reads the video and the step runs once more
const withLead = async (E, extra, fn) => { try { return await fn(); } catch (e) { if (!(e.lost || LOST.test(e.message))) throw e; await relead(E, extra); return fn(); } };

// 2D Animation: the art director's checks (skills/2d-animation/review.md) and what recording found (plate/voice-report.json)
function animReviewNotes(E) {
  const checks = (() => { try { return fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', 'review.md'), 'utf8').trim(); } catch { return ''; } })();
  const report = J(path.join(E.d.ws, 'plate', 'voice-report.json'), []), flagged = (Array.isArray(report) ? report : []).map((r, i) => (r?.redone ? `- line ${i + 1}: ${r.redone}` : null)).filter(Boolean);
  return `${checks}\n\nThe voice report:\n${flagged.length ? flagged.join('\n') : '- every line recorded cleanly'}`;
}
// The body gate over the whole film (no AI): scenes that break a rule go back to their builders, twice at most. `zen finish` checks
// again, and a film that still breaks a rule never renders.
export async function bodyGate(E, extra) {
  if (E.p.kind !== 'animation') return;
  const { checkBody } = await import(pathToFileURL(path.join(ENGINE_DIR, 'cartoon', 'check-body.mjs')).href);
  for (let round = 0; round < 2; round++) {
    E.step('Checking every frame against the body rules');
    const g = await checkBody(E.hf); if (g.ok) return;
    const rows = [...new Set(g.faults.map((f) => f.row))].filter((i) => E.sb.rows[i]?.piece === 'custom');
    if (!rows.length) return;
    const fixes = rows.map((i) => ({ i, note: `The body gate failed on this scene. Fix every line, then look again:\n${g.lines.filter((l) => l.includes(`(scene ${i + 1})`)).slice(0, 12).join('\n')}` }));
    noteReview(E, 'body gate', fixes);
    E.step(`Sending ${fixes.length} scene${fixes.length > 1 ? 's' : ''} back: a body rule is broken`);
    await withLead(E, extra, () => crew(E, fixes));
  }
}

// The final review. fresh (default): a SHORT new conversation. Its system prompt is the builders' (the skill + this video in
// short, so it is read from the cache) and it works from look_video's pictures: it needs nothing from the lead's long planning
// chat, which every step of an old-style review sent again. ZANCUT_REVIEW=lead: the old way (a resume of the lead's chat).
// 2D: the reviewer reads the production script, the plan and its checks ONCE, while the builders work; every review of a built
// run then resumes that conversation (one at a time), so it starts at once and judges every scene against the script it knows.
export function primeReviewer(E, extra) {
  E.reviewer = lead(E, `You are this film's reviewer: you did not plan it or build it (the overview above is the director's plan).
${animReviewNotes(E)}

The production script (scene by scene; the spoken words are recorded):
${extra.animScript || '(none)'}

Read the script and the plan now and keep them in mind. The builders' scenes will come to you as soon as they are built. Answer with one word: ready.`,
  { what: 'reviewer: reads the script', think: 2000, turns: 1, system: crewSystem(E, extra) }).then((r) => r?.session_id || null).catch((e) => { console.error('[reviewer]', String(e.message).slice(0, 160)); return null; });
}
const inTurn = (E, fn) => { const p = (E.reviewQ || Promise.resolve()).then(fn); E.reviewQ = p.catch(() => {}); return p; };
export function review(E, extra, task, what) {
  if (E.p.kind === 'animation' && E.reviewer) return inTurn(E, async () => {
    const s = await E.reviewer;
    const t = `${task}\nApply the anatomy card strictly, but a logic or script problem comes first. Each note names the second, the person or thing, what is wrong and what to change.`;
    if (s) { try { return await lead(E, t, { what, think: THINK.review(), turns: 6, resume: s, system: crewSystem(E, extra) }); } catch (e) { if (E.job.cancelled || !LOST.test(e.message)) throw e; E.reviewer = null; } }
    return lead(E, `You are not building now: you are this video's reviewer. You did not plan it; the overview above is the plan. ${t}\n${animReviewNotes(E)}\n\nThe production script:\n${extra.animScript || '(none)'}`, { what, think: THINK.review(), turns: 6, system: crewSystem(E, extra) });
  });
  if (E.p.kind === 'animation') task += `
Apply the Universal Human Anatomy & Rigging Rules card in your system prompt strictly: a body mistake is always a fix. Start from look_video; use look on a shot only where a physical action (a hand-over, a rise, a landing) needs its before, contact and after frames to judge, or where the sheet shows a doubt. Compare the performance and the shot coverage with the plan. Each fix's note names the second, the person and the rule (like "at 2.4 s, the boy, H12: the card floats beside his hand"), then what to change.
${animReviewNotes(E)}`;
  if (REVIEW() === 'lead') return withLead(E, extra, () => lead(E, task, { what, think: THINK.review(), turns: 6, resume: E.lead, fork: REVIEW_FORK() }));
  return lead(E, `You are not building now: you are this video's reviewer. You did not plan it; the overview above is the plan. ${task}`, { what, think: THINK.review(), turns: 5, system: crewSystem(E, extra) });
}

// A review that answers with fixes: [{ i, note }] for the scenes keep() allows (at most max). Every answer is kept on the project
// (p.editor.reviews), so the usage report shows what the designers' own check missed.
async function askReview(E, extra, task, what, keep, max, which) {
  const idx = E.sb.rows.map((_, i) => i).filter((i) => keep(i) && E.sb.rows[i]?.piece === 'custom'), asked = askedFor(E, idx);
  const skipped = E.p.kind === 'animation' ? idx.map((i) => { const r = E.sb.rows[i], f = r.file && path.join(E.J0, r.file), xs = f && fs.existsSync(f) ? skippedParts(E.parts?.rows?.[i], fs.readFileSync(f, 'utf8')) : []; return xs.length ? `- scene ${i + 1}: ${skippedText(xs)}` : null; }).filter(Boolean) : [];
  const rv = await review(E, extra, `${task}${asked ? `\n${asked}` : ''}${skipped.length ? `\nClose library parts these scenes left out (check 9):\n${skipped.join('\n')}` : ''}
Then answer with ONE \`\`\`json block:
{"fixes": [{"scene": 4, "note": "what the builder must change, and why", "media": {"mine": "<their file>", "steps": [[word, second], …]}}]${asked ? `,
 "asked": [{"scene": 4, "what": "their instruction, in a few words", "done": true, "how": "one plain line: how the scene follows it, or what is missing"}]` : ''}}
${which}${asked ? ', or that ignore what the customer asked for them' : ''} (at most ${max}). An empty list when they hold together. "media" only when
a scene must show one of the customer's files that it does not show yet (its builder cannot add a file itself): name the file, and
for a screen recording the moment each spoken step shows. Use look on a scene only if one frame is not enough to judge it (each
look costs).${asked ? ' "asked": one line per instruction above that these scenes carry, judged on the frames.' : ''}`, what);
  let out = {}; try { out = JSON.parse(String(rv?.result || '').match(/\{[\s\S]*\}/)?.[0] || '{}'); } catch {}
  let fixes = (Array.isArray(out.fixes) ? out.fixes : []).map((x) => ({ i: Math.round(Number(x?.scene)) - 1, note: String(x?.note || '').slice(0, 800), media: x?.media })).filter((x) => keep(x.i) && E.sb.rows[x.i]?.piece === 'custom' && x.note).slice(0, max);
  fixes = await attachFiles(E, fixes);
  noteAsked(E, idx, out.asked, fixes);
  noteReview(E, what, fixes);
  return fixes;
}
// What the customer asked that these scenes must keep: their orders, their notes on these scenes' words and their files with
// their "where to use" notes. The reviewer judges each scene against them too, not only against the skill. '' = nothing asked.
function askedFor(E, idx) {
  const p = E.p, out = [], orders = ordersText(p);
  if (orders) out.push(`Their orders for the whole video: ${orders.slice(0, 1500)}`);
  for (const i of idx) {
    const r = E.sb.rows[i], notes = (p.transcript?.lines || []).filter((l) => (l.hint || '').trim() && l.from <= r.to && l.to >= r.from).map((l) => `"${l.hint.trim().slice(0, 300)}"`);
    if (notes.length) out.push(`Scene ${i + 1}, their note${notes.length > 1 ? 's' : ''} on its words: ${notes.join('; ')}`);
  }
  const files = (p.assets || []).filter((a) => !a.comment && a.role !== 'music').map((a) => `${a.original || a.file}${String(a.note || '').trim() ? ` ("${a.note.trim().slice(0, 200)}")` : ''}${idx.filter((i) => clipOf(p, E.sb.rows[i]) === a).map((i) => `, shown in scene ${i + 1}`).join('')}`);
  if (files.length) out.push(`Their files (and where they asked for them): ${files.join('; ')}`);
  // the director's own choices about their files, told to the customer (a part of a recording that shows an error left out and
  // that moment drawn instead…): judged on sense, not sent back as an ignored file
  const chose = (Array.isArray(E.sb.fileNotes) ? E.sb.fileNotes : []).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 6);
  if (chose.length) out.push(`What the director chose about their files, and told them why: ${chose.join(' | ')}`);
  return out.length ? `What the customer asked for (orders, not suggestions: a scene here that ignores one, or a file meant for it that it does not show or shows as a drawn copy, is a fix: name the instruction). Their real file always beats a drawing of it. A choice the director explained to them is kept only when the frames show it makes sense (a part of their recording that is wrong or off-topic, shown as a graphic instead) and they have not asked for that part as it is; otherwise it is a fix:\n- ${out.join('\n- ')}` : '';
}
// A reviewer's fix that gives a scene one of the customer's files: the row carries it ("media"), the page is built again for that
// scene (a screen recording cut to its words), and the builder is told it is now in the scene. A file it cannot attach (no such
// file, a screen recording without its moments) stays a note.
async function attachFiles(E, fixes) {
  const changed = [];
  for (const f of fixes) {
    const m = f.media, a = m?.mine ? clipOf(E.p, { media: { mine: String(m.mine) } }) : null;
    delete f.media; if (!a) continue;
    const r = E.sb.rows[f.i], was = r.media;
    r.media = { mine: mineName(a.file), ...(Array.isArray(m.steps) && m.steps.length ? { steps: m.steps } : {}) };
    if (missingSteps(E.p, r) || clipOf(E.p, r) !== a) { r.media = was; continue; }
    changed.push(f.i);
    f.note += `\nTheir file ${a.original || a.file} is now in your scene: \`.gx-media\`, the first element of root (full frame${/\.(mp4|mov|m4v|webm)$/i.test(a.file) ? ', cut to the scene\'s words: play it straight through' : ''}). Place it in your design and design around what it really shows; if your scene drew a copy of it, save_scene a new design.`;
  }
  if (changed.length) await E.lock(() => buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery, only: changed })).catch((e) => console.error('[review file]', String(e.message).slice(0, 160)));
  return fixes;
}
// the reviewer's line per customer instruction (kept on the storyboard, shown to the customer with it); a scene sent back for a
// missed one is marked "sent" (sent back to its builder with the note)
function noteAsked(E, idx, list, fixes) {
  if (!Array.isArray(list)) return;
  const keep = (E.sb.asked || []).filter((x) => !idx.includes(x.scene - 1)), sent = new Set(fixes.map((f) => f.i));
  const add = list.map((x) => ({ scene: Math.round(Number(x?.scene)), what: String(x?.what || '').trim().slice(0, 160), done: x?.done === true, how: String(x?.how || '').trim().slice(0, 300) }))
    .filter((x) => x.what && idx.includes(x.scene - 1)).map((x) => (!x.done && sent.has(x.scene - 1) ? { ...x, sent: true } : x));
  E.sb.asked = [...keep, ...add].sort((a, b) => a.scene - b.scene).slice(0, 20);
  fs.writeFileSync(path.join(E.J0, 'work', 'storyboard.json'), JSON.stringify(E.sb, null, 1));
}
function noteReview(E, what, fixes) {
  if (!E.p.editor) return;
  (E.p.editor.reviews ||= []).push({ at: Date.now(), what, fixes: fixes.map((x) => ({ scene: x.i + 1, note: x.note })) });
}

// ---------- Step 3: the whole video ----------
// what a plan was made for: the words of the first cut, the customer's cut and the setup. A different key = plan again.
function planKey(E) {
  const p = E.p, words = firstCutWords(E.J0).map((w) => w.text).join(' ');
  const what = JSON.stringify([words, p.transcript?.removed || [], p.trim?.ranges || [], p.designStyle, p.theme, p.format, p.kind, p.palette, p.pace, p.instructions || '', p.prompt || '']);
  return crypto.createHash('sha1').update(what).digest('hex').slice(0, 16);
}
// extra: { brief, reference, facts, words, screen }
export async function makeVideo(E, extra) {
  E.extra = extra;
  // A run stopped part-way (Claude's limit, a crash) carries on: the plan and the scenes already built are kept. Only when it
  // is the same video it was planned for: the same words, cut and setup (redoing Step 2 or changing the setup plans afresh).
  const key = planKey(E);
  const resume = Boolean(E.sb?.rows?.length) && E.p.editor?.partial === true && (!E.p.editor.key || E.p.editor.key === key);
  if (resume) E.step('Carrying on where the editor stopped: the plan and the finished scenes are kept');
  else {
    const sheet = await footageSheet(E);
    // the customer's video clips: what happens when in each (read once, kept on the file), so the director can pick each step's moment
    await clipLogs(E.d, E.p, { runQuery: E.runQuery, model: pricing().models.study || null, step: E.step }).catch((e) => console.error('[clip log]', String(e.message).slice(0, 160)));
    E.step('The editor is reading your video and planning it scene by scene');
    E.sb = null;
    const noVideo = !stock.stockKeys(); // stock clips need a Pexels or Pixabay key (the desktop app: the backend's)
    const first = message([{ type: 'text', text: leadPrompt(E.p, extra.brief, { ...extra, footage: !!sheet }) + (noVideo ? '\n\n(Stock video clips are not available here: never choose "stock-video" or a "media" of kind "video"; use a photo, the customer\'s own clip, or a graphic instead.)' : '') }, ...(sheet ? [jpeg(sheet)] : [])]);
    const scCount = Math.ceil(videoSecs(extra.words?.length ? extra.words : firstCutWords(E.J0)) / 4); // about one scene every 4 s
    let r = await lead(E, first, { what: 'lead: storyboard', think: THINK.lead(scCount), turns: 6 });
    E.lead = r?.session_id || null;
    if (!E.sb && E.lead) r = await lead(E, 'The storyboard is not saved yet: call save_storyboard with it now.', { what: 'lead: storyboard', think: THINK.lead(scCount), turns: 4, resume: E.lead });
    if (!E.sb) return null;
  }
  // built = finished its look-and-fix loop. A scene whose builder saved it but was cut off before it passed is checked and
  // finished from its own file (never one guessed by file name: after a new plan, scene 5 is another scene).
  const done = new Set(resume ? E.p.editor.done || [] : []);
  E.p.editor = { lead: E.lead, at: Date.now(), partial: true, key, done: [...done], steps: resume ? E.p.editor.steps || {} : {}, builders: resume ? E.p.editor.builders || {} : {}, reviewed: resume ? !!E.p.editor.reviewed : false, reviewedWindows: resume ? E.p.editor.reviewedWindows || [] : [] };
  await buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery });
  stockToGraphic(E);
  // test switch: plan only (the A/B/C builder comparison builds one plan several ways); the run stays "stopped part-way"
  if (process.env.ZANCUT_STOP_AFTER_PLAN === '1') return E.sb;
  await filmKit(E, extra);
  const needed = graphicRows(E).filter((i) => !done.has(i)).map((i) => (resume && E.sb.rows[i].file ? { i, again: true, note: 'This scene was saved but its check was cut off: look at it, fix what fails, and finish.' } : { i }));
  let built = null;
  if (E.p.kind === 'animation' && needed.length && !E.p.editor.reviewed && REVIEW() === 'fresh') primeReviewer(E, extra);
  if (needed.length) {
    if (resume) E.step(`Building ${needed.length} scene${needed.length > 1 ? 's' : ''} not finished yet; the finished ones are kept`);
    built = await withLead(E, extra, () => crew(E, needed));
  }
  // every scene built fresh and reviewed run by run (with the joins between runs): no second review of the whole video
  if (!resume && built?.reviewed) E.p.editor.reviewed = true;
  // the review needs the lead's memory of the video: a lead that is gone (another Claude account) reads it again first
  if (REVIEW() === 'lead' && !E.lead && (needed.length || !E.p.editor.reviewed)) await relead(E, extra);
  // the lead looks at the video and sends back what breaks its look
  // every scene was just built and reviewed in its run: no second review of the same work (also when a stopped run carried on)
  if (built?.reviewed && needed.length === graphicRows(E).length) E.p.editor.reviewed = true;
  const needsReview = !E.p.editor.reviewed || (needed.length > 0 && !(built?.reviewed && (!resume || needed.length === graphicRows(E).length)));
  if (needsReview) {
    const totalScenes = E.sb.rows.length;
    if (totalScenes > 30) {
      // Long video (3–10 min): 20-scene sliding windows with 1-scene overlap
      const windowSize = 20, windows = [];
      for (let s = 0; s < totalScenes; s += windowSize - 1) {
        const e = Math.min(totalScenes, s + windowSize);
        windows.push({ start: s, end: e });
        if (e >= totalScenes) break;
      }
      const reviewedWindows = new Set(E.p.editor?.reviewedWindows || []);
      for (let wIdx = 0; wIdx < windows.length; wIdx++) {
        if (reviewedWindows.has(wIdx)) continue;
        const { start, end } = windows[wIdx];
        E.step(`The editor is reviewing scenes ${start + 1}–${end} (${wIdx + 1} of ${windows.length})`);
        const rv = await review(E, extra, `Review scenes ${start + 1} through ${end} of the video. Call look_video with from ${start + 1} and to ${end} to see their frames and joins (and how code measured each join).
Then answer with ONE \`\`\`json block:
{"fixes": [{"scene": ${start + 2}, "note": "what the builder must change, and why"}]}
Only scenes in this window (${start + 1}–${end}) that clearly break the design system's rules, are unfinished, do not act out their words, or jump at joins (name what to carry on from the scene before: its ground, its shape, the place). A join that code measured as a jump is a fix unless the picture shows it is meant. An empty list when they hold together (at most 4).`, `lead: review ${start + 1}-${end}`);
        let fixes = []; try { fixes = JSON.parse(String(rv?.result || '').match(/\{[\s\S]*\}/)?.[0] || '{}').fixes || []; } catch {}
        fixes = oneEach(fixes.map((x) => ({ i: Math.round(Number(x.scene)) - 1, note: String(x.note || '').slice(0, 800) })).filter((x) => x.i >= start && x.i < end && E.sb.rows[x.i]?.piece === 'custom' && x.note)).slice(0, 4);
        noteReview(E, `lead: review ${start + 1}-${end}`, fixes);
        if (fixes.length) {
          E.step(`The editor sends ${fixes.length} scene${fixes.length > 1 ? 's' : ''} in window ${wIdx + 1} back to be improved`);
          await withLead(E, extra, () => crew(E, fixes));
        }
        reviewedWindows.add(wIdx);
        E.p.editor = { ...(E.p.editor || {}), reviewedWindows: [...reviewedWindows] };
      }
    } else {
      E.step('The editor is looking at the whole video');
      const rv = await review(E, extra, `Every scene is built. Call look_video once to see one frame of each, in order, and every join between two graphic scenes (with how code measured each join in pixels).
Then answer with ONE \`\`\`json block:
{"fixes": [{"scene": 4, "note": "what the builder must change, and why"}]}
Only scenes that clearly break the design system's rules, are unfinished, do not act out their words, do not belong to this
video's look and motion, or jump at the join from the scene before (name what to carry on from it: its ground, its shape, the place) (at most 8). A join that code measured as a jump is a fix unless the picture shows it is meant. An empty list when the video holds together. Use look on a scene only if one frame is not
enough to judge it (each look costs).`, 'lead: review');
      let fixes = []; try { fixes = JSON.parse(String(rv?.result || '').match(/\{[\s\S]*\}/)?.[0] || '{}').fixes || []; } catch {}
      fixes = oneEach(fixes.map((x) => ({ i: Math.round(Number(x.scene)) - 1, note: String(x.note || '').slice(0, 800) })).filter((x) => E.sb.rows[x.i]?.piece === 'custom' && x.note)).slice(0, 8);
      noteReview(E, 'lead: review', fixes);
      if (fixes.length) { E.step(`The editor sends ${fixes.length} scene${fixes.length > 1 ? 's' : ''} back to be improved`); await withLead(E, extra, () => crew(E, fixes)); }
    }
    E.p.editor.reviewed = true;
  }
  await bodyGate(E, extra);
  E.p.editor.partial = false;
  return E.sb;
}

// ---------- a part planned again (words from–to), the rest kept as built ----------
// For a part whose plan no longer fits its words (the timings were wrong). The lead plans just that part on the real
// times; only its new scenes are built (the "carry on" path: a Retry after a stop continues them, it does not plan again).
export async function replanVideo(E, extra, from, to) {
  E.extra = extra;
  if (!E.sb?.rows?.length) throw new Error('no storyboard');
  const hit = E.sb.rows.map((r, i) => [r, i]).filter(([r]) => r.to >= from && r.from <= to);
  if (!hit.length) return [];
  const a = hit[0][0].from, b = hit.at(-1)[0].to, w = extra.words || [];
  E.step(`The editor is planning words ${a}–${b} again on their real timings`);
  await withLead(E, extra, () => lead(E, replanPrompt(E.p, E.sb, a, b, w), { role: { lead: true, range: { from: a, to: b } }, what: 'lead: re-plan', think: THINK.lead(hit.length), turns: 6, resume: E.lead }));
  if (!E.newRows?.length) throw Object.assign(new Error('The editor could not plan that part again. Press Retry.'), { customer: true });
  E.p.editor = { ...(E.p.editor || {}), partial: true, steps: {}, done: E.sb.rows.map((r, i) => i).filter((i) => !E.newRows.includes(i)) }; // new scene numbers: new step counts
  await buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery });
  stockToGraphic(E, new Set(E.newRows));
  await withLead(E, extra, () => crew(E, graphicRows(E, new Set(E.newRows)).map((i) => ({ i }))));
  E.p.editor.partial = false;
  return E.newRows;
}

// ---------- a change round (a Step 3 scene comment, Step 4 timed comments) ----------
// notes: [{ where, text, image (a picture in the workspace) }] → the rows that changed
export async function changeVideo(E, notes, extra) {
  E.extra = extra;
  if (!E.sb?.rows?.length) throw new Error('no storyboard');
  // the pictures the customer drew or attached, as pictures the lead really looks at (a big one is made smaller first)
  const pics = [];
  for (const [k, x] of notes.entries()) {
    if (x.image && fs.existsSync(path.join(E.d.ws, x.image))) pics.push([`Their drawing on the frame for note ${k + 1} (red and yellow marks are theirs):`, path.join(E.d.ws, x.image)]);
    for (const a of x.attach || []) if (a.role === 'image' && /\.(png|jpe?g|webp)$/i.test(a.file) && fs.existsSync(path.join(E.d.assets, a.file))) pics.push([`The picture "${a.name || a.file}" attached to note ${k + 1}:`, path.join(E.d.assets, a.file)]);
  }
  const small = async (file, n) => { const out = path.join(E.d.ws, 'qa', `att-${n}.jpg`); fs.mkdirSync(path.dirname(out), { recursive: true }); try { await run('ffmpeg', ['-v', 'error', '-y', '-i', file, '-vf', 'scale=1600:1600:force_original_aspect_ratio=decrease', '-frames:v', '1', '-q:v', '3', out]); return jpeg(out); } catch { return null; } };
  const evidence = [];
  for (const [n, [label, file]] of pics.slice(0, 8).entries()) { const b = await small(file, n); if (b) evidence.push({ type: 'text', text: label }, b); }
  const blocks = (t) => message([{ type: 'text', text: t }, ...evidence]);
  await clipLogs(E.d, E.p, { runQuery: E.runQuery, model: pricing().models.study || null, step: E.step }).catch((e) => console.error('[clip log]', String(e.message).slice(0, 160))); // a video made before clips had their moments
  const ask = changePrompt(E.p, E.sb, notes.map((x) => ({ ...x, image: !!x.image })));
  E.changed = new Map(); E.global = false; E.report = null;
  E.step('The editor is reading your notes');
  const changeThink = THINK.lead(notes.length);
  if (E.lead) { try { await lead(E, blocks(ask), { what: 'lead: changes', think: changeThink, turns: 8, resume: E.lead }); } catch (e) { if (E.job.cancelled || e.customer) throw e; console.error('[editor] resume failed:', e.message.slice(0, 200)); E.lead = null; } }
  if (!E.lead) {
    // its session is gone (an older video, or another computer): a new lead reads what was built, then the notes
    const b = await lead(E, builtPrompt(E.p, extra.brief, E.sb, extra), { what: 'lead: reads the video', think: 2000, turns: 1 });
    E.lead = b?.session_id || null;
    E.p.editor = { lead: E.lead, at: Date.now() };
    await lead(E, blocks(ask), { what: 'lead: changes', think: changeThink, turns: 8, resume: E.lead });
  }
  if (!E.changed.size) { if (E.global) await buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery, only: [] }); return []; } // only the mix changed
  const rows = [...E.changed.keys()].sort((a, b) => a - b);
  await buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery, only: rows });
  stockToGraphic(E, new Set(rows));
  const g = graphicRows(E, new Set(rows));
  if (g.length) await withLead(E, extra, () => crew(E, g.map((i) => ({ i, note: E.changed.get(i) || 'Rebuild this scene from its new row.' }))));
  // the editor looks again at what the notes point to, on the rebuilt frames, before the render (a note fixed in one scene can
  // still show in another: two scenes made the same mistake); still wrong = one more round, then it renders
  if (g.length && E.lead && !E.job.cancelled && process.env.ZANCUT_RECHECK !== '0' && E.p.kind !== 'animation') {
    E.step('The editor checks your notes on the new frames');
    const first = E.changed; E.changed = new Map();
    const recheck = `The scenes are rebuilt. Look again at what each note points to, on the new frames (look_video from/to those scenes; a note on "the whole video" = every scene, from 1 to ${E.sb.rows.length}):
${notes.map((x, k) => `${k + 1}. ${x.where}: "${x.text}"`).join('\n')}
For each note: is it fixed everywhere it shows? A note still not fixed (in any scene): call change_scenes again with what is still wrong and in which scene. All fixed: answer one line, "fixed", and nothing else.`;
    try { await lead(E, recheck, { what: 'lead: re-check', think: 2000, turns: 4, resume: E.lead }); } catch (e) { if (E.job.cancelled || e.customer) throw e; console.error('[editor] re-check:', e.message.slice(0, 200)); }
    const again = [...E.changed.keys()].sort((a, b) => a - b);
    if (again.length) {
      E.step(`The editor sends scene${again.length > 1 ? 's' : ''} ${again.map((i) => i + 1).join(', ')} back: a note was not fixed yet`);
      await buildPlan(E.d, E.p, E.sb, { step: E.step, ask: E.ask, runQuery: E.runQuery, only: again });
      stockToGraphic(E, new Set(again));
      const g2 = graphicRows(E, new Set(again));
      if (g2.length) await withLead(E, extra, () => crew(E, g2.map((i) => ({ i, note: E.changed.get(i) || 'Rebuild this scene from its new row.' }))));
    }
    for (const [k, v] of E.changed) first.set(k, v);
    E.changed = first;
    return [...new Set([...rows, ...again])].sort((a, b) => a - b);
  }
  return rows;
}
