// Skill adoption: Zancut learns from its customers' change rounds. After every round the editor reports, note by note, the
// cause and whether it was our mistake (editor.mjs report). A learner (Opus) then judges each note: a mistake of the system
// that will happen again in other videos (a proposal), the customer's own taste (their style memory keeps it), the customer
// being wrong, or a one-off (the footage). A proposal names the rule or the code to change, with its references; the same
// lesson from more videos is counted on the one proposal. The owner reviews them in Admin → Skill adoption: Approve applies a
// skill rule at once (the prompt checker runs; on failure it is put back); a code change becomes a ready prompt for Claude Code.
//   data/adoption.json = { items: [proposal], rounds: [{ at, projectId, name, version, notes, ours, taste }] }
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { DATA_DIR, SKILLS_DIR, APP_DIR, MODE } from './config.mjs';

const FILE = path.join(DATA_DIR, 'adoption.json');
const load = () => { try { return JSON.parse(fs.readFileSync(FILE, 'utf8')); } catch { return { items: [], rounds: [] }; } };
const save = (db) => { fs.mkdirSync(DATA_DIR, { recursive: true }); fs.writeFileSync(`${FILE}.tmp`, JSON.stringify(db, null, 1)); fs.renameSync(`${FILE}.tmp`, FILE); };
const id = () => `a${Date.now().toString(36)}${Math.random().toString(36).slice(2, 6)}`;
const day = (t) => new Date(t).toISOString().slice(0, 10);
const J = (t) => { try { return JSON.parse(String(t).match(/\{[\s\S]*\}/)?.[0] || ''); } catch { return null; } };

// The desktop app: every lesson (new, or seen again) also goes to the owner's Admin → CTO → Lessons on the backend,
// through the CTO's outbox (sent when online). The same id again counts up there.
function toOwner(x) {
  if (MODE !== 'desktop') return;
  import('./cto.mjs').then((c) => c.toCloud('/api/desktop/lesson', {
    kind: x.change?.kind === 'code' ? 'code' : 'skill', key: x.key || x.id, title: x.title,
    body: { scenario: x.scenario, check: x.check, general: x.general, change: x.change, prompt: x.codePrompt || undefined },
  })).catch(() => {});
}

// the skill files a rule can go into (relative to skills/), with their headings, so the learner names a real place
function skillMap(style) {
  const files = [`${style}/core-director.md`, `${style}/core-graphic.md`, `${style}/talking-head.md`, `${style}/storytelling.md`, `${style}/interview-broll.md`, 'shared-making.md', 'sound-system.md', 'check.md'];
  return files.filter((f) => fs.existsSync(path.join(SKILLS_DIR, f))).map((f) => `- ${f}: ${(fs.readFileSync(path.join(SKILLS_DIR, f), 'utf8').match(/^## .+$/gm) || []).map((h) => h.slice(3)).join(' | ') || '(no sections)'}`).join('\n');
}

function learnPrompt(p, notes, report, open, done) {
  return `You are Zancut's head of quality. A customer reviewed a video and asked for changes; the editor diagnosed each note.
Judge every note: is it a mistake of OUR SYSTEM that would happen again in other customers' videos (a rule missing or wrong in a
design-system skill, a prompt, or the code), the customer's own TASTE (one person's preference: not a lesson for everyone), the
CUSTOMER BEING WRONG (it would make videos worse; say why), or a ONE-OFF (this footage, this script)? Many customers, many
opinions: adopt only what clearly makes every video better. A critical craft failure (sync, a covered face, unreadable text, sound
over the voice, a frame left empty) is always "system" when our pipeline caused it.

## The video
"${p.name}" · ${p.kind || 'talking'} · ${p.format || '9:16'} · design system ${p.designStyle || 'glossy'} · ${p.theme || 'dark'} · language ${p.language || 'auto'}

## The customer's notes and the editor's diagnosis
${notes.map((n, k) => { const r = report.find((x) => x.note === k + 1) || {}; return `${k + 1}. "${String(n.text).slice(0, 800)}" (${n.where})\n   cause: ${r.cause || '?'} · ours: ${r.ours ?? '?'} · ${r.severity || '?'} · found: ${r.found || '-'} · did: ${r.did || '-'}${r.couldnt ? ` · could not: ${r.couldnt}` : ''}`; }).join('\n')}

## Where a rule can go (skills/<file>: its sections)
${skillMap(p.designStyle || 'glossy')}

## Lessons already known (when a note teaches the same thing, name its id in "same" instead of writing it again)
Open, waiting for review:
${open.map((x) => `- ${x.id}: ${x.title}`).join('\n') || '(none)'}
Already done (applied, or a code task): when the note shows one of these did not work, write a new lesson saying so; else "same"
${done.map((x) => `- ${x.id}: ${x.title}`).join('\n') || '(none)'}

## Answer: one JSON object
{"lessons": [{"note": 1, "verdict": "system | taste | customer-wrong | one-off", "why": "one or two sentences",
  "same": "an open lesson's id, or null",
  "title": "the lesson in a short line (system only)",
  "scenario": "the general situation, never this video: the kind of video and setup, the condition, what the system does wrong
  and what a viewer sees (e.g. 'A talking-head video in Bangla with music under the voice: the transcriber skips stretches, so
  graphics land seconds after their words')",
  "check": "how any AI or engineer can check the system for it: what to run or look at, and what right looks like",
  "general": "why it will happen in other videos",
  "change": {"kind": "skill | code", "file": "shared-making.md (skill: a file from the list)", "section": "the section it goes
  under", "text": "the exact rule to add, written like the skill's own rules"},
  "codePrompt": "code only: a complete instruction for a developer (what to change, in which file of the Zancut repo, and how to check it)"}]}`;
}

// After a change round: the round is counted, then the learner judges its notes (it runs inside the job: runQuery charges it)
export async function learnFrom({ p, version, notes, report, runQuery, model }) {
  const db = load(), ours = (report || []).filter((x) => x.ours).length;
  db.rounds.push({ at: Date.now(), projectId: p.id, name: p.name, version: version || null, notes: notes.length, ours, taste: (report || []).filter((x) => x.cause === 'taste').length });
  db.rounds = db.rounds.slice(-5000); save(db);
  if (!report?.length || !notes.length) return 0;
  const open = db.items.filter((x) => x.status === 'open').slice(-60), done = db.items.filter((x) => ['applied', 'code-task', 'done'].includes(x.status)).slice(-60);
  let out = null;
  try { out = J((await runQuery(learnPrompt(p, notes, report, open, done), model, { tools: [], maxTurns: 1, think: 4000, what: 'learn: lessons' }))?.result); } catch (e) { console.error('[learn]', e.message.slice(0, 160)); return 0; }
  const fresh = load(); let added = 0;
  for (const l of out?.lessons || []) {
    const n = notes[(Number(l.note) || 1) - 1] || notes[0];
    const ref = { at: Date.now(), projectId: p.id, name: p.name, version: version || null, where: n?.where || '', comment: String(n?.text || '').slice(0, 600), verdict: l.verdict, why: String(l.why || '').slice(0, 400) };
    if (l.verdict !== 'system') { fresh.declined = [...(fresh.declined || []), ref].slice(-500); continue; } // taste, customer-wrong, one-off: counted, not adopted
    const same = fresh.items.find((x) => x.id === l.same && x.status !== 'rejected');
    if (same) { same.refs.push(ref); same.seen = same.refs.length; same.updatedAt = Date.now(); toOwner(same); continue; }
    const kind = l.change?.kind === 'code' ? 'code' : 'skill';
    fresh.items.push({ id: id(), createdAt: Date.now(), updatedAt: Date.now(), status: 'open', title: String(l.title || 'Lesson').slice(0, 160), scenario: String(l.scenario || l.issue || '').slice(0, 900), check: String(l.check || '').slice(0, 700), general: String(l.general || '').slice(0, 500),
      change: kind === 'skill' ? { kind, file: String(l.change?.file || 'shared-making.md').replace(/\.\.|^\//g, ''), section: String(l.change?.section || '').slice(0, 120), text: String(l.change?.text || '').slice(0, 1500) } : { kind },
      codePrompt: kind === 'code' ? String(l.codePrompt || '').slice(0, 4000) : '', refs: [ref], seen: 1 });
    toOwner(fresh.items.at(-1));
    added++;
  }
  save(fresh);
  return added;
}

// ---------- Admin ----------
export function view() {
  const db = load(), days = {};
  const bump = (t, k, n = 1) => { const d = day(t); days[d] ||= { day: d, rounds: 0, notes: 0, ours: 0, lessons: 0, declined: 0 }; days[d][k] += n; };
  for (const r of db.rounds) { bump(r.at, 'rounds'); bump(r.at, 'notes', r.notes); bump(r.at, 'ours', r.ours); }
  for (const x of db.items) bump(x.createdAt, 'lessons');
  for (const x of db.declined || []) bump(x.at, 'declined');
  return { days: Object.values(days).sort((a, b) => b.day.localeCompare(a.day)).slice(0, 30), items: db.items.slice().sort((a, b) => (b.status === 'open') - (a.status === 'open') || b.updatedAt - a.updatedAt), declined: (db.declined || []).slice(-50).reverse() };
}
export function edit(itemId, body) {
  const db = load(), x = db.items.find((y) => y.id === itemId); if (!x) return null;
  for (const [k, n] of [['title', 160], ['scenario', 900], ['check', 700]]) if (typeof body[k] === 'string') x[k] = body[k].slice(0, n);
  if (x.change.kind === 'skill') for (const k of ['file', 'section', 'text']) if (typeof body[k] === 'string') x.change[k] = body[k].slice(0, k === 'text' ? 1500 : 160).replace(/\.\./g, '');
  if (typeof body.codePrompt === 'string') x.codePrompt = body.codePrompt.slice(0, 4000);
  x.edited = true; x.updatedAt = Date.now(); save(db); return x;
}
const check = () => new Promise((ok) => execFile('node', [path.join(APP_DIR, 'scripts', 'check-prompts.mjs')], { cwd: APP_DIR, timeout: 300000, maxBuffer: 1 << 24 }, (e, so, se) => ok({ ok: !e, out: String(so || se || e?.message || '').split('\n').filter(Boolean).slice(-4).join('\n') })));
// Approve: a skill rule goes in at the end of its section (or at the end of the director's part of the file); the prompt
// checker must pass or the file is put back. A code lesson becomes a task: its prompt is for Claude Code.
export async function approve(itemId) {
  const db = load(), x = db.items.find((y) => y.id === itemId); if (!x || x.status !== 'open') return { error: 'Not an open lesson.' };
  if (x.change.kind === 'code') { x.status = 'code-task'; x.updatedAt = Date.now(); save(db); return { item: x }; }
  const file = path.join(SKILLS_DIR, x.change.file);
  if (!file.startsWith(SKILLS_DIR) || !fs.existsSync(file)) return { error: `skills/${x.change.file} does not exist: edit the file name.` };
  const before = fs.readFileSync(file, 'utf8'), rule = `\n- ${x.change.text.trim().replace(/^- /, '')} <!-- adopted ${day(Date.now())}: ${x.id} -->\n`;
  let after = before;
  const h = x.change.section ? before.search(new RegExp(`^#{2,3} ${x.change.section.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')}\\s*$`, 'm')) : -1;
  if (h >= 0) { const eol = before.indexOf('\n', h) + 1 || before.length, nx = before.slice(eol).search(/^#{1,3} |^<!-- (?:graphic|director|both) -->/m), at = nx < 0 ? before.length : eol + nx; after = `${before.slice(0, at).replace(/\n+$/, '')}${rule}\n${before.slice(at)}`; }
  else { const g = before.indexOf('<!-- graphic -->'); after = g < 0 ? `${before.replace(/\n+$/, '')}${rule}` : `${before.slice(0, g).replace(/\n+$/, '')}${rule}\n${before.slice(g)}`; }
  fs.writeFileSync(file, after);
  const c = await check();
  if (!c.ok) { fs.writeFileSync(file, before); x.status = 'open'; x.lastError = c.out; save(db); return { error: `The prompt checker failed, the file was put back:\n${c.out}` }; }
  Object.assign(x, { status: 'applied', appliedAt: Date.now(), updatedAt: Date.now(), lastError: null }); save(db);
  return { item: x };
}
export function setStatus(itemId, status) {
  const db = load(), x = db.items.find((y) => y.id === itemId); if (!x) return null;
  x.status = status; x.updatedAt = Date.now(); save(db); return x;
}
// lessons found outside a customer round (an engineer's own diagnosis): recorded the same way, with their state
export function record(item) { const db = load(); const x = { id: id(), createdAt: Date.now(), updatedAt: Date.now(), seen: (item.refs || []).length || 1, refs: [], ...item }; db.items.push(x); save(db); return x; }

// ---------- Missing parts: what 2D Animation scripts ask for that the engine cannot draw yet ----------
// The animation planner shows those moments the simplest way and names the part (skills/2d-animation/script.md "missing").
// One item per part (key `part-<part>`, the same on every install, so the cloud counts them together), one count per film:
// Admin sees what customers want most; Approve makes it a code task with its prompt.
export const PARTS = { walk: 'walking', run: 'running', jump: 'jumping', 'sit-stand': 'sitting down and standing up', dance: 'dancing',
  touch: 'people touching (a hug, a handshake, a push, a fight)', crowd: 'a crowd', 'more-people': 'more than 4 people on screen',
  place: 'more than one place in a film', animal: 'animals', vehicle: 'vehicles', thing: 'things the set kit cannot draw',
  time: 'the time of day changing', other: 'other things' };
const partPrompt = (part, x) => `Zancut 2D Animation (branch 2d-animation): customers' scripts ask for ${PARTS[part]}, and engine/cartoon cannot draw it yet, so the animation planner shows those moments in a simpler way (a close shot, a title card, a voice off screen). It was asked for in ${x.seen} film${x.seen > 1 ? 's' : ''}. What the scripts wanted:
${x.refs.slice(-12).map((r) => `- ${r.comment}`).join('\n')}

Read docs/2D-ANIMATION-PLAN.md first. Plan how engine/cartoon can draw ${PARTS[part]} within the body rules (the frame gate engine/cartoon/check-body.mjs must keep passing), show the owner the plan and wait for a yes. After building it: node scripts/cartoon-test.mjs, then teach it in skills/2d-animation/core-graphic.md, node scripts/check-prompts.mjs, and mark this item done in Admin.`;
export function wantParts({ p, missing }) {
  if (!missing?.length) return 0;
  const db = load(); let added = 0;
  for (const part of [...new Set(missing.map((m) => (PARTS[m.part] ? m.part : 'other')))]) {
    const what = missing.filter((m) => (PARTS[m.part] ? m.part : 'other') === part).map((m) => m.what).filter(Boolean).slice(0, 3).join(' · ').slice(0, 600);
    const key = `part-${part}`, ref = { at: Date.now(), projectId: p.id, name: p.name, version: null, where: 'animation script', from: 'script', comment: what || PARTS[part] };
    let x = db.items.find((y) => y.key === key && ['open', 'code-task'].includes(y.status));
    if (x?.refs.some((r) => r.projectId === p.id)) { Object.assign(x.refs.find((r) => r.projectId === p.id), { comment: ref.comment, at: ref.at }); continue; } // the same film again: counted once
    if (!x) { x = { id: id(), key, createdAt: Date.now(), status: 'open', title: `Build for 2D Animation: ${PARTS[part]}`, change: { kind: 'code' }, refs: [] }; db.items.push(x); added++; }
    x.refs.push(ref); x.seen = x.refs.length; x.updatedAt = Date.now();
    x.scenario = `2D Animation scripts ask for ${PARTS[part]}, but the engine cannot draw it yet, so those moments are shown in a simpler way. Asked for in ${x.seen} film${x.seen > 1 ? 's' : ''}.`;
    x.check = 'node scripts/cartoon-test.mjs passes; a test film whose script has it shows it; it is taught in skills/2d-animation/core-graphic.md.';
    x.general = 'Every customer whose story needs it gets a simpler film until it is built.';
    if (!x.edited) x.codePrompt = partPrompt(part, x);
    toOwner(x);
  }
  save(db);
  return added;
}
