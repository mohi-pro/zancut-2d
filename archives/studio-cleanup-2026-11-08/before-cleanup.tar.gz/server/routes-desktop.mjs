// What the Zancut desktop app talks to on the cloud server: login, account, starting a job (counts toward the
// plan), and the AI relay. The relay forwards Claude API calls with the server's API key, so the key never leaves the
// server, and counts every token against the customer's account.
import crypto from 'node:crypto';
import express from 'express';
import { customAlphabet } from 'nanoid';
import * as users from './users.mjs';
import { USING_API_KEY } from './config.mjs';
import { usdToCredits, planInfo } from './pricing.mjs';
import * as style from './style.mjs';
import * as cto from './cto.mjs';
import * as reports from './reports.mjs';

const newId = customAlphabet('abcdefghijkmnpqrstuvwxyz23456789', 14);
const ANTHROPIC = process.env.ANTHROPIC_BASE_URL_UPSTREAM || 'https://api.anthropic.com';
// Estimated $ per million tokens for the admin portal. Defaults: Claude Opus 5.5 ($4 in, $20 out, $0.20 cache read;
// cache writes estimated at 2x input for the 1-hour cache the engine uses). Override if you switch models.
const PRICE_IN = Number(process.env.ZANCUT_PRICE_IN || 4);
const PRICE_OUT = Number(process.env.ZANCUT_PRICE_OUT || 20);
const PRICE_CACHE_READ = Number(process.env.ZANCUT_PRICE_CACHE_READ || 0.2);
const PRICE_CACHE_WRITE = Number(process.env.ZANCUT_PRICE_CACHE_WRITE || PRICE_IN * 2);

const jobs = new Map(); // job id → { userId, entry }

// Web jobs get a one-job pass instead of the real API key, so nothing the AI runs can read the key.
// Usage for these is recorded from the engine's own result, so the relay doesn't count it again.
const jobPasses = new Map(); // pass → userId
export function issueJobPass(userId) {
  const pass = `zcj_${crypto.randomBytes(32).toString('hex')}`;
  jobPasses.set(pass, userId);
  return pass;
}
export const revokeJobPass = (pass) => jobPasses.delete(pass);

const bearer = (req) => (req.headers['x-api-key'] || (req.headers.authorization || '').replace(/^Bearer\s+/i, '') || '').trim();

export default function desktopRoutes(app) {
  const r = express.Router();

  r.post('/login', express.json(), (req, res) => {
    const key = `desktop|${String(req.body?.email || '').trim().toLowerCase()}|${req.ip}`;
    try {
      users.checkLock(key);
      let u;
      try { u = users.signIn(req.body || {}); } catch (e) { users.noteFail(key); throw e; }
      users.clearFails(key);
      const pu = users.publicUser(u);
      if (!pu.plan.desktop && u.role !== 'admin') return res.status(403).json({ error: `The desktop app is included in Creator and Agency. Your plan is ${pu.plan.name}.`, code: 'plan' });
      res.json({ token: users.createDesktopToken(u, req.body.device), user: pu, credits: users.balance(u), relay: USING_API_KEY });
    } catch (e) { res.status(400).json({ error: e.message }); }
  });

  const auth = (req, res, next) => {
    req.user = users.fromDesktopToken(bearer(req));
    if (!req.user) return res.status(401).json({ error: 'Please sign in again.' });
    next();
  };

  // the CTO on a customer's computer sends what it fixed or could not fix: it joins the owner's list (Admin → CTO)
  r.post('/cto', express.json({ limit: '64kb' }), auth, (req, res) => { try { cto.fromDesktop(req.user, req.body || {}); res.json({ ok: true }); } catch (e) { res.status(400).json({ error: e.message }); } });
  // a customer's bug report from the desktop app (with what its CTO found there): Admin → Reports, and Telegram
  r.post('/report', express.json({ limit: '10mb' }), auth, (req, res) => { try { res.json(reports.fromDesktop(req.user, req.body || {})); } catch (e) { res.status(e.status === 429 ? 429 : 400).json({ error: e.message }); } });

  r.get('/me', auth, (req, res) => res.json({ user: users.publicUser(req.user), credits: users.balance(req.user), relay: USING_API_KEY }));

  // Called before each AI run on the desktop. Counts one edit and opens a job the relay adds tokens to.
  r.post('/job-start', express.json(), auth, (req, res) => {
    const b = req.body || {};
    const project = { id: String(b.projectId || '').slice(0, 40), type: b.type === 'reel' ? 'reel' : 'youtube', mode: b.mode === 'faceless' ? 'faceless' : 'face' };
    const kind = b.kind === 'refine' ? 'refine' : 'edit';
    // own = the desktop app runs the AI on the customer's own Claude plan. Honoured only when this server has no API key to relay.
    const no = users.cannotStart(req.user, project, kind, { own: b.own === true && !USING_API_KEY });
    if (no) return res.status(402).json(no);
    users.claimTrial(req.user, project);
    users.countEdit(req.user);
    const id = newId();
    users.recordUsage(req.user, { projectId: req.body.projectId || null, kind: req.body.kind || 'edit', source: 'desktop' });
    jobs.set(id, { userId: req.user.id, entry: req.user.jobs.at(-1) });
    res.json({ jobId: id, credits: users.balance(req.user) });
  });

  r.post('/job-end', express.json(), auth, (req, res) => {
    const j = jobs.get(req.body.jobId);
    if (j && j.userId === req.user.id) { j.entry.ok = req.body.ok !== false; users.persist(); jobs.delete(req.body.jobId); }
    res.json({ ok: true });
  });

  // Style memory for the desktop app (stored on the cloud account; learning runs here on the server).
  r.get('/style', auth, (req, res) => res.json(style.memoryOf(req.user)));
  r.put('/style', express.json({ limit: '20kb' }), auth, (req, res) => {
    const b = req.body || {};
    res.json(style.setMemory(req.user, { ...(typeof b.enabled === 'boolean' ? { enabled: b.enabled } : {}), ...(Array.isArray(b.items) ? { items: b.items } : {}) }));
  });
  r.delete('/style', auth, (req, res) => res.json(style.clearMemory(req.user)));
  r.post('/style/learn', express.json({ limit: '64kb' }), auth, (req, res) => {
    const notes = (Array.isArray(req.body?.notes) ? req.body.notes : []).slice(0, 30)
      .map((n) => ({ text: typeof n?.text === 'string' ? n.text.slice(0, 500) : '', whole: n?.whole === true, drawing: n?.drawing === true }))
      .filter((n) => n.text.trim());
    const v = req.body?.video || {};
    const video = { type: v.type === 'reel' ? 'reel' : 'youtube', mode: v.mode === 'faceless' ? 'faceless' : 'face', theme: v.theme === 'dark' ? 'dark' : 'light' };
    const projectId = typeof req.body?.projectId === 'string' ? req.body.projectId.slice(0, 40) : null;
    if (notes.length) style.learn(req.user, notes, video, { projectId, source: 'desktop' });
    res.json({ ok: true });
  });

  app.use('/api/desktop', r);

  const relayAuth = (req, res, next) => {
    const key = bearer(req);
    const passUser = jobPasses.get(key);
    // Job passes only work from this machine (the engine runs here).
    if (passUser && ['127.0.0.1', '::1', '::ffff:127.0.0.1'].includes(req.socket.remoteAddress)) {
      req.user = users.byId(passUser);
      req.internal = true;
      return next();
    }
    return auth(req, res, next);
  };

  // AI relay: the desktop engine uses ANTHROPIC_BASE_URL=<server>/api/ai with its desktop token as the API key.
  app.use('/api/ai', express.raw({ type: '*/*', limit: '50mb' }), relayAuth, async (req, res) => {
    if (!USING_API_KEY) return res.status(503).json({ type: 'error', error: { type: 'api_error', message: 'The Zancut AI relay is not set up on this server yet.' } });
    if (!req.internal && !req.headers['x-zancut-job'] && users.cannotStart(req.user, { id: '' })) return res.status(402).json({ type: 'error', error: { type: 'permission_error', message: 'No AI edits left on this plan.' } });
    const headers = { 'x-api-key': process.env.ANTHROPIC_API_KEY, 'content-type': req.headers['content-type'] || 'application/json' };
    for (const h of ['anthropic-version', 'anthropic-beta', 'accept']) if (req.headers[h]) headers[h] = req.headers[h];
    let upstream;
    try {
      upstream = await fetch(ANTHROPIC + req.originalUrl.replace(/^\/api\/ai/, ''), {
        method: req.method, headers, body: ['GET', 'HEAD'].includes(req.method) ? undefined : req.body,
      });
    } catch (e) {
      return res.status(502).json({ type: 'error', error: { type: 'api_error', message: `Relay could not reach the AI: ${e.message}` } });
    }
    res.status(upstream.status);
    upstream.headers.forEach((v, k) => { if (!['content-encoding', 'content-length', 'transfer-encoding', 'connection'].includes(k)) res.setHeader(k, v); });

    // Pass the response through as it streams, reading the token counts on the way.
    const usage = { in: 0, out: 0, cacheRead: 0, cacheWrite: 0 };
    const take = (u) => {
      if (!u) return;
      if (u.input_tokens) usage.in = Math.max(usage.in, u.input_tokens);
      if (u.output_tokens) usage.out = Math.max(usage.out, u.output_tokens);
      if (u.cache_read_input_tokens) usage.cacheRead = Math.max(usage.cacheRead, u.cache_read_input_tokens);
      if (u.cache_creation_input_tokens) usage.cacheWrite = Math.max(usage.cacheWrite, u.cache_creation_input_tokens);
    };
    let buf = '';
    const sse = (upstream.headers.get('content-type') || '').includes('text/event-stream');
    const decoder = new TextDecoder();
    try {
      for await (const chunk of upstream.body) {
        res.write(chunk);
        const text = decoder.decode(chunk, { stream: true });
        if (sse) {
          buf += text;
          const lines = buf.split('\n');
          buf = lines.pop();
          for (const line of lines) {
            if (!line.startsWith('data:')) continue;
            try { const ev = JSON.parse(line.slice(5)); take(ev.message?.usage); take(ev.usage); } catch {}
          }
        } else if (buf.length < 2e6) buf += text;
      }
      if (!sse) { try { take(JSON.parse(buf).usage); } catch {} }
    } catch {}
    res.end();

    const tokensIn = usage.in + usage.cacheRead + usage.cacheWrite;
    if (!req.internal && (tokensIn || usage.out)) {
      const cost = (usage.in * PRICE_IN + usage.cacheWrite * PRICE_CACHE_WRITE + usage.cacheRead * PRICE_CACHE_READ + usage.out * PRICE_OUT) / 1e6;
      const job = jobs.get(req.headers['x-zancut-job']);
      const u = req.user;
      users.publicUser(u); // rolls the month
      for (const b of [u.usage, u.totals]) {
        b.tokensIn = (b.tokensIn || 0) + tokensIn;
        b.tokensOut = (b.tokensOut || 0) + usage.out;
        b.costUsd = Number(((b.costUsd || 0) + cost).toFixed(4));
      }
      const credits = usdToCredits(cost);
      if (job?.userId === u.id) {
        job.entry.tokensIn += tokensIn;
        job.entry.tokensOut += usage.out;
        job.entry.costUsd = Number((job.entry.costUsd + cost).toFixed(4));
        job.entry.credits = (job.entry.credits || 0) + credits;
      }
      users.spendCredits(u, credits); // live, as the desktop AI works
      users.persist();
    }
  });
}
