// Animation voice preparation and the production-script handoff to the shot director.
// Pictures are authored per shot by the director/designer/reviewer pipeline.
import fs from 'node:fs';
import path from 'node:path';
import { SKILLS_DIR } from './config.mjs';
import { tidyScript, recordLines, FORMATS } from './animation.mjs';

const J = (f, d) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
const files = (d) => { const P = path.join(d.ws, 'plate'); return { P, script: path.join(P, 'ANIMATION.json'), dialogue: path.join(P, 'dialogue.json'), lines: path.join(P, 'lines.json'), words: path.join(P, 'voice.words.json'), wav: path.join(P, 'voice.wav') }; };
// the planner's skill, with the one rule on who speaks (it lives in dialogue.md, the voice director's skill)
const skill = () => {
  const who = (/## Who speaks[\s\S]*?(?=\n## )/.exec(fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', 'dialogue.md'), 'utf8')) || [''])[0];
  const anatomy = fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', 'anatomy-card.md'), 'utf8'); // the card: the full contract is for engine work
  return `${anatomy}\n\n${fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', 'script.md'), 'utf8')}\n\n${who}`;
};
const jsonOf = (r) => { const t = String(r?.result || ''), m = t.match(/\{[\s\S]*\}(?![\s\S]*\})/); if (!m) throw new Error('The animation planner did not return a script'); return JSON.parse(m[0]); };
const asked = (p) => [`Language of the spoken words: ${p.language || 'bn'}.`, `The customer picked the format: ${FORMATS.includes(p.animFormat) ? p.animFormat : 'mixed'}.`, `Narrator: ${p.narratorGender === 'female' ? 'female' : 'male'}.`,
  p.instructions ? `The customer's instructions (follow them):\n${p.instructions}` : ''].filter(Boolean).join('\n');
const fmtNote = (S, p) => { const chosen = FORMATS.includes(p.animFormat) ? p.animFormat : 'mixed', used = FORMATS.includes(S.mode) ? S.mode : chosen; S.format = { chosen, used, note: used === chosen ? '' : String(S.note || '').slice(0, 300) }; delete S.note; };
// the recorded words never change: whatever came back, each line keeps its text, speaker and delivery, each person their voice
function keepRecorded(N, S) {
  // (the timing of silence too: silent beats, pre / post are in the recorded track)
  N.lines = S.lines.map((l, i) => { const o = { ...(N.lines[i] || {}), text: l.text, speaker: l.speaker, tone: l.tone, ...(l.s != null ? { s: l.s, e: l.e } : {}) };
    for (const k of ['hold', 'pre', 'post']) { if (l[k] != null) o[k] = l[k]; else delete o[k]; }
    return o; });
  // Preserve the planner's order without moving additional people off screen.
  const at = (c) => { const k = N.characters.findIndex((x) => x.id === c.id); return k < 0 ? 99 : k; };
  N.characters = [...S.characters].sort((a, b) => at(a) - at(b)).map((c) => ({ ...c, ...(N.characters.find((x) => x.id === c.id) || {}), id: c.id, name: c.name, voice: c.voice, style: c.style }));
  N.narrator = S.narrator; N.language = S.language; N.format = S.format; if (S.recorded) N.recorded = true;
  return N;
}
const numbered = (S) => JSON.stringify({ ...S, lines: S.lines.map((l, i) => ({ n: i + 1, ...l })) });

const directionsOf = (S) => (Array.isArray(S?.directions) ? S.directions : []).map((x) => String(x || '').trim()).filter(Boolean).slice(0, 30).join('\n');
/** Start editing: the animation script and its voices → plate/voice.wav (the main track) */
export async function plate(d, p, { runQuery, speak, step, model, onUsage, signal }) {
  const F = files(d); fs.mkdirSync(F.P, { recursive: true });
  const lang = p.language || 'bn';
  let S = J(F.script, null);
  const dlg = !S && J(F.dialogue, null);
  if (dlg) { // a Text-to-Dialogue take: the voices are made, the planner adds what we see
    step('Planning the animation around your voices: the people, the place, the shots');
    const prompt = `${skill()}\n\n---\n${asked(p)}\nThese lines are already recorded (numbered from 1). Keep every line's text, speaker, tone, the number and order of lines, the people's ids and names (add no silent lines: the sound is recorded). Add the title, the people's looks (spec) and roles, the scenes (places, staging, B-roll and motion graphics), and for every line its scene and what we see (see, shot, acts, badge, sfx, captions).\n${numbered(dlg)}\n\nAnswer with the whole script JSON only.`;
    S = keepRecorded(tidyScript(jsonOf(await runQuery(prompt, model, { tools: [], allowedTools: [], maxTurns: 1 }))), dlg);
    fs.writeFileSync(F.script, JSON.stringify(S, null, 1));
  } else if (!S) {
    step('Planning the animation: the script, the people, the place');
    const story = String(p.script || p.prompt || '').trim();
    if (!story) throw Object.assign(new Error('Write the story or paste the script first, then press Retry.'), { customer: true });
    const prompt = `${skill()}\n\n---\n${asked(p)}\nWhat the customer gave:\n\n${story.slice(0, 40000)}\n\nWrite the production script, scene by scene. Add "note" next to "mode": one short English sentence for the customer when the mode you used differs from the one they picked, else "". Answer with the JSON only.`;
    S = tidyScript(jsonOf(await runQuery(prompt, model, { tools: [], allowedTools: [], maxTurns: 1 })), { narratorVoice: p.voiceId, narratorGender: p.narratorGender });
    S.language = lang; fmtNote(S, p);
    fs.writeFileSync(F.script, JSON.stringify(S, null, 1));
  }
  p.filmOrders = directionsOf(S); // what the customer asked for the whole film reaches the director, the designers and the reviewer as their orders
  // every line on its own, so each line's speaker, start and end are exact (lip-sync, captions, cuts)
  const { times } = await recordLines(S, F.P, { speak, step, id: p.id, lang, onUsage, signal });
  p.animation = summary(S, times);
  return F.wav;
}
const nameOf = (S, who) => (who === 'narrator' ? 'Narrator' : S.characters.find((c) => c.id === who)?.name || who);
const summary = (S, times) => ({ title: S.title || '', format: S.format || null, cast: [{ id: 'narrator', name: 'Narrator', voice: S.narrator?.voice }, ...S.characters.map((c) => ({ id: c.id, name: c.name, voice: c.voice }))].filter((c) => S.lines.some((l) => l.speaker === c.id)),
  lines: S.lines.map((l, i) => ({ who: nameOf(S, l.speaker), text: l.text, see: l.see || '', s: times[i]?.start, e: times[i]?.end })) });

/** An uploaded voice (no script): the planner decides who says each sentence and what we see. The words stay as heard. */
export async function fromRecording(d, p, { runQuery, step, model, words = [] }) {
  const F = files(d);
  if (J(F.script, null) || !words.length) return;
  step('Planning the animation around your recording: who speaks, the people, the place, the shots');
  const said = (w) => String(w.text ?? w.word ?? '').trim(), lines = []; let cur = null;
  words.forEach((w, i) => {
    if (!cur) cur = { text: '', s: w.start, e: w.end };
    cur.text = `${cur.text} ${said(w)}`.trim(); cur.e = w.end;
    const next = words[i + 1], end = /[.!?।]$/.test(said(w)) || !next || next.start - w.end > 0.7;
    if (end) { lines.push(cur); cur = null; }
  });
  const prompt = `${skill()}\n\n---\n${asked(p)}\nThe voice is already recorded by the customer: these are its sentences in order (numbered from 1). Keep every sentence's words, their number and order exactly; add no lines. Decide who says each one (speaker: "narrator" or a cast id; one voice may be one person only). Add the title, the people's looks (spec), the scenes and, for every line, its scene and what we see.\n${JSON.stringify(lines.map((l, i) => ({ n: i + 1, text: l.text })))}\n\nAnswer with the whole script JSON only.`;
  const S = tidyScript(jsonOf(await runQuery(prompt, model, { tools: [], allowedTools: [], maxTurns: 1 })), { narratorVoice: p.voiceId, narratorGender: p.narratorGender });
  S.lines = lines.map((l, i) => ({ scene: S.scenes?.[0]?.id, ...(S.lines[i] || {}), speaker: S.lines[i]?.speaker || 'narrator', text: l.text, s: l.s, e: l.e }));
  S.recorded = true; S.language = p.language || S.language; fmtNote(S, p); p.filmOrders = directionsOf(S);
  fs.mkdirSync(F.P, { recursive: true }); fs.writeFileSync(F.script, JSON.stringify(S, null, 1));
  p.animation = summary(S, lines.map((l) => ({ start: l.s, end: l.e })));
}
/** what the script wanted that the engine cannot draw yet, for Admin → Skill adoption */
export const gapsOf = (d) => J(files(d).script, null)?.missing || [];

/** the production script as the director reads it (the 2D pipeline): the cast with their looks, the scenes, every line
    numbered with who says it and what we see. Lines the customer trimmed away are gone: a confirmed trim is final. */
export function scriptText(d, p = null) {
  const S = J(files(d).script, null); if (!S) return '';
  const ranges = p?.trim?.ranges || [], heard = p?.animation?.lines || [];
  const cut = (i) => { const t = heard[i]; return t?.s != null && ranges.some(([a, b]) => a <= t.s + 0.01 && b >= t.e - 0.01); };
  const cast = (S.characters || []).map((c) => `- ${c.name} (${c.id}${c.role ? `, ${c.role}` : ''}): spec ${JSON.stringify(c.spec || {})}${c.sheet ? `\n  sheet ${JSON.stringify(c.sheet)}` : ''}`).join('\n');
  // every scene in full: place, staging, camera, shots, atmosphere, reactions, texts, sound, transition, notes (the planner's whole direction)
  const scenes = (S.scenes || []).map((sc) => { const { id, type, name, title, time, ...rest } = sc; return `- ${id} · ${type} · ${title || name || ''}${time ? ` (${time})` : ''}: ${JSON.stringify(rest)}`; }).join('\n');
  const extras = (l) => [l.volume && l.volume !== 'normal' ? `volume ${l.volume}` : '', l.pace ? `pace ${l.pace}` : '', l.badge ? 'first-appearance badge' : '', (l.sfx || []).length ? `sound ${JSON.stringify(l.sfx)}` : '', l.captions === 'hide' ? 'captions hidden (the picture shows these words)' : '', l.missing ? `the engine has no ready part for this (${l.missing.part}: ${l.missing.what}): author it for this shot` : ''].filter(Boolean).map((x) => ` · ${x}`).join('');
  const lines = (S.lines || []).map((l, i) => (cut(i) ? null : `${i + 1}. [${l.scene || ''}] ${l.speaker === 'silent' ? `(silent ${l.hold || 1} s)` : `${l.speaker}${l.tone ? ` (${l.tone})` : ''}: ${l.text}`}\n   see: ${l.see || ''}${l.shot ? ` · shot ${JSON.stringify(l.shot)}` : ''}${(l.acts || []).length ? ` · acts ${JSON.stringify(l.acts)}` : ''}${extras(l)}`)).filter(Boolean).join('\n');
  return `Title: ${S.title || ''}${S.about ? `\nThe film: ${JSON.stringify(S.about)}` : ''}\nNarrator: ${S.narrator?.voice || ''}\nCast (copy each spec exactly into every row that shows the person):\n${cast || '- (narrator only)'}\nScenes (their "time" and shot seconds are the writer's plan from before the voice was recorded: the recorded voice is the clock, so time every row by its words):\n${scenes || '-'}\nLines (the voice track, in order; a character's line moves only their mouth, a narrator line moves no mouth):\n${lines}`;
}
