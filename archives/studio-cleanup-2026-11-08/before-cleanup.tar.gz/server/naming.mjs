// Short titles: a plan, a script, captions, a thumbnail or a video made on its own is named from its topic (2–5 words, in
// the topic's own language) instead of "New plan" / "New video"; a name the person typed is never changed. The exported
// file is "Zancut - <title> - v<n>.mp4".
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { query } from './no-ai.mjs';
import { CLAUDE_PATH } from './config.mjs';
import * as users from './users.mjs';
import * as claude from './claude-auth.mjs';
import { usageCost, usdToCredits, pricing } from './pricing.mjs';
import { DEMO } from './demo.mjs';

// a name nobody chose: the tools' and the app's placeholders
export const isPlaceholder = (t) => !String(t || '').trim() || /^(new( \w+){0,4}|untitled|thumbnail|video|my video)$/i.test(String(t).trim());

const tidy = (t) => String(t || '').split('\n')[0].replace(/^(title|name)\s*:\s*/i, '').replace(/^["'“”«»*#\s]+|["'“”«»*.\s]+$/g, '').replace(/\s+/g, ' ').trim().slice(0, 60);

// a short title for this text (what was asked and what came back), with Haiku; '' when it cannot (no login, the demo)
export async function shortTitle(u, text) {
  const body = String(text || '').replace(/https?:\/\/\S+/g, (m) => m.replace(/^https?:\/\/(www\.)?/, '').slice(0, 60)).trim().slice(0, 3000);
  if (!u || !body || DEMO) return '';
  const prompt = `Give this video a short title of 2 to 5 words, the way a creator would name the project: the topic itself, plain and clear, in the same language as the text (keep English brand and tech words as they are). No quotes, no emoji, no punctuation at the end. Answer with the title only.\n\n${body}`;
  let out = '', usd = 0;
  try {
    const cwd = path.join(os.tmpdir(), 'zancut-chat'); fs.mkdirSync(cwd, { recursive: true });
    for await (const ev of query({ prompt, options: { model: pricing().models?.naming || 'claude-haiku-5-5', maxTurns: 1, cwd, settingSources: [], tools: [], env: { ...process.env, ...claude.envFor(u.id), ENABLE_CLAUDEAI_MCP_SERVERS: 'false', CLAUDE_CODE_DISABLE_CLAUDE_MDS: '1' }, canUseTool: async () => ({ behavior: 'deny', message: 'no tools' }), ...(CLAUDE_PATH ? { pathToClaudeCodeExecutable: CLAUDE_PATH } : {}) } })) {
      claude.seeFor(u.id)(ev);
      if (ev.type === 'result') { out = String(ev.result || ''); usd = ev.total_cost_usd || usd; }
      if (ev.type === 'assistant' && ev.message?.usage && !usd) usd = usageCost(ev.message.model, ev.message.usage);
    }
  } catch (e) { console.error('[naming]', e.message?.slice(0, 120)); return ''; }
  if (usd) users.spendCredits(u, Math.max(0, Math.round(usdToCredits(usd))));
  const t = tidy(out);
  return t.split(' ').length <= 8 ? t : '';
}

// the exported file's name: Zancut - <title> - v<n> (letters of any language kept; only what a file name cannot hold goes)
export function exportName(title, n, extra = '') {
  const t = String(title || '').replace(/[\\/:*?"<>|\u0000-\u001f]+/g, ' ').replace(/\s+/g, ' ').trim().slice(0, 60);
  return `Zancut - ${isPlaceholder(t) ? 'Video' : t} - v${n}${extra}.mp4`;
}
