import path from 'node:path';
import fs from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';

export const APP_DIR = path.resolve(path.dirname(fileURLToPath(import.meta.url)), '..');

// The design-system skills (skills/<style>/), the engine (engine/: media, compose, sound kit, fonts) and the shared assets
// (assets/: music, voice samples) ship inside the project. ZANCUT_ENGINE / ZANCUT_SKILLS can point elsewhere (desktop).
export const ENGINE_DIR = process.env.ZANCUT_ENGINE || path.join(APP_DIR, 'engine');
export const SKILLS_DIR = process.env.ZANCUT_SKILLS || path.join(APP_DIR, 'skills');
export const ASSETS_DIR = path.join(APP_DIR, 'assets');
export const DATA_DIR = process.env.ZANCUT_DATA ? path.resolve(process.env.ZANCUT_DATA) : path.join(APP_DIR, 'data'); // always absolute (files are sent by absolute path)

export const PORT = Number(process.env.PORT || 4400);
// Local by default. Set HOST=0.0.0.0 to open it to your phone on the same Wi-Fi (accounts protect it).
export const HOST = process.env.HOST || '127.0.0.1';

// Empty = whatever Claude Code defaults to. With ANTHROPIC_API_KEY set the engine bills the API;
// without it, it uses the Claude login on this machine (fine for local use, not for customers).
export const MODEL = process.env.ZANCUT_MODEL || '';
// ZANCUT_LOCAL_LOGIN=1 (npm run app:local): ignore the API key and edit with the Claude login on this machine (your own
// Claude plan). For testing on your own computer only: never on the customer server.
if (process.env.ZANCUT_LOCAL_LOGIN === '1') delete process.env.ANTHROPIC_API_KEY;
// ZANCUT_OWN_CLAUDE=1 (the installed app on the owner's own computer): everything runs on the owner's own Claude plan,
// signed in through the official Claude login (server/claude-auth.mjs). Never an API key, never the cloud relay.
export const OWN_CLAUDE = process.env.ZANCUT_OWN_CLAUDE === '1';
if (OWN_CLAUDE) {
  for (const k of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'CLAUDE_CODE_OAUTH_TOKEN',
    'CLAUDE_CODE_USE_BEDROCK', 'CLAUDE_CODE_USE_VERTEX', 'CLAUDE_CODE_USE_FOUNDRY']) delete process.env[k];
  // The app has its own Claude login, kept in its own folder (Claude Code's documented way to hold a separate login): a computer
  // that is already signed in to Claude elsewhere still has to connect here, and logging out here never signs out the terminal.
  // ZANCUT_CLAUDE_CONFIG=default: the computer's own Claude login instead (the owner running the AI on their own account)
  if (process.env.ZANCUT_CLAUDE_CONFIG === 'default') delete process.env.CLAUDE_CONFIG_DIR;
  else process.env.CLAUDE_CONFIG_DIR = process.env.ZANCUT_CLAUDE_CONFIG || path.join(DATA_DIR, 'claude-login');
}
// The hosted web service: every customer connects their own Claude account (the same browser sign-in as the installed app,
// with the code pasted back), kept in their own folder (data/claude-users/<user id>). Never a server key: no credits, the
// customer's own Claude plan pays for their AI. ZANCUT_USER_CLAUDE=0 = the older way (the server's key or login, credits).
export const USER_CLAUDE = !OWN_CLAUDE && process.env.ZANCUT_MODE !== 'desktop' && process.env.ZANCUT_USER_CLAUDE !== '0';
if (USER_CLAUDE) {
  for (const k of ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'CLAUDE_CODE_OAUTH_TOKEN', 'CLAUDE_CONFIG_DIR',
    'CLAUDE_CODE_USE_BEDROCK', 'CLAUDE_CODE_USE_VERTEX', 'CLAUDE_CODE_USE_FOUNDRY']) delete process.env[k];
}
// TEMPORARY, until the Zancut server is online: the installed app has a built-in login that anyone holding the app can use
// (ZANCUT_DEFAULT_LOGIN=1, set by desktop/main.cjs while desktop/cloud.json has no server address). Remove it by putting the server
// address in desktop/cloud.json. Only honoured while the server listens on this computer alone.
export const DEFAULT_LOGIN = process.env.ZANCUT_DEFAULT_LOGIN === '1' ? { name: 'Mohi', alias: 'mohi', email: 'mohi@zancut.app', password: '12345' } : null;
export const USING_API_KEY = Boolean(process.env.ANTHROPIC_API_KEY);
export const MAX_TURNS = Number(process.env.ZANCUT_MAX_TURNS || 400);

// The Claude Code program the engine drives. The SDK ships its own copy, but if that is missing
// (it is on this Mac) use the one installed on the machine.
function findClaude() {
  if (process.env.ZANCUT_CLAUDE_PATH) return process.env.ZANCUT_CLAUDE_PATH;
  const bundled = path.join(APP_DIR, 'node_modules', '@anthropic-ai', `claude-agent-sdk-${process.platform}-${process.arch}`, 'claude');
  if (fs.existsSync(bundled)) return '';
  try { return execFileSync('which', ['claude'], { encoding: 'utf8' }).trim(); } catch {}
  const home = path.join(process.env.HOME || '', '.local', 'bin', 'claude');
  return fs.existsSync(home) ? home : '';
}
export const CLAUDE_PATH = findClaude();

// The Claude Code program itself, always a real path (the sign-in check and the Connect button run it directly).
function findClaudeBin() {
  if (CLAUDE_PATH) return CLAUDE_PATH;
  const bundled = path.join(APP_DIR, 'node_modules', '@anthropic-ai', `claude-agent-sdk-${process.platform}-${process.arch}`, process.platform === 'win32' ? 'claude.exe' : 'claude');
  return fs.existsSync(bundled) ? bundled : '';
}
export const CLAUDE_BIN = findClaudeBin();

// Python with OpenCV + NumPy for the reel engine's speaker cut-out. Set up once with scripts/setup-python.sh
// (the Docker image installs it system-wide); falls back to python3.
// A venv's Python: ~/.cache/zancut/<name>/bin/python, on Windows %USERPROFILE%\.cache\zancut\<name>\Scripts\python.exe
export const venvPython = (name) => path.join(process.env.HOME || process.env.USERPROFILE || '', '.cache', 'zancut', name, ...(process.platform === 'win32' ? ['Scripts', 'python.exe'] : ['bin', 'python']));
function findPython() {
  if (process.env.ZANCUT_PYTHON) return process.env.ZANCUT_PYTHON;
  const venv = venvPython('py');
  return fs.existsSync(venv) ? venv : process.platform === 'win32' ? 'python' : 'python3';
}
export const PYTHON = findPython();

// 'web' = the hosted service. 'desktop' = the installed app: sign-in, plans and AI go through CLOUD_URL, files stay local.
export const MODE = process.env.ZANCUT_MODE === 'desktop' ? 'desktop' : 'web';
export const CLOUD_URL = (process.env.ZANCUT_CLOUD || 'http://localhost:4400').replace(/\/$/, '');
// The marketing website (website/): where "No account yet?" on the sign-in screen sends people. Empty = no link.
export const SITE_URL = (process.env.ZANCUT_SITE_URL || '').replace(/\/$/, '');
