// The customer's video clips among the extra files (a "video clip": often a phone or screen recording of steps) follow the
// voice in the scene that shows them. (A screen-led video, its recordings marked "screen", is screensync.mjs: the whole cut.)
//   1. clipLogs: once per clip (kept on the file, a.log, while the clip and its note stay the same) Claude reads frames of it
//      with their seconds (every half second; a long clip in 30 s parts) and writes what happens when: { screen, steps:
//      [{ t, what, kind, focus }] } (focus = where to look, % of the clip's frame). The director gets the list with the file, so it
//      can pick which moment each spoken step shows (director.mjs mediaText).
//   2. a row that shows a clip names its moments: "media": { "mine": "<file>", "steps": [[word, second], …] } = while that word is
//      said the clip is at that second (it lands LEAD s before the word). syncClip cuts the clip to the scene's words: between two
//      moments the clip plays at 0.7×–2× (a little too long: its end is kept; far too long, other things happen in between: the
//      moment stays and the next comes in a jump cut on its word; too short: the screen holds still, then the action plays at
//      normal speed and lands on its word), so the scene plays it straight through
//      (assets/mine/<name>.sync-<hash>.mp4) and the designer never seeks it.
//   3. clipBrief: the designer's list of the steps in its scene (the time, the word, what the screen shows, where to zoom), so
//      its step pills, captions, zooms and tap sounds change on the same words as the screen.
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { createHash } from 'node:crypto';
import { isOwnClip } from './studio.mjs';

const run = promisify(execFile);
const r2 = (x) => Math.round(x * 100) / 100;
export const SLOW = 0.7, FAST = 2, LEAD = 0.2;
const LOG_V = 3, PART = 30; // 3: the device and the crop are read too
const VIDEO = /\.(mp4|mov|m4v|webm|mkv)$/i;
export const clipsOf = (p) => (p.assets || []).filter((a) => isOwnClip(a, p) && VIDEO.test(a.file) && !a.comment);
const sigOf = (d, a) => { const f = path.join(d.assets, a.file); return fs.existsSync(f) ? createHash('md5').update(JSON.stringify([LOG_V, a.file, fs.statSync(f).size, String(a.note || '').trim()])).digest('hex') : null; };
const box = (v) => { const f = Array.isArray(v) && v.length === 4 && v.every((n) => Number.isFinite(+n)) ? v.map((n) => Math.max(0, Math.min(100, Math.round(+n)))) : null; return f && f[2] >= 3 && f[3] >= 3 ? f : null; };

// one part of a clip (from–to s): frames every half second, each with its second → Claude → steps
async function logPart(a, file, dir, from, to, dur, runQuery, model) {
  const shots = [];
  for (let t = from, i = 0; t < to - 0.05; t = r2(t + 0.5), i++) {
    const f = path.join(dir, `${Math.round(t * 10)}.jpg`);
    await run('ffmpeg', ['-v', 'error', '-y', '-ss', String(t), '-i', file, '-frames:v', '1', '-vf', "scale='if(gt(iw,ih),384,-2)':'if(gt(iw,ih),-2,384)'", '-q:v', '5', f], { timeout: 30e3 }).catch(() => {});
    if (fs.existsSync(f)) shots.push({ t, file: f });
  }
  if (!shots.length) return null;
  const text = `A customer's video clip, "${a.original || a.file}" (${r2(dur)} s)${a.note ? `. Their note on where and how to use it: "${String(a.note).trim()}"` : ''}.
${from > 0 || to < dur ? `This is the part from ${from} s to ${r2(to)} s. ` : ''}Frames follow, one every half second, each after its second. Write what happens when, so an editor
can show the right moment while the voice says it:
- "screen": true when it is a phone or computer screen recording (or a video of one) that shows steps; false for ordinary footage.
- "device": "phone", "tablet", "computer" (a desktop or a browser) or "footage" (a camera clip): it decides the frame it is shown in.
- "crop": the part of the frame worth showing, [x, y, w, h] in % of the frame: leave out black bars, an empty margin, the phone's
  status bar or the computer's dock, the browser's tab strip and bookmarks when they say nothing; null = the whole frame.
- "steps": every moment that matters, in order: the screen or app that opens, each tap or click and what it is on, a menu or sheet
  that appears, a scroll, a toggle, the result. For ordinary footage: each new shot or action.
  "t" = the second it happens (the tap lands, or the new screen is complete); "what" = a few plain words ("Share tapped",
  "share sheet scrolled to More", "ChatGPT added to Favourites"); name the device or system when it changes inside the clip
  ("Android: …"). "kind": "tap" (a tap, click, press or long press), "screen" (a screen, sheet or menu appears or scrolls),
  "result" (what the steps achieved is shown), "idle" (waiting, loading, nothing happening: worth cutting).
  "focus": where the viewer must look at that moment, [x, y, w, h] in % of the frame: the tapped button or the new element with
  a little room (usually 15–40% wide); a whole new screen: null.
Answer JSON only: {"screen": true, "device": "phone", "crop": [0, 6, 100, 90], "steps": [{"t": 5.2, "what": "…", "kind": "tap", "focus": [5, 88, 18, 8]}, …]}`;
  const img = (f) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(f).toString('base64') } });
  const blocks = [{ type: 'text', text }, ...shots.flatMap((x) => [{ type: 'text', text: `${x.t.toFixed(1)} s:` }, img(x.file)])];
  const message = (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
  const res = await runQuery(message, model, { tools: [], maxTurns: 1, what: 'clip steps' });
  const m = String(res?.result || '').match(/\{[\s\S]*\}/); if (!m) return null;
  return JSON.parse(m[0]);
}
// what happens when in one clip, part by part
async function logOne(d, a, runQuery, model) {
  const file = path.join(d.assets, a.file), dur = Number(a.duration) || 0; if (!dur) return null;
  const dir = path.join(d.ws, 'job', 'work', 'clip-frames', a.file.replace(/[^\w.-]/g, '_'));
  fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
  let screen = false, device = null, crop = null; const steps = [];
  for (let from = 0; from < dur - 0.2; from += PART) {
    const got = await logPart(a, file, dir, from, Math.min(dur, from + PART), dur, runQuery, model);
    if (!got) continue;
    screen ||= !!got.screen;
    if (!device && ['phone', 'tablet', 'computer', 'footage'].includes(got.device)) device = got.device;
    const c = box(got.crop); // the parts' crops together: what any part needs stays in
    if (c) crop = crop ? (() => { const x = Math.min(crop[0], c[0]), y = Math.min(crop[1], c[1]); return [x, y, Math.max(crop[0] + crop[2], c[0] + c[2]) - x, Math.max(crop[1] + crop[3], c[1] + c[3]) - y]; })() : c;
    for (const x of Array.isArray(got.steps) ? got.steps : []) if (Number.isFinite(+x?.t) && x.what) {
      const f = box(x.focus);
      steps.push({ t: r2(Math.max(0, Math.min(dur, +x.t))), what: String(x.what).slice(0, 100), kind: ['tap', 'screen', 'result', 'idle'].includes(x.kind) ? x.kind : 'screen', ...(f ? { focus: f } : {}) });
    }
  }
  return steps.length ? { screen, ...(device ? { device } : {}), ...(crop && (crop[2] < 97 || crop[3] < 97) ? { crop } : {}), steps: steps.sort((x, y) => x.t - y.t) } : null;
}

// The customer's pictures: what each one shows, read once (kept on the file, a.log, while it and its note stay the same), so the
// director can judge where it fits and the designer how to crop and frame it. Up to 6 pictures a look.
const PICTURE = /\.(png|jpe?g|webp)$/i;
export const picturesOf = (p) => (p.assets || []).filter((a) => a.role === 'image' && PICTURE.test(a.file) && !a.comment);
async function logPictures(d, list, runQuery, model) {
  const dir = path.join(d.ws, 'job', 'work', 'picture-looks'); fs.mkdirSync(dir, { recursive: true });
  const shots = [];
  for (const [k, a] of list.entries()) {
    const f = path.join(dir, `${k}.jpg`);
    await run('ffmpeg', ['-v', 'error', '-y', '-i', path.join(d.assets, a.file), '-vf', "scale='if(gt(iw,ih),768,-2)':'if(gt(iw,ih),-2,768)'", '-q:v', '4', f], { timeout: 30e3 }).catch(() => {});
    if (fs.existsSync(f)) shots.push({ k, a, file: f });
  }
  if (!shots.length) return [];
  const text = `The customer's pictures for their video follow, each after its number, name and their note on where and how to use it.
For each one write what an editor needs to place it well:
- "kind": "screenshot" (of an app, a site or a chat), "photo", "logo", "chart", "document" or "other".
- "shows": what is in it, in a few plain words (the app and screen, the product, the person, the result it proves).
- "text": the words a viewer must be able to read in it (short), or "".
- "crop": the part worth showing, [x, y, w, h] in % of the picture (leave out empty margins, a status bar, unrelated clutter);
  null = all of it. "focus": the one spot that matters most (the number, the button, the face), the same way, or null.
- "ground": "plain" (a flat or empty background around the subject), "busy" or "dark".
Answer JSON only: [{"n": 1, "kind": "screenshot", "shows": "…", "text": "…", "crop": [0, 8, 100, 80], "focus": [20, 40, 30, 12], "ground": "plain"}, …]`;
  const img = (f) => ({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: fs.readFileSync(f).toString('base64') } });
  const blocks = [{ type: 'text', text }, ...shots.flatMap((x, i) => [{ type: 'text', text: `${i + 1}. "${x.a.original || x.a.file}"${x.a.note ? `, note: "${String(x.a.note).trim().slice(0, 300)}"` : ''}:` }, img(x.file)])];
  const message = (async function* () { yield { type: 'user', message: { role: 'user', content: blocks }, parent_tool_use_id: null, session_id: '' }; })();
  const res = await runQuery(message, model, { tools: [], maxTurns: 1, what: 'picture looks' });
  const m = String(res?.result || '').match(/\[[\s\S]*\]/); if (!m) return [];
  const got = JSON.parse(m[0]);
  return (Array.isArray(got) ? got : []).map((x) => { const s = shots[(+x?.n || 0) - 1]; if (!s) return null;
    return { a: s.a, log: { picture: true, kind: String(x.kind || 'other').slice(0, 20), shows: String(x.shows || '').slice(0, 160), text: String(x.text || '').slice(0, 160), ...(box(x.crop) ? { crop: box(x.crop) } : {}), ...(box(x.focus) ? { focus: box(x.focus) } : {}), ground: ['plain', 'busy', 'dark'].includes(x.ground) ? x.ground : 'busy' } };
  }).filter(Boolean);
}
// every clip without a log (or with an old one) gets one; returns how many were read. opts: { runQuery, model, step }
export async function clipLogs(d, p, { runQuery, model = null, step } = {}) {
  if (!runQuery) return 0;
  let n = 0;
  for (const a of clipsOf(p)) {
    const sig = sigOf(d, a); if (!sig || a.log?.sig === sig) continue;
    if (!n) step?.('Watching your clips and screen recordings step by step');
    try { const log = await logOne(d, a, runQuery, model); if (log) { a.log = { sig, ...log }; n++; } } catch (e) { console.error('[clip log]', a.file, String(e.message).slice(0, 160)); }
  }
  const pics = picturesOf(p).filter((a) => { const sig = sigOf(d, a); return sig && a.log?.sig !== sig; });
  if (pics.length) step?.('Looking at your pictures');
  for (let k = 0; k < pics.length; k += 6) {
    try { for (const x of await logPictures(d, pics.slice(k, k + 6), runQuery, model)) { x.a.log = { sig: sigOf(d, x.a), ...x.log }; n++; } } catch (e) { console.error('[picture look]', String(e.message).slice(0, 160)); }
  }
  return n;
}
// for the director: one clip's moments, one line
const pct = (f) => `[${f.join(', ')}]%`;
export const logLine = (a) => {
  const L = a.log; if (!L) return '';
  if (L.picture) return `a ${L.kind}: ${L.shows}${L.text ? `; its words: "${L.text}"` : ''}${L.crop ? `; worth showing ${pct(L.crop)}` : ''}${L.focus ? `; what matters most ${pct(L.focus)}` : ''}; ${L.ground} background`;
  if (!L.steps?.length) return '';
  return `${L.screen ? `screen recording${L.device ? ` of a ${L.device}` : ''}; ` : L.device === 'footage' ? 'camera footage; ' : ''}${L.crop ? `worth showing ${pct(L.crop)} of its frame; ` : ''}what happens when: ${L.steps.map((x) => `${x.t} s ${x.kind && x.kind !== 'screen' ? `[${x.kind}] ` : ''}${x.what}`).join(' · ')}`;
};
// the logged step at (or nearest to) a second of the clip
const stepAt = (a, sec) => (a?.log?.steps || []).reduce((b, x) => (Math.abs(x.t - sec) < 0.8 && (!b || Math.abs(x.t - sec) < Math.abs(b.t - sec)) ? x : b), null);
export const clipOf = (p, r) => { const n = path.basename(String(r?.media?.mine || r?.media?.src || r?.media?.file || '')).replace(/\.sync-[0-9a-f]{8}\.mp4$/, ''); return (p.assets || []).find((a) => a.file === n || path.basename(a.file).replace(/\.[^.]+$/, '') === n.replace(/\.[^.]+$/, '')); };

// The stretches of the clip for a scene: moments [[t in the scene, second of the clip], …] → [{ T, a, b, speed, hold }] covering
// the whole scene: before the first moment the lead-in at normal speed; between two moments the clip at SLOW–FAST (too long:
// its end, the result, is kept; too short: the screen holds still `hold` s, then plays at normal speed into its moment); after
// the last moment it plays on at normal speed, then holds.
export function stretches(marks, secs, dur) {
  const m = marks.filter(([t, x]) => Number.isFinite(t) && Number.isFinite(x)).map(([t, x]) => [Math.max(0, Math.min(secs, t)), Math.max(0, Math.min(dur, x))]).sort((u, v) => u[0] - v[0]);
  if (!m.length) return [];
  const out = [], seg = (T, a, b) => {
    if (T < 0.04) return;
    a = Math.max(0, Math.min(a, dur - 0.1));
    if (b - a < 0.05) { out.push({ T: r2(T), a: r2(a), b: r2(Math.min(dur, a + 0.1)), speed: 1, hold: r2(T) }); return; } // a still moment (or going back): it holds
    // far too long (other things happen in between, e.g. more apps added): this step's own moment stays on screen and the next
    // one comes in a jump cut on its word; a little too long (a wait, a scroll): its end, the action or result, at FAST
    if ((b - a) / T > FAST * 2) { out.push({ T: r2(T), a: r2(a), b: r2(Math.min(dur, a + T)), speed: 1, hold: 0 }); return; }
    if ((b - a) / T > FAST) a = b - T * FAST;
    const speed = (b - a) / T;
    if (speed < SLOW) { out.push({ T: r2(T), a: r2(a), b: r2(b), speed: 1, hold: r2(T - (b - a)) }); return; }
    out.push({ T: r2(T), a: r2(a), b: r2(b), speed: r2(speed), hold: 0 });
  };
  seg(m[0][0], Math.max(0, m[0][1] - m[0][0]), m[0][1]);
  for (let k = 0; k + 1 < m.length; k++) seg(m[k + 1][0] - m[k][0], m[k][1], m[k + 1][1] > m[k][1] ? m[k + 1][1] : m[k][1]);
  const [tl, xl] = m.at(-1); seg(secs - tl, xl, Math.min(dur, xl + (secs - tl)));
  return out;
}
// the clip cut to the scene's words → its file name under assets/mine (made once per set of moments), or null
export async function syncClip(J0, src, marks, secs) {
  const file = path.join(J0, src); if (!fs.existsSync(file)) return null;
  const { stdout } = await run('ffprobe', ['-v', 'error', '-show_entries', 'format=duration', '-of', 'csv=p=0', file], { timeout: 30e3 });
  const dur = Number(stdout) || 0; if (!dur) return null;
  const segs = stretches(marks, secs, dur); if (!segs.length) return null;
  const name = `${path.basename(src).replace(/\.[^.]+$/, '')}.sync-${createHash('md5').update(JSON.stringify([fs.statSync(file).size, segs])).digest('hex').slice(0, 8)}.mp4`;
  const rel = path.join(path.dirname(src), name), out = path.join(J0, rel);
  if (fs.existsSync(out)) return rel;
  // a screen recording's frame rate changes with the screen (no frame while nothing moves): made steady first, so every stretch
  // has frames to its end; a held start, then the stretch at its speed, padded with its last frame and cut to its exact time
  const chains = segs.map((s, k) => `[i${k}]fps=30,trim=start=${s.a}:end=${s.b},setpts=(PTS-STARTPTS)/${s.speed},fps=30,scale=-2:'min(1280,ih)',setsar=1${s.hold ? `,tpad=start_mode=clone:start_duration=${s.hold}` : ''},tpad=stop_mode=clone:stop_duration=${s.T},trim=duration=${s.T},setpts=PTS-STARTPTS[v${k}]`);
  const graph = `[0:v]split=${segs.length}${segs.map((_, k) => `[i${k}]`).join('')};${chains.join(';')};${segs.map((_, k) => `[v${k}]`).join('')}concat=n=${segs.length}:v=1:a=0,tpad=stop_mode=clone:stop_duration=0.5,format=yuv420p[v]`;
  await run('ffmpeg', ['-v', 'error', '-y', '-i', file, '-filter_complex', graph, '-map', '[v]', '-an', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '17', '-movflags', '+faststart', `${out}.tmp.mp4`], { timeout: 10 * 60e3, maxBuffer: 1 << 24 });
  fs.renameSync(`${out}.tmp.mp4`, out);
  return rel;
}

// For the designer: the steps of its scene, in the scene's time (the clip is already cut so each lands LEAD s before its word)
// sceneWords: [{ i, w, at }] (director.mjs sceneWordsOf)
export function clipBrief(p, r, sceneWords) {
  const a = clipOf(p, r), steps = (r?.media?.steps || []).filter((x) => Array.isArray(x) && x.length === 2);
  if (!steps.length) return '';
  const lines = steps.map(([w, sec]) => {
    const wd = (sceneWords || []).find((y) => y.i === Math.round(+w)); if (!wd) return null;
    const s = stepAt(a, +sec), t = r2(Math.max(0, wd.at - LEAD));
    const zoom = s?.focus ? (() => { const [x, y, fw, fh] = s.focus, k = r2(Math.max(1.25, Math.min(1.8, 45 / Math.max(fw, fh * 0.6)))); return `; zoom the clip ${k}× toward ${Math.round(x + fw / 2)}% ${Math.round(y + fh / 2)}% of its frame (transform-origin there, 0.5 s in, eased), back to 1× before the next step or the result`; })() : '';
    // a tap or click is marked where it lands, so the viewer sees exactly what to press
    const mark = s?.focus && s.kind === 'tap' ? `; mark it: a highlight ring (accent colour, 3 px, soft glow) around [${s.focus.join(', ')}]% of the clip's frame pops in 0.2 s before the tap and fades after it, with a small pointer or tap ripple on it` : '';
    return `- at(${t.toFixed(2)}) "${wd.w}": the screen shows ${s ? `${s.what}${s.kind === 'tap' ? ' (a tap: `tx-ui` cue)' : s.kind === 'result' ? ' (the result: `tx-success` cue)' : ''}` : `second ${sec} of the clip`}${zoom}${mark}`;
  }).filter(Boolean);
  const L = a?.log || {}, frame = L.device === 'phone' ? 'a phone frame' : L.device === 'tablet' ? 'a tablet frame' : L.device === 'computer' ? 'a browser or app window' : 'a framed card';
  const how = `in ${frame} of the design system${L.crop ? `, cropped to [${L.crop.join(', ')}]% of the clip's frame (the rest says nothing)` : ''}`;
  return lines.length ? `\n- Your clip is already cut to this scene's words: each step below is on its screen at that time. Show it ${how}, never raw. Play it straight through (never seek it). Change the step pill (the step's number and a few words), its caption and a 0.15 s cut flash on these same times, zoom and mark where it says (the ring sits on the clip and moves with its zoom), and put the sound cue it names:\n${lines.join('\n')}` : '';
}

// A walkthrough goes forward: one clip's moments move forward scene after scene and within a scene, and each moment sits on a
// word of its own scene. → what breaks that, in words for the director (empty = fine)
export function stepTrouble(p, rows) {
  const out = [], last = new Map();
  rows.forEach((r, k) => {
    const st = (r?.media?.steps || []).filter((x) => Array.isArray(x) && x.length === 2 && Number.isFinite(+x[0]) && Number.isFinite(+x[1])), a = st.length ? clipOf(p, r) : null;
    if (!a) return;
    const name = a.original || a.file;
    for (const [w, sec] of st) {
      if (+w < r.from || +w > r.to) out.push(`scene ${k + 1}: the moment ${sec} s of ${name} is on word ${w}, outside its words ${r.from}–${r.to}`);
      const prev = last.get(a.file);
      if (prev && +sec < prev.sec - 0.3) out.push(`scene ${k + 1}: ${name} goes back from ${prev.sec} s (scene ${prev.k}) to ${sec} s`);
      last.set(a.file, { sec: +sec, k: k + 1 });
    }
  });
  return out.slice(0, 8);
}

// a graphic row that shows a screen recording must say which moment each spoken step shows (else the clip plays from its start:
// another phone, another app): the recording's name when its "steps" are missing, else null
export function missingSteps(p, row) {
  if (row?.piece !== 'custom' || !row.media?.mine || (Array.isArray(row.media.steps) && row.media.steps.length)) return null;
  const a = clipOf(p, row);
  return a?.log?.screen ? path.basename(a.file) : null;
}

// a graphic row whose plan names one of the customer's video clips (in its design, what it shows…) without carrying it in
// "media": its designer gets no clip (a <video> it writes itself does not play) and can only draw a stand-in of it. The clip's
// name, else null. (A picture can be placed by its path, so only clips.)
export function unattached(p, row) {
  if (row?.piece !== 'custom') return null;
  const own = clipOf(p, row), said = JSON.stringify({ ...row, media: undefined });
  const a = (p.assets || []).find((x) => !x.comment && x !== own && VIDEO.test(x.file || '') && [x.file, x.original].some((n) => n && said.includes(path.basename(n))));
  return a ? path.basename(a.file) : null;
}
