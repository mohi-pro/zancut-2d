// Desktop mode: this copy of Zancut runs on the customer's computer and talks to the Zancut backend (backend/) for
// only these: sign-in, the subscription check, job counts, reports (cto.mjs outbox), and the services that need our
// keys (Gemini, Pexels, Pixabay: the backend calls them with the keys from Admin → Settings, so no key is on this
// computer). Projects, footage, renders, style memory and the AI (the customer's own Claude account) stay here.
import { CLOUD_URL, MODE } from './config.mjs';
import * as users from './users.mjs';

export const DESKTOP = MODE === 'desktop';

async function call(path, { method = 'GET', body, token } = {}) {
  let r;
  try {
    r = await fetch(CLOUD_URL + path, {
      method,
      headers: { ...(body ? { 'Content-Type': 'application/json' } : {}), ...(token ? { Authorization: `Bearer ${token}` } : {}) },
      body: body ? JSON.stringify(body) : undefined,
      signal: AbortSignal.timeout(20000),
    });
  } catch {
    throw Object.assign(new Error(`Can't reach Zancut (${CLOUD_URL}). Check your internet connection.`), { status: 503, code: 'offline' });
  }
  const j = await r.json().catch(() => ({}));
  if (!r.ok) throw Object.assign(new Error(j.error || `Zancut server error (${r.status})`), { status: r.status, code: j.code });
  return j;
}

// → { token, user (with .subscription), checkedAt, graceHours }
export const login = (email, password, device) => call('/api/desktop/login', { method: 'POST', body: { email, password, device } });
// the subscription check → { user, checkedAt, graceHours }
export const me = (token) => call('/api/desktop/me', { token });
export const logout = (token) => call('/api/desktop/logout', { method: 'POST', token, body: {} }).catch(() => {});
// before each AI run: refused (402, code expired) once the month has ended
export const jobStart = (token, p, kind) => call('/api/desktop/job-start', { method: 'POST', token, body: { projectId: p.id, kind, type: p.type, mode: p.mode } });
// "Renew" on the Profile page → Admin → Requests (a renewal on this account) → { ok, already }
export const renew = (token, message) => call('/api/desktop/renew', { method: 'POST', token, body: { message } });
export const jobEnd = (token, ok) => call('/api/desktop/job-end', { method: 'POST', token, body: { ok } }).catch(() => {});

// The signed-in customer's token (one person per app). The services below and the CTO's outbox use it.
// The account that signed in (or was checked) most recently: one person uses the app, and an older saved sign-in may be dead.
export const serviceToken = () => (DESKTOP ? users.all().filter((u) => u.cloudToken).sort((a, b) => (b.checkedAt || 0) - (a.checkedAt || 0))[0]?.cloudToken || '' : '');

// Where a service call goes and how it signs in. Desktop: the backend, with the customer's token.
export const services = {
  gemini: (path) => `${CLOUD_URL}/api/desktop/services/gemini/${path}`,
  pexels: (kind, qs) => `${CLOUD_URL}/api/desktop/services/pexels/${kind}?${qs}`,
  pixabay: (kind, qs) => `${CLOUD_URL}/api/desktop/services/pixabay/${kind}?${qs}`,
  auth: () => ({ Authorization: `Bearer ${serviceToken()}` }),
};

// Offline grace: after a good check the app keeps working this long without reaching the backend.
export const DEFAULT_GRACE_HOURS = 48;
export function offlineTooLong(u) {
  if (!DESKTOP || !u?.checkedAt) return false;
  return Date.now() - u.checkedAt > (u.graceHours || DEFAULT_GRACE_HOURS) * 3600e3;
}
