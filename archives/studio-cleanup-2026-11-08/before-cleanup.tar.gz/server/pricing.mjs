// The plan and the price. One plan: a month of Zancut (web and the desktop app), paid by hand and recorded by the admin;
// the AI runs on the customer's own Claude account, so there are no credits and no limits beyond the end date. Every
// number can be changed in Admin → Settings. Real AI cost is still measured (in "credits", 1 credit = BDT 0.10) for the
// admin's usage numbers only: nothing is ever taken from or checked against a customer.
import { getSettings } from './admin.mjs';

export const DEFAULT_PRICING = {
  usdToBdt: 122,
  creditsPerTaka: 10,
  minToStart: 300, // credits needed to start a new video (a running job is never cut off)
  minToChange: 50, // credits needed to ask for a round of changes: small balances stay usable
  trialSafetyCap: 5000, // hidden: AI credits one "Try once" video may use (about one Opus video + a change round)
  plans: {
    monthly: { name: 'Monthly', usd: 29, bdt: 2499, credits: 0, oneTime: false, desktop: true, versions: 99, months: 1,
               who: 'Everything in Zancut for one month, on the web and the desktop app, with your own Claude account.' },
  },
  topUp: { usd: 4.99, bdt: 399, credits: 2200 },
  // Typical credits per video (shown to customers before they start): Gemini transcript + Opus storyboard; change = one
  // scene fix. Measured on the human-in-the-loop flow (19 Oct 2026): a 30–75 s video ≈ $0.65–0.75 (≈ 800–920 credits)
  // before scene fixes; the first scene fix ≈ $0.17 (it fills Opus's cache), later ones ≈ $0.06.
  estimates: { short: [700, 1100], long: [1200, 3000], change: [60, 220] },
  // Which Claude model does what (credits follow the model used): plan = the creative part of a new library-engine video
  // (cut, pictures, plan, review of the build; the render needs no AI); short/long = change rounds and older projects.
  models: { plan: 'claude-opus-5-5', short: 'claude-sonnet-5-5', long: 'claude-sonnet-5-5', simpleRound: 'claude-sonnet-5-5', study: 'claude-sonnet-5-5' }, // study: reads a style reference video before the edit; // simpleRound: change rounds that only adjust what exists
  // $ per million tokens (cache writes: the engine uses the 1-hour cache, ~2x input).
  modelPrices: {
    'claude-opus-5-5':   { in: 4, out: 20, cacheRead: 0.2, cacheWrite: 8 },
    'claude-sonnet-5-5': { in: 2, out: 10, cacheRead: 0.2, cacheWrite: 4 },
    // the home page chat's other Claude models (estimates; change in Admin → Settings)
    'claude-fable-5-1':  { in: 6, out: 30, cacheRead: 0.6, cacheWrite: 12 },
    'claude-haiku-5-5':  { in: 0.8, out: 4, cacheRead: 0.08, cacheWrite: 1.6 },
    // Gemini (listening breakdown before the storyboard); estimates, change in Admin → Settings
    'gemini-pro-latest': { in: 2.5, out: 15, cacheRead: 0.25, cacheWrite: 2.5 },
    'gemini-flash-latest': { in: 0.5, out: 3, cacheRead: 0.05, cacheWrite: 0.5 },
    'gemini-flash-lite-latest': { in: 0.1, out: 0.4, cacheRead: 0.01, cacheWrite: 0.1 },
    'gemini-2.5-flash': { in: 0.3, out: 2.5, cacheRead: 0.03, cacheWrite: 0.3 },
    'gemini-2.5-pro': { in: 1.25, out: 10, cacheRead: 0.125, cacheWrite: 1.25 },
    'gemini-3.8-flash-tts': { in: 0.5, out: 10, cacheRead: 0, cacheWrite: 0 }, // AI voice (audio out)
    'gemini-2.5-flash-preview-tts': { in: 0.5, out: 10, cacheRead: 0, cacheWrite: 0 },
    'gemini-2.5-pro-preview-tts': { in: 1, out: 20, cacheRead: 0, cacheWrite: 0 },
  },
  // Keeps one hard video from running away with credits.
  maxTurns: { short: 260, long: 360 },
};

// every older plan is the one monthly plan now
const LEGACY = { free: 'monthly', pro: 'monthly', studio: 'monthly', trial: 'monthly', starter: 'monthly', creator: 'monthly', agency: 'monthly' };
export const planId = (id) => LEGACY[id] || id;

// The live pricing: defaults merged with whatever the admin saved.
export function pricing() {
  const saved = getSettings().pricing || {};
  const plans = {};
  for (const [k, v] of Object.entries(DEFAULT_PRICING.plans)) plans[k] = { ...v, ...(saved.plans?.[k] || {}) };
  return {
    ...DEFAULT_PRICING, ...saved, plans,
    topUp: { ...DEFAULT_PRICING.topUp, ...(saved.topUp || {}) },
    estimates: { ...DEFAULT_PRICING.estimates, ...(saved.estimates || {}) },
    models: { ...DEFAULT_PRICING.models, ...(saved.models || {}) },
    modelPrices: { ...DEFAULT_PRICING.modelPrices, ...(saved.modelPrices || {}) },
    maxTurns: { ...DEFAULT_PRICING.maxTurns, ...(saved.maxTurns || {}) },
  };
}

export const planInfo = (id) => {
  const p = pricing().plans[planId(id)] || pricing().plans.monthly;
  return { id: planId(id) in pricing().plans ? planId(id) : 'monthly', ...p };
};

export const usdToCredits = (usd) => {
  const p = pricing();
  return Math.round(usd * p.usdToBdt * p.creditsPerTaka);
};

// $ cost of one assistant message's token usage on a model.
export function usageCost(model, u) {
  const prices = pricing().modelPrices;
  const m = String(model || '').toLowerCase();
  let key = Object.keys(prices).find((k) => m.startsWith(k.toLowerCase()));
  if (!key) {
    if (m.includes('sonnet')) key = 'claude-sonnet-5-5';
    else if (m.includes('haiku')) key = 'claude-haiku-5-5';
    else if (m.includes('opus')) key = 'claude-opus-5-5';
    else if (m.includes('gemini')) key = 'gemini-2.5-pro';
    else key = 'claude-opus-5-5';
  }
  const pr = prices[key] || prices['claude-opus-5-5'];
  return ((u.input_tokens || 0) * pr.in + (u.output_tokens || 0) * pr.out
    + (u.cache_read_input_tokens || 0) * pr.cacheRead + (u.cache_creation_input_tokens || 0) * pr.cacheWrite) / 1e6;
}

// Short = reels, shorts and faceless pieces; long = YouTube edits from footage.
export const jobSize = (project) => (project.type === 'reel' || project.mode === 'faceless' ? 'short' : 'long');
export const modelFor = (project) => process.env.ZANCUT_MODEL || pricing().models[jobSize(project)];

// What the browser may see (no model prices).
export function publicPricing() {
  const p = pricing();
  return {
    usdToBdt: p.usdToBdt, creditsPerTaka: p.creditsPerTaka, minToStart: p.minToStart, minToChange: p.minToChange ?? 50, estimates: p.estimates,
    topUp: p.topUp, plans: Object.entries(p.plans).map(([id, v]) => ({ id, ...v })),
  };
}
