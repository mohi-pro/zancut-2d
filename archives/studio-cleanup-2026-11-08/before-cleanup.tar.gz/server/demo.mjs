// Demo mode (ZANCUT_DEMO=1; `npm run demo` runs a separate app on its own data in data/demo, never the real one):
// every step can be opened and every AI step is acted in seconds, with no AI at all. The steps are played from a few real
// finished videos copied in as templates (scripts/demo-seed.mjs; marked demoTemplate, owned by nobody):
//   prepare (Confirm trimming, Magic Cut, Generate the voice) ~2 s → the video takes the template's media and words
//   storyboard / replan ~5 s → the template's storyboard · scene ~3 s → the scene "changes" (the same still)
//   render ~5 s → the template's next version · revise ~5 s → the comments are marked done and a new version comes
// The chat answers with ready demo text (no model is called).
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import * as store from './store.mjs';

export const DEMO = process.env.ZANCUT_DEMO === '1';

const STEPS = {
  prepare: [2000, ['Listening to your words', 'Timing every word exactly (WhisperX)', 'Laying out the transcript']],
  storyboard: [5000, ['Planning the storyboard with Opus', 'Cutting your clips', 'Designing every graphic scene', 'Building the page', 'Checking quality', 'Drawing scenes']],
  scene: [3000, ['Opus is changing this scene', 'Rebuilding the scene', 'Checking quality', 'Drawing the still']],
  render: [5000, ['Rendering every frame', 'Mixing the voice, music and sound', 'Checking the render']],
  revise: [5000, ['Opus is reading your comments', 'Rebuilding the scenes', 'Checking quality', 'Rendering the new version']],
};
STEPS.replan = STEPS.storyboard;
const timers = new Map();

// the template that fits a video best: same type and design system, else same type, else any
export function templateFor(p) {
  const all = store.list((x) => x.demoTemplate);
  return all.find((t) => t.kind === p.kind && t.designStyle === p.designStyle) || all.find((t) => t.kind === p.kind) || all[0] || null;
}

// a folder copied as a clone where the disk can (APFS: instant, no extra space), else a plain copy
const clone = (from, to) => new Promise((ok) => {
  fs.rmSync(to, { recursive: true, force: true });
  execFile('cp', ['-c', '-R', from, to], (e) => { if (e) fs.cpSync(from, to, { recursive: true }); ok(); });
});

// what a video keeps of its own when it takes a template's media: who it is; everything else (media, words, look) is the template's
const OWN = ['id', 'ownerId', 'name', 'createdAt', 'updatedAt', 'demoTemplate'];
async function takeMedia(p, t) {
  const a = store.dirs(t.id), b = store.dirs(p.id);
  await clone(a.ws, b.ws);
  if (fs.existsSync(a.out)) await clone(a.out, b.out);
  for (const k of Object.keys(p)) if (!OWN.includes(k)) delete p[k];
  for (const [k, v] of Object.entries(structuredClone(t))) if (!OWN.includes(k)) p[k] = v;
  Object.assign(p, { demoFrom: t.id, board: null, boardAt: null, versions: [], comments: [], spend: [], lastJob: null });
}

// a job, acted: the steps appear one by one over its time, then the result
export function run(id, kind, extra = {}) {
  const p = store.get(id); if (!p) return;
  const [ms, steps] = STEPS[kind] || STEPS.render;
  p.status = 'editing'; p.error = null;
  p.job = { kind, startedAt: Date.now(), steps: [], todos: [], demo: true, ...(kind === 'scene' ? { row: extra.row } : {}) };
  store.save(p, { immediate: true });
  const ts = steps.map((text, i) => setTimeout(() => { const q = store.get(id); if (!q?.job) return; q.job.steps.push({ t: Date.now(), type: 'step', text }); store.save(q, { immediate: true }); }, (ms / steps.length) * i + 150));
  ts.push(setTimeout(async () => {
    const q = store.get(id); if (!q?.job) return;
    try { await apply(q, kind, extra); }
    catch (e) { console.error('[demo]', e.message); q.error = 'The demo could not play this step. Try again.'; }
    timers.delete(id);
    q.status = store.idleStatus(q); q.lastJob = { kind, steps: q.job?.steps || [] }; q.job = null;
    store.save(q, { immediate: true });
  }, ms));
  timers.set(id, ts);
}
export function cancel(id) {
  const ts = timers.get(id); if (!ts) return false;
  ts.forEach(clearTimeout); timers.delete(id);
  const p = store.get(id); if (p) { if (p.job?.kind === 'prepare' && !p.transcript && p.trim) p.trim.confirmed = false; p.status = store.idleStatus(p); p.job = null; store.save(p, { immediate: true }); }
  return true;
}

async function apply(p, kind, extra) {
  const t = (p.demoFrom && store.get(p.demoFrom)) || templateFor(p);
  if (!t) throw new Error('no demo template (run scripts/demo-seed.mjs)');
  const now = Date.now();
  if (kind === 'prepare') { await takeMedia(p, t); if (p.trim) p.trim.confirmed = true; else p.trim = { ranges: [], confirmed: true }; p.scriptAt = now; return; }
  // a video that never took the template's media (opened at Step 3 or 4 straight away) takes it now
  if (!p.demoFrom) await takeMedia(p, t);
  if (kind === 'storyboard' || kind === 'replan') { p.board = structuredClone(t.board); p.boardAt = p.built = p.edited = now; return; }
  if (kind === 'scene') { p.edited = p.built = now; return; }
  if (kind === 'render' || kind === 'revise') {
    if (!p.board) { p.board = structuredClone(t.board); p.boardAt = now; }
    const tv = t.versions || [], n = p.versions.length + 1;
    const src = tv[Math.min(n, tv.length) - 1]; if (!src) throw new Error('the template has no version');
    p.versions.push({ ...structuredClone(src), n, createdAt: now });
    if (kind === 'revise') for (const c of p.comments || []) if (!c.resolvedIn) c.resolvedIn = n;
  }
}

// the chat, without a model: ready answers that read like real ones, with the result blocks the tools save (a plan, a
// script, a caption), in Bangla when the task or the workspace is Bangla
export function chatAnswer(text, mode, task, wsLang) {
  const bn = (task?.language || wsLang) === 'bn';
  const topic = String(task?.title || text || 'your video').replace(/\s+/g, ' ').trim().slice(0, 80);
  const kind = task?.kind === 'faceless' ? 'Storytelling' : 'Talking head', size = task?.format || '9:16';
  if (mode === 'plan') return bn
    ? `যা এখন চলছে (ডেমো উত্তর, এখানে কোনো AI বা সার্চ নেই): ছোট, হাতে-কলমে টিপস আর "আমি ভুল করেছিলাম" ধরনের গল্প সবচেয়ে বেশি সেভ হচ্ছে।\n\nতিনটা অ্যাঙ্গেল:\n1. **উল্টো কথা**: "সবাই যা বলে, সেটা ভুল"\n2. **হাতে-কলমে গাইড**: ৩টা ধাপ, আজই করা যায়\n3. **গল্প**: আমার নিজের ভুল থেকে শেখা\n\nআমি ২ নম্বর বেছে নিয়ে প্ল্যান লিখলাম:\n\n\`\`\`plan\nTitle: ${topic}\nBig idea: একটা ছোট বদল, প্রতি সপ্তাহে ঘণ্টা বাঁচায়\nAudience & pain point: ব্যস্ত মানুষ, যাদের সময় কোথায় যায় বোঝে না\nHooks:\n1. Spoken: "বেশিরভাগ মানুষ এই ভুলটা করে।" · Visual: লাল ক্রস দিয়ে একটা ঘড়ি\n2. Spoken: "এক সপ্তাহে ৫ ঘণ্টা ফেরত পেলাম।" · Visual: বড় করে ৫ ঘণ্টা\n3. Spoken: "এটা কেউ বলে না।" · Visual: ঠোঁটে আঙুল\nOutline:\n1. Setup: সমস্যাটা এক লাইনে\n2. Core value: সহজ সমাধান, ধাপে ধাপে\n3. Climax: ফলাফল, আগে আর পরে\n4. Outro & call to action: সেভ করো, ফলো করো\nFormat: ${kind} · ${size} · 45 s\nPost: Instagram, মঙ্গলবার সন্ধ্যা ৬টা\n\`\`\`\n\nপ্ল্যানটা ডানের ফলাফলে এসে গেছে: ঠিক করে নাও, তারপর **Save & continue to Script Writer** চাপো।`
    : `What is working now (demo answer: the demo calls no AI and no search): short, practical tips and "I got this wrong" stories get the most saves.\n\nThree angles:\n1. **Contrarian**: "Everything you were told about this is wrong"\n2. **Practical guide**: three steps you can do today\n3. **Story**: what my own mistake taught me\n\nI went with the practical guide:\n\n\`\`\`plan\nTitle: ${topic}\nBig idea: one small change that saves hours every week\nAudience & pain point: busy people who never know where their time goes\nHooks:\n1. Spoken: "Most people get this wrong." · Visual: a clock with a red cross\n2. Spoken: "I got five hours back in one week." · Visual: a big 5 HOURS\n3. Spoken: "Nobody tells you this." · Visual: a finger on the lips\nOutline:\n1. Setup: the problem, in one sentence\n2. Core value: the simple fix, step by step\n3. Climax: the result, before and after\n4. Outro & call to action: save it, follow for part two\nFormat: ${kind} · ${size} · 45 s\nPost: Instagram, Tuesday 6 pm\n\`\`\`\n\nThe plan is in the result next to the chat: edit it there, then press **Save & continue to Script Writer**.`;
  if (mode === 'script') {
    const hooks = bn ? ['বেশিরভাগ মানুষ এই ভুলটা করে, আর ঘণ্টার পর ঘণ্টা নষ্ট হয়।', 'এক সপ্তাহে আমি ৫ ঘণ্টা ফেরত পেয়েছি। কীভাবে, বলছি।', 'এই কথাটা কেউ তোমাকে বলবে না।'] : ['Most people get this wrong, and it costs them hours.', 'I got five hours back in one week. Here is how.', 'Nobody is going to tell you this.'];
    const ends = bn ? ['সেভ করে রাখো, পরের পর্বের জন্য ফলো করো।', 'তুমি কোনটা আগে করবে? কমেন্টে বলো।'] : ['Save this, and follow for part two.', 'Which one will you try first? Tell me in the comments.'];
    const body = bn ? ['সমস্যাটা সহজ: আমরা সব একসাথে করতে চাই।', 'সমাধান আরও সহজ: একটা কাজ, একটা সময়।', 'এক সপ্তাহ করে দেখো, পার্থক্যটা নিজেই বুঝবে।'] : ['The problem is simple: we try to do everything at once.', 'The fix is simpler: one task, one block of time.', 'Try it for one week, and you will feel the difference.'];
    const notes = { hooks, scenes: [{ time: '0:00–0:04', say: hooks[0], show: bn ? 'মুখ, পাঞ্চ জুম' : 'Face, punch zoom', text: bn ? 'বড় ভুল' : 'BIG MISTAKE' }, { time: '0:04–0:10', say: body[0], show: bn ? 'একসাথে অনেক ট্যাব খোলা' : 'Many tabs open at once', text: '' }, { time: '0:10–0:16', say: body[1], show: bn ? 'একটা টাইমার' : 'One timer', text: bn ? '১ কাজ = ১ সময়' : '1 task = 1 block' }, { time: '0:16–0:22', say: body[2], show: bn ? 'আগে / পরে' : 'Before / after', text: '' }, { time: '0:22–0:26', say: ends[0], show: bn ? 'মুখ, হাসি' : 'Face, smile', text: '' }], endings: ends };
    const intro = bn ? 'স্ক্রিপ্ট (ডেমো উত্তর):' : 'The script (demo answer):';
    const outro = bn ? 'প্রায় ২৫ সেকেন্ড। স্ক্রিপ্ট ডানে এসে গেছে: দরকার হলে বদলাও, তারপর **Send clean script to Voice Artist**।' : 'About 25 seconds. The script is in the result next to the chat: swap a hook or an ending there, then **Send clean script to Voice Artist**.';
    return `${intro}\n\n\`\`\`breakdown\n${JSON.stringify(notes)}\n\`\`\`\n\n\`\`\`script\n${[hooks[0], ...body, ends[0]].join('\n\n')}\n\`\`\`\n\n${outro}`;
  }
  if (mode === 'caption') {
    const titles = [topic, 'The one change that saves me hours', 'Stop doing this (do this instead)', 'I tried this for 7 days', 'The 5-minute fix nobody uses'];
    const desc = `One simple change that saves hours every week. Watch to the end for the trick.\n\n• The mistake most people make\n• The simple fix\n• What changes after one week\n\n00:00 The mistake\n00:08 The fix\n00:20 The result\n\nFollow for part two.`;
    const ig = `Most people waste hours on this, and never notice. ⏳\n\nOne task, one block of time. That's it.\n\nSave this for tomorrow morning and tell me in the comments if it worked.\n\n#productivity #timemanagement #focus #tips #creator #habits #worksmart #dailyroutine #motivation #selfimprovement`;
    const c = { title: titles[0], description: desc, hashtags: '#productivity #timemanagement #focus #tips', platforms: { youtube: { titles, description: desc, tags: 'productivity, time management, focus, deep work, productivity tips, save time, habits, work smarter' }, instagram: ig, tiktok: 'The 5-minute fix that gave me hours back 👀 #productivity #fyp #lifehack #focus #tips', linkedin: 'Multitasking is costing your team more than you think.\n\nOne task, one block of time:\n→ fewer context switches\n→ deeper work\n→ less end-of-day fatigue\n\nWhat is the one habit that changed how you work?\n\n#productivity #leadership #deepwork' } };
    return `The whole package (demo answer):\n\n\`\`\`caption\n${JSON.stringify(c)}\n\`\`\`\n\nEvery platform is in the result next to the chat, each with its own copy button.`;
  }
  if (mode === 'idea') return `**5 video ideas** for "${topic}" (demo answer)\n\n1. **The 30-second myth-buster**: one common mistake, then the fix.\n2. **Before / after**: show the result first, then how.\n3. **3 tools I use daily**: quick, visual, easy to save.\n4. **A day in 60 seconds**: behind the scenes, fast cuts.\n5. **Ask me anything**: answer the top comment of the week.`;
  if (mode === 'thumbnail') return `A thumbnail idea (demo answer):\n\n\`\`\`thumbnail\n{"title":${JSON.stringify(topic.slice(0, 40))},"subtitle":"","points":[],"layout":"big word left, face right","look":"the video's own colours","format":"${size === '9:16' ? '9:16' : '16:9'}","photo":false}\n\`\`\`\n\nAI pictures need the AI, so in the demo use **a frame of the video** or **your own picture** on the right.`;
  return `**Demo answer** about "${topic}": the demo calls no AI. In the real app this is where the AI answers you.`;
}
