// What the editor (server/editor.mjs) reads, driven by the design system's skill folder (skills/<style>/), and the code that
// turns its answers into the engine's files.
//   directorSystem the director's system prompt: the directing parts of the design system's skill for this video type and of the
//                 shared playbook, and the check rules. builderSystem: the building parts, the page contract and the check rules,
//                 the same for every scene builder of a video (and the fresh reviewer), so it is read from the cache.
//   leadPrompt    this video: setup, the customer's cut, notes and files, the Brief → the storyboard (save_storyboard)
//   batchTask     one graphic scene or a few neighbours: the exact scene-relative word times ("the voice is the clock"), the
//                 layout's free zones in pixels, the anchor poses and the ready icons → save_scene (its frames come back), fix
//   Code          checks every answer, builds edit/plan.json (scenes back to back, never overlapping) and composes the page.
// Skill folders share five file names (+ its atoms.css), so a new design system is a new folder and its styles.json entry.
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { stockCandidates, downloadStock, candidatesSheet } from './stock.mjs';
import { SKILLS_DIR, ENGINE_DIR, ASSETS_DIR } from './config.mjs';
import { setupBlock, styleLook, tokensFor, designOf, themeOf, FORMATS, langName, styleInfo, screenLed, voiceSource, isOwnClip, isOwnMedia } from './studio.mjs';
import { syncScreen, fitsScreens, syncStale } from './screensync.mjs';
import { syncClip, logLine, clipBrief, LEAD } from './clipsync.mjs';
import { pricing } from './pricing.mjs';
import { kitBlock, libraryForBuilders } from './filmkit.mjs';
import { rowPartsText } from './parts.mjs';

const J = (f, d = null) => { try { return JSON.parse(fs.readFileSync(f, 'utf8')); } catch { return d; } };
// the kind the plan is made for: the customer's type, or "screen" when screen recordings among the extra files carry the picture
const typeOf = (p) => (['talking', 'faceless', 'interview'].includes(p.kind) ? p.kind : p.mode === 'faceless' || !p.footage?.length ? 'faceless' : 'talking');
const kindOf = (p) => (screenLed(p) && voiceSource(p) !== 'video' ? 'screen' : typeOf(p));
// a talking head with screen recordings: the camera carries it, and "screen" rows show the recording matched to the voice
// (cut/screen.mp4, a layer of its own) in a window, zoomed to what is said
const beside = (p) => typeOf(p) === 'talking' && fitsScreens(p);
const wordsOf = (t) => (Array.isArray(t) ? t : t?.words || []);
export const jobDir = (ws) => path.join(ws, 'job');

// ---------- the skill files ----------
const TYPE_FILE = { talking: 'talking-head', faceless: 'storytelling', interview: 'interview-broll' };
const readSkill = (style, name) => { try { return fs.readFileSync(path.join(SKILLS_DIR, style, `${name}.md`), 'utf8').trim(); } catch { return ''; } };
const readShared = (name) => { try { return fs.readFileSync(path.join(SKILLS_DIR, `${name}.md`), 'utf8').trim(); } catch { return ''; } };
// One anatomy contract reaches the planner, every shot designer and the reviewer.
// Do not silently continue without it for a human animation project.
// the anatomy every 2D prompt carries: the short card; the full contract (human-anatomy-rigging.md) is for whoever changes the engine
const humanRules = (p) => {
  if (designOf(p) !== '2d-animation') return '';
  const rules = fs.readFileSync(path.join(SKILLS_DIR, '2d-animation', 'anatomy-card.md'), 'utf8').trim();
  if (!rules) throw new Error('The universal human anatomy and rigging contract is empty.');
  return rules;
};
const hasOwnMedia = (p) => (p.assets || []).some((a) => isOwnMedia(a, p));
// Every skill file is read in parts by who it is for: the director (plans the video) or the builder (writes one scene's file).
// A part starts at a marker line, <!-- director -->, <!-- graphic --> (the builder) or <!-- both -->; the text before the first
// marker is for the file's own reader (core-director and a video type's file: the director; core-graphic: the builder; the
// shared files: both). Each reader gets only its parts, so neither reads rules that are not its job.
const MARKS = /^<!-- (director|graphic|both) -->[ \t]*$/m;
export function skillPart(text, who, first) {
  const out = []; let aud = first;
  String(text || '').split(MARKS).forEach((piece, k) => {
    if (k % 2) { aud = piece; return; }
    if (piece.trim() && (aud === who || aud === 'both')) out.push(piece.trim());
  });
  return out.join('\n\n');
}
// the customer's own pictures and clips (in the interview file of every design system): read by any video that has some
const OWN = "## The customer's own pictures and clips";
const ownMedia = (st, who) => { const part = skillPart(readSkill(st, 'interview-broll'), who, 'director'); if (who === 'graphic') return part; const at = part.indexOf(OWN); return at < 0 ? '' : part.slice(at); };
// the director: core-director + the video type's director part (+ the customer-footage part when they added pictures or clips)
export function directorSkill(p) {
  const st = designOf(p), type = TYPE_FILE[typeOf(p)];
  return [humanRules(p), readSkill(st, 'core-director'), skillPart(readSkill(st, type), 'director', 'director'), type !== 'interview-broll' && hasOwnMedia(p) ? ownMedia(st, 'director') : ''].filter(Boolean).join('\n\n');
}
// the motion designer: core-graphic + the video type's graphic part (+ how to frame the customer's own pictures and clips)
export function graphicSkill(p) {
  const st = designOf(p), type = TYPE_FILE[typeOf(p)];
  return [humanRules(p), skillPart(readSkill(st, 'core-graphic'), 'graphic', 'graphic'), skillPart(readSkill(st, type), 'graphic', 'director'), type !== 'interview-broll' && hasOwnMedia(p) ? ownMedia(st, 'graphic') : ''].filter(Boolean).join('\n\n');
}

// The shared making playbook (how a scene is planned, built and moves, any design system) and the 4-pass sound system, read
// after the design system's own skill, so the style decides the look and these decide the method and the sound.
// (+ how the customer's files are placed and shown, when they added any)
// a 2D shot designer reads the 2D playbook (in core-graphic.md), not the general one written for cards and joins
// and the 2D director reads its one file (core-director.md), not the playbook written for motion-graphics cards and joins
const is2d = (p) => !!p && designOf(p) === '2d-animation';
export const sharedSkill = (who, p = null) => [...(is2d(p) ? [] : ['shared-making']), 'sound-system', ...(p && hasOwnMedia(p) ? ['shared-files'] : [])].map((f) => skillPart(readShared(f), who, 'both')).filter(Boolean).map((x) => `# SHARED BY EVERY DESIGN SYSTEM (the design system above wins where they disagree)\n\n${x}`).join('\n\n');
const checkSkill = (who) => skillPart(readShared('check'), who, 'both');

// ---------- the system prompts (cached: nothing about one video in them except its type and own-media rules) ----------
// The director plans the video, judges it and answers the customer's changes; a builder writes one scene's file at a time. Each
// reads only its own parts of the skill. Every builder of a video has the same system prompt, so it is read from the cache.
export function directorSystem(p) {
  return `You are the director of Zancut, a premium video studio: a senior editor at a desk. You read the customer's material,
plan the video scene by scene, judge the rendered frames and answer the customer's changes; motion designers build the scenes you
plan. You turn what is said into what is seen: for every moment you read its meaning and feeling and the customer's note for
those words, find a literal visual metaphor that acts out the words, and brief its design from scratch for that moment. Strictly
by the design system skill below.

The customer's own inputs are orders, not suggestions: their notes on lines, their Prompt of orders, and the files they add with
where they want them. Read them first, follow them and make them look premium; never ignore one. A file goes where it truly fits
the words: when a part of one fits nowhere, it is shown another way or left out and the customer is told why (the files skill).
Their real file always beats a drawing of it: a recording that shows what the words say is shown as it is, never redrawn. Only
a part that is wrong for its words (an error on screen, something off-topic) may be shown another way, and only until they ask
for it: when they say to use it anyway, use it exactly as they ask.

Your tools are your desk: save_storyboard (plan), look (one scene's real frames), look_video (one frame of every scene and the
joins), change_scenes (the customer's changes), check_sync and retime (word timing), mix (the whole video's sound and frame) and
report. Code checks every call and tells you what is wrong. You never ask questions: you decide like a senior editor and keep your
messages short (the work is in the tools).

# THE DESIGN SYSTEM SKILL (your only rules — follow them strictly)

## Directing
${directorSkill(p)}
${sharedSkill('director', p)}

${is2d(p) ? '' : `# JUDGING THE WORK (look shows you a scene the way a viewer sees it on a phone)
${checkSkill('director')}
`}
${ADOPT}`;
}
export function builderSystem(p) {
  return `You are a motion designer of Zancut, a premium video studio. The director planned this video scene by scene; you build
the graphic scenes you are given as HTML + CSS + GSAP, look at the real rendered frames and fix what you see until it is right.
Every scene acts out its words with the literal visual metaphor of its row, designed from scratch for that moment. Strictly by the
design system skill below. The customer's notes and orders for your scene are orders: follow them exactly and make them premium.
You never ask questions and keep your messages short (the work is in the tools).

# THE DESIGN SYSTEM SKILL (your only rules — follow them strictly)

## Designing the graphics
${graphicSkill(p)}
${is2d(p) ? libraryForBuilders() : ''}
${GRAPHIC_CONTRACT}

${sharedSkill('graphic', p)}

# CHECKING YOUR WORK (the frames you get back show the scene the way a viewer sees it on a phone)
${checkSkill('graphic')}
Never stop at "it renders": stop when it would pass a senior art director at a premium studio.`;
}

// ---------- the storyboard ----------
const MODES = {
  talking: '"thMode": "popout-box-split | behind-head-depth | bg-replace-stage | over-torso-glass | lower-third-kinetic | masked-pip-stage | full-broll-takeover | speaker"',
  interview: '"thMode": "over-torso-glass | lower-third-kinetic | masked-pip-stage | full-broll-takeover | speaker"',
  screen: '"srMode": "speaker-intro-hook|pc-browser-spotlight|mobile-device-stage|concept-takeover-graphic|none"',
  faceless: '"mode": "full-broll-takeover"',
};
const ROW = (kind, scr = false) => `{
  "from": 0, "to": 9,
  "say": "the spoken words of this row",
  "idea": "meaning + feeling, ≤ 12 words",
  "metaphor": "the literal visual metaphor that acts out the words, one sentence",
  "piece": "custom | ${kind === 'screen' ? 'screen' : kind === 'faceless' ? '' : scr ? 'speaker | screen | ' : 'speaker | '}stock-photo | stock-video | mine",
  ${MODES[kind]},
  "archetype": 1,
  "bgStage": "stage-radial-tint | stage-spotlight-cone | stage-perspective-floor | stage-eclipse-horizon | stage-elevated-wash | none",
  "design": "for the motion designer: hero + ≥2 supporting chips, where they sit, what moves on which wordLock, the exact on-screen words and numbers",
  "wordLocks": [{ "word": 3, "event": "the hero card lands" }],
  "anchorIn": null,
  "anchorOut": { "type": "orb|card|pill|beam|box|ring|line", "xPct": 50, "yPct": 50, "wPx": 420, "hPx": 120, "color": "var(--zk-a)", "scale": 1, "look": "how the shape is drawn so two builders draw it the same: fill, edge, glow, what is inside it" },
  "pivot": false,
  "rise": false,
  "transition": "cut | zoom-blur | blur",
  "icons": ["the icons, logos and emoji this scene needs: plain words, brand names or the emoji itself (code fetches them)"],
  "captions": "show | hide",${kind === 'screen' || scr ? '\n  "focus": [x, y, w, h],' : ''}${kind === 'talking' || kind === 'interview' ? '\n  "punch": [5],' : ''}
  "reuse": { "scene": 2, "how": "what changes from that scene: the words, numbers, colours, one element" },
  "media": { "search": "2–4 plain English words of what to see", "kind": "photo | video" },  (or the customer's clip: { "mine": "<file>", "steps": [[word, second], …] })
  "stock": { "search": "2–4 plain English words of what to see", "text": "words on top", "sub": "small line" },
  "mine": { "file": "assets/mine/<the customer's file>", "kicker": "SMALL BADGE", "text": "one line" }
}`;
const ADOPT = `Adopt & Elevate: customers write casual notes ("make it go boom", "something cool here", "show money"). Adopt the wish
behind the words and elevate it into a professional choice in this design system: the metaphor, archetype, mode, motion and
where the sound lands ("boom" → a fast radial ripple with an impact; "show growth" → a luminous spline climbing to the number
that is said; "calm here" → a slow drift, no texture sound). Never ignore a note; never take it so literally that it looks cheap.`;
// ---------- the budget: every graphic scene is a builder's work (most of a video's tokens), so a video gets a few good ones ----------
// storytelling: every scene is a graphic, so each carries a whole idea for 4–7 s. Talking / interview / screen: the speaker or the
// screen carries the video (captions + punch-ins by code, free) and graphics land only on the moments that matter.
export const videoSecs = (words) => Math.max(1, (words.at(-1)?.end ?? 0) - (words[0]?.start ?? 0));
// The speaker's pace, measured on the word times (no AI): words per second, where a sentence ends (its punctuation, or a clear
// pause of 0.6 s or more; with no punctuation at all, a pause of 0.45 s) and how long a sentence lasts. The voice is the clock:
// a scene ends only at one of these points, and scenes and motion follow the speaker's pace.
export function voicePace(words) {
  const W = (words || []).filter((w) => Number.isFinite(+w?.start) && Number.isFinite(+w?.end));
  if (W.length < 4) return null;
  const secs = Math.max(1, W.at(-1).end - W[0].start), rate = W.length / secs, ends = [], lens = [];
  const END = /[.!?।]["')]*$/, punct = W.some((w) => END.test(String(w.text || ''))), gap = (i) => W[i + 1].start - W[i].end;
  W.forEach((w, i) => { if (i < W.length - 1 && (punct ? END.test(String(w.text || '')) || gap(i) >= 0.6 : gap(i) >= 0.45)) ends.push(i); });
  let a = 0; for (const b of ends) { lens.push(W[b].end - W[a].start); a = b + 1; }
  if (a < W.length) lens.push(W.at(-1).end - W[a].start);
  const sentence = [...lens].sort((x, y) => x - y)[Math.floor(lens.length / 2)] || secs;
  return { secs: Math.round(secs), rate: Math.round(rate * 100) / 100, feel: rate < 2.4 ? 'calm' : rate < 3 ? 'steady' : 'brisk', ends, sentence: Math.round(sentence * 10) / 10 };
}
// seconds of voice per graphic scene: a slower voice gets fewer, longer scenes; the customer's pace leans it a little
const perScene = (p, rate) => (!rate ? 5.5 : rate < 2.4 ? 6.5 : rate < 3 ? 5.5 : 4.5) * (p.pace === 'calm' ? 1.2 : p.pace === 'fast' ? 0.85 : 1);
// lines: screen recordings with their own voice (work/screen-lines.json): its "graphic" lines are carried by graphics like storytelling
export function graphicBudget(p, secs, lines = null, rate = null) {
  const kind = kindOf(p), per = perScene(p, rate);
  if (kind === 'screen' && lines?.length) { const g = lines.filter((l) => l.show === 'graphic').reduce((a, l) => a + l.T, 0); return Math.max(2, Math.ceil(g / per) + Math.ceil((secs - g) / 14)); }
  return Math.max(2, Math.ceil(secs / (kind === 'faceless' ? per : kind === 'screen' ? 12 : per * 1.7)));
}
function budgetBlock(p, words, lines = null) {
  const kind = kindOf(p), secs = videoSecs(words), pace = voicePace(words), n = graphicBudget(p, secs, lines, pace?.rate);
  const how = kind === 'faceless'
    ? `Every scene is a graphic, so each one carries one complete thought (a sentence or two) for as long as the speaker takes to
say it, with its beats on the words that carry the idea. Never a new scene for each clause.`
    : kind === 'screen' && lines?.length
      ? `The voice was recorded on its own and the screen recordings were matched to it line by line (the list "What the screen
shows, line by line" below). A line marked SCREEN shows the screen ("piece": "screen"; code zooms to the exact element named).
A line marked GRAPHIC is carried by a designed graphic like a Storytelling video: the intro, advice, warnings, the outro, and a
line that only says to go to a website (a designed browser bar typing that address, the page appearing; M02). Never a plain
text card, never the raw recording for a GRAPHIC line. The SCREEN/GRAPHIC marks are what the matching found: follow them unless
the words clearly say otherwise. A graphic lasts as long as its thought; several GRAPHIC lines may share one scene.`
      : kind === 'screen'
        ? `The screen carries the video. Graphics where the screen cannot show the idea: often the hook, a key concept and the ending, each as long as its thought.`
        : `A person speaks to the camera: they are the anchor (captions run under them). From what is said, decide moment by moment
where the person alone carries it, where a graphic, a b-roll, a lower third, words behind the head or a pop-out carry it, and
where a punch-in ("punch": [word]) lands (the making playbook's "A person on camera"). A graphic where it earns its place: the hook, a number, a list or a comparison, the key claim,
the call to action. Each graphic carries one complete thought, for as long as the speaker takes to say it; where the person is
seen is your call (the playbook's "A person on camera"), and they come back between full-screen graphics. The captions run the
whole video in their own lane (y 77–93% of the frame): no graphic is planned there, and nothing ever covers the face.`;
  return `
## How many graphic scenes (a guide from this voice, not a quota)
Every graphic scene is designed and checked by hand, so plan about ${n} graphic ("custom") scenes for this ${Math.round(secs)} s
video: fewer when the content needs fewer, more only where the content truly needs them (code stops a plan above ${Math.ceil(n * 1.5)}).
How many scenes, where they cut and what each one is (a graphic, b-roll, the person, a lower third, words behind the head, the
screen) is your decision from what is said and how.
${how}
${pace ? `
## The voice's pace (measured on the word times by code)
${pace.secs} s of voice at ${pace.rate} words per second: a ${pace.feel} speaker; a sentence lasts about ${pace.sentence} s. The voice
is the clock, not a timer: a row is one complete thought (often one or two sentences: about ${Math.round((pace.secs / Math.max(1, n)) * 10) / 10} s a graphic scene here) and
ends only where a sentence ends or the speaker clearly pauses, after one of these word numbers: ${pace.ends.join(', ')}. A slower
voice gets fewer, longer scenes and calmer motion; never a new scene for each clause, never a scene that ends in the middle of a
phrase. Word locks only on the words that carry the idea (2–3 in most scenes, at most 4).
` : ''}${kind !== 'screen' && beside(p) && lines?.length ? `
The customer's screen recordings were matched to the voice line by line (the list "What the screen shows, line by line" below).
A line marked SCREEN is a "screen" row: the recording in a window, zoomed by code to the exact element named (never a graphic
for it, never boxes drawn on it). The other lines are the speaker or graphics as above. "screen" rows do not count in the budget.
` : ''}Reuse: when a later moment means the same as an earlier graphic scene, or its metaphor fits after small changes (the same object,
the same comparison, the same kind of list), give that row "reuse": {"scene": <the earlier scene's number>, "how": "what changes"}.
Its builder adapts that scene's file instead of designing from zero. Only when it truly fits the words; never force it, and never
right after the scene it reuses.
`;
}
// the mix a change round set (sb.video.mix): { sfxDb, risers, musicDb, zoom, captions: 'on'|'off', capScale }
export const mixOf = (sb) => (sb?.video?.mix && typeof sb.video.mix === 'object' && Object.keys(sb.video.mix).length ? sb.video.mix : null);
export const mineName = (file) => `assets/mine/${path.basename(String(file))}`;
function customerBlock(p, words) {
  const t = p.transcript || {};
  const removed = (t.removed || []).filter(([a, b]) => Number.isInteger(a) && Number.isInteger(b));
  const say = (a, b) => words.slice(a, b + 1).map((w) => w.text).join(' ').slice(0, 160);
  const notes = (t.lines || []).filter((l) => (l.hint || '').trim() || l.file);
  const file = (l) => { const a = (p.assets || []).find((x) => x.file === l.file); return a ? ` [attached: ${mineName(a.file)} (${isOwnClip(a, p) ? (a.role === 'screen' ? 'screen recording' : 'video clip') : 'picture'})]` : ''; };
  const media = (p.assets || []).filter((a) => isOwnMedia(a, p) && !a.comment); // a file attached to a comment belongs to that comment
  const music = (p.assets || []).find((a) => a.role === 'music');
  return `
## The customer's cut (decided on the transcript: strict)
${removed.length ? `They removed these first-cut words: ${JSON.stringify(removed)}. Rows still cover every word number (removed ones are skipped).` : 'They kept every word.'}
${notes.length ? `
## The customer's notes, line by line (orders: each one is followed in the rows of those words)
${notes.map((l) => `- words ${l.from}–${l.to} "${say(l.from, l.to)}" → ${(l.hint || '').trim() ? `"${String(l.hint).trim().slice(0, 400)}"` : 'use the attached file here'}${file(l)}`).join('\n')}
` : ''}
${ADOPT}
${media.length ? `
## The customer's own pictures and clips (use every one where its note says, or where it fits): a "mine" row each
${media.map((a) => `- ${mineName(a.file)} (${isOwnClip(a, p) ? `${a.role === 'screen' ? 'screen recording' : 'video clip'}${a.duration ? `, ${Number(a.duration).toFixed(1)} s` : ''}` : 'picture'})${a.note ? ` — where: "${a.note}"` : ''}${logLine(a) ? `\n  ${logLine(a)}` : ''}`).join('\n')}${media.some((a) => a.log?.steps?.length) ? `\nA clip shown in a graphic row ("media": {"mine": "<file>"}) follows the voice: give its moments in "steps": [[word, second], …], at that word the clip is at that second (one pair per spoken step, from the list above). Code cuts the clip to those words (sped up or slowed down), so each step is on screen while it is said. A part of the clip that does not belong to this row (another phone, another app) is never shown.` : ''}
` : ''}${music ? `\n## The customer's own music\n"${music.original || music.file}" is the music bed${music.note ? ` (note: "${music.note}")` : ''}.\n` : ''}`;
}
// The customer's own words about this video (what they want + the Prompt of orders in Step 2): the most important input.
// The lead follows every line before its own ideas; every scene builder is told them too.
export const ordersText = (p) => [p.prompt, p.instructions, p.filmOrders].map((x) => String(x || '').trim()).filter(Boolean).join('\n'); // filmOrders: the film-wide directions the 2D planner read in the customer's script
const ordersBlock = (p) => (ordersText(p) ? `\n## The customer's orders (the most important input: follow every line exactly, before your own ideas; where an order and the skill disagree, the order wins unless it would break the frame, the readability or the voice timing)\n${ordersText(p).slice(0, 4000)}\n` : '');

// The lead's first message: this video. extra: { reference, facts, words (first-cut words), screen (the screen events),
// footage (true when a sheet of frames from the footage follows this text) }
export function leadPrompt(p, brief, extra = {}) {
  const kind = kindOf(p), words = extra.words || [];
  return `Plan the video "${p.name}" as a storyboard. You will build every graphic scene of it yourself next, so plan what you can
make beautiful.

${setupBlock(p)}
${extra.animScript ? `\n## The production script (the 2D film's plan, written by the animation planner; the words are recorded)\n${extra.animScript}\n` : ''}${extra.reference ? `\n## Style reference (from a video the customer gave; take its feel in this design system)\n${String(extra.reference).slice(0, 3000)}\n` : ''}${ordersBlock(p)}${(p.styleMemory || []).length ? `\n## This customer's taste\n${p.styleMemory.map((x) => `- ${x}`).join('\n')}\n` : ''}${customerBlock(p, words)}${extra.facts ? `\n## Facts from the customer's reference files (names, numbers and claims come from here; never shown as a file)\n${extra.facts}\n` : ''}${extra.footage ? `\n## The footage\nThe picture after this text is a sheet of frames from the first cut, left to right and top to bottom, evenly spread over the\nvideo. Look at it: the framing, where the face is, the light, the colours, what is behind the speaker.\n` : ''}
${budgetBlock(p, words, extra.screenLines)}
## The storyboard: call save_storyboard with this JSON
Word numbers are the numbers of "The first cut" list in the Brief (number:word@second). Rows follow each other with no gap and
no overlap and together cover every word from the first to the last.
\`\`\`json
{
  "video": { "mood": "calm | upbeat | dramatic | inspiring | …", "hook": "what the first second shows", "ending": "what the last seconds show", "music": "bed | none", "captions": "on | off" },
  "memory": { "look": "the one visual language: hero placement, type weight, how graphics sit", "motion": "the motion family", "rhythm": "e.g. long → short → short → pause → impact", "recurring": "what comes back" },
  "cut": { "removeWords": [], "fixRanges": [[a, b, "the sentence spelled right"]] },${hasOwnMedia(p) ? `
  "fileNotes": ["for the customer, one short plain line each: a file, or a part of one, you left out or showed another way than their note asks, and why"],` : ''}
  "rows": [
    ${ROW(kind, beside(p)).replace(/\n/g, '\n    ')}
  ]
}
\`\`\`
Fix EVERY misheard or misspelled word of the kept speech with fixRanges (the right text for those word numbers; captions come
from it). Keep the JSON lean: leave out every field a row does not use. Never write library IDs, backups or stickers.
When save_storyboard reports a problem, fix it and save again. When it is saved, answer with one short line.
${(kind === 'screen' || beside(p)) && extra.screenLines?.length ? `\n## What the screen shows, line by line (word numbers of the first cut; SCREEN = show the recording, GRAPHIC = design it)\n${extra.screenLines.map((l) => `- words ${l.from}–${l.to} (${Number(l.t0).toFixed(1)} s, ${Number(l.T).toFixed(1)} s) ${l.show === 'graphic' ? 'GRAPHIC' : 'SCREEN'}${l.what ? `: ${l.what}` : ''} · "${String(l.says).slice(0, 120)}"`).join('\n')}\n` : ''}${kind === 'screen' && extra.screen?.events?.length ? `\n## The screen recording, as tracked by code (seconds of the first cut; deviceAspect ${extra.screen.deviceAspect})\n${extra.screen.events.map((e) => `- ${Number(e.fromSec).toFixed(1)}–${Number(e.toSec).toFixed(1)} s ${e.action}${e.targetLabel ? ` "${e.targetLabel}"` : ''}${e.focusRectPct ? ` focus [${e.focusRectPct.join(', ')}]` : ''}${e.idleScreen ? ' IDLE' : ''}${e.calloutSuggestion ? ` — ${e.calloutSuggestion}` : ''}`).join('\n')}\n` : ''}
${String(brief || '').trim()}`;
}
// A video built before its editor's session was kept (or whose session is gone): the lead reads what was built instead of
// planning again.
export function builtPrompt(p, brief, sb, extra = {}) {
  return `${leadPrompt(p, brief, extra).replace(/\n## (?:The budget|How many graphic scenes)[\s\S]*?answer with one short line\.\n/, '\n')}

## This video is already built
You planned it earlier; this is its storyboard (scenes with a built file are done). Do not plan again: read it, then answer
"ready". What comes next follows: the scenes still to build, or the customer's changes.
\`\`\`json
${JSON.stringify({ video: sb.video, memory: sb.memory, rows: sb.rows.map(({ file, ...r }) => r) })}
\`\`\``;
}
export function parseStoryboard(text) {
  const m = String(text || '').match(/```json\s*([\s\S]*?)```/) || String(text || '').match(/(\{[\s\S]*\})/);
  if (!m) return null;
  try { const sb = JSON.parse(m[1]); return Array.isArray(sb.rows) && sb.rows.length ? sb : null; } catch { return null; }
}
// Code keeps only what must be true for the page to work: rows back to back (no gap, no overlap), valid values, anchors chained
// on cut joins (the cutless contract) and one ground per run of joined scenes. Every choice of design, pace and camera (how many
// scenes, where they cut, archetypes, stages, transitions, word locks, punch-ins, risers) stays as the director made it.
const STAGES = ['stage-radial-tint', 'stage-spotlight-cone', 'stage-perspective-floor', 'stage-eclipse-horizon', 'stage-elevated-wash'];
const POSE = (a) => (a && typeof a === 'object' && Number.isFinite(+a.xPct) && Number.isFinite(+a.yPct) ? { type: String(a.type || 'card').slice(0, 10), xPct: Math.max(0, Math.min(100, +a.xPct)), yPct: Math.max(0, Math.min(100, +a.yPct)), wPx: Math.max(4, Math.min(4000, +a.wPx || 200)), hPx: Math.max(4, Math.min(4000, +a.hPx || 120)), color: String(a.color || 'var(--zk-a)').slice(0, 40), scale: Math.max(0.1, Math.min(4, +a.scale || 1)), ...(typeof a.look === 'string' && a.look.trim() ? { look: a.look.trim().slice(0, 200) } : {}) } : null);
export function tidyStoryboard(p, sb, nWords) {
  // the visible transitions this design system allows (styles.json "transitions"; light leaks are not glass or editorial)
  let MOVES = (styleInfo(p)?.transitions || ['zoom-blur', 'blur']).filter((x) => ['zoom-blur', 'blur', 'light-leak'].includes(x));
  // where the director left no valid transition: a calm video gets the soft blur, others alternate (its own choice always stays)
  const calmMood = /calm|caring|gentle|soft|serious|informative|educational|medical|warm|relax/i.test(String(sb.video?.mood || ''));
  if (!MOVES.length) MOVES = ['blur'];
  const pick = (i) => (calmMood && MOVES.includes('blur') ? 'blur' : MOVES[i % MOVES.length]);
  const kind = kindOf(p), rows = sb.rows.map((r, k) => ({ ...r, _k: k })).filter((r) => Number.isInteger(+r.from) && Number.isInteger(+r.to)).map((r) => ({ ...r, from: +r.from, to: +r.to })).sort((a, b) => a.from - b.from);
  if (!rows.length) return null;
  rows[0].from = 0;
  for (let i = 1; i < rows.length; i++) rows[i].from = rows[i - 1].to + 1; // no gap, no overlap: each row starts right after the last
  for (let i = 0; i < rows.length; i++) rows[i].to = i < rows.length - 1 ? Math.max(rows[i].from, rows[i + 1].from - 1) : Math.max(rows[i].from, nWords - 1);
  const keep = rows.filter((r, i) => r.to >= r.from && (i === rows.length - 1 || r.from < nWords));
  keep.forEach((r, i) => {
    const prev = keep[i - 1];
    if (kind === 'faceless' && r.piece === 'speaker') r.piece = 'custom';
    if (kind === 'screen' && r.piece === 'speaker') r.piece = 'screen';
    if (!r.piece) r.piece = 'custom';
    const cutJoin = prev && prev.piece === 'custom' && r.piece === 'custom' && !['over-torso-glass', 'lower-third-kinetic', 'behind-head-depth'].includes(r.thMode) && !['over-torso-glass', 'lower-third-kinetic'].includes(prev.thMode);
    // One continuous film: scenes joined on an anchor keep ONE ground (the same stage, which carries on from where the last scene
    // left it). The ground changes only at a pivot, the director's deliberate turn of the idea: that join arrives with a visible
    // transition instead of a cut.
    const pivot = Boolean(cutJoin && r.pivot === true);
    const graphicChain = Boolean(cutJoin && !pivot);
    delete r.pivot; if (pivot) r.pivot = true;
    const frozen = r._frozen; delete r._frozen; // a scene built before and kept as it is (a part planned again): its ground stays as built
    if (r.piece === 'custom') {
      if (frozen) r.groundRun = graphicChain ? (prev.groundRun || 0) + 1 : 0;
      else if (graphicChain) { r.bgStage = prev.bgStage; r.groundRun = (prev.groundRun || 0) + 1; }
      else {
        r.groundRun = 0;
        if (!STAGES.includes(r.bgStage) && r.bgStage !== 'none') r.bgStage = STAGES[i % STAGES.length];
      }
      r.archetype = Math.max(1, Math.min(7, +r.archetype || 1));
    } else delete r.groundRun;
    r.anchorIn = POSE(r.anchorIn); r.anchorOut = POSE(r.anchorOut);
    if (graphicChain && prev.anchorOut) { r.anchorIn = prev.anchorOut; r.transition = 'cut'; }
    // a film's cut (styles.json filmCuts: 2D Animation): the director's hard cut between two shots stays a cut
    else if (styleInfo(p)?.filmCuts && (r.transition === 'cut' || !r.transition)) { r.transition = 'cut'; r.anchorIn = null; }
    else { if (r.transition === 'cut' || !r.transition || !MOVES.includes(r.transition)) r.transition = i === 0 ? 'cut' : pick(i); if (!graphicChain) r.anchorIn = null; }
    // the director's riser + hit into this scene (the engine places it where the director marks, nowhere else)
    if (r.rise === true) r.rise = true; else delete r.rise;
    // the icons, logos and emoji the row needs (code looks them up before its builder starts)
    r.icons = r.piece === 'custom' && Array.isArray(r.icons) ? [...new Set(r.icons.map((x) => String(x || '').trim().slice(0, 40)).filter(Boolean))].slice(0, 6) : [];
    if (!r.icons.length) delete r.icons;
    // a 2D shot's needs: what it uses, in plain words (code finds the library parts for them: server/parts.mjs)
    r.needs = r.piece === 'custom' && Array.isArray(r.needs) ? [...new Set(r.needs.map((x) => String(x || '').trim().slice(0, 100)).filter(Boolean))].slice(0, 12) : [];
    if (!r.needs.length) delete r.needs;
    // every word on screen, written out by the director: one set of words for the designer, the reviewer and the customer's changes
    r.texts = Array.isArray(r.texts) ? r.texts.map((x) => ({ on: String(x?.on || '').trim().slice(0, 80), words: String(x?.words || '').trim().slice(0, 300) })).filter((x) => x.words).slice(0, 16) : [];
    if (!r.texts.length) delete r.texts;
    r.wordLocks = (Array.isArray(r.wordLocks) ? r.wordLocks : []).filter((x) => x && Number.isInteger(+x.word) && +x.word >= r.from && +x.word <= r.to).slice(0, 8).map((x) => ({ word: +x.word, event: String(x.event || '').slice(0, 120) }));
    // punch-ins (a speaker row's zoom on its strongest words): whole word numbers inside the row, at most 2
    r.punch = r.piece === 'speaker' && Array.isArray(r.punch) ? [...new Set(r.punch.map(Number).filter((w) => Number.isInteger(w) && w >= r.from && w <= r.to))].sort((a, b) => a - b).slice(0, 2) : [];
    if (!r.punch.length) delete r.punch;
  });
  // reuse: the scene number as the lead sent it → an earlier graphic row of the tidy list that is built from zero (not itself a reuse)
  keep.forEach((r, i) => {
    const src = r.piece === 'custom' && r.reuse && typeof r.reuse === 'object' ? keep.findIndex((x) => x._k === Math.round(Number(r.reuse.scene)) - 1) : -1;
    r.reuse = src >= 0 && src < i - 1 && keep[src].piece === 'custom' && !keep[src].reuse?.scene ? { scene: src + 1, how: String(r.reuse.how || '').slice(0, 400) } : null;
  });
  keep.forEach((r) => { if (!r.reuse) delete r.reuse; delete r._k; });
  sb.rows = keep;
  sb.v = 3; // planned with the director deciding risers, music and captions (older storyboards keep the engine's own)
  return sb;
}

// ---------- a part planned again on its real timings (words a–b) ----------
// words: the first-cut words (their seconds are now right)
export function replanPrompt(p, sb, a, b, words) {
  const kept = (r) => (r ? `${r.piece}${r.thMode || r.srMode ? ` · ${r.thMode || r.srMode}` : ''} · archetype ${r.archetype || '-'} · ${r.bgStage || '-'}: "${String(r.metaphor || r.say || '').slice(0, 160)}"` : 'none');
  const before = sb.rows.filter((r) => r.to < a).at(-1), after = sb.rows.find((r) => r.from > b);
  const old = sb.rows.filter((r) => r.to >= a && r.from <= b), r2 = (x) => Math.round(x * 100) / 100;
  const ws = words.slice(a, b + 1).map((w, k) => `${a + k}:${w.text}@${r2(w.start)}`).join(' ');
  return `Plan words ${a}–${b} again. The transcript's timings were wrong when you planned them (a stretch of speech was heard
seconds too late), so the old scenes there do not fit the voice: ${old.map((r) => `words ${r.from}–${r.to} became one scene`).join('; ')}.
These words really run from ${r2(words[a]?.start ?? 0)} s to ${r2(words[b]?.end ?? 0)} s (${r2((words[b]?.end ?? 0) - (words[a]?.start ?? 0))} s).

Every other scene is built and stays exactly as it is. Plan only this part, as new scenes of the same video (the same design
system, the memory card, the rhythm, the budget: graphics only where they earn their place), each one idea on these real
seconds, acting out its words.
- The scene before (kept): ${kept(before)}; it ends on ${JSON.stringify(before?.anchorOut || null)}: your first new scene starts from exactly that, on the same ground (${before?.bgStage || '-'}; code carries it on).
- The scene after (kept): ${kept(after)}; it starts from ${JSON.stringify(after?.anchorIn || null)}: your last new scene ends on exactly that.

## The words with their real seconds (number:word@second)
${ws}

## Your answer
Call save_storyboard with {"rows": [...]}: only the new rows (same row format as your storyboard), the first "from" ${a}, the last
"to" ${b}, back to back. When it is saved, answer with one short line.`;
}

// ---------- the customer's changes (Step 3 scene comments, Step 4 timed comments) ----------
// notes: [{ where: 'scene 3' | '0:12.0–0:15.5 (scenes 4, 5)' | 'the whole video', text, image (true when their drawing follows),
//   attach: [{ file, role: image | broll | sound | music, name, duration }] }]
const attachLine = (list) => (list || []).map((a) => {
  const d = a.duration ? `, ${Number(a.duration).toFixed(1)} s` : '', f = path.basename(String(a.file));
  if (a.role === 'image') return ` [picture "${a.name || f}": the file is assets/mine/${f}; it follows this text as a picture. Use it where the note says: in a graphic write <img src="assets/mine/${f}"> (sized and placed like a premium card), or make the scene a "mine" row with {"file":"assets/mine/${f}"}]`;
  if (a.role === 'broll') return ` [video clip "${a.name || f}"${d}: the file is assets/mine/${f}. Make the scene a "mine" row with {"file":"assets/mine/${f}","kicker":"…","text":"…"}, or play it inside a graphic with <video muted playsinline src="assets/mine/${f}">]`;
  if (a.role === 'music') return ` [music "${a.name || f}"${d}: it is long, so it becomes the music bed of the whole video. Nothing to plan for it]`;
  return ` [sound "${a.name || f}"${d}: the file is ${f}. Put "sound": {"file":"${f}","at":<seconds from the scene's start>,"vol":0.7} on the row of the scene where the note says it plays; it plays there as a sound effect]`;
}).join('');
export function changePrompt(p, sb, notes) {
  const near = (k) => (sb.rows[k] ? `${sb.rows[k].piece}${sb.rows[k].thMode || sb.rows[k].srMode ? ` · ${sb.rows[k].thMode || sb.rows[k].srMode}` : ''} · archetype ${sb.rows[k].archetype || '-'} · ${sb.rows[k].bgStage || '-'}` : 'none');
  return `The customer reviewed the video and asks for changes. Like a senior editor, find WHY each note happened and fix the cause,
not only the scene it shows in; keep everything the notes do not touch as it is.

## The customer's notes
${notes.map((x) => `- ${x.where}: "${String(x.text).slice(0, 1500)}"${x.image ? ' (they drew on the frame: their drawing follows this text; red/yellow marks are theirs)' : ''}${attachLine(x.attach)}`).join('\n')}

## The storyboard as built now (your memory card: ${JSON.stringify(sb.memory || {}).slice(0, 500)})
\`\`\`json
${JSON.stringify(sb.rows.map((x, k) => ({ n: k + 1, from: x.from, to: x.to, say: x.say, piece: x.piece, mode: x.thMode || x.srMode, archetype: x.archetype, bgStage: x.bgStage, before: near(k - 1), after: near(k + 1), metaphor: String(x.metaphor || '').slice(0, 160) })))}
\`\`\`
Use look on a scene first when you need to see it as it is now.
${(p.assets || []).some((a) => a.log?.steps?.length) ? `\n## The customer's video clips: what happens when (a row showing one gives its moments in "media"."steps": [[word, second], …]; code cuts the clip to those words)\n${(p.assets || []).filter((a) => a.log?.steps?.length).map((a) => `- ${mineName(a.file)}: ${logLine(a)}`).join('\n')}\n` : ''}
## How you work
1. Diagnose every note before you change anything. Its cause is one of: timing (the visual or a sound comes before or after its
   words: call check_sync on those seconds and read the numbers), design (look at the scene), sound (effects or music too loud,
   wrong, or playing over nothing), framing (the speaker too far, something to hide in the footage), captions, cut (words to
   remove), or taste (the customer simply wants it another way). A note can have several causes.
2. Fix the cause with the right tool: retime (timing), mix (effects_db, risers, music_db, speaker_zoom, captions,
   caption_size), change_scenes (design, or a scene that must act out its words differently). The customer's wish wins on
   taste; on craft (sync, a face covered, unreadable text, sound over the voice) do it right even if they did not name it.
   A note asking for their own file (or the part of it you left out or drew instead) is followed exactly, even where you see a
   flaw in it: the row carries it in "media" and the scene shows it as it is.
3. change_scenes, when scenes change: one call with every scene that must change: the complete new row of each (same format as
   your storyboard rows), plus "change": what the builder must do, in one or two sentences. Keep "from" and "to" and the joins
   to the scenes that do not change; never the same archetype, bgStage or mode as the scene right before or after. A note on a
   moment (a time) belongs to the scenes it touches; a note on the whole video may touch many.
4. Check: check_sync again after retime; look_video when scenes change.
5. report, once, at the end: for every note (its number in the list above) the cause, whether it was our mistake (ours: true
   when the video broke a rule of craft or of the design system; false when it is the customer's taste or the footage),
   how serious, what you found, what you did, and what you could not do and why (e.g. it needs new footage). It is for
   Zancut's team (the customer never sees it): be exact and honest.
Then answer with one short line.`;
}
export function parseRow(text, old) {
  const m = String(text || '').match(/```json\s*([\s\S]*?)```/) || String(text || '').match(/(\{[\s\S]*\})/);
  if (!m) return null;
  try { const r = JSON.parse(m[1]); if (!r || typeof r !== 'object' || Array.isArray(r)) return null; return { ...r, from: old.from, to: old.to, say: old.say || r.say, piece: r.piece || old.piece }; } catch { return null; }
}

// ---------- a graphic scene ----------
export const GRAPHIC_CONTRACT = `## The scene file (strict — the engine renders by seeking the timeline)
- ONE html file: the markup, then one <style>, then one <script>, then the cues comment as its last line.
- The script body runs as function (tl, root, s, d, words, ZK, at): tl = the paused GSAP timeline, root = this scene's section
  (full frame), s = the scene's start second on the video, d = its length, words = [{text, t, e}] spoken in it (video seconds),
  at(x) = s + x. Call \`ZK.unit(root)\` FIRST (it sets --u = 1% of the frame's short side).
- Animate ONLY with tweens on tl at times between s and s + d (use \`immediateRender: true\` on fromTo tweens that start after s).
  Never gsap.to on its own, timers, Math.random, Date, requestAnimationFrame, CSS animations or transitions, repeat: -1.
- Give every class and id the prefix gx- (the page already styles other names). Sizes as calc(var(--u)*N); colours only from the
  tokens (var(--zk-a), --zk-b, --zk-a-tint, --zk-c, --zk-pos, --zk-neg, --zk-bg-deep, --zk-bg-mid, --zk-glass, --zk-ink, --zk-mute,
  --zk-line, --zk-grid) or the recipe's whites; fonts var(--zk-display), var(--zk-font), var(--zk-bangla).
- Kit (ZK): unit(root) · stage(tl, root, {kind, t: s, d}) draws Glossy's bgStage ground as the first element (it carries on from
  the scene before by itself) · rich("text *accent*") · text(el, "…") (Bangla gets its font and spacing by itself) · fit(el, {u, w, h}) · motion(tl, el,
  "pop|glide|snap|fade", time, {dir}) · pop(tl, el, time) · words(tl, el, {text, at: [seconds per word]}) · type(tl, el, {text, t,
  dur}) · count(tl, el, {from, to, t, dur, dec, prefix, suffix}) · draw(tl, svg, time, dur) · icon("name" | "logo:brand" | "set:name"
  from find_icons) → SVG text · emoji("😂", {style: "3d" | "flat"}) → a sticker · peep({face, hair, body, beard, glasses, skin, hairColor,
  top}) → a hand-drawn person (find_people lists the names) · push(tl, el, t, d, 0.05) · breathe(tl, el, t, d) · zones(root) → this layout's free zones in
  pixels · face(root) → the speaker's face box or null · place(root, el, spots).
- Ready parts: the page already has your design system's materials as classes (zk-card, zk-pill, zk-tile, zk-title, zk-num and
  the others your skill lists), for light and dark. Put them on your elements for the material and add your own gx- class for
  size, place and motion; you write less, and every scene shares the exact look.`;
// scene-relative word times quantized to 1/30 s ("the voice is the clock")
const q30 = (x) => Math.round(x * 30) / 30;
// One builder's task: one scene, or a few neighbours built one after another in the same session (the skill, the plan and the
// video are read once for all of them). The scenes' facts come last: everything before them is shared and cached.
// ctx: { n, secs, sceneWords, zones, face, memory, holdOut, note (what to change), current (the scene's file now), looks,
//   reuse: { n, how } (current is then scene n's file, already saved as this scene's start) }
export const sceneTask = (p, r, ctx) => batchTask(p, [{ r, ctx }]);
export function batchTask(p, items) {
  const f = FORMATS[p.format] ? FORMATS[p.format] : FORMATS['9:16'], many = items.length > 1, c0 = items[0].ctx;
  const nums = items.map((x) => x.ctx.n).join(', ');
  // a reuse or a change of a built scene starts from its file: an edit (small replacements), never the whole file again
  const edit = items.every(({ ctx }) => ctx.reuse || (ctx.note && ctx.current));
  const head = many
    ? `Build scenes ${nums} of the storyboard, one after another (you are their builder now; other scenes are built by others in
parallel). Finish each one (save, look, fix) before you start the next. One film: an object that comes back (the same pill, panel,
button) keeps the exact look you gave it (copy its CSS). But every scene is a new idea, designed for its own words: its own
composition, mechanic and motion. Never repeat an earlier scene's layout or choreography with new text.`
    : `${c0.current && !c0.reuse ? 'Change' : 'Build'} scene ${c0.n} of the storyboard (you are its builder now; other scenes are built by others in parallel).`;
  return `${head}
Frame ${f.w}×${f.h} · ${themeOf(p).toUpperCase()} mode.

${items.map(({ r, ctx }) => sceneBlock(p, r, ctx, many)).join('\n\n')}
## How to work${many ? ' (for each scene, in order)' : ''}
1. Plan the scene once before you write: what is on screen at each word lock, every element's place and size in frame pixels,
   its timing, and how it starts from and hands on its anchor. Then ${many ? 'write the scene (or make its change)' : c0.current ? (c0.reuse ? 'adapt the reused design' : 'make the change') : 'write the scene'} in one go and save it with ${edit ? 'edit_scene' : 'save_scene'} (scene ${many ? 'n' : c0.n}). The time variables in the file are video
   seconds: use at(x) with the scene-relative seconds above. The answer shows you the scene's real frames (one every ~2 s, the
   key word landing among them) and what code measured${many ? ', and how it joins the scene before' : ''}.
2. Judge every frame like an art director. Every frame shows something finished that fits the words said at that second: no
   empty frame, box or card waiting for its content, no element that arrives long before or after its word. At each word lock's
   moment its element is complete: in place, fully opaque and sharp (a title still blurred, faded or flying in at its own word
   fails). What the words list builds up and stays (chip after chip, row after row); replace something only when the words move
   on to a new idea. The hero big and clear, main text large and crisp, strong contrast, nothing dim or half-visible, the design
   system's look. When the scenes next to yours are built, the frames also measure your joins with them: a JUMP at your first
   frame is yours to fix (start from the real last frame of the scene before: the same ground, the same shape in the same place).
3. Fix what fails with ONE edit_scene call holding every replacement of this round (small exact replacements; writing the whole
   file again costs many times more): its answer shows the new frames. save_scene again only when the design itself is wrong.
   Fix and look again for as long as something fails. The moment the frames pass and code measured nothing wrong, stop: no
   look and no edit on a scene that passes (polishing a passing scene only costs).
4. When ${many ? 'every scene passes' : 'it passes'}, answer with one line${many ? ' per scene' : ''}: what the scene shows.${is2d(p) && !items.some(({ ctx }) => ctx.note) ? `
This is ROUND 1 of a 2D film (your skill's "Two rounds"). Code already searched the library: each scene below lists its parts. Call
find_parts at most ONCE, only for things none of those lists has. Every cartoon shot is ONE ZC.shot call (your skill's §1: names, metres and
shot sizes, never pixel maths); people, poses and hands only from the library (the closest one when nothing fits); an OBJECT the library lacks
you draw once as a reusable ZS.define with a generic name; motion graphics, B-roll and cards designed freely, in the film's palette with cinematic
light. Save each scene once; a clean save answers in one line, then the next scene. Fix only what a save reports (all of it in one edit_scene):
the reviewer judges the whole film after you. End with a \`gap:\` line for every person's move or hand the library did not have.` : ''}`;
}
// The video as a scene builder needs it. Builders start fresh (not as a copy of the lead's whole planning conversation): the
// setup, the customer's orders, taste and facts, the video's memory card and the plan of every scene in one line. The same text
// for every builder of a round, so it goes after the skill in their system prompt and is read from the cache.
export function videoHandoff(p, sb, extra = {}) {
  const line = (r, i) => `${i + 1}. ${r.piece === 'custom' ? `graphic · ${modeOf(p, r)} · archetype ${r.archetype || '-'} · ${r.bgStage || 'no stage'}${r.groundRun > 0 ? ' (same ground as before)' : ''}` : r.piece}: "${String(r.say || '').slice(0, 160)}" → ${String(r.metaphor || r.idea || '').slice(0, 220)}`;
  const v = sb.video || {};
  const isLong = (sb.rows || []).length > 30;
  const scenesText = isLong
    ? `${sb.rows.slice(0, 4).map(line).join('\n')}\n… [Scenes 5–${sb.rows.length - 4} planned in acts; each builder's task receives its exact 3-scene window: Scene N-1, Scene N, Scene N+1] …\n${sb.rows.slice(-4).map((r, idx) => line(r, sb.rows.length - 4 + idx)).join('\n')}`
    : sb.rows.map(line).join('\n');
  return `# THIS VIDEO (you are one of its scene builders: the lead editor planned it; other builders make the other scenes at the same time)

${setupBlock(p)}
${ordersBlock(p)}${(p.styleMemory || []).length ? `\n## This customer's taste\n${p.styleMemory.map((x) => `- ${x}`).join('\n')}\n` : ''}${extra.animScript && !sb.film?.cast?.length ? `\n## The production script (the 2D film's plan, written by the animation planner; the words are recorded)\n${extra.animScript}\n` : ''}${extra.reference ? `\n## Style reference (from a video the customer gave; take its feel in this design system)\n${String(extra.reference).slice(0, 3000)}\n` : ''}${extra.facts ? `\n## Facts from the customer's reference files (names, numbers and claims come from here)\n${String(extra.facts).slice(0, 4000)}\n` : ''}
## The video as the lead planned it
${[v.mood && `Mood: ${v.mood}`, v.hook && `Hook: ${v.hook}`, v.ending && `Ending: ${v.ending}`].filter(Boolean).join(' · ')}
The memory card (the one look, motion and rhythm every scene shares: match it): ${JSON.stringify(sb.memory || {})}${(() => { const v = voicePace(extra.words); return v ? `\nThe voice: ${v.rate} words per second, a ${v.feel} speaker (a sentence lasts about ${v.sentence} s). Motion follows it: ${v.feel === 'brisk' ? 'lively but never ahead of the words' : 'relaxed and smooth, every element given time to be read'}.` : ''; })()}

${kitBlock(sb)}
## Scenes overview
${scenesText}`;
}
function sceneBlock(p, r, ctx, many) {
  const words = (ctx.sceneWords || []).map((w) => `${q30(w.at).toFixed(2)}s "${w.w}"${w.isEmphasis ? ' ★' : ''}`).join(' · ');
  const locks = (r.wordLocks || []).map((x) => { const w = (ctx.sceneWords || []).find((y) => y.i === x.word); return w ? `at(${q30(w.at).toFixed(2)}) "${w.w}" → ${x.event}` : null; }).filter(Boolean);
  const note = (p.transcript?.lines || []).filter((l) => (l.hint || '').trim() && l.from <= r.to && l.to >= r.from).map((l) => l.hint.trim());
  const screenWords = (r.texts || []).map((x) => `${x.on ? `${x.on}: ` : ''}"${x.words}"`).join(' · ');
  return `${many ? `# Scene ${ctx.n} · length ${ctx.secs.toFixed(2)} s\n` : `Scene ${ctx.n} · length ${ctx.secs.toFixed(2)} s.\n`}
## 3-Scene Transition Window (One continuous broadcast film)
- Entry Context (Scene ${ctx.n - 1}): ${ctx.before ? `${ctx.before}${r.anchorIn ? ` (ends on shape ${JSON.stringify(r.anchorIn)}; start first frame from it)` : ''}` : 'Video opening (arrives fresh with transition)'}
- Target To Build (Scene ${ctx.n}): length ${ctx.secs.toFixed(2)} s · Archetype ${r.archetype || '—'} · Stage: ${r.bgStage || 'none'}${r.groundRun > 0 ? ' (carried on from the scene before)' : ''}
- Exit Context (Scene ${ctx.n + 1}): ${ctx.after ? `${ctx.after}${ctx.holdOut && r.anchorOut ? ` (next scene starts from ${JSON.stringify(r.anchorOut)}; hold still in last 0.3s)` : ''}` : 'Video ending (fade-out in last 0.4s)'}

## The moment
- Words said: "${String(r.say || '').slice(0, 400)}" (${langName(p.language) || 'as spoken'})
- Idea: ${r.idea || ''}
- Literal metaphor (act this out): ${r.metaphor || '—'}
- Archetype: ${r.archetype || '—'} · bgStage: ${r.bgStage || 'none'} · layout mode: ${modeOf(p, r)}
- Your design brief: ${String(r.design || r.show || '').slice(0, 1600)}
${rowPartsText(ctx.parts)}${ctx.ready?.length ? `- Ready to use (fetched for this scene): ${ctx.ready.map((x) => (x.emoji ? `${x.want} → ZK.emoji("${x.want}")` : x.use.length ? `${x.want} → ${x.use.map((n) => `ZK.icon("${n}")`).join(' or ')}` : `${x.want} → nothing found: draw it or use find_icons`)).join(' · ')}\n` : ''}${note.length ? `- The customer asked for (an order): ${note.map((x) => `"${x.slice(0, 500)}"`).join(' · ')}\n` : ''}${ordersText(p) ? `- The customer's orders for the whole video (follow them in this scene too): ${ordersText(p).slice(0, 700).replace(/\n/g, ' · ')}\n` : ''}
## The voice is the clock (scene-relative seconds; ★ = emphasis, the voice peaks there)
${words || '(no words in this scene)'}
${screenWords ? `Words on screen, use them exactly: ${screenWords}\n` : ''}${locks.length ? `Word locks — these events START or LAND exactly there:\n${locks.map((x) => `- ${x}`).join('\n')}` : ''}

## Your layout (frame pixels)
- Free zones: ${JSON.stringify(ctx.zones || {})}${ctx.face ? `\n- The speaker's face (never cover it): ${JSON.stringify(ctx.face)}` : ''}${PERSON_KINDS.has(kindOf(p)) ? `\n- The caption lane (y ${Math.round(0.77 * (FORMATS[p.format] || FORMATS['9:16']).h)}–${Math.round(0.93 * (FORMATS[p.format] || FORMATS['9:16']).h)} px): the captions run there the whole video. Keep it empty; never draw your own captions or subtitles.` : ''}
- Starts from: ${r.anchorIn ? `${JSON.stringify(r.anchorIn)} — the previous scene ends on exactly this shape. Draw it there in your first frame (same place, size, colour${r.anchorIn.look ? `, drawn as: ${r.anchorIn.look}` : ''}) and transform it into your hero; no fade-in of the anchor, and nothing else on screen is new in that first frame except what grows from it.` : 'nothing — it arrives fresh (the engine plays its transition)'}
- Ends with: ${ctx.holdOut && r.anchorOut ? `${JSON.stringify(r.anchorOut)} held still in the last 0.3 s at exactly that place${r.anchorOut.look ? `, drawn as: ${r.anchorOut.look}` : ''} (the next scene starts from it). No fade.` : 'a fade-out in the last 0.4 s'}
- One continuous film, not separate slides: carry the motion through (the direction, the light, the hero's place) from the
  scene before into yours and hand it on to the next; the same visual language, never a reset to an empty frame.
- The ground ${r.groundRun > 0 ? `carries on: this scene uses the SAME ground as the scene before (${r.bgStage || 'none'}), at the same colour and light, and it does not restart or enter again.${/^stage-/.test(String(r.bgStage)) ? ' If you use the kit, ZK.stage does this by itself (the page marks the scene); draw nothing else as a full-frame ground.' : ' Draw it as the scene before does, in the state that scene ends in.'}` : r.pivot ? 'changes here on purpose (the idea turns): the scene arrives with the transition above, not a cut.' : 'starts here (nothing before it to carry on from).'}
${ctx.memory ? `- The video's memory card (match it): ${JSON.stringify(ctx.memory).slice(0, 500)}\n` : ''}- The look: ${styleLook(p)}${r.media?.file ? `\n- Your ${MEDIA.test(r.media.file) ? 'clip' : 'photo'} ("${r.media.search || r.media.mine || ''}") is already in the scene: the first element of root, \`.gx-media\` (full frame, cover; a <${MEDIA.test(r.media.file) ? 'video' : 'img'}> inside). Make it part of the design: a framed card, a device screen, a full background under a tint, a split; move and scale it on the words with tweens, and put the graphics over it. To show it in a frame, place \`.gx-media\` itself there (size and position it, or append it into your frame's screen element). Never hide it under your design and never draw a copy of what it shows.${MEDIA.test(r.media.file) ? clipBrief(p, r, ctx.sceneWords) : ''}` : r.media?.mine ? `\n- The customer's file ${path.basename(String(r.media.mine))} could not be put in this scene. Never draw a copy of it: design the scene around what is said, and say in your answer line that their file was missing.` : r.media && !r.media.file ? '\n- No picture could be found for this scene: design it as a graphic alone.' : ''}
${ctx.beforeCode || ctx.afterCode ? `\n## The neighbours' real code (for the hand-off only)
The scene${ctx.beforeCode && ctx.afterCode ? 's' : ''} you join on a shape ${ctx.beforeCode && ctx.afterCode ? 'are' : 'is'} built. Copy the shared shape from ${ctx.beforeCode && ctx.afterCode ? 'their' : 'its'} real code below: the same element, its CSS,
place, size and colour, so the join is seamless. Take nothing else: your layout, composition mechanic and motion are your own,
made for your words and archetype. A viewer must see a new idea, not the scene before with new text.
${ctx.beforeCode ? `### Scene ${ctx.n - 1} (your first frame starts from its last frame)\n\`\`\`html\n${ctx.beforeCode}\n\`\`\`\n` : ''}${ctx.afterCode ? `### Scene ${ctx.n + 1} (its first frame starts from your last frame)\n\`\`\`html\n${ctx.afterCode}\n\`\`\`\n` : ''}` : ''}${ctx.note ? `\n## What to change\n${ctx.note}\n` : ''}${ctx.reuse ? `\n## Reuse: this scene starts from scene ${ctx.reuse.n}'s design
Its file (below) is already saved as this scene's file. Adapt it to THIS scene with edit_scene: every text and number to these
words, every at(…) time to these word times, the anchors above${ctx.reuse.how ? `, and: ${ctx.reuse.how}` : ''}. The meaning must fit;
when it does not after all, write a new scene with save_scene.
` : ''}${ctx.current ? `\n## The scene's file now (edit it with edit_scene, or rewrite it with save_scene)\n\`\`\`html\n${ctx.current}\n\`\`\`\n` : ''}`;
}
const PERSON_KINDS = new Set(['talking', 'interview']);
// the layout mode a scene is built for (the compositor's own default when the row has none)
export const modeOf = (p, r) => r.thMode || r.srMode || (kindOf(p) === 'screen' ? 'pc-browser-spotlight' : kindOf(p) === 'faceless' ? 'full-broll-takeover' : 'speaker');
// a scene file → checked and written to edit/scenes/: { rel } or { error } (what the builder must fix)
export function writeGraphic(J0, name, html) {
  html = String(html || '').replace(/^\s*```html\s*/, '').replace(/```\s*$/, '').trim();
  if (!/<script>[\s\S]*<\/script>/.test(html)) return { error: 'The file needs one <script> block (the timeline code).' };
  const js = [...html.matchAll(/<script[^>]*>([\s\S]*?)<\/script>/gi)].map((m) => m[1]).join('\n');
  const bad = html.match(/setTimeout|setInterval|Math\.random|Date\.now|new Date|requestAnimationFrame|repeat:\s*-1|@keyframes/); // renders must repeat exactly
  if (bad) return { error: `The file uses "${bad[0]}": renders must repeat exactly. Animate only with tweens on tl.` };
  try { new Function('tl', 'root', 's', 'd', 'words', 'ZK', 'at', js); } catch (e) { return { error: `The script does not run: ${e.message}` }; }
  // a scene stays inside its own time and its own section: "visibility: visible" on a part shows it even while its scene is
  // hidden (a part of scene 7 was seen over 0–45 s), so it becomes "inherit" (visible exactly while the scene is); a lookup in
  // the whole page reaches other scenes' parts, so it looks in the scene only
  const fixed = [];
  const fix = (re, to, what) => { if (re.test(html)) { html = html.replace(re, to); fixed.push(what); } re.lastIndex = 0; };
  fix(/visibility\s*:\s*visible\b/gi, 'visibility:inherit', '"visibility: visible" is now "visibility:inherit" (a part may show only while its scene does)');
  fix(/(visibility\s*:\s*)(["'])visible\2/gi, '$1$2inherit$2', 'visibility "visible" in the script is now "inherit"');
  fix(/\bdocument\.querySelector(All)?\(/g, 'root.querySelector$1(', 'document.querySelector… is now root.querySelector… (only this scene\'s own parts)');
  const rel = `edit/scenes/${name}.html`;
  fs.mkdirSync(path.join(J0, 'edit', 'scenes'), { recursive: true });
  fs.writeFileSync(path.join(J0, rel), html);
  return { rel, fixed };
}
// the designer's sound cues (<!--cues [["wh-deep", 0.62], ...]-->): only families the sound kit has
let KIT = null;
// names from skill packs that our kit calls differently (skills/sound-system.md)
const CUE_ALIAS = { 'tx-reward': 'tx-success', 'wh-soft': 'wh-wind', 'wh-spacey': 'wh-future', 'wh-scifi': 'wh-future', 'tx-gizmo': 'tx-scifi-click' };
export function cuesOf(html, secs) {
  KIT ||= (J(path.join(ENGINE_DIR, 'sfx', 'pro-kit.json'), { items: [] }).items || []).map((x) => x.id);
  let list; try { list = JSON.parse((String(html).match(/<!--\s*cues\s*(\[[\s\S]*?\])\s*-->/) || [])[1]); } catch { return []; }
  if (!Array.isArray(list)) return [];
  const ok = (n) => n === 'typing' || n === 'hit' || /^lib:[a-z0-9-]+$/.test(n) || (/^(wh|tx|rs)-[a-z-]+$/.test(n) && KIT.some((id) => id === n || id.startsWith(`${n}-`))); // lib: = a sound found with find_sound
  return list.filter((x) => Array.isArray(x) && Number.isFinite(+x[1]) && +x[1] >= 0 && +x[1] < secs).map((x) => [CUE_ALIAS[String(x[0])] || String(x[0]), Math.round(+x[1] * 1000) / 1000]).filter(([n]) => ok(n)).slice(0, 8);
}

// ---------- storyboard → engine files ----------
export const firstCutWords = (J0) => wordsOf(J(path.join(J0, 'work', 'first-cut.json')) || J(path.join(J0, 'cut', 'transcript.json'), []));
export const cutWords = (J0) => wordsOf(J(path.join(J0, 'cut', 'transcript.json'), []));
const mapper = (firstWords, words) => (i, last) => {
  const src = firstWords[i]?.src; let k = src == null ? Math.min(i, words.length - 1) : words.findIndex((w) => w.src >= src);
  if (k < 0) k = words.length - 1; if (last && src != null && words[k]?.src > src && k > 0) k--; return Math.max(0, k);
};
export const zen = (ws, args, timeout = 40 * 60000) => new Promise((ok) => execFile('node', [path.join(ENGINE_DIR, 'zen.mjs'), args[0], '--ws', ws, ...args.slice(1)], { timeout, maxBuffer: 1 << 26 }, (e, so, se) => {
  const t = `${so || ''}${se || ''}`; let j = null; for (const s of [...t.matchAll(/\{[^\n]*\}/g)].map((x) => x[0]).reverse()) { try { j = JSON.parse(s); break; } catch { } } ok(j || { ok: false, error: t.slice(-600) });
}));
// a picture the customer gave: placed whole on a plate when it is a logo (transparent background)
const MEDIA = /\.(mp4|mov|m4v|webm)$/i;
// Stock for these rows: 6 candidates each, Sonnet picks from one picture sheet
async function pickStock(J0, rows, ask, orient) {
  const choice = new Map(); if (!rows.length) return choice;
  const cands = await Promise.all(rows.map(async (r) => { const kind = /video/.test(r.piece) ? 'video' : 'photo'; let l = await stockCandidates(r.stock.search, kind, orient).catch(() => []); if (!l.length && kind === 'video') l = await stockCandidates(r.stock.search, 'photo', orient).catch(() => []); return l; }));
  const sheet = path.join(J0, 'work', 'stock-choices.jpg');
  let picks = {};
  if (ask && await candidatesSheet(cands, sheet)) {
    const answer = await ask(`Read job/work/stock-choices.jpg: one row per moment below, top to bottom; candidates 1–6 left to right (grey = none). For each moment pick the candidate that best carries its idea and feeling: subject first, then mood, light and colour; clean, beautiful, on-topic, real; no generic posed smiles. Always pick one.\n${rows.map((r, i) => `Row ${i + 1}: ${r.metaphor || r.idea || r.stock.search}`).join('\n')}\nAnswer only JSON like {"1": 3, "2": 1}.`).catch(() => '');
    try { picks = JSON.parse(String(answer).match(/\{[^{}]*\}/)?.[0] || '{}'); } catch { }
  }
  rows.forEach((r, i) => { const k = Number(picks[i + 1] ?? picks[String(i + 1)]); const list = cands[i]; choice.set(r, list[(k >= 1 && k <= list.length ? k : 1) - 1] || null); });
  return choice;
}
// the layout zones and face box of each scene, computed by the compositor's own rules, for the motion designer
function layoutInfo(J0, p, r) {
  const f = FORMATS[p.format] || FORMATS['9:16'], W = f.w, H = f.h, TALL = H > W * 1.15, WIDE = W > H * 1.15;
  const R = (x, y, w, h) => ({ x: Math.round(x * W), y: Math.round(y * H), w: Math.round(w * W), h: Math.round(h * H) });
  const m = r.thMode || r.srMode;
  const Z = {
    'popout-box-split': TALL ? { top: R(0.06, 0.06, 0.88, 0.38), bridge: R(0.06, 0.45, 0.88, 0.06), speakerBox: R(0.06, 0.53, 0.88, 0.39) } : WIDE ? { top: R(0.04, 0.1, 0.46, 0.8), speakerBox: R(0.54, 0.16, 0.4, 0.76) } : { top: R(0.06, 0.05, 0.88, 0.36), speakerBox: R(0.08, 0.5, 0.84, 0.44) },
    'behind-head-depth': { behind: TALL ? R(0.04, 0.1, 0.92, 0.38) : R(0.04, 0.08, 0.92, 0.5) },
    'bg-replace-stage': { left: TALL ? R(0.02, 0.3, 0.3, 0.4) : R(0.03, 0.15, 0.3, 0.7), right: TALL ? R(0.68, 0.3, 0.3, 0.4) : R(0.67, 0.15, 0.3, 0.7), person: TALL ? R(0.25, 0.15, 0.5, 0.85) : R(0.33, 0.1, 0.34, 0.9) },
    'over-torso-glass': TALL ? { face: R(0.1, 0.1, 0.8, 0.33), header: R(0.08, 0.44, 0.84, 0.08), card: R(0.1, 0.53, 0.8, 0.31) } : { header: R(0.52, 0.4, 0.42, 0.1), card: R(0.55, 0.52, 0.37, 0.33) },
    'lower-third-kinetic': { lower: TALL ? R(0.06, 0.74, 0.88, 0.12) : R(0.05, 0.72, 0.5, 0.16) },
    'masked-pip-stage': TALL ? { pip: R(0.06, 0.6, 0.36, 0.3), stage: R(0.04, 0.06, 0.92, 0.52) } : { pip: R(0.04, 0.58, 0.24, 0.36), stage: R(0.3, 0.06, 0.66, 0.88) },
  }[m];
  if (Z) return { zones: Z, face: null };
  if (m === 'pc-browser-spotlight' || m === 'mobile-device-stage') {
    const sw = J(path.join(J0, 'work', 'screen.json'), {})?.aspect || 16 / 9;
    if (m === 'mobile-device-stage') { let h = H * (TALL ? 0.66 : 0.82), w = h * Math.min(sw, 0.6); if (w > W * 0.62) { w = W * 0.62; h = w / sw; } return { zones: { device: { x: Math.round((W - w) / 2), y: Math.round((H - h) / 2), w: Math.round(w), h: Math.round(h) }, free: 'everything outside the device' } }; }
    let w = W * (TALL ? 0.92 : 0.74), h = w / sw; if (h > H * (TALL ? 0.6 : 0.78)) { h = H * (TALL ? 0.6 : 0.78); w = h * sw; }
    return { zones: { device: { x: Math.round((W - w) / 2), y: Math.round((H - h) / 2 + (TALL ? H * 0.03 : H * 0.02)), w: Math.round(w), h: Math.round(h) }, free: 'everything outside the device' } };
  }
  return { zones: { full: R(0, 0, 1, 1), safe: TALL ? R(0.06, 0.08, 0.82, 0.77) : R(0.05, 0.06, 0.9, 0.88) } };
}
// the cut words of a row, scene-relative (seconds from the scene's start), with emphasis from Gemini
function sceneWordsOf(J0, r, toNew, words, sceneStart, emph) {
  const a = toNew(r.from, false), b = toNew(r.to, true);
  return words.slice(a, b + 1).map((w, k) => ({ i: r.from + k, w: w.text, at: Math.max(0, w.start - sceneStart), end: Math.max(0, w.end - sceneStart), isEmphasis: emph.has(r.from + k) }));
}

// Each scene's facts for its builder, on the cut: its length, its words (scene-relative), its free zones and how it joins the next.
const cutLength = (J0) => Math.max(0, ...(J(path.join(J0, 'cut', 'segments.json'), {})?.segments || []).map((s) => Number(s.outEnd) || 0));
export function sceneContexts(d, p, sb) {
  const J0 = jobDir(d.ws), firstWords = firstCutWords(J0), words = cutWords(J0), toNew = mapper(firstWords, words);
  const gem = J(path.join(J0, 'work', 'GEMINI.json'), {}) || {};
  const emph = new Set([...(gem.emphasis || []).filter((e) => ['hero', 'key'].includes(e.kind || e[1])).map((e) => e.word ?? e[0]), ...(gem.moments || []).flatMap((m) => m.emphasisWords || [])]);
  // scene times on the cut (the compositor uses the same rule): each scene from its first word to the next scene
  const starts = sb.rows.map((r, i) => (i === 0 ? 0 : Math.max(0, (words[toNew(r.from, false)]?.start ?? 0) - 0.06)));
  // a 2D film's last scene runs to the end of the track: its silent end (a laugh, an end card) is part of the scene
  const trackEnd = J(path.join(J0, 'job.json'), {})?.keepTail ? cutLength(J0) : 0;
  const ends = sb.rows.map((r, i) => (i < sb.rows.length - 1 ? starts[i + 1] : Math.max(words.at(-1)?.end ?? 0, trackEnd)));
  return sb.rows.map((r, i) => {
    const L = layoutInfo(J0, p, r), nx = sb.rows[i + 1];
    const near = (x) => (x ? `${x.piece === 'custom' ? `graphic (${modeOf(p, x)}, archetype ${x.archetype || '-'}, ${x.bgStage || 'no stage'})` : x.piece}: "${String(x.metaphor || x.say || '').slice(0, 140)}"` : null);
    return { n: i + 1, secs: Math.max(1, ends[i] - starts[i]), sceneWords: sceneWordsOf(J0, r, toNew, words, starts[i], emph), zones: L.zones, face: L.face, memory: sb.memory, holdOut: !!(nx && nx.piece === 'custom' && nx.anchorIn && r.anchorOut), before: near(sb.rows[i - 1]), after: near(nx) };
  });
}
// The design system's ready parts (skills/<style>/atoms.css: its materials as classes), carried in the plan to the page
const atomsOf = (p) => { try { return fs.readFileSync(path.join(SKILLS_DIR, designOf(p), 'atoms.css'), 'utf8'); } catch { return ''; } };
// A ground that carries on (see tidyStoryboard): the page marks the scene so the stage starts where the scene before left it
const carryOf = (r) => (r.groundRun > 0 ? { carry: r.groundRun, ...(r.anchorIn ? { carryFrom: { x: r.anchorIn.xPct, y: r.anchorIn.yPct } } : {}) } : {});
// A graphic scene a builder saved, into the plan (the page is composed by the caller). Keeps the file on its row.
export function placeGraphic(d, p, sb, i, rel, secs) {
  const J0 = jobDir(d.ws), pf = path.join(J0, 'edit', 'plan.json'), plan = J(pf, null), r = sb.rows[i], nx = sb.rows[i + 1];
  const sc = plan?.scenes?.find((x) => x.row === i);
  if (!sc) throw new Error(`scene ${i + 1} is not in the plan`);
  const html = fs.readFileSync(path.join(J0, rel), 'utf8');
  delete sc.carry; delete sc.carryFrom;
  Object.assign(sc, { kind: 'graphic', mode: modeOf(p, r), file: rel, ...(r.media?.file ? { media: r.media.file } : {}), cues: cuesOf(html, secs), exit: !(nx && nx.piece === 'custom' && nx.anchorIn && r.anchorOut), ...carryOf(r) });
  r.file = rel;
  fs.writeFileSync(pf, JSON.stringify(plan, null, 1));
  fs.writeFileSync(path.join(J0, 'work', 'storyboard.json'), JSON.stringify(sb, null, 1));
}

// Storyboard → cut → stock → plan.json → composed page. Graphic rows use the file their builder saved (r.file); a row without
// one shows a stand-in until it is built. only = a row or a list of rows to redo (the rest keep their scenes). Returns { missing }.
// hooks: step(text), ask(prompt) = Sonnet with one picture
// the screen's zooms: where the screen matching said to look during each spoken line (screensync.mjs; on the cut's times
// already), and in the moments it left free the clicks the screen tracker saw (first-cut times)
function screenZooms(J0, p, screen, toCut) {
  const look = fitsScreens(p) ? J(path.join(J0, 'work', 'screen-focus.json'), []) || [] : [];
  const clicks = (screen?.events || []).filter((e) => e.focusRectPct && !e.idleScreen).map((e) => { const a = toCut(e.fromSec), b = toCut(e.toSec); return a != null && b != null && b > a ? { from: a, to: b, focus: e.focusRectPct, action: e.action } : null; }).filter(Boolean);
  return [...look, ...clicks.filter((c) => !look.some((l) => c.from < l.to && c.to > l.from))].sort((x, y) => x.from - y.from);
}
export async function buildPlan(d, p, sb, { step, ask, only = null, runQuery = null }) {
  const J0 = jobDir(d.ws), kind = kindOf(p);
  let resynced = false;
  const firstWords = firstCutWords(J0);
  const redo = only == null ? null : new Set([].concat(only)), mine = (i) => !redo || redo.has(i);
  // 1. the cut: the customer's removals and spelling fixes + the director's fixes (always from the prep's first cuts file)
  if (only == null) {
    const cuts = J(path.join(J0, 'work', 'cuts.first.json'), null) || J(path.join(J0, 'work', 'cuts.json'), {}) || {};
    const src = (i) => firstWords[i]?.src;
    const removed = (p.transcript?.removed || []).map(([a, b]) => [src(a), src(b)]).filter(([a, b]) => Number.isInteger(a) && Number.isInteger(b));
    if (removed.length) cuts.removeWords = [...(cuts.removeWords || []), ...removed];
    if (p.trim?.ranges?.length) cuts.removeRanges = [...(cuts.removeRanges || []), ...p.trim.ranges];
    const fixes = [...(sb.cut?.fixRanges || []).map(([a, b, t]) => [src(a), src(b), String(t || '')]), ...Object.entries(p.transcript?.fixes || {}).map(([i, t]) => [src(+i), src(+i), String(t || '')])].filter(([a, b, t]) => Number.isInteger(a) && Number.isInteger(b) && t);
    if (fixes.length) cuts.fixRanges = [...(cuts.fixRanges || []), ...fixes];
    cuts.decided = true; // the cut is exactly the customer's: roughcut.mjs shortens and speeds up nothing
    fs.writeFileSync(path.join(J0, 'work', 'cuts.json'), JSON.stringify(cuts, null, 1));
    step('Cutting');
    const c = await zen(d.ws, ['cut']); if (!c.ok) throw new Error(`cut: ${c.error}`);
    // screen recordings with a voice of their own: the new cut's screen picture is made again, re-timed from the kept picks
    // (asked again only when the recordings, their notes or the brief changed since)
    if (fitsScreens(p)) { await syncScreen(d, p, { runQuery, model: pricing().models.study || null, step }).catch((e) => console.error('[screen sync]', String(e.message).slice(0, 200))); resynced = true; }
  }
  // no new cut, but the recordings, their notes, the brief or the lines changed since the screen was matched: match again
  if (fitsScreens(p) && !resynced && runQuery && syncStale(d, p)) await syncScreen(d, p, { runQuery, model: pricing().models.study || null, step }).catch((e) => console.error('[screen sync]', String(e.message).slice(0, 200)));
  const words = cutWords(J0), toNew = mapper(firstWords, words), ctxs = sceneContexts(d, p, sb);
  const old = J(path.join(J0, 'edit', 'plan.json'), null);
  // 2. stock pictures
  const orient = p.format === '16:9' ? 'landscape' : p.format === '1:1' ? 'square' : 'portrait';
  const stockRows = sb.rows.filter((r, i) => /^stock/.test(String(r.piece || '')) && r.stock?.search && mine(i));
  if (stockRows.length) step('Finding stock pictures');
  const picks = await pickStock(J0, stockRows, ask, orient);
  // a graphic scene built over a photo or a clip ("media" on a custom row): a stock one is found and downloaded now, the
  // customer's own is linked; its builder gets it in the scene as .gx-media. Their files go into the job first (a fresh job
  // folder has none yet): a row is linked only to a file that is there
  for (const a of (p.assets || []).filter((x) => isOwnMedia(x, p))) { const to = path.join(J0, mineName(a.file)); if (!fs.existsSync(to)) { fs.mkdirSync(path.dirname(to), { recursive: true }); try { fs.linkSync(path.join(d.assets, a.file), to); } catch { fs.copyFileSync(path.join(d.assets, a.file), to); } } }
  const mediaRows = sb.rows.filter((r, i) => r.piece === 'custom' && r.media && !r.media.file && mine(i));
  for (const r of mediaRows) if (r.media.mine && fs.existsSync(path.join(J0, mineName(r.media.mine)))) r.media.file = mineName(r.media.mine);
  const want = mediaRows.filter((r) => !r.media.file && r.media.search);
  if (want.length) {
    step('Finding pictures for the graphics');
    const got = await pickStock(J0, want.map((r) => ({ piece: r.media.kind === 'video' ? 'stock-video' : 'stock-photo', stock: { search: r.media.search }, metaphor: r.metaphor, idea: r.idea, _r: r })), ask, orient);
    for (const [q, pick] of got) { try { if (pick) q._r.media.file = (await downloadStock(J0, pick, q.stock.search)).file; } catch (e) { console.error('[media]', e.message.slice(0, 120)); } }
  }
  // a customer's clip shown with its moments ("steps": [[word, second], …]): cut to this scene's words, so the scene plays it
  // straight through and each step is on screen while it is said (clipsync.mjs); made again only when the timings change
  let synced = 0;
  for (const [i, r] of sb.rows.entries()) {
    if (r.piece !== 'custom' || !mine(i) || !Array.isArray(r.media?.steps) || !r.media.steps.length) continue;
    const src = r.media.src || (/\.sync-[0-9a-f]{8}\.mp4$/.test(String(r.media.file || '')) ? null : r.media.file);
    if (!src || !MEDIA.test(src)) continue;
    const start = i === 0 ? 0 : Math.max(0, (words[toNew(r.from, false)]?.start ?? 0) - 0.06);
    const marks = r.media.steps.filter((x) => Array.isArray(x) && x.length === 2 && Number.isFinite(+x[0]) && Number.isFinite(+x[1])).map(([w, x]) => [Math.max(0, (words[toNew(Math.round(+w), false)]?.start ?? start) - start - LEAD), +x]); // each step lands just before its word
    try { const rel = await syncClip(J0, src, marks, ctxs[i].secs); if (rel) { r.media.src = src; r.media.file = rel; synced++; } } catch (e) { console.error('[clip sync]', String(e.message).slice(0, 160)); }
  }
  if (mediaRows.length || synced) fs.writeFileSync(path.join(J0, 'work', 'storyboard.json'), JSON.stringify(sb, null, 1));
  // 3. the graphics their builders saved (the file each row recorded; never one guessed by its name: after a new plan, scene 5
  // is another scene)
  const files = {};
  sb.rows.forEach((r, i) => { if (r.piece === 'custom' && r.file && fs.existsSync(path.join(J0, r.file)) && fs.statSync(path.join(J0, r.file)).size > 50) files[i] = r.file; else delete r.file; });
  // 4. the plan
  const music = (() => {
    const own = (p.assets || []).find((a) => a.role === 'music');
    if (own) { const to = path.join(J0, mineName(own.file)); if (!fs.existsSync(to)) { fs.mkdirSync(path.dirname(to), { recursive: true }); try { fs.linkSync(path.join(d.assets, own.file), to); } catch { fs.copyFileSync(path.join(d.assets, own.file), to); } } return { src: mineName(own.file), volume: 0.112, own: true }; }
    // the director's call ("music": "bed" | "none"); with no call (older storyboards): none under Storytelling animations or in a
    // design system without a music bed (Minimal), a bed under a person speaking
    const want = sb.video?.music;
    if (want === 'none') return null;
    if (want !== 'bed' && (kind === 'faceless' || styleInfo(p).music === false)) return null;
    const cat = J(path.join(ASSETS_DIR, 'music', 'catalog.json'), { items: [] }), mood = String(sb.video?.mood || '').toLowerCase();
    const list = (cat.items || []).filter((x) => x.file); const pool = list.filter((x) => mood.includes(x.mood)); const all = pool.length ? pool : list.filter((x) => x.mood === 'inspiring').concat(list);
    const seed = [...String(p.id)].reduce((h, c) => (h * 31 + c.charCodeAt(0)) >>> 0, 7), t = all[seed % Math.max(1, all.length)];
    return t ? { src: path.join(ASSETS_DIR, 'music', String(t.file).replace(/^music\//, '')), volume: 0.112, title: t.title, id: t.id } : null;
  })();
  const missing = [];
  const scenes = await Promise.all(sb.rows.map(async (r, i) => {
    const prevScene = old?.scenes?.find((x) => x.row === i);
    // a kept graphic keeps its file, but how it joins its neighbours is read again (a changed neighbour may now start from its anchor)
    if (!mine(i) && prevScene) {
      if (prevScene.kind !== 'graphic') return prevScene;
      const nx = sb.rows[i + 1], { carry, carryFrom, ...rest } = prevScene;
      return { ...rest, exit: !(nx && nx.piece === 'custom' && nx.anchorIn && r.anchorOut), ...carryOf(r) };
    }
    const base = {
      uid: prevScene?.uid || `u${Math.random().toString(36).slice(2, 10)}`, row: i, startWord: toNew(r.from, false), endWord: toNew(r.to, true), say: r.say, title: r.idea, transition: r.transition || 'cut', captions: r.captions || 'show',
      mode: modeOf(p, r), ...(Array.isArray(r.focus) ? { focus: r.focus } : {}), ...(r.punch?.length ? { punch: r.punch.map((w) => toNew(w, false)) } : {}), ...(r.rise ? { rise: true } : {})
    };
    const nx = sb.rows[i + 1];
    const snd = r.sound?.file && (p.assets || []).find((a) => a.role === 'sound' && a.file === path.basename(String(r.sound.file)));
    if (snd) { // a sound the customer attached to a comment: it plays at its moment in this scene
      const to = path.join(J0, 'assets', 'sounds', snd.file);
      if (!fs.existsSync(to)) { fs.mkdirSync(path.dirname(to), { recursive: true }); try { fs.linkSync(path.join(d.assets, snd.file), to); } catch { fs.copyFileSync(path.join(d.assets, snd.file), to); } }
      base.sound = { src: `assets/sounds/${snd.file}`, at: Math.max(0, Number(r.sound.at) || 0), vol: Math.max(0.05, Math.min(1.5, Number(r.sound.vol) || 0.7)) };
    }
    if (r.piece === 'custom') {
      const file = files[i];
      if (!file) { missing.push({ row: i, why: 'the graphic is not built yet' }); return { ...base, kind: kind === 'screen' || kind === 'faceless' ? 'fallback' : 'speaker', mode: kind === 'screen' ? 'concept-takeover-graphic' : base.mode === 'full-broll-takeover' ? 'speaker' : base.mode }; }
      const html = fs.readFileSync(path.join(J0, file), 'utf8');
      return { ...base, kind: 'graphic', file, ...(r.media?.file ? { media: r.media.file } : {}), cues: cuesOf(html, ctxs[i].secs), exit: !(nx && nx.piece === 'custom' && nx.anchorIn && r.anchorOut), ...carryOf(r) };
    }
    if (/^stock/.test(String(r.piece))) { const pick = picks.get(r); let got = null; try { got = pick ? await downloadStock(J0, pick, r.stock.search) : null; } catch { } return got ? { ...base, kind: 'stock', media: got.file, text: r.stock?.text || '', sub: r.stock?.sub || '' } : { ...base, kind: kind === 'faceless' || kind === 'screen' ? 'fallback' : 'speaker', mode: kind === 'screen' ? 'concept-takeover-graphic' : 'speaker' }; }
    if (r.piece === 'mine' && r.mine?.file && fs.existsSync(path.join(J0, mineName(r.mine.file)))) return { ...base, kind: 'mine', media: mineName(r.mine.file), kicker: r.mine.kicker || '', text: r.mine.text || '' };
    const device = () => (['pc-browser-spotlight', 'mobile-device-stage'].includes(base.mode) ? base.mode : (J(path.join(J0, 'work', 'screen.json'), {})?.deviceAspect === 'mobile-9:16' ? 'mobile-device-stage' : 'pc-browser-spotlight'));
    if (kind === 'screen' || (r.piece === 'screen' && beside(p))) return { ...base, kind: 'screen', mode: device() };
    if (kind === 'faceless') return { ...base, kind: 'fallback' };
    return { ...base, kind: 'speaker', mode: 'speaker' };
  }));
  const screen = J(path.join(J0, 'work', 'screen.json'), null);
  const toCut = (sec) => { const fw = firstWords.findIndex((w) => w.start >= sec); return fw < 0 ? null : words[toNew(fw, false)]?.start; };
  // the customer's music level from a change round (the mix tool): quieter, louder or none
  const mdb = Number(mixOf(sb)?.musicDb);
  if (music && Number.isFinite(mdb) && mdb) music.volume = mdb <= -40 ? 0 : Math.round(music.volume * Math.pow(10, Math.max(-30, Math.min(6, mdb)) / 20) * 1000) / 1000;
  const plan = {
    version: 2, canvas: `${(FORMATS[p.format] || FORMATS['9:16']).w}x${(FORMATS[p.format] || FORMATS['9:16']).h}`, kind, style: designOf(p), theme: themeOf(p), tokens: tokensFor(p), ...(atomsOf(p) ? { atoms: atomsOf(p) } : {}),
    // running captions: always under a person speaking; in Storytelling only when the director turns them on
    captions: { on: kind === 'faceless' ? sb.video?.captions === 'on' : true }, ...(sb.v >= 3 ? { directorRisers: true } : {}), ...(music ? { music } : {}), ...(sb.video?.mood ? { mood: String(sb.video.mood).slice(0, 80) } : {}), ...(mixOf(sb) ? { mix: mixOf(sb) } : {}), ...(styleInfo(p).sound ? { soundProfile: styleInfo(p).sound } : {}), scenes,
    screenEvents: kind === 'screen' || beside(p) ? screenZooms(J0, p, screen, toCut) : [],
    ...(beside(p) && fs.existsSync(path.join(J0, 'cut', 'screen.mp4')) ? { screenVideo: 'cut/screen.mp4' } : {}),
    ...(old?.soundsOwn ? { sounds: old.sounds, soundsOwn: true } : {}), ...(old?.fx ? { fx: old.fx } : {}),
  };
  fs.mkdirSync(path.join(J0, 'edit'), { recursive: true });
  fs.writeFileSync(path.join(J0, 'edit', 'plan.json'), JSON.stringify(plan, null, 1));
  fs.writeFileSync(path.join(J0, 'work', 'storyboard.json'), JSON.stringify(sb, null, 1));
  step('Building the scenes');
  const c = await zen(d.ws, ['compose']); if (!c.ok) throw new Error(`compose: ${c.error}`);
  return { missing };
}
