// The job queue (one job at a time) and the jobs of a video:
//   prepare     Step 2: the narration (faceless), the words with exact times (Gemini + WhisperX), the first cut, the
//               listening tags (Magic Cut list, emphasis, metaphors, uiText), the screen recordings' events, the Brief
//   storyboard  Step 3: the editor (server/editor.mjs) plans the video, builds every graphic scene and checks each one on its
//               real frames, then looks at the whole video; then the scene pictures
//   replan      a part of the storyboard (words from–to) planned again on its real timings; the other scenes kept as built
//   scene       a comment on one storyboard scene: the editor (its session resumed) changes what it asks, the builder redoes it
//   revise      Step 4: the customer's comments on the finished video → the editor changes those scenes → the next version
//   render      the finished video (no AI)  ·  refresh  the speaker cut-out is ready: compose again (no AI)
// The AI never runs commands: code runs the engine; Claude uses only the editor's own tools (and may read a picture in this
// video's folder).
import * as anim from './animpipe.mjs';
import * as codefilm from './codefilm.mjs';
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile, spawnSync } from 'node:child_process';
import { pathToFileURL } from 'node:url';
import { createRequire } from 'node:module';
import { query } from './no-ai.mjs';
import * as store from './store.mjs';
import * as users from './users.mjs';
import { probe, makeThumbs, measureMix } from './media.mjs';
import { learnFrom, wantParts } from './learn.mjs';
import { transcribeFootage, geminiUsage, alignScript, whisperxReady, relistenRange } from './transcribe.mjs';
import { geminiOn, speak as geminiSpeak, testSoundMix, GEMINI_VOICES } from './gemini.mjs';
import { tagPrompt, parseTags, toFirstCut, breakdownText, proofPrompt, parseProof, applyProof } from './claude.mjs';
import { editor, makeVideo, changeVideo, replanVideo, bodyGate } from './editor.mjs';
import { jobExtras, voiceLangs, FORMATS, screenLed, voiceSource } from './studio.mjs';
import { voiceSetup, awaitVoice } from './voice-setup.mjs';
import { firstRun, awaitFirstRun, ensureRenderer } from './first-run.mjs';
import { MODEL, MAX_TURNS, CLAUDE_PATH, DATA_DIR, APP_DIR, PORT, USING_API_KEY, MODE, OWN_CLAUDE, ENGINE_DIR, ASSETS_DIR } from './config.mjs';
import * as claude from './claude-auth.mjs';
import { issueJobPass, revokeJobPass } from './routes-desktop.mjs';
import { firstCutWords, zen, jobDir } from './director.mjs';
import * as naming from './naming.mjs';
import { scriptWords, saveScript, makeBoard, needsJoin, joinedRel, restoreNotes } from './board.mjs';
import { usageCost, usdToCredits, modelFor, jobSize, pricing } from './pricing.mjs';
import { SYSTEM_APPEND, scriptPrompt, studyPrompt } from './prompts.mjs';
import { syncScreen, fitsScreens, syncStale } from './screensync.mjs';
import { checkVideo } from './aftercheck.mjs';
import * as cto from './cto.mjs';

const STOP_GRACE_MS = 15000;
// what Claude says when a limit stops a conversation (the same words editor.mjs knows); QUOTA = the account's own limit
const LIMIT_SAID = /hit your .*limit|usage limit|rate.?limit|session limit|(5-hour|weekly|daily) limit|limit is reached|claude_limit|overloaded|\b429\b|\b529\b/i;
const QUOTA_SAID = /5-hour|weekly|daily|usage limit|session limit|claude_limit|hit your .*limit/i;
const queue = [];
let running = null;
// HyperFrames keeps an undo history of every page it builds: Zancut's go to one folder, emptied when idle
export const HF_HISTORY = path.join(os.homedir(), '.cache', 'zancut', 'hf-history');
process.env.HYPERFRAMES_HISTORY_ROOT ||= HF_HISTORY;
const clearHistory = () => { if (!running && !queue.length) fs.rmSync(HF_HISTORY, { recursive: true, force: true }); };

export function shutdown() { queue.length = 0; if (running) { running.cancelled = true; running.abort.abort(); } }
export function status() { return { running: running?.id || null, queued: queue.map((j) => j.id) }; }
export function activeFor(ownerId) { const ids = [running?.id, ...queue.map((j) => j.id)].filter(Boolean); return ids.find((id) => store.get(id)?.ownerId === ownerId) || null; }
let onJobDone = () => { };
export const setJobDone = (fn) => { onJobDone = fn; };
let onSpend = () => { };
export const setSpend = (fn) => { onSpend = fn; };

export function enqueue(id, kind, extra = {}) {
  const p = store.get(id);
  if (!p) throw new Error('Project not found');
  if (running?.id === id || queue.some((j) => j.id === id)) throw new Error('This video is already being edited.');
  p.status = 'queued'; p.error = null; p.job = { kind, queuedAt: Date.now(), steps: [], todos: [] };
  store.save(p, { immediate: true });
  queue.push({ id, kind, extra });
  pump();
}
export function cancel(id) {
  const i = queue.findIndex((j) => j.id === id);
  if (i >= 0) { queue.splice(i, 1); const p = store.get(id); p.status = store.idleStatus(p); p.job = null; store.save(p, { immediate: true }); return true; }
  if (running?.id === id) {
    const job = running; job.cancelled = true;
    const p = store.get(id); if (p?.job) { p.job.stopping = true; store.save(p, { immediate: true }); }
    job.abort.abort();
    setTimeout(() => { if (running === job && !job.finished) { console.error('[stop] releasing', id); finish(job, () => finishFailed(store.get(id), '', true)); running = null; pump(); } }, STOP_GRACE_MS);
    return true;
  }
  return false;
}
async function pump() {
  if (running || !queue.length) return;
  const job = queue.shift(), me = { ...job, abort: new AbortController(), cancelled: false, finished: false };
  running = me;
  try { await runJob(me); }
  catch (e) {
    // thrown before the job's own error handling (e.g. while its folder was being made ready): close it anyway, so the video is
    // never left "waiting in line" with nothing running, and the CTO hears about it like any failed job
    console.error('[job]', job.id, e);
    if (!me.finished) { me.error = e; finish(me, () => finishFailed(store.get(job.id), e?.customer ? e.message : 'Something went wrong on our side. Your files are safe. Please press Retry; if it happens again, contact support.', false, e, job.extra)); }
  }
  finally { if (running === me) { running = null; pump(); clearHistory(); } }
}
function finish(job, fn) {
  if (job.finished) return;
  job.finished = true;
  if (job.pass) revokeJobPass(job.pass);
  fn();
  const p = store.get(job.id);
  // the CTO hears how every job ended: a failed one is diagnosed, fixed (a fallback, a repair) and run again when it can be
  try { cto.jobEnded({ project: p, job, ok: !p?.error && !p?.lastJob?.failed && !job.cancelled }); } catch (e) { console.error('[cto]', e.message); }
  try { onJobDone({ project: p, job, ok: p?.status !== 'error' && !p?.error && !job.cancelled, tokensIn: job.tokensIn || 0, tokensOut: job.tokensOut || 0, costUsd: Math.max(job.costUsd || 0, job.estUsd || 0), credits: job.credits || 0, byModel: job.byModel || {} }); }
  catch (e) { console.error('[jobDone]', e); }
}
class CustomerError extends Error { constructor(m) { super(m); this.customer = true; } }

// ---------- the video's folder: <ws>/job is the engine's job; the main track is linked into job/raw ----------
export function mainClips(p) {
  const screen = (p.assets || []).filter((a) => a.role === 'screen');
  // screen recordings beside a voice of its own (a Storytelling video's recording or AI voice, a talking head's camera) are the
  // customer's clips, shown where the voice talks about them (clipsync.mjs): the voice (or the camera) is the main track.
  // Only screen recordings (no other voice): their own sound is the voice and they are the main track
  if (screen.length && screenLed(p)) return screen.map((a) => ({ ...a, hasAudio: a.hasAudio ?? true, rel: `assets/${a.file}` }));
  const joined = needsJoin(p) && p.joined && fs.existsSync(path.join(store.dirs(p.id).ws, joinedRel(p)));
  if (joined && p.footage.length && p.mode !== 'faceless') return [{ file: 'joined.mp4', rel: 'raw/joined.mp4', hasAudio: true, duration: p.joined.duration }];
  if (p.footage.length && p.mode !== 'faceless') return p.footage.map((f) => ({ ...f, rel: `raw/${f.file}` }));
  return [{ file: 'plate.mp4', rel: 'plate/plate.mp4', hasAudio: true, plate: true }];
}
// a person on the main track (a talking head, also with screen recordings: they are a layer of their own over the ground)
const hasPresenter = (p) => { const m = mainClips(p)[0]; return !m.plate && !String(m.rel).startsWith('assets/'); };
// a link to the customer's file in the job folder; where symbolic links are not allowed (Windows without Developer Mode) a
// hard link, else a copy
const relink = (target, at) => {
  try { const st = fs.lstatSync(at); if (st.isSymbolicLink() && fs.readlinkSync(at) === target) return; fs.rmSync(at, { force: true }); } catch { }
  const src = path.resolve(path.dirname(at), target);
  // not made yet (a Storytelling video's plate: makePlate makes it in this job, then linkMain runs again). A link to a file that
  // is not there works on a Mac but not on Windows (no symbolic links there, and nothing to hard-link or copy): it failed the job
  // before it even started, and the video stayed "waiting in line" for ever
  if (!fs.existsSync(src)) return;
  try { fs.symlinkSync(target, at); } catch (e) {
    try { fs.linkSync(src, at); } catch { fs.copyFileSync(src, at); }
    cto.fallback('symlink', { title: 'Symbolic links are not allowed on this computer: files are linked another way', detail: String(e.code || e.message).slice(0, 120) });
  }
};
// the main track into the job's raw/ (numbered links, or their hard-link / copy stand-ins): the engine cuts whatever is there
function linkMain(d, p) {
  const J0 = jobDir(d.ws), main = mainClips(p);
  for (const f of fs.readdirSync(path.join(J0, 'raw'))) if (fs.lstatSync(path.join(J0, 'raw', f)).isSymbolicLink() || /^\d{2}-/.test(f)) fs.rmSync(path.join(J0, 'raw', f), { force: true });
  main.forEach((f, i) => { const at = path.join(J0, 'raw', `${String(i + 1).padStart(2, '0')}-${f.file}`); relink(path.relative(path.dirname(at), path.join(d.ws, f.rel)), at); });
  return main;
}
const GOLDEN_GRADE = 'hqdn3d=1.5:1.5:4:4,eq=contrast=1.06:brightness=0.02:saturation=1.06:gamma=1.02,colorbalance=rs=0.008:gs=0.0:bs=-0.015:rm=0.018:gm=0.005:bm=-0.02:rh=0.01:gh=0.005:bh=-0.01,vibrance=intensity=0.08,unsharp=5:5:0.6:5:5:0.0';
function prepareWorkspace(p) {
  const d = store.dirs(p.id), J0 = jobDir(d.ws);
  for (const x of [path.join(J0, 'raw'), path.join(J0, 'assets'), path.join(J0, 'work'), d.exports, d.assets]) fs.mkdirSync(x, { recursive: true });
  const main = linkMain(d, p);
  const jobFile = path.join(J0, 'job.json');
  // a screen recording that is the main picture keeps its own shape through the cut (the compositor puts it in a window or a
  // phone); a talking head's screen recordings are fitted beside its camera cut (screensync.mjs) and the cut stays the camera's
  const shot = screenLed(p) && voiceSource(p) !== 'video' && (p.assets || []).find((a) => a.role === 'screen');
  const shape = shot?.width && shot?.height ? { canvas: `${shot.width - (shot.width % 2)}x${shot.height - (shot.height % 2)}`, fit: 'cover' } : null;
  if (!fs.existsSync(jobFile)) {
    const x = jobExtras(p);
    const job = {
      format: 'short-explainer', lang: p.language && p.language !== 'auto' ? p.language : 'en', created: new Date().toISOString().slice(0, 10),
      ...(themeLight(p) && hasPresenter(p) ? { grade: GOLDEN_GRADE } : {}),
      ...(whisperxReady() ? { exactTimes: true } : {}),
      ...(hasPresenter(p) ? {} : { noPresenter: true, balance: false, grade: 'none' }),
      ...(mainClips(p)[0].plate && p.aiVoice && !(p.assets || []).some((a) => a.role === 'voiceover') ? { speed: 1 } : {}),
      ...(p.kind === 'animation' ? { keepTail: true } : {}), // the film's own silent end is part of it: a confirmed track is never shortened
      ...x, ...(shape || {}), cutBy: 'ai',
    };
    fs.writeFileSync(jobFile, JSON.stringify(job, null, 2));
  }
  // kept in step on every job (screen recordings can be added or removed after the first one): the type, the shape, whether a
  // person is on the main track
  try {
    const job = JSON.parse(fs.readFileSync(jobFile, 'utf8')), x = jobExtras(p);
    job.zancut = x.zancut; delete job.presenter;
    if (shape) Object.assign(job, shape); else { delete job.fit; if (x.canvas) job.canvas = x.canvas; else delete job.canvas; }
    if (hasPresenter(p)) { if (job.noPresenter) { delete job.noPresenter; delete job.balance; if (themeLight(p)) job.grade = GOLDEN_GRADE; else delete job.grade; } }
    else Object.assign(job, { noPresenter: true, balance: false, grade: 'none' });
    fs.writeFileSync(jobFile, JSON.stringify(job, null, 2));
  } catch (e) { console.error('[job.json]', e.message); }
  return d;
}
const themeLight = (p) => p.theme === 'light';
function seedWords(d, p, transcripts) {
  const J0 = jobDir(d.ws), main = mainClips(p), t = transcripts.find((x) => x.rel === main[0]?.rel);
  if (!t) return;
  try {
    const raw = path.join(J0, 'work', 'transcript.raw.json');
    if (main.length === 1 && !fs.existsSync(raw)) {
      const words = JSON.parse(fs.readFileSync(path.join(d.ws, t.transcript), 'utf8')).filter((w) => w && typeof w.text === 'string' && w.text.trim()).map((w) => ({ text: w.text.trim(), start: Number(w.start), end: Number(w.end), p: 1 }));
      if (words.length) fs.writeFileSync(raw, JSON.stringify(words));
    }
  } catch (e) { console.error('[seed]', p.id, e.message); }
}

// The AI voice for a script, into wav (Gemini's voices when it is on, else the local ones), at the chosen speed; its word
// times (Gemini) beside it as voice.words.json. Used for a Storytelling video's plate.
// languages the free local voice has on this computer (engine/tts.cjs), looked up again at most once a minute
let voicesSeen = { at: 0, list: [] };
function localVoices() {
  if (Date.now() - voicesSeen.at > 60e3) {
    try { voicesSeen = { at: Date.now(), list: createRequire(import.meta.url)(path.join(ENGINE_DIR, 'tts.cjs')).available() }; }
    catch { voicesSeen = { at: Date.now(), list: [] }; }
  }
  return voicesSeen.list;
}
export async function speakScript(p, script, wav, lang = p.language || 'en') {
  const run = (cmd, args) => new Promise((ok, no) => execFile(cmd, args, { timeout: 15 * 60000, maxBuffer: 1 << 24 }, (e, so, se) => (e ? no(new Error(String(se || so || e.message).slice(-300))) : ok(so))));
  const txt = wav.replace(/\.wav$/, '.txt');
  fs.writeFileSync(txt, script.replace(/\[pause:[^\]]*\]/gi, ' '));
  let geminiFailed = null;
  // the free local voice speaks English and Bangla when its files are on this computer (desktop: downloaded on first run);
  // a local voice that isn't installed is spoken by a similar Gemini voice instead (female → Kore, male → Charon)
  const localReady = ['en', 'bn'].includes(lang) && localVoices().includes(lang);
  const useGemini = geminiOn() && (!p.voiceId || String(p.voiceId).startsWith('g-') || !localReady);
  if (useGemini) {
    try {
      const gVoice = String(p.voiceId || '').startsWith('g-') ? p.voiceId : /^male/.test(String(p.voiceId || '')) ? 'g-charon' : 'g-kore';
      const g = await geminiSpeak(script, gVoice, lang, wav, { speed: p.voiceSpeed, style: p.voiceStyle, model: p.ttsModel });
      g.usage.forEach((u) => geminiUsage.push({ ...u }));
      const words = [];
      for (const c of g.chunks || []) { const ws = String(c.text).split(/\s+/).filter(Boolean), tot = ws.reduce((a, w) => a + w.length + 1, 0) || 1; let k = 0; for (const w of ws) { const a = c.start + ((c.end - c.start) * k) / tot; k += w.length + 1; words.push({ text: w, start: +a.toFixed(3), end: +(c.start + ((c.end - c.start) * k) / tot).toFixed(3), p: 1 }); } }
      if (words.length) fs.writeFileSync(wav.replace(/\.wav$/, '.words.json'), JSON.stringify(words));
    } catch (e) {
      // the Gemini voice failed (limit, key, network): the local voice speaks instead (the CTO's fallback), when it has the language
      console.error('[gemini] voice:', e.message.slice(0, 160));
      // 2D Animation: one line in another voice breaks the film; the caller waits and asks the same voice again
      if (p.noLocalVoice) throw e;
      cto.fallback('gemini-voice', { title: 'The Gemini AI voice failed: the local voice spoke instead', detail: e.message.slice(0, 300), projectId: p.id });
      geminiFailed = e;
    }
  }
  if (!useGemini || geminiFailed) {
    const male = /Male/.test((GEMINI_VOICES.find((v) => v.id === p.voiceId) || {}).sub || '');
    const local = String(p.voiceId || '').startsWith('g-') ? (male ? 'male-calm' : 'female-warm') : p.voiceId || 'female-warm';
    try { await run('node', [path.join(ENGINE_DIR, 'tts.cjs'), lang, local, txt, wav]); }
    catch (e) {
      // no voice at all: the local voice files are not downloaded (yet) and the online voice is not available
      if (!geminiFailed && /no AI voice for/.test(e.message)) {
        cto.fallback('voice-missing', { title: `No AI voice for "${lang}": the local voice is not downloaded and Gemini is off`, detail: 'Desktop: the voice download (first run) or a Gemini key in Admin → Settings → API keys. Elsewhere: GEMINI_API_KEY in .env or npm run setup:audio.', projectId: p.id });
        throw new CustomerError(voiceSetup().busy
          ? 'The free AI voice is still downloading on this computer. Try again in a few minutes, or upload your own recording.'
          : 'No AI voice is available on this computer right now. Upload your own recording, or contact Zancut support.');
      }
      if (!geminiFailed) throw e;
      throw new CustomerError(/429|quota/i.test(geminiFailed.message) ? 'The AI voice has reached its limit for today. Press Retry later or upload your own recording.' : 'The AI voice is busy right now. Press Retry in a few minutes, or upload your own recording.'); }
  }
  const tempo = { slow: 1, normal: 1.1, fast: 1.25 }[p.voiceSpeed || 'normal'] || 1.1;
  if (tempo !== 1) {
    const fast = wav.replace(/\.wav$/, '.tempo.wav'); await run('ffmpeg', ['-v', 'error', '-y', '-i', wav, '-af', `atempo=${tempo}`, fast]); fs.renameSync(fast, wav);
    const wf = wav.replace(/\.wav$/, '.words.json');
    if (fs.existsSync(wf)) try { const w = JSON.parse(fs.readFileSync(wf, 'utf8')), k = (x) => +(x / tempo).toFixed(3); fs.writeFileSync(wf, JSON.stringify(w.map((x) => ({ ...x, start: k(x.start), end: k(x.end) })))); } catch { }
  }
  return wav;
}

// ---------- faceless: the narration over a plain plate (the customer's recording, or the AI voice) ----------
async function makePlate(d, p, runQuery, step, signal) {
  const plate = path.join(d.ws, 'plate', 'plate.mp4');
  if (fs.existsSync(plate)) return;
  fs.mkdirSync(path.dirname(plate), { recursive: true });
  const run = (cmd, args) => new Promise((ok, no) => execFile(cmd, args, { timeout: 15 * 60000, maxBuffer: 1 << 24 }, (e, so, se) => (e ? no(new Error(String(se || so || e.message).slice(-300))) : ok(so))));
  const vo = (p.assets || []).find((a) => a.role === 'voiceover');
  let audio = needsJoin(p) && p.joined && fs.existsSync(path.join(d.ws, joinedRel(p))) ? path.join(d.ws, joinedRel(p)) : vo ? path.join(d.assets, vo.file) : null;
  if (!audio && p.kind === 'animation') { // 2D Animation: the planner writes the animation script and every character is recorded
    try { audio = await anim.plate(d, p, { runQuery, speak: speakScript, step: (t) => step('tool', t), model: pricing().models.director || pricing().models.study || null, onUsage: (u) => u.forEach((x) => geminiUsage.push({ ...x })), signal }); }
    catch (e) { if (e.customer) throw new CustomerError(e.message); throw e; }
  }
  if (!audio) {
    if (!p.aiVoice) throw new CustomerError('A Storytelling video needs a voice: upload your recording or write a script for the AI voice, then press Retry.');
    const lang = p.language || 'en';
    // the desktop app on Windows: the voice is a one-time download (server/voice-setup.mjs), fetched now if still missing
    if (!voiceLangs().includes(lang) && voiceSetup().on && !voiceSetup().ready) {
      try { await awaitVoice((pct) => step('tool', `Downloading the AI voice, one time only: ${pct}%`), signal); }
      catch (e) { if (signal?.aborted) throw e; throw new CustomerError(String(e.message)); }
    }
    if (!voiceLangs().includes(lang)) throw new CustomerError('The AI voice cannot speak this language yet. Upload your own recording, then press Retry.');
    const sf = path.join(d.ws, 'plate', 'SCRIPT.txt');
    let script = String(p.script || '').trim();
    // the customer's own script is spoken exactly as they wrote it (never rewritten); only an empty one is written by Claude
    if (!script) { step('tool', 'Writing the voiceover script'); script = String((await runQuery(scriptPrompt(p), pricing().models.study || null, { tools: [], allowedTools: [], maxTurns: 1 }))?.result || '').trim(); }
    if (!script) throw new CustomerError('The voiceover script could not be written. Paste your script and press Retry.');
    fs.writeFileSync(sf, script);
    step('tool', 'Recording the AI voice');
    const txt = path.join(d.ws, 'plate', 'script.txt'), wav = path.join(d.ws, 'plate', 'voice.wav');
    fs.writeFileSync(txt, script.replace(/\[pause:[^\]]*\]/gi, ' '));
    await speakScript(p, script, wav, lang);
    audio = wav;
  }
  const f = FORMATS[p.format] || FORMATS['9:16'];
  step('tool', 'Preparing the narration');
  const screen = mainClips(p)[0].screen;
  if (screen) await run('ffmpeg', ['-y', '-v', 'error', '-i', path.join(d.ws, screen), '-i', audio, '-filter_complex', '[0:v]fps=30,tpad=stop_mode=clone:stop_duration=900,format=yuv420p[v]', '-map', '[v]', '-map', '1:a:0', '-shortest', '-c:v', 'libx264', '-preset', 'veryfast', '-crf', '20', '-c:a', 'aac', '-b:a', '192k', plate]);
  else await run('ffmpeg', ['-y', '-v', 'error', '-f', 'lavfi', '-i', `color=c=${themeLight(p) ? '0xF4F3EF' : '0x0E0E13'}:s=${f.w}x${f.h}:r=30`, '-i', audio, '-map', '0:v', '-map', '1:a:0', '-shortest', '-c:v', 'libx264', '-preset', 'veryfast', '-tune', 'stillimage', '-crf', '28', '-pix_fmt', 'yuv420p', '-c:a', 'aac', '-b:a', '192k', plate]);
}

// ---------- the style reference video and the customer's facts ----------
function referenceSheets(d, a) {
  return new Promise((resolve) => {
    const dir = path.join(d.ws, 'reference'); fs.rmSync(dir, { recursive: true, force: true }); fs.mkdirSync(dir, { recursive: true });
    const src = path.join(d.assets, a.file); if (!fs.existsSync(src)) return resolve([]);
    execFile('ffmpeg', ['-v', 'error', '-y', '-t', '60', '-i', src, '-vf', 'fps=2,scale=-2:420,tile=6x4:padding=4', '-q:v', '4', path.join(dir, 's%02d.jpg')], { timeout: 180000 }, () => {
      let list = []; try { list = fs.readdirSync(dir).filter((f) => f.endsWith('.jpg')).sort().slice(0, 5).map((f) => `reference/${f}`); } catch { }
      resolve(list);
    });
  });
}
async function studyStyle(d, p, job, runQuery, step) {
  const ref = (p.assets || []).find((x) => x.role === 'style'), out = path.join(d.ws, 'reference', 'REFERENCE.md');
  if (!ref || fs.existsSync(out)) return;
  step('tool', 'Studying your reference video');
  const sheets = await referenceSheets(d, ref);
  if (sheets.length) {
    try { const r = await runQuery(studyPrompt(sheets, ref.note), pricing().models.study || null, { tools: ['Read'], maxTurns: 8 }); if (r?.result) fs.writeFileSync(out, String(r.result).trim()); }
    catch (e) { if (job.cancelled) throw e; console.error('[study]', p.id, e.message); }
  }
}
function factsOf(d, p) {
  let out = '';
  for (const a of (p.assets || []).filter((x) => x.role === 'reference')) {
    const f = path.join(d.assets, a.file); if (!fs.existsSync(f)) continue;
    let text = '';
    try { text = /\.pdf$/i.test(f) ? spawnSync('pdftotext', ['-layout', '-l', '20', f, '-'], { encoding: 'utf8', timeout: 30000, maxBuffer: 1 << 24 }).stdout || '' : fs.readFileSync(f, 'utf8'); } catch { }
    text = text.replace(/[ \t]+/g, ' ').replace(/\n{3,}/g, '\n\n').trim();
    if (text) out += `### ${a.original || a.file}${a.note ? ` (note: "${a.note}")` : ''}\n${text.slice(0, Math.max(0, 6000 - out.length))}\n`;
    if (out.length >= 6000) break;
  }
  return out;
}
function cleanEnv() {
  const env = {};
  for (const [k, v] of Object.entries(process.env)) { if (/KEY|TOKEN|SECRET|PASSW|CREDENTIAL|PRIVATE|COOKIE|SESSION|AUTH/i.test(k)) continue; if (/^(CLAUDE|CLAUDECODE|ANTHROPIC_)/i.test(k)) continue; env[k] = v; }
  return env;
}
const secs = (x) => `${Math.floor(x / 60)}:${(x % 60).toFixed(1).padStart(4, '0')}`;

async function runJob(job) {
  const p = store.get(job.id);
  if (!p) return;
  const d = prepareWorkspace(p), J0 = jobDir(d.ws);
  const n = p.versions.length + 1;
  p.status = 'editing';
  p.job = { ...p.job, kind: job.kind, version: n, startedAt: Date.now(), steps: [], todos: [], ...(job.kind === 'scene' ? { row: job.extra.row } : {}) };
  store.save(p, { immediate: true });
  // Windows app: the renderer's browser is really there before a render (server/first-run.mjs ensureRenderer)
  const renderer = async () => { try { await ensureRenderer((t) => step('tool', t)); } catch (e) { throw new CustomerError(`${e.message} Check the internet connection, then press Retry.`); }
    // before every render: no part of a scene may be seen outside its scene (it would cover the others); found = told to the
    // owner with the scene and the seconds (the compositor already keeps parts inside their scene, so this is the last net)
    try {
      const hf = path.join(J0, 'edit', 'hf');
      if (fs.existsSync(path.join(hf, 'index.html'))) {
        const { leakCheck } = await import(pathToFileURL(path.join(ENGINE_DIR, 'readcheck.mjs')).href);
        const leaks = await leakCheck(hf);
        if (leaks.length) { console.error('[render] parts seen outside their scene:', JSON.stringify(leaks)); cto.record({ tag: 'critical', key: 'render:leak', title: `A scene's part covers other scenes in "${p.name}"`, detail: leaks.map((x) => `scene ${x.k + 1}: ${x.what} seen from ${x.from} s to ${x.to} s`).join('\n'), projectId: p.id, ok: false, action: 'rendered as it is; the scene needs a fix' }); }
      }
    } catch (e) { console.error('[render] leak check:', e.message); }
  };
  const step = (type, text) => { if (job.finished || !p.job) return; p.job.steps.push({ t: Date.now(), type, text }); if (p.job.steps.length > 300) p.job.steps.splice(0, p.job.steps.length - 300); store.save(p); };
  const pass = MODE === 'web' && USING_API_KEY ? issueJobPass(p.ownerId) : null;
  job.pass = pass; job.byModel = {};
  const useOf = (model, add) => { const k = model || 'default', b = (job.byModel[k] = job.byModel[k] || { calls: 0, in: 0, out: 0, usd: 0, sec: 0 }); for (const [x, v] of Object.entries(add)) b[x] = Number(((b[x] || 0) + v).toFixed(4)); };
  const geminiCost = (u) => {
    const pr = pricing().modelPrices[u.model] || pricing().modelPrices['gemini-2.5-pro'] || { in: 1.25, out: 10 };
    const usd = ((u.in || 0) * pr.in + (u.out || 0) * pr.out) / 1e6;
    useOf(u.model, { calls: 1, in: u.in || 0, out: u.out || 0, usd, sec: (u.ms || 0) / 1000 });
    job.costUsd = (job.costUsd || 0) + usd; job.estUsd = (job.estUsd || 0) + usd; job.tokensIn = (job.tokensIn || 0) + (u.in || 0); job.tokensOut = (job.tokensOut || 0) + (u.out || 0);
    const credits = usdToCredits(usd); job.credits = (job.credits || 0) + credits; if (p.job) { p.job.credits = Math.round(job.credits); p.job.costUsd = Number(((p.job.costUsd || 0) + usd).toFixed(4)); }
    p.costUsd = Number(((p.costUsd || 0) + usd).toFixed(4)); onSpend(p, credits, usd);
  };
  const drainGemini = () => { while (geminiUsage.length) geminiCost(geminiUsage.shift()); };

  // One Claude answer. extra: { tools: [] | ['Read'], maxTurns, systemPrompt, think (thinking budget), what (for the usage log),
  //   mcp + allowed (the editor's own tools), resume (a session id) + fork (a new session from it) }
  // prompt: text, or a user message with pictures (the SDK's streaming input). Returns the result message (session_id on it).
  const runQuery = async (prompt, model, extra = {}) => {
    throw new CustomerError('AI is switched off in Zancut 2D.');
    // a 2D film pauses BEFORE a new conversation when the 5-hour window is almost full (ZANCUT_WINDOW_STOP, percent): a
    // conversation the limit cuts off re-reads its whole history and makes nothing (0.35 $ lost in the 5 Nov test)
    if (p.kind === 'animation') {
      const fh = claude.usageView(claude.dirOf(p.ownerId) ?? undefined).buckets.find((b) => b.key === 'five_hour'), stop = Number(process.env.ZANCUT_WINDOW_STOP || 97);
      if (fh?.percent != null && fh.percent >= stop && fh.resetsAt) {
        const at = new Date(fh.resetsAt).toLocaleTimeString('en-US', { hour: 'numeric', minute: '2-digit' });
        throw new Error(`Your Claude 5-hour limit is reached (${fh.percent}% used). New AI steps pause here, before a new step starts; the window resets at ${at}.`);
      }
    }
    const qStart = Date.now(), qAbort = new AbortController(), onJobAbort = () => qAbort.abort();
    job.abort.signal.addEventListener('abort', onJobAbort);
    const IDLE = Number(process.env.ZANCUT_IDLE_MIN || 12) * 60000; let lastMsg = Date.now(), stalled = false;
    // a tick that comes late = the server itself was frozen (nothing could arrive): that time is not the AI's silence
    let lastTick = Date.now();
    const dog = setInterval(() => { const now = Date.now(), lost = now - lastTick - 30000; lastTick = now; if (lost > 15000) lastMsg += lost; if (now - lastMsg > IDLE) { stalled = true; qAbort.abort(); } }, 30000);
    const tools = extra.tools || [], own = extra.allowed || [];
    const options = {
      cwd: d.ws, permissionMode: 'dontAsk', tools,
      allowedTools: [...(tools.includes('Read') ? [`Read(/${d.ws}/**)`] : []), ...own],
      disallowedTools: ['Bash', 'Write', 'Edit', 'AskUserQuestion', 'EnterPlanMode', 'ExitPlanMode', 'WebFetch', 'WebSearch', 'Agent', 'Task', 'Glob', 'Grep', 'TodoWrite'],
      mcpServers: extra.mcp ? { zancut: extra.mcp } : {},
      ...(extra.resume ? { resume: extra.resume, ...(extra.fork ? { forkSession: true } : {}) } : {}),
      env: {
        ...cleanEnv(), CLAUDE_CODE_DISABLE_CLAUDE_MDS: '1', ENABLE_CLAUDEAI_MCP_SERVERS: 'false', ...(process.env.ZANCUT_NO_CACHE === '1' ? { DISABLE_PROMPT_CACHING: '1' } : {}), // prompt caching ON: the skill files and rules repeat in every call
        // the editor's conversations last minutes: the 5-minute cache (writes 1.25× input) instead of the hour (2×)
        ...(extra.cache5m ? { FORCE_PROMPT_CACHING_5M: '1' } : {}),
        ...claude.envFor(p.ownerId), // the customer's own Claude login (web), the app's (computer); none with a server key
        ...(pass ? { ANTHROPIC_BASE_URL: `http://127.0.0.1:${PORT}/api/ai`, ANTHROPIC_API_KEY: pass } : {}), ...(job.extra?.env || {})
      },
      settingSources: [], skills: [],
      systemPrompt: extra.systemPrompt || { type: 'preset', preset: 'claude_code', append: SYSTEM_APPEND },
      maxTurns: Math.min(MAX_TURNS, extra.maxTurns || 1), abortController: qAbort,
      // thinking: the editor's calls let the model decide how much each step needs (adaptive, at the effort the call names: the
      // lead high, the builders low), the way it works in a chat; ZANCUT_THINKING=fixed gives every step a fixed budget instead.
      // Other calls keep their small budget.
      ...(extra.adaptive && process.env.ZANCUT_THINKING !== 'fixed' && extra.think !== 0 ? { thinking: { type: 'adaptive' }, effort: typeof extra.adaptive === 'string' ? extra.adaptive : process.env.ZANCUT_EFFORT || 'high' } : { maxThinkingTokens: extra.think ?? 4000 }),
      canUseTool: async (toolName, input) => {
        if (own.includes(toolName)) return { behavior: 'allow', updatedInput: input };
        console.log(`[deny] ${p.id} ${toolName} ${JSON.stringify(input).slice(0, 200)}`); return { behavior: 'deny', message: 'Not allowed in Zancut jobs.' };
      },
    };
    options.model = MODEL || model || modelFor(p);
    if (CLAUDE_PATH) options.pathToClaudeCodeExecutable = CLAUDE_PATH;
    let result = null, sid = null, estUsd = 0, seenIn = 0, seenOut = 0, lastTotal = 0, synthetic = '';
    const seen = new Set();
    // one line per AI step in usage.jsonl (scripts/usage-report.mjs): a step arrives in parts (thinking, text, tool calls) that
    // share its id, so its line is written when the next step starts or the conversation ends, with every tool it called. Its
    // usage is the stream's early snapshot (the output is not counted yet): the conversation's total line has the real numbers.
    const open = new Map();
    const conv = { input_tokens: 0, output_tokens: 0, cache_read_input_tokens: 0, cache_creation_input_tokens: 0 };
    const flush = (keep = null) => { for (const [id, x] of open) { if (id === keep) continue; open.delete(id); for (const k of Object.keys(conv)) conv[k] += x.u[k] || 0; try { fs.appendFileSync(path.join(d.root, 'usage.jsonl'), JSON.stringify({ t: x.t, v: n, kind: job.kind, what: extra.what || '', model: x.model, in: x.u.input_tokens || 0, cacheRead: x.u.cache_read_input_tokens || 0, cacheWrite: x.u.cache_creation_input_tokens || 0, out: x.u.output_tokens || 0, usd: Number(x.usd.toFixed(5)), tools: x.tools }) + '\n'); } catch { } } };
    // the budget of a 2D film: warns on the way (it never stops a job): ZANCUT_BUDGET_USD, 0 = off
    const budgetCheck = () => { const cap = Number(process.env.ZANCUT_BUDGET_USD ?? (p.kind === 'animation' ? 8 : 0)); if (!(cap > 0)) return; const spent = Math.max(job.costUsd || 0, job.estUsd || 0), mark = spent >= cap ? 100 : spent >= cap * 0.8 ? 80 : 0; if (mark > (job.budgetMark || 0)) { job.budgetMark = mark; step('tool', `Cost so far: about $${spent.toFixed(2)} of this film's $${cap} target`); } };
    const see = claude.seeFor(p.ownerId);
    const charge = (usd) => { if (!(usd > 0)) return; const credits = usdToCredits(usd); job.credits = (job.credits || 0) + credits; if (p.job) p.job.credits = Math.round(job.credits); onSpend(p, credits, usd); };
    try {
      for await (const m of query({ prompt, options })) {
        lastMsg = Date.now();
        if (job.cancelled) break;
        see(m);
        // Claude's limit reached inside a conversation is no error: one "<synthetic>" reply says so and the conversation ends
        if (m.type === 'assistant' && m.message?.model === '<synthetic>') synthetic = (m.message.content || []).map((b) => b.text || '').join(' ').trim() || synthetic;
        if (m.type === 'assistant' && m.message?.usage && m.message.id && !seen.has(m.message.id)) {
          seen.add(m.message.id); const u = m.message.usage, usd = usageCost(m.message.model || options.model, u);
          estUsd += usd; job.estUsd = (job.estUsd || 0) + usd;
          const tin = (u.input_tokens || 0) + (u.cache_read_input_tokens || 0) + (u.cache_creation_input_tokens || 0);
          seenIn += tin; seenOut += u.output_tokens || 0; job.tokensIn = (job.tokensIn || 0) + tin; job.tokensOut = (job.tokensOut || 0) + (u.output_tokens || 0); charge(usd); budgetCheck();
          flush(); open.set(m.message.id, { t: Date.now(), model: m.message.model || options.model, u: { ...u }, usd, tools: [] });
        }
        if (m.type === 'assistant' && m.message?.id && open.has(m.message.id)) {
          const x = open.get(m.message.id), u = m.message.usage || {};
          if ((u.output_tokens || 0) > (x.u.output_tokens || 0)) x.u = { ...x.u, ...u };
          for (const b of m.message.content || []) if (b.type === 'tool_use') x.tools.push(String(b.name).replace('mcp__zancut__', ''));
        }
        if (m.session_id) sid = m.session_id; // kept for an error too: its conversation can be carried on (a 2D builder that ran out of turns)
        if (m.type === 'result') {
          flush();
          // a resumed conversation's total_cost_usd is the WHOLE conversation's (every earlier call again): its own cost is priced
          // from this call's tokens, so a builder carried on in round 2 or a reviewer resumed is never counted twice
          const own = extra.resume && m.usage ? usageCost(options.model, m.usage) : m.total_cost_usd;
          try { fs.appendFileSync(path.join(d.root, 'usage.jsonl'), JSON.stringify({ t: Date.now(), v: n, kind: job.kind, total: true, model: options.model, usd: own ?? null, usage: m.usage || null, turns: m.num_turns ?? null, ms: m.duration_ms ?? null, what: extra.what || '' }) + '\n'); } catch { }
          result = m;
          const added = Math.max(0, (own || 0) - lastTotal); lastTotal = Math.max(lastTotal, own || 0);
          job.costUsd = (job.costUsd || 0) + added;
          if (m.usage) { const rin = (m.usage.input_tokens || 0) + (m.usage.cache_read_input_tokens || 0) + (m.usage.cache_creation_input_tokens || 0); if (rin > seenIn) job.tokensIn += rin - seenIn; if ((m.usage.output_tokens || 0) > seenOut) job.tokensOut += m.usage.output_tokens - seenOut; }
          if ((own || 0) > estUsd) { charge(own - estUsd); estUsd = own; }
          p.costUsd = Number(((p.costUsd || 0) + added).toFixed(4)); if (p.job) p.job.costUsd = Number(((p.job.costUsd || 0) + added).toFixed(4));
          if (m.usage) useOf(options.model, { calls: 1, in: (m.usage.input_tokens || 0) + (m.usage.cache_read_input_tokens || 0) + (m.usage.cache_creation_input_tokens || 0), out: m.usage.output_tokens || 0, usd: added, sec: (Date.now() - qStart) / 1000 });
        }
      }
    } catch (e) { if (!stalled || job.cancelled) { if (sid && e && typeof e === 'object') e.session_id ||= sid; throw e; } const err = new Error('stalled'); err.stalled = true; err.session_id = sid; throw err; }
    finally {
      flush();
      // a conversation cut off (a limit, a stop) sends no total: its steps are the record, so its cost is never lost from the report or the meter
      if (!result && conv.input_tokens + conv.cache_read_input_tokens + conv.cache_creation_input_tokens > 0) {
        try { fs.appendFileSync(path.join(d.root, 'usage.jsonl'), JSON.stringify({ t: Date.now(), v: n, kind: job.kind, total: true, partial: true, model: options.model, usd: Number(estUsd.toFixed(5)), usage: conv, ms: Date.now() - qStart, what: extra.what || '' }) + '\n'); } catch { }
        job.costUsd = (job.costUsd || 0) + estUsd; p.costUsd = Number(((p.costUsd || 0) + estUsd).toFixed(4)); if (p.job) p.job.costUsd = Number(((p.job.costUsd || 0) + estUsd).toFixed(4));
      }
      clearInterval(dog); job.abort.signal.removeEventListener('abort', onJobAbort); }
    if (job.cancelled) throw new Error('cancelled');
    // ...so it stops the job like a limit error (paused, the scenes built so far kept), instead of passing for a finished step
    const said = synthetic || (result?.is_error ? String(result.result || '') : '');
    if (LIMIT_SAID.test(said)) throw Object.assign(new Error(said.slice(0, 300)), { quotaLimit: QUOTA_SAID.test(said) });
    return result;
  };
  const OPUS = () => pricing().models.plan || null;
  const ask = async (q) => (await runQuery(q, pricing().models.short || null, { tools: ['Read'], maxTurns: 3, systemPrompt: 'You choose pictures for a video editor. Read the image you are given, then answer with the JSON only.', what: 'stock pick' }))?.result || '';
  const fullBrief = () => {
    const brief = fs.existsSync(path.join(J0, 'work', 'BRIEF.md')) ? fs.readFileSync(path.join(J0, 'work', 'BRIEF.md'), 'utf8') : '';
    if (!brief) throw new CustomerError('The transcript step is missing. Go back to Step 2 and press Retry.');
    let gb = null; try { gb = JSON.parse(fs.readFileSync(path.join(J0, 'work', 'GEMINI.json'), 'utf8')); } catch { }
    return brief + breakdownText(gb);
  };
  const readSb = () => { try { return JSON.parse(fs.readFileSync(path.join(J0, 'work', 'storyboard.json'), 'utf8')); } catch { return null; } };
  // what the editor reads about this video (the Brief, the customer's files, the style reference)
  const videoFacts = () => {
    const refFile = path.join(d.ws, 'reference', 'REFERENCE.md');
    const screen = (() => { try { return JSON.parse(fs.readFileSync(path.join(J0, 'work', 'screen.json'), 'utf8')); } catch { return null; } })();
    const screenLines = (() => { try { return JSON.parse(fs.readFileSync(path.join(J0, 'work', 'screen-lines.json'), 'utf8')); } catch { return null; } })(); // screen recordings with their own voice: screen or graphic per line (screensync.mjs)
    return { brief: fullBrief(), reference: fs.existsSync(refFile) ? fs.readFileSync(refFile, 'utf8') : '', facts: factsOf(d, p), words: firstCutWords(J0), screen, screenLines, animScript: anim.scriptText(d, p) };
  };
  const E = editor({ d, p, job, step: (t) => step('tool', t), ask, runQuery, model: OPUS() });
  // the customer's notes → the editor changes those scenes (its session resumed) → their new pictures
  // a long sound attached to a comment is not an effect: it becomes the music bed (the old bed goes)
  const attachFiles = (list) => (list || []).map((a) => {
    if (a.role !== 'sound' || !(a.duration > 25)) return a;
    for (const old of (p.assets || []).filter((x) => x.role === 'music' && x.file !== a.file)) { try { fs.rmSync(path.join(d.assets, old.file), { force: true }); } catch { } }
    p.assets = (p.assets || []).filter((x) => x.role !== 'music' || x.file === a.file);
    const own = p.assets.find((x) => x.file === a.file); if (own) own.role = 'music';
    store.save(p);
    return { ...a, role: 'music' };
  });
  // 2D Animation: the planner, its model and the heard words (an uploaded voiceover is planned from them)
  const change = async (notes) => {
    if (!E.sb?.rows?.length) throw new CustomerError('This video has no storyboard to change. Make the storyboard again in step 3.');
    const rows = await changeVideo(E, notes, videoFacts());
    if (job.cancelled) throw new Error('cancelled');
    await bodyGate(E, videoFacts());
    if (job.cancelled) throw new Error('cancelled');
    if (!rows.length && !E.global) throw new CustomerError('The editor could not tell what to change. Try saying it another way.');
    await makeBoard(d, p, E.sb, { only: rows, step: (t) => step('tool', t) });
    drainGemini();
    return rows;
  };
  // the editor's report on the notes never reaches the customer (they see their change made): it goes to Admin → Skill adoption
  const learn = async (notes) => { if (!E.report?.length) return; step('tool', 'Learning from your notes for the next videos'); try { await learnFrom({ p, version: n, notes, report: E.report, runQuery, model: OPUS() }); } catch (e) { console.error('[learn]', e.message?.slice(0, 160)); } };

  try {
    // the Windows app's first run still downloading (server/first-run.mjs): wait for it here rather than fail half-way
    if (firstRun().on && !firstRun().ready) {
      try { await awaitFirstRun((t) => step('tool', t), job.abort.signal); }
      catch (e) { if (job.abort.signal.aborted) throw e; throw new CustomerError(String(e.message)); }
    }
    if (job.kind === 'prepare') await prepareScript(d, p, job, runQuery, step, geminiCost);
    else if (job.kind === 'storyboard') {
      // Zancut 2D: no AI. The scene file and the voice's words become shots from the library.
      if (!p.film) throw new CustomerError('Add the scene file first (who is where, doing what).');
      const sb = await codefilm.build(d, p, p.film, { step: (t) => step('tool', t) });
      if (job.cancelled) throw new Error('cancelled');
      if (!sb) throw new CustomerError('The storyboard could not be made this time. Press Retry.');
      if (p.board) p.board = { rev: p.board.rev, rows: [] };
      await makeBoard(d, p, sb, { step: (t) => step('tool', t) });
      drainGemini();
    } else if (job.kind === 'replan') { // a part of the storyboard planned again on its real timings: words from–to
      const rows = await replanVideo(E, videoFacts(), job.extra.from, job.extra.to);
      if (job.cancelled) throw new Error('cancelled');
      if (p.board) p.board = { rev: p.board.rev, rows: [] };
      await makeBoard(d, p, E.sb, { step: (t) => step('tool', t) });
      drainGemini();
      if (!rows.length) throw new CustomerError('Those words are not in the storyboard.');
    } else if (job.kind === 'scene') {
      const { row: i, note, image, cid } = job.extra;
      if (!E.sb?.rows?.[i]) throw new CustomerError('This scene is not in the storyboard any more. Reload the page.');
      const notes = [{ where: `scene ${i + 1}`, text: note, image, attach: attachFiles(job.extra.attach) }];
      await change(notes);
      const c = (p.board?.rows?.[i]?.comments || []).find((x) => x.id === cid); if (c) Object.assign(c, { status: 'done', doneAt: Date.now() });
      await learn(notes);
    } else if (job.kind === 'revise') {
      const open = (p.comments || []).filter((c) => (job.extra.ids || []).includes(c.id));
      if (!open.length) throw new CustomerError('There are no changes to make. Add a comment first.');
      const rows = p.board?.rows || [];
      const hit = (c) => (c.start == null ? [] : rows.map((r, i) => [r, i]).filter(([r]) => r.s != null && (c.end > c.start + 0.05 ? r.s < c.end - 0.05 && r.e > c.start + 0.05 : c.start >= r.s - 0.05 && c.start < r.e + 0.05)).map(([, i]) => i));
      const when = (c) => (c.start == null ? 'the whole video' : c.end > c.start + 0.05 ? `${secs(c.start)}–${secs(c.end)}` : `at ${secs(c.start)}`);
      // the editor decides which scenes a note touches (a time names them; a note on the whole video may touch many)
      const notes = open.map((c) => ({ where: `${when(c)}${hit(c).length ? ` (scene${hit(c).length > 1 ? 's' : ''} ${hit(c).map((i) => i + 1).join(', ')})` : ''}`, text: c.text, image: c.image || null, attach: attachFiles(c.attach) }));
      await change(notes);
      step('tool', 'Rendering the new version');
      await renderer();
      const r = await zen(d.ws, ['finish', `v${n}`]); if (!r.ok) { console.error('[render]', r.error); job.renderError = r.error; }
      await learn(notes);
    } else if (job.kind === 'refresh') { step('tool', 'Adding the cut-out to your scenes'); const r = await zen(d.ws, ['compose']); if (!r.ok) throw new Error(r.error); const sb = readSb(); if (sb && p.board) { const keep = p.board.rows; await makeBoard(d, p, sb, { step: (t) => step('tool', t) }); p.board.rows.forEach((r2, k) => { r2.comments = keep[k]?.comments || r2.comments; }); } if (p.board) p.board.cutout = 'ready'; }
    else if (job.kind === 'render') { step('tool', 'Rendering your video'); await renderer(); const r = await zen(d.ws, ['finish', `v${n}`]); if (!r.ok) { console.error('[render]', r.error); job.renderError = r.error; } }
    else throw new Error(`unknown job ${job.kind}`);
  } catch (e) {
    const c = job.kind === 'scene' && (p.board?.rows?.[job.extra.row]?.comments || []).find((x) => x.id === job.extra.cid); if (c) c.status = job.cancelled ? 'stopped' : 'failed';
    if (job.cancelled) return finish(job, () => finishFailed(p, '', true));
    console.error('[job]', p.id, job.kind, e);
    job.error = e;
    return finish(job, () => finishFailed(p, e.customer ? e.message : 'Something went wrong on our side. Your files are safe. Please press Retry; if it happens again, contact support.', false, e, job.extra));
  }
  if (job.finished) return;
  if (job.kind !== 'render' && job.kind !== 'revise') return finish(job, () => finishStep(p, job));

  const file = path.join(d.exports, `v${n}.mp4`);
  if (!fs.existsSync(file)) { job.error = new Error(`The render did not finish: ${String(job.renderError || 'no file was made').slice(0, 2000)}`); return finish(job, () => finishFailed(p, 'The render did not finish. Press Retry.')); }
  // the sound check, measured before the version is shown: a sound over the voice is lowered by what it needs (work/sfx-fix.json,
  // read by the compositor) and the video rendered once more, no AI; what is still over it is shown under the version
  const voiceOnly = path.join(J0, 'cut', 'cut.mp4'), placedNow = () => { try { return JSON.parse(fs.readFileSync(path.join(J0, 'edit', 'hf', 'sfx-auto.json'), 'utf8')); } catch { return []; } };
  let audio = null;
  if (fs.existsSync(voiceOnly)) {
    try {
      audio = await measureMix(file, voiceOnly, placedNow());
      if (!audio.ok && !job.cancelled) {
        step('tool', 'Lowering the sounds that cover your voice');
        const fx = path.join(J0, 'work', 'sfx-fix.json'); let list = []; try { list = JSON.parse(fs.readFileSync(fx, 'utf8')); } catch { }
        for (const i of audio.issues) if (i.name) { const old = list.find((x) => x.name === i.name && Math.abs(x.t - i.at) < 0.2); if (old) old.db = Math.min(30, old.db + i.db); else list.push({ t: i.at, name: i.name, db: i.db }); }
        fs.writeFileSync(fx, JSON.stringify(list, null, 1));
        const r = await zen(d.ws, ['finish', `v${n}`]);
        if (r.ok) audio = await measureMix(file, voiceOnly, placedNow()); else console.error('[sound fix] render:', String(r.error).slice(0, 200));
      }
    } catch (e) { console.error('[sound check]', String(e.message).slice(0, 160)); }
  }
  // the picture check on the real frames (screen moments that are empty or miss what is said get a new zoom and one more render)
  let check = null;
  try { check = await checkVideo(d, p, { n, file, runQuery, model: pricing().models.study || null, step: (t) => step('tool', t) }); } catch (e) { console.error('[video check]', String(e.message).slice(0, 200)); }
  if (job.cancelled) return finish(job, () => finishFailed(p, '', true));
  let info; try { info = await probe(file); } catch { info = null; }
  if (!info?.hasVideo || info.duration < 1) return finish(job, () => finishFailed(p, 'The rendered file is broken. Press Retry.'));
  const name = `v${n}.mp4`, dest = path.join(d.out, name);
  fs.rmSync(dest, { force: true }); try { fs.linkSync(file, dest); } catch { fs.copyFileSync(file, dest); }
  let thumbs = null; try { thumbs = await makeThumbs(dest, d.out, `v${n}`, info.duration); } catch (e) { console.error('[thumbs]', e.message); }
  const nf = path.join(d.exports, `v${n}.md`);
  const notes = [fs.existsSync(nf) ? fs.readFileSync(nf, 'utf8').trim() : '', musicCredit(J0)].filter(Boolean).join('\n\n');
  finish(job, () => {
    p.versions.push({ n, file: name, duration: info.duration, width: info.width, height: info.height, size: info.size, notes, thumbs, createdAt: Date.now(), kind: job.extra?.manual ? 'manual' : 'ai', ...(check ? { check } : {}), ...(audio ? { audio: { ...audio, measured: true } } : {}), took: Date.now() - p.job.startedAt, costUsd: Number((p.costUsd || 0).toFixed(4)) });
    if (job.kind === 'revise') for (const c of p.comments || []) if ((job.extra.ids || []).includes(c.id)) c.resolvedIn = n;
    p.draft = null;
    finishStep(p, job);
  });
  // The sound check of every finished video, measured (not guessed): each placed sound against the voice-only track. Shown
  // under the version. (Gemini's listen, below, is optional: it reports a problem at almost every sound, even inaudible ones.)
  if (!audio && fs.existsSync(voiceOnly)) {
    let placed = []; try { placed = JSON.parse(fs.readFileSync(path.join(J0, 'edit', 'hf', 'sfx-auto.json'), 'utf8')); } catch { }
    measureMix(dest, voiceOnly, placed).then((r) => { const q = store.get(p.id), v = q?.versions.find((x) => x.n === n); if (!v) return; v.audio = { ...r, measured: true }; store.save(q, { immediate: true }); }).catch((e) => console.error('[sound check]', e.message.slice(0, 160)));
  }
  if (geminiOn() && (process.env.GEMINI_SOUND_TEST === '1' || job.extra?.soundTest)) {
    let placed = []; try { placed = JSON.parse(fs.readFileSync(path.join(J0, 'edit', 'hf', 'sfx-auto.json'), 'utf8')).map((x) => ({ at: x.t, name: x.name })); } catch { }
    testSoundMix(dest, placed).then((r) => {
      const q = store.get(p.id), v = q?.versions.find((x) => x.n === n); if (!v || !r?.data) return;
      v.audio = { ok: !!r.data.ok, summary: String(r.data.summary || '').slice(0, 200), issues: (r.data.issues || []).slice(0, 6).map((x) => ({ at: Number(x.at) || null, problem: String(x.problem || '').slice(0, 120), fix: String(x.fix || '').slice(0, 160) })) };
      store.save(q, { immediate: true });
    }).catch((e) => console.error('[sound test]', e.message.slice(0, 160)));
  }
}

function finishStep(p, job) {
  p.spend = [...(p.spend || []), { kind: job.kind, at: Date.now(), sec: Math.round((Date.now() - (p.job?.startedAt || Date.now())) / 1000), usd: Number((p.job?.costUsd || 0).toFixed(4)), byModel: job.byModel || {} }].slice(-200);
  if (['storyboard', 'replan', 'scene'].includes(job.kind)) p.edited = p.built = Date.now();
  if (['storyboard', 'replan'].includes(job.kind)) p.boardAt = Date.now();
  if (['storyboard', 'replan', 'scene'].includes(job.kind)) watchCutout(p.id);
  p.status = store.idleStatus(p); p.error = null; p.quota = null;
  p.lastJob = { kind: job.kind, steps: (p.job?.steps || []).slice(-60) };
  p.job = null;
  store.save(p, { immediate: true });
}
// what a stopped job needs to run again (a re-plan's words, a change round's comments), never a desktop app's cloud pass
const safeExtra = (x) => { const o = Object.fromEntries(Object.entries(x || {}).filter(([k]) => !['env', 'cloudToken', 'cloudJobId', 'relay', 'pass'].includes(k))); return Object.keys(o).length ? o : null; };
function finishFailed(p, message, cancelled = false, err = null, extra = null) {
  if (!p) return;
  const isQuotaLimit = !cancelled && (err?.quotaLimit || /5-hour|weekly|daily|usage limit|session limit|claude_limit|hit your .*limit/i.test(message) || /5-hour|weekly|daily|usage limit|session limit|claude_limit|hit your .*limit/i.test(err?.message || ''));
  if (isQuotaLimit) {
    // paused by Claude's limit: the scenes built so far are kept; it carries on by itself when the limit resets only when the
    // customer said so (their account setting, or their answer on the pause card: null = not asked yet)
    p.status = 'PAUSED_QUOTA_LIMIT';
    const sb = (() => { try { return JSON.parse(fs.readFileSync(path.join(jobDir(store.dirs(p.id).ws), 'work', 'storyboard.json'), 'utf8')); } catch { return null; } })();
    const graphic = (sb?.rows || []).map((r, i) => (r.piece === 'custom' ? i : -1)).filter((i) => i >= 0);
    const owner = users.byId(p.ownerId);
    p.quota = {
      reachedAt: Date.now(),
      resetAt: claude.blockedFor(p.ownerId)?.until || err?.resetAt || Date.now() + 5 * 3600e3,
      doneScenes: graphic.filter((i) => (p.editor?.done || []).includes(i)).length,
      totalScenes: graphic.length,
      autoResume: owner?.autoResume === true ? true : owner?.autoResume === false ? false : null,
      message: message || "Claude's usage limit was reached.",
    };
    p.error = message || null;
  } else {
    p.status = store.idleStatus(p);
    p.error = cancelled ? null : message || null;
  }
  // stopped while the transcript was being made: back to trimming (the step before), where Confirm starts it again
  if (cancelled && p.job?.kind === 'prepare' && !p.transcript && p.trim) p.trim.confirmed = false;
  p.lastJob = { kind: p.job?.kind, steps: (p.job?.steps || []).slice(-60), failed: !cancelled, ...(safeExtra(extra) ? { extra: safeExtra(extra) } : {}) };
  p.job = null; store.save(p, { immediate: true });
}
// The storyboard never waits for the speaker cut-out (those scenes show the plain speaker until then). Every 20 s: when the
// cut-out is ready and nothing else runs, a quick no-AI job composes the page again with it.
const watching = new Set();
export function watchCutout(id) {
  if (watching.has(id)) return; watching.add(id);
  const t0 = Date.now();
  const tick = () => {
    const p = store.get(id); if (!p?.board || Date.now() - t0 > 40 * 60000) return watching.delete(id);
    if (['queued', 'editing'].includes(p.status)) return setTimeout(tick, 20000);
    const J0 = jobDir(store.dirs(id).ws), log = path.join(J0, 'cut', 'matte.log'), planText = fs.existsSync(path.join(J0, 'edit', 'plan.json')) ? fs.readFileSync(path.join(J0, 'edit', 'plan.json'), 'utf8') : '';
    if (!/"(popout-box-split|behind-head-depth|bg-replace-stage)"/.test(planText)) { p.board.cutout = 'not needed'; store.save(p); return watching.delete(id); }
    const txt = fs.existsSync(log) ? fs.readFileSync(log, 'utf8') : '';
    if (/error|Traceback/i.test(txt)) { p.board.cutout = 'failed'; store.save(p); return watching.delete(id); }
    if (/"ok":\s*true/.test(txt) && fs.existsSync(path.join(J0, 'cut', 'subject.webm'))) { watching.delete(id); if (p.board.cutout !== 'ready') { try { enqueue(id, 'refresh'); } catch { } } return; }
    if (p.board.cutout !== 'pending') { p.board.cutout = 'pending'; store.save(p); }
    setTimeout(tick, 20000);
  };
  setTimeout(tick, 3000);
}

// Step 2: the narration, the words with exact times, the first cut, Gemini's listening and (screen recordings) the screen events
async function prepareScript(d, p, job, runQuery, step, geminiCost) {
  const J0 = jobDir(d.ws), main = mainClips(p), isPlate = !!main[0]?.plate;
  if (isPlate) { await makePlate(d, p, runQuery, step, job.abort.signal); linkMain(d, p); } // the plate exists now: into raw/
  while (geminiUsage.length) geminiCost(geminiUsage.shift());
  if (job.cancelled) throw new Error('cancelled');
  // Listen again (Step 2): only that part of the main track gets new words; everything after is made from the words again
  const again = job.extra?.relisten;
  if (again) {
    const r = await relistenRange(d.ws, main[0].rel, again[0], again[1], p, (t) => step('tool', t), job.abort.signal);
    if (!r) throw new CustomerError('That part could not be listened to again. Press Transcribe all again.');
    fs.rmSync(path.join(J0, 'work', 'transcript.raw.json'), { force: true });
    if (job.cancelled) throw new Error('cancelled');
  }
  const ttsWords = path.join(d.ws, 'plate', 'voice.words.json');
  if (isPlate && fs.existsSync(ttsWords) && fs.existsSync(path.join(d.ws, 'plate', 'voice.wav'))) {
    // 2D Animation: every word was already timed while the voices were recorded (animation.mjs recordLines)
    if (!(p.kind === 'animation' && fs.existsSync(path.join(d.ws, 'plate', 'aligned.json')))) {
      step('tool', 'Timing every word of your script (WhisperX)');
      await alignScript(path.join(d.ws, 'plate', 'voice.wav'), ttsWords, p.language || 'en', job.abort.signal);
    }
    fs.copyFileSync(ttsWords, path.join(J0, 'work', 'transcript.raw.json'));
    main.length = 0;
  }
  const tp = { ...p, footage: main, assets: (p.assets || []).filter((a) => !(isPlate && a.role === 'voiceover')), wordsByGemini: true };
  const needs = tp.footage.length || (tp.assets || []).some((a) => a.role === 'voiceover');
  const transcripts = needs ? await transcribeFootage(d.ws, tp, (t) => step('tool', t), job.abort.signal) : [];
  while (geminiUsage.length) geminiCost(geminiUsage.shift());
  if (job.cancelled) throw new Error('cancelled');
  // words a local model heard (no Gemini: Bangla and other languages, or English it was unsure of): Claude proofreads them in place
  for (const t of transcripts) {
    if (t.tags === 'gemini' || (t.language === 'en' && (t.conf ?? 1) >= 0.85) || !t.words) continue;
    const file = path.join(d.ws, t.transcript);
    try {
      const words = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (!Array.isArray(words) || !words.length) continue;
      step('tool', 'Proofreading the words (spelling, misheard words, loops)');
      const proof = { fix: [], drop: [] };
      for (let a = 0; a < words.length; a += 400) { // long recordings in parts
        const r = parseProof((await runQuery(proofPrompt({ ...p, language: t.language }, words.slice(a, a + 400), a), pricing().models.plan || null, { tools: [], maxTurns: 1, think: 2000, what: 'proofread words' }))?.result);
        if (r) { proof.fix.push(...r.fix); proof.drop.push(...r.drop); }
      }
      if (proof.fix.length || proof.drop.length) {
        fs.writeFileSync(file.replace(/\.json$/, '.heard.json'), JSON.stringify(words));
        const fixed = applyProof(words, proof);
        fs.writeFileSync(file, JSON.stringify(fixed, null, 1));
        console.log(`[transcribe] ${t.file}: proofread by Claude (${proof.fix.length} words fixed, ${proof.drop.reduce((n, [a, b]) => n + b - a + 1, 0)} looped words dropped)`);
      }
    } catch (e) { if (job.cancelled) throw e; console.error('[proofread]', e.message?.slice(0, 200)); } // the words as heard stay
  }
  await studyStyle(d, p, job, runQuery, step);
  seedWords(d, p, transcripts);
  // Step 2 again: the first cut starts from its own settings, never from the storyboard's (its spelling fixes join words,
  // which would renumber every word the storyboard's scenes point at)
  const firstCuts = path.join(J0, 'work', 'cuts.first.json');
  if (fs.existsSync(firstCuts)) fs.copyFileSync(firstCuts, path.join(J0, 'work', 'cuts.json'));
  step('tool', 'Putting the words on the timeline');
  const r = await zen(d.ws, ['prep'], 20 * 60000);
  if (!r.ok) {
    console.error('[prep]', r.error);
    // "check the sound" only when it really has none: otherwise that sends people looking for the wrong problem
    throw new CustomerError(main.some((m) => m.hasAudio === false) ? 'Your footage could not be prepared: it has no sound. Add footage with sound, then press Retry.'
      : 'Your footage could not be prepared. Press Retry; if it happens again, use Report a bug in your profile menu.');
  }
  if (job.cancelled) throw new Error('cancelled');
  // screen recordings with a voice of their own (a recording, a script, a talking-head video): they are cut to follow it
  if (fitsScreens(p)) {
    try { const s = await syncScreen(d, p, { runQuery, model: pricing().models.study || null, step: (t) => step('tool', t) }); if (!s.ok) console.error('[screen sync]', s.why); }
    catch (e) { console.error('[screen sync]', String(e.message).slice(0, 300)); }
    if (job.cancelled) throw new Error('cancelled');
  }
  // screen recordings: the screen is tracked locally (frame differencing at 4 fps): what changes, where, and when nothing moves
  if (screenLed(p)) {
    step('tool', 'Tracking your screen recording');
    const own = path.join(J0, 'cut', 'screen.mp4'); // a talking head's screen: its own video beside the camera cut
    const r = await zen(d.ws, ['screen', ...(voiceSource(p) === 'video' && fs.existsSync(own) ? [own] : [])], 10 * 60000);
    if (!r.ok) {
      console.error('[screen]', r.error);
      try { const pb = await probe(path.join(J0, 'cut', 'cut.mp4')); fs.writeFileSync(path.join(J0, 'work', 'screen.json'), JSON.stringify({ deviceAspect: pb.width / pb.height < 0.8 ? 'mobile-9:16' : 'pc-16:9', events: [], aspect: pb.width / pb.height })); } catch { }
    }
    if (job.cancelled) throw new Error('cancelled');
  }
  // the listening tags (emphasis, uiText, literalMetaphor, Magic Cut ranges): Gemini's when it transcribed this speech (they come
  // with the words), else Claude reads the words of the first cut
  const cutWordsList = firstCutWords(J0);
  fs.rmSync(path.join(J0, 'work', 'GEMINI.json'), { force: true });
  if (cutWordsList.length) {
    let tags = null;
    const t = main.length === 1 && transcripts.find((x) => x.rel === main[0].rel);
    if (t?.tags === 'gemini') {
      try { tags = toFirstCut(parseTags(JSON.parse(fs.readFileSync(path.join(path.dirname(path.join(d.ws, t.transcript)), 'gemini-tags.json'), 'utf8'))), cutWordsList); } catch (e) { console.error('[tags] gemini:', e.message.slice(0, 120)); }
    }
    if (!tags) {
      step('say', 'Reading the words for meaning, emphasis and fillers');
      try { tags = parseTags((await runQuery(tagPrompt(p, cutWordsList), pricing().models.short || null, { tools: [], maxTurns: 1, think: 2000, what: 'listening tags' }))?.result); }
      catch (e) { if (job.cancelled) throw e; console.error('[tags] claude:', e.message.slice(0, 200)); }
    }
    if (tags) fs.writeFileSync(path.join(J0, 'work', 'GEMINI.json'), JSON.stringify(tags, null, 1));
  }
  step('tool', 'Laying out your transcript');
  saveScript(d, p);
  if (!p.named && naming.isPlaceholder(p.name)) {
    const said = scriptWords(d).map((w) => w.t).join(' ').slice(0, 2500);
    const t = await naming.shortTitle(users.byId(p.ownerId), [p.transcript?.summary, said].filter(Boolean).join('\n')).catch(() => '');
    if (t) p.name = t;
  }
  if (job.extra?.notes) restoreNotes(d, p, job.extra.notes, again || null);
  p.board = null;
}
function musicCredit(J0) {
  try {
    const plan = JSON.parse(fs.readFileSync(path.join(J0, 'edit', 'plan.json'), 'utf8')), lines = [];
    if (plan.music?.id) { const t = JSON.parse(fs.readFileSync(path.join(ASSETS_DIR, 'music', 'catalog.json'), 'utf8')).items.find((x) => x.id === plan.music.id); if (t?.credit) lines.push(`- Music: ${t.credit}`); }
    const cr = (() => { try { return JSON.parse(fs.readFileSync(path.join(J0, 'work', 'credits.json'), 'utf8')); } catch { return {}; } })();
    for (const c of Object.values(cr)) if (c?.credit) lines.push(`- ${c.credit}`);
    return lines.length ? `Credits\n${lines.join('\n')}` : '';
  } catch { return ''; }
}
