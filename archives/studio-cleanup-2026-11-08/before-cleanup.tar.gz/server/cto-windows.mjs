// The CTO on Windows (server/cto.mjs calls this): what the Windows app needs, checked and repaired. Only repairs from this
// fixed list, tested on Windows and from trusted sources; the CTO's Claude may choose one of them, never a download of its own:
//   ffmpeg   too old (before 7, which the engine's `-/filter_complex <file>` needs) or broken → Gyan's essentials build (the one
//            the installer ships, desktop/prepare.mjs) into ~/.cache/zancut/ffmpeg, first on PATH (also after a restart)
//   parts    the first run's downloads (video tools, renderer, speech model, cut-out, AI voice: server/first-run.mjs) → again
//   bundled  node.exe, the AI program, the app's Python: only a new install brings them back (reported, critical)
// On only in the desktop app (desktop/main.cjs sets ZANCUT_FIRST_RUN, Windows and Mac); the ffmpeg download is the Windows
// app's alone (the Mac app ships ffmpeg 9: a new install is its repair). The web never loads a repair from here.
import fs from 'node:fs';
import os from 'node:os';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { firstRun, startFirstRun, awaitFirstRun } from './first-run.mjs';

export const DESKTOP_APP = process.env.ZANCUT_FIRST_RUN === '1'; // the desktop app, Windows or Mac
export const WIN_APP = process.platform === 'win32' && DESKTOP_APP;
const run = promisify(execFile);
const FFMPEG_VERSION = '9.0.2';
const OWN_FFMPEG = path.join(os.homedir(), '.cache', 'zancut', 'ffmpeg');
const TAR = path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe');

// ffmpeg's major version (null: a build from git, which is new)
export async function ffmpegMajor(bin = 'ffmpeg') {
  const { stdout } = await run(bin, ['-hide_banner', '-version'], { timeout: 30000, windowsHide: true });
  const m = String(stdout).match(/ffmpeg version n?(\d+)\./);
  return m ? Number(m[1]) : null;
}
export const ffmpegNewEnough = (major) => major === null || major >= 7;

// a repaired ffmpeg from an earlier run goes first on PATH again (the server and everything it starts use it)
export function useOwnFfmpeg() {
  if (!WIN_APP || !fs.existsSync(path.join(OWN_FFMPEG, 'ffmpeg.exe'))) return;
  if (!String(process.env.PATH).split(path.delimiter).includes(OWN_FFMPEG)) process.env.PATH = [OWN_FFMPEG, process.env.PATH].join(path.delimiter);
}

let fixingFfmpeg = null;
export function repairFfmpeg() {
  if (!WIN_APP) return Promise.resolve(false);
  return (fixingFfmpeg ||= (async () => {
    const tmp = fs.mkdtempSync(path.join(os.tmpdir(), 'zancut-ffmpeg-'));
    try {
      const zip = path.join(tmp, 'ffmpeg.zip'), out = path.join(tmp, 'bin');
      const r = await fetch(`https://github.com/GyanD/codexffmpeg/releases/download/${FFMPEG_VERSION}/ffmpeg-${FFMPEG_VERSION}-essentials_build.zip`, { redirect: 'follow' });
      if (!r.ok) throw new Error(`ffmpeg download: ${r.status}`);
      await pipeline(Readable.fromWeb(r.body), fs.createWriteStream(zip));
      fs.mkdirSync(out);
      await run(TAR, ['-xf', zip, '-C', out, '--strip-components', '2', '*/bin/ffmpeg.exe', '*/bin/ffprobe.exe'], { timeout: 10 * 60000, windowsHide: true });
      if (!ffmpegNewEnough(await ffmpegMajor(path.join(out, 'ffmpeg.exe')))) throw new Error('the downloaded ffmpeg does not run');
      fs.rmSync(OWN_FFMPEG, { recursive: true, force: true });
      fs.cpSync(out, OWN_FFMPEG, { recursive: true });
      useOwnFfmpeg();
      return true;
    } finally { fs.rmSync(tmp, { recursive: true, force: true }); fixingFfmpeg = null; }
  })());
}

// the first run's downloads again, waiting until they are there (a job's repair) or only started (the health check)
export async function repairParts({ wait = true } = {}) {
  if (!DESKTOP_APP) return false;
  const s = firstRun(); if (!s.on || s.ready) return true;
  if (!wait) { startFirstRun(); return true; }
  await awaitFirstRun(() => {}, null);
  return true;
}

// a job failed with "a tool is missing": whatever of the list is wrong on this computer, repaired
export async function repairTools() {
  if (!DESKTOP_APP) return false;
  if (WIN_APP) { try { if (!ffmpegNewEnough(await ffmpegMajor())) await repairFfmpeg(); } catch { await repairFfmpeg(); } }
  return repairParts();
}

// the health check's Windows part. add(id, ok, detail): one line of Admin → CTO's health; record(item): an item on its list
export async function checkWindows(add, record, { claudePath } = {}) {
  if (!DESKTOP_APP) return;
  // the Mac app: its bundled ffmpeg 9 must run and be new enough (only a new install replaces it)
  if (!WIN_APP) {
    const major = await ffmpegMajor().catch(() => -1), ok = major !== -1 && ffmpegNewEnough(major);
    add('ffmpeg-version', ok, major === -1 ? 'not running' : `ffmpeg ${major ?? 'git build'}`);
    if (!ok) record({ tag: 'critical', key: 'mac:ffmpeg', title: major === -1 ? "The app's ffmpeg does not run on this Mac" : `The app's ffmpeg ${major} is too old for the engine`, detail: String(process.env.PATH).split(path.delimiter).slice(0, 3).join('\n'), ok: false, action: 'install Zancut again (a new .dmg)' });
  } else try {
    const major = await ffmpegMajor();
    if (ffmpegNewEnough(major)) add('ffmpeg-version', true, `ffmpeg ${major ?? 'git build'}`);
    else {
      try { await repairFfmpeg(); add('ffmpeg-version', true, `was ${major}: repaired`); record({ tag: 'fixed', key: 'win:ffmpeg', title: `ffmpeg ${major} was too old for the engine: ffmpeg ${FFMPEG_VERSION} installed`, detail: OWN_FFMPEG, ok: true, action: `downloaded ffmpeg ${FFMPEG_VERSION} (gyan.dev build)` }); }
      catch (e) { add('ffmpeg-version', false, `${major}: too old`); record({ tag: 'critical', key: 'win:ffmpeg', title: `ffmpeg ${major} is too old and could not be replaced`, detail: e.message, ok: false, action: 'download failed: install Zancut again' }); }
    }
  } catch (e) {
    try { await repairFfmpeg(); add('ffmpeg-version', true, 'missing: repaired'); record({ tag: 'fixed', key: 'win:ffmpeg', title: `ffmpeg was missing: ffmpeg ${FFMPEG_VERSION} installed`, detail: String(e.message).slice(0, 300), ok: true, action: 'downloaded' }); }
    catch (x) { add('ffmpeg-version', false, 'missing'); record({ tag: 'critical', key: 'win:ffmpeg', title: 'ffmpeg is missing and could not be downloaded', detail: x.message, ok: false, action: 'install Zancut again' }); }
  }
  // the first run's downloads (deleted caches, a run that failed offline): started again, with its own screen
  const f = firstRun();
  if (!f.on || f.ready) add('parts', true, 'all downloaded');
  else if (f.busy) add('parts', true, `downloading (${f.pct}%)`);
  else {
    await repairParts({ wait: false });
    add('parts', false, `missing: ${f.parts.filter((x) => !x.done).map((x) => x.label).join(', ')}`);
    record({ tag: 'fixed', key: 'win:parts', title: 'Parts Zancut downloads were missing: downloading them again', detail: `${f.parts.filter((x) => !x.done).map((x) => x.label).join(', ')}${f.error ? `\n\nLast try: ${f.error}` : ''}`, ok: null, action: 'downloading again (Getting Zancut ready)' });
  }
  // what ships inside the app: a new install is the only repair
  for (const [id, file, what] of [...(WIN_APP ? [['node', process.env.ZANCUT_NODE, 'the engine\'s Node']] : []), ['claude-program', claudePath, 'the AI program'], ['python-app', process.env.ZANCUT_PYTHON, 'the app\'s Python']]) {
    const ok = !!file && fs.existsSync(file);
    add(id, ok, ok ? 'ok' : 'missing');
    if (!ok) record({ tag: 'critical', key: `win:${id}`, title: `${what[0].toUpperCase()}${what.slice(1)} is missing from the installed app`, detail: String(file || '(not set)'), ok: false, action: 'install Zancut again (an antivirus may have removed it)' });
  }
}
