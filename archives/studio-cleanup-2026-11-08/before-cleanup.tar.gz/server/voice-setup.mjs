// Desktop app (Windows and Mac): the free AI voice (engine/tts.cjs) is a one-time download, started the first time someone opens
// "Write a script (AI voice)": the English Kokoro voice (~320 MB, sherpa-onnx's releases) and its runtime (sherpa-onnx-node,
// npm), into ZANCUT_TTS_DIR. On only where desktop/main.cjs sets ZANCUT_VOICE_DOWNLOAD (the web: unchanged),
// and not with a Gemini key (its voices need no download).
import fs from 'node:fs';
import path from 'node:path';
import { execFile } from 'node:child_process';
import { promisify } from 'node:util';
import { Readable } from 'node:stream';
import { pipeline } from 'node:stream/promises';
import { geminiOn } from './gemini.mjs';

const run = promisify(execFile);
const BASE = process.env.ZANCUT_TTS_DIR || '';
const on = () => process.env.ZANCUT_VOICE_DOWNLOAD === '1' && !!BASE && !geminiOn();
const RUNTIME = '1.13.8'; // sherpa-onnx 2.x drops the espeak data the voices need
// the runtime's own program for this computer (Windows x64, a Mac with Apple Silicon or Intel)
const NATIVE = `sherpa-onnx-${process.platform === 'win32' ? 'win' : process.platform}-${process.arch}`;
// each part unpacks into .download first and moves into place whole, so a half-finished download never looks ready
const PARTS = [
  { url: `https://registry.npmjs.org/sherpa-onnx-node/-/sherpa-onnx-node-${RUNTIME}.tgz`, at: ['bn-tts', 'node_modules', 'sherpa-onnx-node'], strip: 1 },
  { url: `https://registry.npmjs.org/${NATIVE}/-/${NATIVE}-${RUNTIME}.tgz`, at: ['bn-tts', 'node_modules', NATIVE], strip: 1 },
  { url: 'https://github.com/k2-fsa/sherpa-onnx/releases/download/tts-models/kokoro-en-v0_19.tar.bz2', at: ['en-tts', 'kokoro-en-v0_19'], inner: 'kokoro-en-v0_19' },
];
const TAR = process.platform === 'win32' ? path.join(process.env.SystemRoot || 'C:\\Windows', 'System32', 'tar.exe') : 'tar'; // Windows' own, the Mac's bsdtar (bz2 and gz)
const ready = () => PARTS.every((p) => fs.existsSync(path.join(BASE, ...p.at)));
let job = null; // the download in progress: { pct, error }

export const voiceSetup = () => (!on() ? { on: false } : ready() ? { on: true, ready: true }
  : { on: true, ready: false, busy: !!job && !job.error, pct: job?.pct || 0, error: job?.error || null });

export function startVoiceSetup() {
  if (!on() || ready() || (job && !job.error)) return voiceSetup();
  const j = (job = { pct: 0, error: null });
  install(j).then(() => { if (job === j) job = null; }, (e) => {
    console.error('[voice] download:', e.message);
    j.error = `The download stopped (${String(e.message).slice(0, 80)}). Check the internet connection, then press Retry.`;
  });
  return voiceSetup();
}

// a video that needs the voice now (its job): start or join the download and wait for it, telling progress every 10%
export async function awaitVoice(onProgress, signal) {
  startVoiceSetup();
  for (let told = -1; ; await new Promise((r) => setTimeout(r, 1500))) {
    const s = voiceSetup();
    if (!s.on || s.ready) return;
    if (s.error) throw new Error(s.error);
    if (signal?.aborted) throw new Error('stopped');
    if (Math.floor(s.pct / 10) > told) { told = Math.floor(s.pct / 10); onProgress(s.pct); }
  }
}

async function install(j) {
  const tmp = path.join(BASE, '.download');
  fs.rmSync(tmp, { recursive: true, force: true });
  fs.mkdirSync(tmp, { recursive: true });
  const todo = PARTS.filter((p) => !fs.existsSync(path.join(BASE, ...p.at)));
  // the sizes first, so one bar covers every part
  const sizes = await Promise.all(todo.map((p) => fetch(p.url, { method: 'HEAD', redirect: 'follow' }).then((r) => Number(r.headers.get('content-length')) || 0)));
  const total = sizes.reduce((a, b) => a + b, 0) || 1;
  let done = 0;
  for (const [i, p] of todo.entries()) {
    const r = await fetch(p.url, { redirect: 'follow' });
    if (!r.ok) throw new Error(`${path.basename(p.url)}: ${r.status}`);
    const file = path.join(tmp, path.basename(new URL(p.url).pathname));
    const body = Readable.fromWeb(r.body);
    body.on('data', (c) => { done += c.length; j.pct = Math.min(99, Math.round((done / total) * 100)); });
    await pipeline(body, fs.createWriteStream(file));
    const out = path.join(tmp, `part${i}`);
    fs.mkdirSync(out, { recursive: true });
    await run(TAR, ['-xf', file, '-C', out, ...(p.strip ? ['--strip-components', String(p.strip)] : [])], { timeout: 15 * 60000 });
    fs.rmSync(file, { force: true });
    const dest = path.join(BASE, ...p.at);
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    fs.renameSync(p.inner ? path.join(out, p.inner) : out, dest);
  }
  fs.rmSync(tmp, { recursive: true, force: true });
  j.pct = 100;
}
