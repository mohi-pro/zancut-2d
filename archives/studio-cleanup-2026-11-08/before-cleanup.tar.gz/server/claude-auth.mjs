// The one door to Claude when the AI runs on a person's own Claude plan, through the official Claude Code program:
//   the installed app (ZANCUT_OWN_CLAUDE=1): one login for the computer, in the app's own folder (CLAUDE_CONFIG_DIR);
//   the hosted web service (USER_CLAUDE): one login per customer, each in their own folder (data/claude-users/<user id>).
// This file only asks that program whether the sign-in worked (`claude auth status`), starts its own sign-in (`claude auth
// login`; on a server the customer opens the link it prints and pastes Claude's code back), and remembers the usage numbers
// Claude reports while the AI works. It never reads, copies or sends the login token or the program's credential files, never
// calls Claude's servers itself and has no password form of its own: the password and the plan check stay on Anthropic's page.
// Everything is kept per login folder (an "account"): the sign-in check, the sign-in in progress, the usage and the limit.
import { execFile, spawn } from 'node:child_process';
import fs from 'node:fs';
import path from 'node:path';
import { CLAUDE_BIN, DATA_DIR, OWN_CLAUDE, USER_CLAUDE } from './config.mjs';

export const MIN_VERSION = process.env.ZANCUT_MIN_CLAUDE || '2.1.280';

// Does the AI run on the person's own Claude plan (no credits, their limits)?
export const MINE = OWN_CLAUDE || USER_CLAUDE;
// The login folder of a person: their own on the web, the app's on the computer, none with a server key
export const dirOf = (uid) => (USER_CLAUDE ? (uid ? path.join(DATA_DIR, 'claude-users', String(uid).replace(/[^\w-]/g, '')) : null) : OWN_CLAUDE ? process.env.CLAUDE_CONFIG_DIR || null : null);
// What a Claude run for this person adds to its environment
export const envFor = (uid) => { const d = dirOf(uid); return d ? { CLAUDE_CONFIG_DIR: d } : {}; };

// The program must see the plan login, never a key or a relay.
const NOT_FOR_CLAUDE = ['ANTHROPIC_API_KEY', 'ANTHROPIC_AUTH_TOKEN', 'ANTHROPIC_BASE_URL', 'CLAUDE_CODE_OAUTH_TOKEN',
  'CLAUDE_CODE_USE_BEDROCK', 'CLAUDE_CODE_USE_VERTEX', 'CLAUDE_CODE_USE_FOUNDRY'];
function cliEnv(dir) {
  const env = { ...process.env };
  for (const k of NOT_FOR_CLAUDE) delete env[k];
  if (dir) env.CLAUDE_CONFIG_DIR = dir;
  if (USER_CLAUDE) { env.BROWSER = process.platform === 'win32' ? 'none' : '/usr/bin/false'; delete env.DISPLAY; } // a server opens no browser: the link is shown to the customer
  return env;
}
const bin = () => CLAUDE_BIN || 'claude';

function run(args, timeout = 15000, dir) {
  return new Promise((resolve) => {
    execFile(bin(), args, { env: cliEnv(dir), timeout, maxBuffer: 1 << 20, windowsHide: true }, (err, stdout, stderr) => {
      resolve({ code: err ? (typeof err.code === 'number' ? err.code : 1) : 0, out: String(stdout || ''), err: String(stderr || ''), missing: err?.code === 'ENOENT' });
    });
  });
}

/* ---------- 1. is the Claude Code program there, and new enough ---------- */

export function compareVersions(a, b) {
  const x = String(a).split('.').map(Number), y = String(b).split('.').map(Number);
  for (let i = 0; i < 3; i++) if ((x[i] || 0) !== (y[i] || 0)) return (x[i] || 0) - (y[i] || 0);
  return 0;
}

function installHelp() {
  return process.platform === 'win32'
    ? { install: 'irm https://claude.ai/install.ps1 | iex', where: 'Open PowerShell, paste this line, press Enter.', update: 'claude update' }
    : { install: 'curl -fsSL https://claude.ai/install.sh | bash', where: 'Open Terminal, paste this line, press Enter.', update: 'claude update' };
}

let cliCache = null;
export async function cliInfo(force = false) {
  if (!force && cliCache && Date.now() - cliCache.at < 30000) return cliCache.v;
  const r = await run(['--version'], 10000);
  let v;
  if (r.missing || r.code !== 0) v = { found: false, ok: false, min: MIN_VERSION, help: installHelp() };
  else {
    const version = (r.out.match(/\d+\.\d+\.\d+/) || [])[0] || null;
    const ok = Boolean(version) && compareVersions(version, MIN_VERSION) >= 0;
    v = { found: true, version, min: MIN_VERSION, ok, help: ok ? null : installHelp() };
  }
  cliCache = { at: Date.now(), v };
  return v;
}

/* ---------- the accounts: one per login folder ---------- */

const accounts = new Map();
function acct(dir) {
  const key = dir || '';
  let a = accounts.get(key);
  if (a) return a;
  // the usage file: the app's (or the server's) in data/, a web customer's inside their own login folder
  const file = USER_CLAUDE && dir ? path.join(dir, 'zancut-usage.json') : path.join(DATA_DIR, 'claude-usage.json');
  a = { dir, file, authCache: null, authEpoch: 0, login: { state: 'idle' }, state: { buckets: {}, blocked: null }, saveTimer: null };
  try { a.state = { ...a.state, ...JSON.parse(fs.readFileSync(file, 'utf8')) }; } catch { /* first run */ }
  accounts.set(key, a);
  return a;
}
const defaultDir = () => (USER_CLAUDE ? null : OWN_CLAUDE ? process.env.CLAUDE_CONFIG_DIR || null : null);
const A = (dir) => acct(dir === undefined ? defaultDir() : dir);
function save(a) {
  clearTimeout(a.saveTimer);
  a.saveTimer = setTimeout(() => { try { fs.mkdirSync(path.dirname(a.file), { recursive: true }); fs.writeFileSync(a.file, JSON.stringify(a.state)); } catch { /* read-only: the panel just starts empty next time */ } }, 400);
}
// the usage and any limit belong to one Claude account: a different account signs in → start fresh
function noteAccount(a, email) {
  if (a.state.account === email) return;
  if (a.state.account) a.state = { buckets: {}, blocked: null };
  a.state.account = email; save(a);
}

/* ---------- 2. is it signed in to a Claude plan ---------- */

export async function authStatus(force = false, dir) {
  const a = A(dir);
  if (USER_CLAUDE && !a.dir) return { connected: false, ok: false, reason: 'logged-out', message: 'Connect your Claude account first.' };
  if (!force && a.authCache && Date.now() - a.authCache.at < 15000) return a.authCache.v;
  const epoch = a.authEpoch;
  const r = await run(['auth', 'status'], 15000, a.dir); // JSON; exit code 1 (with JSON) when signed out
  let j = null;
  try { j = JSON.parse(r.out); } catch { /* not JSON */ }
  let v;
  if (!j) v = { connected: false, ok: false, reason: 'unknown', message: 'Zancut could not check the Claude sign-in. Press Check again.' };
  else {
    const connected = j.loggedIn === true;
    const plan = typeof j.subscriptionType === 'string' && !/^(free|none)$/i.test(j.subscriptionType) ? j.subscriptionType : null;
    const viaPlan = j.authMethod === 'claude.ai';
    const reason = !connected ? 'logged-out' : !viaPlan ? 'not-subscription' : !plan ? 'no-plan' : null;
    v = { connected, ok: !reason, reason, email: connected ? j.email || null : null, plan, message: {
      'logged-out': 'Claude is not connected yet. Press Connect Claude (in the header or your profile menu), then try again.',
      'not-subscription': 'This login uses an API key. Zancut works with your Claude subscription: connect with your Claude account.',
      'no-plan': `Claude subscription not found${j.email ? ` for ${j.email}` : ''}. A paid Claude plan (Pro or Max) is needed.`,
    }[reason] || null };
  }
  if (epoch === a.authEpoch) a.authCache = { at: Date.now(), v };
  if (v.connected && v.email) noteAccount(a, v.email);
  return v;
}

/* ---------- 3. Connect Claude: the official sign-in ---------- */
// On the computer the program opens the browser itself. On the web server it prints a link: the customer opens it, signs in
// on Anthropic's page, and pastes the code Claude shows back into Zancut (submitCode writes it to the program).

export const loginState = (dir) => { const l = A(dir).login; return { state: l.state, startedAt: l.startedAt || null, message: l.message || null, url: l.url || null, needsCode: Boolean(l.url && l.state === 'waiting') }; };

export function startLogin(email, dir) {
  const a = A(dir);
  if (a.login.state === 'waiting') return loginState(dir);
  if (!a.dir) { a.login = { state: 'failed', message: 'The login folder is not set.' }; return loginState(dir); } // never the computer's own login
  try { fs.mkdirSync(a.dir, { recursive: true }); } catch { /* the program reports it */ }
  const args = ['auth', 'login', '--claudeai'];
  const e = String(email || '').trim();
  if (e.length < 200 && /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(e)) args.push('--email', e); // pre-fills the email on Anthropic's own page
  let child;
  try { child = spawn(bin(), args, { env: cliEnv(a.dir), stdio: ['pipe', 'pipe', 'pipe'], windowsHide: true }); }
  catch { a.login = { state: 'failed', message: 'Zancut could not start the Claude sign-in.' }; return loginState(dir); }
  const mine = { state: 'waiting', startedAt: Date.now(), child, url: null };
  a.login = mine;
  let out = '';
  const read = (b) => { out = (out + String(b)).slice(-8000); const m = out.match(/https:\/\/\S*oauth\/authorize\S+/); if (m && !mine.url) mine.url = m[0]; };
  child.stdout.on('data', read); child.stderr.on('data', read);
  const timer = setTimeout(() => { try { child.kill(); } catch { /* gone */ } }, 15 * 60000);
  const end = (state, message) => { clearTimeout(timer); if (a.login === mine) a.login = { state, message }; a.authCache = null; a.authEpoch++; };
  child.on('error', () => end('failed', 'Zancut could not start the Claude sign-in. Is Claude installed?'));
  child.on('exit', (code) => end(code === 0 ? 'done' : 'failed', code === 0 ? null : /login failed/i.test(out) ? 'Claude did not accept that code. Press Connect Claude and copy the new code exactly.' : 'The sign-in was not finished. Press Connect Claude to try again.'));
  return loginState(dir);
}

// The code Claude showed after the sign-in (web): handed to the waiting program, which finishes the login itself.
export function submitCode(code, dir) {
  const a = A(dir), c = String(code || '').trim();
  if (a.login.state !== 'waiting' || !a.login.child) return { ...loginState(dir), error: 'Press Connect Claude first.' };
  if (!c || c.length > 400 || /\s/.test(c)) return { ...loginState(dir), error: 'Paste the whole code Claude showed you.' };
  try { a.login.child.stdin.write(`${c}\n`); } catch { return { ...loginState(dir), error: 'The sign-in has ended. Press Connect Claude again.' }; }
  return loginState(dir);
}

export function cancelLogin(dir) {
  const a = A(dir);
  if (a.login.state === 'waiting') { const c = a.login.child; a.login = { state: 'idle' }; try { c.kill(); } catch { /* gone */ } }
  return loginState(dir);
}

// Log out: signs this login folder out (never the computer's own Claude login) and forgets that account's numbers.
export async function logout(dir) {
  const a = A(dir);
  if (!a.dir) return { ok: false };
  cancelLogin(dir);
  const r = await run(['auth', 'logout'], 20000, a.dir);
  a.authCache = null; a.authEpoch++;
  a.state = { buckets: {}, blocked: null };
  save(a);
  return { ok: r.code === 0 };
}

/* ---------- 4. usage: what Claude reports while the AI works ---------- */

const RAW = path.join(DATA_DIR, 'claude-rate-limit-events.jsonl'); // raw events (no secrets), to check the field names in real use
// resetsAt: Unix seconds or milliseconds (the docs do not say which): both work.
export const toMs = (t) => (typeof t === 'number' && t > 0 ? (t < 1e12 ? t * 1000 : t) : null);
// utilization: a fraction (0–1) in Claude's events; a plain percent is accepted too. Often missing while status is "allowed".
export const toPercent = (u) => (typeof u === 'number' && u >= 0 ? Math.round(Math.min(u <= 1 ? u * 100 : u, 100)) : null);

const WINDOW = { five_hour: 5 * 3600e3 };
const windowOf = (key) => WINDOW[key] || (/^seven_day/.test(key) ? 7 * 86400e3 : null);
export function labelOf(key) {
  if (key === 'five_hour') return '5-hour';
  if (key === 'seven_day') return 'Weekly';
  if (key === 'overage') return 'Extra usage';
  const m = key.match(/^seven_day_(.+)$/); // a model's own weekly bucket, e.g. seven_day_opus
  if (m) return `Weekly · ${m[1].replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase())}`;
  return key === 'unknown' ? 'Claude limit' : key.replace(/_/g, ' ').replace(/^\w/, (c) => c.toUpperCase());
}
const rank = (k) => (k === 'five_hour' ? 0 : k === 'seven_day' ? 1 : /^seven_day_/.test(k) ? 2 : 3);

// One window's numbers. A new window (the reset time moved) drops the old percent.
function putBucket(a, key, { status, resetsAt, utilization }, now) {
  const prev = a.state.buckets[key] || {};
  const b = { ...prev, status: status || prev.status || 'allowed', seenAt: now };
  const reset = toMs(resetsAt);
  if (reset) b.resetsAt = reset;
  const pct = toPercent(utilization);
  if (pct != null) b.percent = pct;
  else if (reset && prev.resetsAt && Math.abs(reset - prev.resetsAt) > 60000) delete b.percent;
  a.state.buckets[key] = b;
  return b;
}

// What Claude really sends (seen on 21 Oct 2026, v2.1.296): { status, resetsAt (seconds), rateLimitType: 'five_hour', overageStatus…,
// unifiedWindows: { five_hour: { utilization: 0.4, resetsAt }, seven_day: { utilization: 0.05, resetsAt } } }. The docs list only
// status / resetsAt / utilization, so both shapes are read; a window's own utilization is a fraction.
export function noteRateLimit(info, dir) {
  if (!info || typeof info !== 'object') return;
  const a = A(dir), now = Date.now();
  const key = typeof info.rateLimitType === 'string' && info.rateLimitType ? info.rateLimitType : 'unknown';
  for (const [k, w] of Object.entries(info.unifiedWindows || {})) {
    if (!w || typeof w !== 'object' || k === key) continue;
    putBucket(a, k, { status: toPercent(w.utilization) >= 100 ? 'rejected' : 'allowed', resetsAt: w.resetsAt, utilization: w.utilization }, now);
  }
  const own = info.unifiedWindows?.[key] || {};
  const b = putBucket(a, key, { status: info.status, resetsAt: info.resetsAt ?? own.resetsAt, utilization: info.utilization ?? own.utilization }, now);
  if (info.status === 'rejected') a.state.blocked = { key, until: b.resetsAt || now + 30 * 60000, at: now, credits: info.errorCode === 'credits_required' };
  else if (a.state.blocked?.key === key) a.state.blocked = null;
  save(a);
  try {
    fs.mkdirSync(DATA_DIR, { recursive: true });
    if (fs.existsSync(RAW) && fs.statSync(RAW).size > 200000) fs.truncateSync(RAW, 0);
    fs.appendFileSync(RAW, JSON.stringify({ t: now, info }) + '\n');
  } catch { /* the log is optional */ }
}

export function usageView(dir) {
  const a = A(dir), now = Date.now();
  const buckets = Object.entries(a.state.buckets).sort((x, y) => rank(x[0]) - rank(y[0]) || x[0].localeCompare(y[0])).map(([key, b]) => {
    const over = Boolean(b.resetsAt && b.resetsAt <= now); // the window ended: Claude's counter started again
    return { key, label: labelOf(key), status: b.status, percent: over ? 0 : b.percent ?? null, resetsAt: over ? null : b.resetsAt || null,
      windowMs: windowOf(key), seenAt: b.seenAt, fresh: over };
  });
  return { buckets, blocked: blockedNow(dir) };
}

export function blockedNow(dir) {
  const b = A(dir).state.blocked;
  return b && b.until > Date.now() ? { key: b.key, label: labelOf(b.key), until: b.until, credits: Boolean(b.credits) } : null;
}

function inText(ms) {
  const m = Math.max(1, Math.round(ms / 60000));
  return m >= 90 ? `${Math.floor(m / 60)} h ${m % 60 ? `${m % 60} min` : ''}`.trim() : `${m} min`;
}
export function limitText(b) {
  if (!b) return 'Claude is not accepting requests right now. Try again in a few minutes.';
  const at = new Date(b.until).toLocaleString([], { weekday: new Date(b.until).toDateString() === new Date().toDateString() ? undefined : 'short', hour: 'numeric', minute: '2-digit' });
  return `Your Claude ${b.key === 'unknown' ? 'usage' : b.label.toLowerCase()} limit is reached. New AI steps are paused until ${at} (in ${inText(b.until - Date.now())}). The manual editor still works.`;
}

/* ---------- 5. guards used by the AI runners ---------- */

// An error the customer should read as it is (agent.mjs shows messages of errors marked `customer`).
export class ClaudeError extends Error { constructor(message, code) { super(message); this.customer = true; this.code = code; } }

const AUTH_ERRORS = {
  authentication_failed: 'Claude is not signed in any more. Press Connect Claude, then Retry.',
  oauth_org_not_allowed: 'This Claude account is not allowed to be used here. Connect a different Claude account, then Retry.',
  account_on_hold: 'This Claude account is on hold. Check your Claude account, then Retry.',
  billing_error: 'Claude reports a problem with the subscription. Check your Claude account, then Retry.',
};

// A server key (ZANCUT_USER_CLAUDE=0): only the limit numbers are kept, so the admin sees the 5 hour and weekly use
export function track(m, dir) { if (m?.type === 'rate_limit_event') noteRateLimit(m.rate_limit_info, dir); }

// Call with every message from query(): remembers the usage numbers, and turns Claude's refusals into plain sentences.
export function watch(m, dir) {
  if (m.type === 'rate_limit_event') return noteRateLimit(m.rate_limit_info, dir);
  const err = m.type === 'assistant' ? m.error : m.type === 'result' && m.is_error ? 'result' : null;
  if (!err) return;
  const a = A(dir);
  if (AUTH_ERRORS[err]) { a.authCache = null; throw new ClaudeError(AUTH_ERRORS[err], 'claude_login'); }
  const recent = a.state.blocked && Date.now() - a.state.blocked.at < 120000;
  if (err === 'rate_limit' && !recent) { a.state.blocked = { key: 'unknown', until: Date.now() + 10 * 60000, at: Date.now() }; save(a); }
  if (err === 'rate_limit' || (err === 'result' && recent)) throw new ClaudeError(limitText(blockedNow(dir)), 'claude_limit');
}
// The reader for one person's Claude run: watch on their own plan, track with a server key
export const seeFor = (uid) => { const d = dirOf(uid); return (m) => (MINE ? watch(m, d ?? undefined) : track(m)); };

// Before a new AI step: null = go ahead, else { status, body } for the browser.
// The sign-in is checked first: another account signed in forgets the old one's limit (noteAccount) before it is read.
export async function cannotStart(dir) {
  const st = await authStatus(false, dir);
  if (!st.ok) return { status: 401, body: { code: 'claude_login', error: st.message || 'Connect Claude first.' } };
  const b = blockedNow(dir);
  if (b) return { status: 429, body: { code: 'claude_limit', until: b.until, error: limitText(b) } };
  return null;
}
// The same for one person (their own login on the web, the app's on the computer)
export const cannotStartFor = (uid) => (MINE ? cannotStart(dirOf(uid) ?? undefined) : Promise.resolve(null));
export const blockedFor = (uid) => blockedNow(dirOf(uid) ?? undefined);
