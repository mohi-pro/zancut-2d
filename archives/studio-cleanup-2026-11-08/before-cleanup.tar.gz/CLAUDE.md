# Zancut 2D — rules for the engineer
**Never use any pretrained AI model (Claude, Qwen, Ollama, APIs…) to make animation.** Only exception (owner's decision): local WhisperX may listen to the voice (words + times), nothing else. Intelligence = our own brain (`server/brain.mjs`, trained from scratch on `brain/seed.jsonl` + the owner's corrections) + deterministic rules. Keep adding data, places, actions, checks. `server/no-ai.mjs` blocks AI calls. Zancut Studio is never touched.
Run `npm start` (http://127.0.0.1:4500). Tests (no AI): `node scripts/cartoon-test.mjs`, `film-kit-test.mjs`, `parts-test.mjs`, `qa-test.mjs`, `codefilm-test.mjs [film.json] [outdir]`; brain: `node scripts/brain-seed.mjs` then `node scripts/brain-train.mjs` (writes docs/MODEL_EVAL.md).
Flow: script → `brainplan.mjs` → scene file → `qa.mjs` → `codefilm.mjs` → engine → `videoqa.mjs`. Add a place in `engine/cartoon/places-kit.js`.
Honesty: report real measured numbers; keep the real-sentence test set (brain/real-test.jsonl) out of training and never copy its sentences into the seed. Resume: read docs/STATUS.md first.

Always-on worker = the app's Autopilot (`server/autopilot.mjs`, inbox/ → outbox/), not Claude. The Claude Code agent `.claude/agents/zancut-builder.md` only runs while a session is open.
